﻿namespace RD.RDF.StoragePortal.Contracts.Messages
{
    public enum MigrationTypeEnum
    {
        /// <summary>
        /// migrate old GDrive bucket to new storage api container
        /// </summary>
        GDriveMigration,
        /// <summary>
        /// migrate storage api container to new storage api container 
        /// (Like between Storage accounts , Containers or between clouds)
        /// </summary>
        StorageAPIMigration
    }

}
