﻿using System;

namespace RD.RDF.StoragePortal.Contracts.Messages
{
    public abstract class BaseEvent
    {

        public DateTimeOffset EventCreateDate { get; set; }

        
    }
}
