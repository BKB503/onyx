﻿namespace RD.RDF.StoragePortal.Contracts.Messages
{
    public class MigrationRunObjectEvent : BaseEvent
    { 
        

        public int MigrationRunId { get; set; }

        public int MigrationId { get; set; }

        public long MigrationRunObjectId { get; set; }

        public MigrationTypeEnum MigrationType { get; set; }

        public MigrationObject MigrationObject { get; set; }

    }
}
