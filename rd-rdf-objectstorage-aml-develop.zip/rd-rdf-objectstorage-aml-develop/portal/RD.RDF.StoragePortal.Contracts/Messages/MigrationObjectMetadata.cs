﻿using RD.RDF.StoragePortal.Contracts.Model;
using System.Collections.Generic;

namespace RD.RDF.StoragePortal.Contracts.Messages
{
    public class MigrationObjectMetadata : Dictionary<string, string>
    {

        private List<MetadataKeyValue> metadata;

        public MigrationObjectMetadata()
        {

        }

        public MigrationObjectMetadata(IDictionary<string, string> inputDict)
        {
            if (inputDict != null)
            {
                foreach (var item in inputDict)
                {
                    this[item.Key] = item.Value;
                }
            }
        }

        public MigrationObjectMetadata(MetadataCollections inputDict)
        {
            if (inputDict != null)
            {
                foreach (var item in inputDict.Items)
                {
                    this[item.Key] = item.Value;
                }
            }
        }

        public MigrationObjectMetadata(List<MetadataKeyValue> metadata)
        {
            foreach (var item in metadata)
            {
                this[item.Key] = item.Value;
            }
        }
    }
}
