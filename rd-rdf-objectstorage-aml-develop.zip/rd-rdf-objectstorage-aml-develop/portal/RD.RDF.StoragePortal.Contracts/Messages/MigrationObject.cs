﻿using System;
using System.Collections.Generic;

namespace RD.RDF.StoragePortal.Contracts.Messages
{
    public class MigrationObject
    {
        /// <summary>
        /// file name without a path
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? CreationTime { get; set; }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? ModifiedTime { get; set; }

        /// <summary>
        /// file size
        /// </summary>
        public long? FileSize { get; set; }

        /// <summary>
        /// Full path in storage
        /// </summary>
        public string FilePath { get; set; }

        /// <summary>
        /// File GUID
        /// </summary>
        public string FileGuid { get; set; }

        /// <summary>
        /// File Version Id
        /// </summary>
        public string FileVersionId { get; set; }

        /// <summary>
        /// Folder Name
        /// </summary>
        public string FolderName { get; set; }

        /// <summary>
        /// File GUID
        /// </summary>
        public List<MigrationObjectVersion> FileVersions { get; set; } = new List<MigrationObjectVersion>();

        /// <summary>
        /// file e-tag
        /// </summary>
        public string FileETag { get; set; }

        /// <summary>
        /// file content hash
        /// </summary>
        public string FileContentHash { get; set; }


        /// <summary>
        /// mime content type
        /// </summary>
        public string FileContentType { get; set; }

        /// <summary>
        /// Storage blob type
        /// </summary>
        public string FileBlobType { get; set; }

        public MigrationObjectMetadata Metadata { get; set; } = new MigrationObjectMetadata();

    }
}
