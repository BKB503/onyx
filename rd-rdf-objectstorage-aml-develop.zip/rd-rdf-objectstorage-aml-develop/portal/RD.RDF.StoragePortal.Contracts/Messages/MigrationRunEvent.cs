﻿using RD.RDF.StoragePortal.Contracts.Model;
using System;

namespace RD.RDF.StoragePortal.Contracts.Messages
{
    public class MigrationRunEvent : BaseEvent
    {   
        /// <summary>
        /// id of migration
        /// </summary>
        public int MigrationId { get; set; }
         
        /// <summary>
        /// id of migration run
        /// </summary>
        public int MigrationRunId { get; set; }

        /// <summary>
        /// type of migration
        /// </summary>
        public MigrationTypeEnum MigrationType { get; set; }

        public DateTimeOffset MigrationRunStartDate { get; set; }
        public DateTimeOffset? MigrationRunFinishDate { get; set; }
        public MigrationRunStatusEnum MigrationRunStatus { get; set; } //start, stop              
      
}
}
