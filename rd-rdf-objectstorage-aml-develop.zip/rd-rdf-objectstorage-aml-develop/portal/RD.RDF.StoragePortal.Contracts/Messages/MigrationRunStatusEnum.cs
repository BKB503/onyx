﻿namespace RD.RDF.StoragePortal.Contracts.Messages
{
    public enum MigrationRunStatusEnum
    {
        Start,
        Stop
    }

}
