﻿using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
   public interface IStorageContainerClientFactory
    {
        IStorageWorkerClient GetStorageClient(ContainerResource container);

    }
}
