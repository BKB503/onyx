﻿using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IContainersRepository
    {
        Task<ContainersModel> GetStorageContainerByIdAsync(int id, CancellationToken token);

        Task<int> CreateStorageContainerAsync(ContainersModel newStorageProperties, CancellationToken token);

        Task<bool> DeleteStorageContainerAsync(ContainersModel storageProperties, CancellationToken token);

        Task<IEnumerable<ContainersModel>> GetAllStorageContainersAsync(CancellationToken token);
        Task UpdateContainerAsync(ContainersModel container, CancellationToken token);
        Task<AudiencesModel> GetAudienceByIdAsync(int id, CancellationToken token);
        Task UpdateAudienceByIdAsync(AudiencesModel input, CancellationToken token);
        Task<int> CreateAudienceRecordAsync(AudiencesModel input, CancellationToken token);
    }
}
