﻿using RD.RDF.StoragePortal.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IMigrationService
    {
        Task<int> AddMigrationAsync(MigrationsModel migrations, CancellationToken token);
        Task<List<DataSourceMigrationVM>> GetAllMigrationsAsync(CancellationToken token);
        Task<int> AddDataSourceMigrationAsync(DataSourceMigrationVM migrationDatasource, CancellationToken token);
        Task<DataSourceMigrationVM> UpdateDataSourceMigAsync(DataSourceMigrationVM migrationDatasource, CancellationToken token);
        Task<DataSourceMigrationVM> GetDataSourceMigbyIdAsync(int id, CancellationToken token);
        Task<int> DeleteDataSourcebyIdAsync(int id, CancellationToken token);

    }
}
