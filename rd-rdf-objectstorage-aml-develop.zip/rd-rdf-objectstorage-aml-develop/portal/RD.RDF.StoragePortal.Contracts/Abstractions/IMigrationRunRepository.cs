﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RD.RDF.StoragePortal.Contracts.Model;


namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IMigrationRunRepository
    {
               

        Task<int> AddMigRunDataSourceAsync(int migRunId, CancellationToken token);
        Task<RunMigrationVM> GetDataSourceRunbyIdAsync(int runId, CancellationToken token);

        Task<List<RunMigrationVM>> GetAllMigrationRunAsync(int migdsid, CancellationToken token);
        Task<List<MigrationRunObjectsModel>> GetDataSourceRunObjectsAsync(int migrunId, CancellationToken token);
    }
}
