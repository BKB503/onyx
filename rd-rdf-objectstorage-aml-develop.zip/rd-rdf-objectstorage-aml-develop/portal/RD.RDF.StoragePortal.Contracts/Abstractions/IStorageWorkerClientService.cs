﻿using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IStorageWorkerClientService
    {
        public Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, CancellationToken token);
        Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token);
        Task<Stream> GetFileStreamAsync(ContainerResource container, FileResource fileInfo, CancellationToken token = default);
        Task<UploadFileResult> UploadFileToFolderAsync(ContainerResource container, string fileName, string folder, Stream fileData, CancellationToken token = default);

    }
}
