﻿using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IMigrationRunObjectsRepository
    {
        Task<int> InsertRunObjectsRecord(MigrationRunObjectsModel objectInfo, CancellationToken token);
    }
}
