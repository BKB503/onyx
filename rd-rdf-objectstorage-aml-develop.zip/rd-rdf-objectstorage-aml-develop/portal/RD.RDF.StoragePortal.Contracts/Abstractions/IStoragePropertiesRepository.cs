﻿using RD.RDF.StoragePortal.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IStoragePropertiesRepository
    {
        Task<StoragePropertiesModel> GetStoragePropertiesByIdAsync(int id, CancellationToken token);

        Task<int> CreateStoragePropertiesAsync(StoragePropertiesModel newStorageProperties, CancellationToken token);

        Task<bool> DeleteStoragePropertiesAsync(StoragePropertiesModel storageProperties, CancellationToken token);

        Task<IEnumerable<StoragePropertiesModel>> GetAllAsync(CancellationToken token);

    }
}
