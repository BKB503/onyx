﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RD.RDF.StoragePortal.Contracts.Model;


namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IMigrationsRepository 
    {
        
        Task<MigrationsModel> GetByIdAsync(int migrationId, CancellationToken token);

        Task<List<DataSourceMigrationVM>>GetAllAsync(CancellationToken token);
        
        Task<int>AddAsync(MigrationsModel entity, CancellationToken token);
        Task<int> AddDataSourceAsync(MigrationDataSourcesModel dbModel, int MigrationId, CancellationToken token);
        Task<MigrationsModel> UpdateAsync(MigrationsModel migmodel, CancellationToken token);
        Task<MigrationDataSourcesModel> UpdateDataSourceAsync(MigrationDataSourcesModel migDsmodel, CancellationToken token);
        Task<DataSourceMigrationVM> GetDataSourceMigrationbyIdAsync(int id, CancellationToken token);
        Task<int> DeletebyIdAsync(int id,CancellationToken token);

    }
}
