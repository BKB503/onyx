﻿using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IIndexingPortalService
    {
        Task<EditIndexingModel> GetIndexingByIdAsync(int id, CancellationToken token);
        Task<int> CreateIndexingAsync(IndexingModel newStorageProperties, CancellationToken token);
        Task<IEnumerable<IndexingModel>> GetAllAsync(CancellationToken token);
        Task UpdateIndexingByIdAsync(EditIndexingModel input, CancellationToken token);
    }
}
