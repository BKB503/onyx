﻿
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IStorageWorkerClient
    {
        StorageContainerType StorageClientType { get; }

        Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token);
        Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token);
        Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token);
        Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token);
        Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folder, Stream fileData, CancellationToken token);

    }
}
