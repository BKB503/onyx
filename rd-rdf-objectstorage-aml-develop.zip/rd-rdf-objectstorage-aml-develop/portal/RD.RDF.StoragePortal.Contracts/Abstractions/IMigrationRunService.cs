﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RD.RDF.StoragePortal.Contracts.Model;


namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IMigrationRunService
    {

        Task<RunMigrationVM> AddMigrationRunDataSourceAsync(int migId, CancellationToken token);

        Task<List<RunMigrationVM>> GetAllMigrationRunsAsync(int migdsid, CancellationToken token);

       Task<List<MigrationRunObjectsModel>> GetMigRunObjectsAsync(int migrunId, CancellationToken token);

        Task<RunMigrationVM> GetMigrationRunByIdAsync(int migrunId, CancellationToken token);

    }
}
