﻿using RD.RDF.StoragePortal.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IIndexingPortalRepository
    {
        Task<EditIndexingModel> GetIndexingByIdAsync(int indexingId, CancellationToken token);
        Task<int> CreateIndexingAsync(IndexingModel input, CancellationToken token);
        Task<IEnumerable<IndexingModel>> GetAllAsync(CancellationToken token);
        Task UpdateIndexingByIdAsync(EditIndexingModel input, CancellationToken cancellationToken);
    }
}
