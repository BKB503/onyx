﻿using RD.RDF.StoragePortal.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Abstractions
{
    public interface IStoragePropertiesService
    {
        Task<StoragePropertiesModel> GetDefaultStoragePropertiesAsync(CancellationToken token);


    }
}
