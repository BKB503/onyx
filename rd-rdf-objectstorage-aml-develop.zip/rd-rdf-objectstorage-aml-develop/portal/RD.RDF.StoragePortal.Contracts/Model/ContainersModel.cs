﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class ContainersModel
    {
        public int ContainerId { get; set; }
        [Required(ErrorMessage = "IsRequired")]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "IsRequired")]
        [Display(Name = "Container Type")]
        public StoragePortalContainerType ContainerType { get; set; }
        [Required(ErrorMessage = "IsRequired")]
        [Display(Name = "Container Account Name")]
        public string ContainerAccountName { get; set; }
        [Required(ErrorMessage = "IsRequired")]
        [Display(Name = "Container Account Url")]
        public string ContainerAccountUrl { get; set; }
        [Required(ErrorMessage = "IsRequired")]
        [Display(Name = "Container Name")]
        public string ContainerName { get; set; }
        [Display(Name = "Container Connection String")]
        public string ContainerConnectionString { get; set; }
        [Display(Name = "Container Key")]
        public string ContainerKey { get; set; }
        [Display(Name = "Container User Id")]
        public string ContainerUserId { get; set; }
        [Display(Name = "Alliance Tag Name")]
        public string AllianceTagName { get; set; }
        [Display(Name = "Validate Audience")]
        public bool ValidateAudience { get; set; }
        [Display(Name = "Valid Audience List")]
        public List<AudiencesModel> ValidAudiences { get; set; }
        [Display(Name = "Proxy Url")]
        public string ProxyUrl { get; set; }
        public int IndexId { get; set; }

        public IndexingModel Indexing { get; set; }

    }


    public enum StoragePortalContainerType
    {
        [Description("objectstorage")]
        objectstorage = 0,
        [Description("azureblob")]
        azureblob = 1,
        [Description("azureadls")]
        azureadls = 2,
        [Description("googleblob")]
        googleblob = 3
    }
}
