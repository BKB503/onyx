﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class IndexingModel : BaseModel
    {
        public int IndexId { get; set; }
        [Required]
        public string RDFKafkaTopic { get; set; }
         
        public string Type { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string RDFKafkaConnectionString { get; set; }
 
        [DataType(DataType.Password)]
        public string RDFKafkaKey { get; set; }
        [Required]
        public string KafkaServers { get; set; }
        public string SaslUsername { get; set; } = "$ConnectionString";
        
        [DataType(DataType.Password)]
        [Required]
        public string IndexOdbcConnectionString { get; set; }
    }
}
