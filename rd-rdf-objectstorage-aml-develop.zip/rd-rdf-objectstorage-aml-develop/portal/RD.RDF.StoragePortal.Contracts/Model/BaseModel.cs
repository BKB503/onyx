﻿using System;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class BaseModel
    {
        public DateTime CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}