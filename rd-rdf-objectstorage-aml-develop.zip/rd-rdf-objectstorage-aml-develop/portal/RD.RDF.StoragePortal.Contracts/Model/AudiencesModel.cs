﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class AudiencesModel : BaseModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please enter Audience")]
        [Display(Name = "Valid Audience")]
        public string ValidAudience { get; set; }
        public int ContainerId { get; set; }
    }
}
