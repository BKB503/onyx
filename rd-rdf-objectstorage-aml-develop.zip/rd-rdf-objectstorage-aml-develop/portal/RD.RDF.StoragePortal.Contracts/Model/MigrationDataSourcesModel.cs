﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace RD.RDF.StoragePortal.Contracts.Model
{
     public class MigrationDataSourcesModel : MigrationsBaseModel
    {
        public int Id { get; set; }
        public int MigrationId { get; set; }
        public MigrationsModel Migration { get; set; }
        public DataSourceType DataSourceType { get; set; }

        public StoragePortalContainerType ContainerType { get; set; }

        public string ContainerAccountName { get; set; }
        public string ContainerAccountUrl { get; set; }

        public string ContainerName { get; set; }

        public string ContainerConnectionString { get; set; }

        public string ContainerKey { get; set; }

        public string ContainerUserId { get; set; }

        public string ProxyUrl { get; set; }

    }

    public enum DataSourceType
    {
        [Description("Source")]
        Source = 0,
        [Description("Destination")]
        Destination = 1
    }
}
