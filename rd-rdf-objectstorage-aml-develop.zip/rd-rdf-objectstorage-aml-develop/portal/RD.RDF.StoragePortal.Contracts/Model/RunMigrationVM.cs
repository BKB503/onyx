﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class RunMigrationVM
    {
        public MigrationsModel MigrationModel { get; set; }
        public MigrationRunsModel MigrationRunModel { get; set; }
        public MigrationRunDataSourcesModel SourcesRunModel { get; set; }
        public MigrationRunDataSourcesModel DestinationRunModel { get; set; }
        public MigrationRunObjectsModel MigrationRunObjectsModel { get; set; }

    }
}
