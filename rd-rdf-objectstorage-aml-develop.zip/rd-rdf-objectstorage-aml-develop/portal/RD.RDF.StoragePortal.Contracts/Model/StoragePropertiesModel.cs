﻿namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class StoragePropertiesModel
    {
        /// <summary>
        /// id of storage properties settings
        /// </summary>
        public int Id { get; set; }


        /// <summary>
        /// default container
        /// </summary>
        public string DefaultContainer { get; set; }

        /// <summary>
        /// default indexing settings 
        /// </summary>
        public string DefaultIndex { get; set; }
    }
}
