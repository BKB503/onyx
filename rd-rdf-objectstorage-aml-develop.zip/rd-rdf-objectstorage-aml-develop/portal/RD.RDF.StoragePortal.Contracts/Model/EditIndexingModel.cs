﻿using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class EditIndexingModel : BaseModel
    {
        public int IndexId { get; set; }
        [Required]
        public string RDFKafkaTopic { get; set; }

        public string Type { get; set; }
 
        [DataType(DataType.Password)]
        public string RDFKafkaConnectionString { get; set; }
        public bool RDFKafkaConnectionStringChanged { get; set; } = false;

        [DataType(DataType.Password)]
        public string RDFKafkaKey { get; set; }
        public bool RDFKafkaKeyChanged { get; set; } = false;

        [Required]
        public string KafkaServers { get; set; }
        public string SaslUsername { get; set; } = "$ConnectionString";

        [DataType(DataType.Password)]   
        public string IndexOdbcConnectionString { get; set; }

        public bool IndexOdbcConnectionStringChanged { get; set; } = false;

    }
}

