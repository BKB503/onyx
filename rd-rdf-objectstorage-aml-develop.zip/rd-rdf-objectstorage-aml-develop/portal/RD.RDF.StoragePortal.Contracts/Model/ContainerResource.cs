﻿using RD.RDF.StoragePortal.Contracts.Configuration;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public record ContainerResource(string ContainerName)
    {
        public StorageContainerConfiguration Configuration { get; set; }

        public KafkaConfiguration IndexingConfiguration { get; set; }
    }
}
