﻿namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class MigrationRunDataSourcesModel : BaseModel
    {
        public int Id { get; set; }
        public int MigrationRunId { get; set; }
        public string Name { get; set; }
        public DataSourceType DataSourceType { get; set; }
        public StoragePortalContainerType ContainerType { get; set; }
        public string ContainerAccountName { get; set; }
        public string ContainerAccountUrl { get; set; }
        public string ContainerName { get; set; }
        public string ContainerConnectionString { get; set; }
        public string ContainerKey { get; set; }
        public string ContainerUserId { get; set; }
        public string ProxyUrl { get; set; }
    }
}

