﻿using Microsoft.AspNetCore.Mvc;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    [ModelBinder(BinderType = typeof(MetadataValueModelBinder))]
    public class MetadataItem
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public bool IsIndexed { get; set; }
    }
}

