﻿namespace RD.RDF.StoragePortal.Contracts.Model
{
    public enum FileMigrationStatus
    {
        Start,
        InProgress,
        Finished,
        Stopped,
        Error
    }
}
