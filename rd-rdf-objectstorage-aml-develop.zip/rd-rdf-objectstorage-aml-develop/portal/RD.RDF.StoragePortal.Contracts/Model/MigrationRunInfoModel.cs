﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Model
{
   public class MigrationRunInfoModel
    {
        public int MigrationRunId { get; set; }
        public int MigrationRunDataSourceId { get; set; }
        public int MigrationRunDataDestinationId { get; set; }
        public int MigrationId { get; set; }
    }
}
