﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace RD.RDF.StoragePortal.Contracts.Model
{
     public class DataSourceMigrationVM
    {
        public MigrationDataSourcesModel SourcesModel { get; set; }
        public MigrationDataSourcesModel DestinationModel { get; set; }
        public MigrationsModel MigrationsModel { get; set; }

    }
}
