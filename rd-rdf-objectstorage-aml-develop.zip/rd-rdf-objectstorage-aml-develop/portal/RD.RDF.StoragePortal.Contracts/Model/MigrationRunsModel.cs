﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class MigrationRunsModel : BaseModel
    {

        public int Id { get; set; }
                
        public int MigrationId { get; set; }

        public DateTime RunStartDate { get; set; }
        public DateTime? RunFinishDate { get; set; }
        public RunStatusEnum RunStatus { get; set; }

        public RunStageEnum RunStage { get; set; }
        public long RunObjectsCount { get; set; }
        public long RunObjectsMigrated { get; set; }
        public MigrationType MigrationType { get; set; }
    }
    public enum RunStatusEnum
    {
        [Description("Start")]
        Start = 0,
        [Description("InProgress")]
        InProgress = 1,
        [Description("Finished")]
        Finished = 2,
        [Description("Stopped")]
        Stopped = 3,
        [Description("Stopped")]
        Error = 4
    }
    public enum RunStageEnum
    {
        [Description("Reading")]
        Reading = 0,
        [Description("Migrating")]
        Migrating = 1,
        [Description("Finished")]
        Finished = 2,
        [Description("Stopped")]
        Stopped = 3,
        [Description("Error")]
        Error = 4
    }
}
