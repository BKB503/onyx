﻿using System.Text.Json.Serialization;

namespace RD.RDF.StoragePortal.Contracts.Model.Filters
{
    public class PaginationFilter
    {
        public const int MaxLimit = 1000;

        /// <summary>
        /// a token to start with 
        /// </summary>
        [JsonPropertyName("continuationToken")]        
        public string ContinuationToken { get; set; }

        /// <summary>
        /// limit of objects read from underlying Storage solution = up to 1000 
        /// </summary>
        [JsonPropertyName("limit")]
        public int Limit { get; set; }

        public PaginationFilter()
        {            
            this.Limit = MaxLimit;
        }

        public PaginationFilter(string continuationToken, int limit)
        {
            ContinuationToken = continuationToken;
            Limit = (limit < 0 || limit > MaxLimit) ? MaxLimit : limit;
        }
    }
}
