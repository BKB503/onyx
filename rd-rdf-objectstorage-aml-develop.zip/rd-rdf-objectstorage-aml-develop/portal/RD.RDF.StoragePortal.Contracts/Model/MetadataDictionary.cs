﻿using System.Collections.Generic;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class MetadataDictionary : Dictionary<string, string>
    {
        private List<MetadataKeyValue> metadata;

        public MetadataDictionary()
        {

        }

        public MetadataDictionary(IDictionary<string, string> inputDict)
        {
            if (inputDict != null)
            {
                foreach (var item in inputDict)
                {
                    this[item.Key] = item.Value;
                }
            }
        }

        public MetadataDictionary(MetadataCollections inputDict)
        {
            if (inputDict != null)
            { 
                foreach (var item in inputDict.Items)
                {
                    this[item.Key] = item.Value;
                }
            }
        }

        public MetadataDictionary(List<MetadataKeyValue> metadata)
        {
            foreach (var item in metadata)
            {
                this[item.Key] = item.Value;
            }
        }
    }
}
