﻿using RD.RDF.StoragePortal.Contracts.Messages;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace RD.RDF.StoragePortal.Contracts.Model
{
    public class MigrationsModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Description { get; set; }

        public DateTime LastMigrationRunDate { get; set; }

        public DateTime LastMigrationFinishDate { get; set; }

        public int MigrationRunCount { get; set; }

        public int MigrationStatus { get; set; }

        public MigrationType MigrationType { get; set; }

        public bool MigrationRunActive { get; set; }

        public bool IsDeleted { get; set; }

        public string Actions { get; set; }

        public string Summary { get; set; }
        public List<MigrationDataSourcesModel> DataSources { get; set; }
    }
    public enum MigrationType
    {
        [Description("GDriveMigration")]
        GDriveMigration = 0,

        [Description("StorageAPIMigration")]
        StorageAPIMigration = 1
    }

}
