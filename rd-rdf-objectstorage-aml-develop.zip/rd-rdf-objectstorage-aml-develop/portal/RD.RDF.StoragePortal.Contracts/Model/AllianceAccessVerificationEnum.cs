﻿namespace RD.RDF.StoragePortal.Contracts.Model
{

    public enum AllianceAccessVerificationEnum
    {
        /// <summary>
        /// restricted alliance and user is not in that alliance
        /// </summary>
        NotAllowed,
        /// <summary>
        /// Allowed - GSK Proprietary
        /// </summary>
        AllowedGSKProprietary,
        /// <summary>
        /// User is in that Alliance
        /// </summary>
        AllowedUserAlliance,
        /// <summary>
        /// Not Restricted Alliance
        /// </summary>
        AllowedNotRestrictedAlliance,
        /// <summary>
        /// Allowed No Alliance Information provided
        /// </summary>
        AllowedNoAlliance,
        /// <summary>
        /// Allowed No Alliance Information found in database
        /// </summary>
        AllowedNoAllianceFoundInDatabase
    }

}
