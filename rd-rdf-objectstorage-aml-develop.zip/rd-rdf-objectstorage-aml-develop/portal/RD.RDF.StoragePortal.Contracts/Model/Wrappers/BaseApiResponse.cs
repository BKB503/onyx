﻿namespace RD.RDF.StoragePortal.Contracts.Model.Wrappers
{
    public abstract class BaseApiResponse
    {
        public BaseApiResponse()
        {
            Succeeded = true;
            Message = null;
            Errors = null;
        }

        public bool Succeeded { get; set; }

        public string[] Errors { get; set; }
        public string Message { get; set; }
    }
}
