﻿namespace RD.RDF.StoragePortal.Contracts.Model.Wrappers
{
    public class ApiResponse<T> : BaseApiResponse
    {
        public ApiResponse()
        {

        }

        public ApiResponse(T data = default) : base()
        {
            Data = data;
        }

        public ApiResponse(string message) : base()
        {
            this.Message = message;
            this.Succeeded = false;
        }


        public T Data { get; set; }
    }
}
