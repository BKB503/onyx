﻿namespace RD.RDF.StoragePortal.Contracts.Configuration
{
    public class PingIdConfiguration
    {
        public const string PingId = "PingId";

        /// <summary>
        ///   AuthorizationEndpoint
        /// </summary>
        public string AuthorizationEndpoint { get; set; }

        /// <summary>
        /// TokenEndpoint
        /// </summary>
        public string TokenEndpoint { get; set; }

        /// <summary>
        /// UserInformationEndpoint
        /// </summary>
        public string UserInformationEndpoint { get; set; }

        /// <summary>
        /// client id 
        /// </summary>
        public string ClientId { get; set; }
        /// <summary>
        /// client secret 
        /// </summary>
        public string ClientSecret { get; set; }
        
    }


}
