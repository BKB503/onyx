﻿namespace RD.RDF.StoragePortal.Contracts.Configuration
{
    public class MigrationKafkaConfiguration
    {
        public const string KafkaSettings = "KafkaSettings";

        public KafkaConfiguration MigrationRun { get; set; }

        public KafkaConfiguration MigrationRunObjects { get; set; }
    }
}
