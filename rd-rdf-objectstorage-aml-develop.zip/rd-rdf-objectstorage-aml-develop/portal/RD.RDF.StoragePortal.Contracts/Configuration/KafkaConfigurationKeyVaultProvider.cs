﻿using Microsoft.Extensions.Configuration;

namespace RD.RDF.StoragePortal.Contracts.Configuration
{
    public class KafkaConfigurationKeyVaultProvider
    {
        private readonly IConfiguration configuration;

        public KafkaConfigurationKeyVaultProvider(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public KafkaConfiguration AddSecretsFromKeyValut(KafkaConfiguration kafkaConfiguration)
        {
            kafkaConfiguration.KafkaServers = configuration["RDFKafkaServers"];            
            kafkaConfiguration.SaslPassword = configuration["RDFKafkaConnectionString"];            
            kafkaConfiguration.SaslUsername = configuration["RDFKafkaUserName"];
            return kafkaConfiguration;
        }
    }
}
