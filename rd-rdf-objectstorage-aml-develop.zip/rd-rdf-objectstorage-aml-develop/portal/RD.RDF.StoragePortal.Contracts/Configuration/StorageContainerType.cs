﻿namespace RD.RDF.StoragePortal.Contracts.Configuration
{
    public enum StorageContainerType
    {
        objectstorage = 0,
        azureblob = 1,
        azureadls = 2,
        googleblob = 3
    }
}
