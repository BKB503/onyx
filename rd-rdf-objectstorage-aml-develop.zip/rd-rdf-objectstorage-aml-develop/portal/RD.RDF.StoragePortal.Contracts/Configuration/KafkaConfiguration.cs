﻿namespace RD.RDF.StoragePortal.Contracts.Configuration
{
    public class KafkaConfiguration
    {
        /// <summary>
        /// Topic for Reading
        /// </summary>
        public string KafkaTopic { get; set; }
         
        /// <summary>
        /// Connection string to Azure Event Hub
        /// </summary>        
        public string SaslPassword { get; set; }

        /// <summary>
        /// user name
        /// </summary>
        public string SaslUsername { get; set; }

        /// <summary>
        /// Bootstrap Servers
        /// </summary>
        public string KafkaServers { get; set; }

        /// <summary>
        /// group Id
        /// </summary>
        public string KafkaGroupId { get; set; }
    }


}
