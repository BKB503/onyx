﻿using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Core.Services
{
      public class MigrationService : IMigrationService
    {
        private readonly IMigrationsRepository repository;

        public MigrationService(IMigrationsRepository repository)
        {
            this.repository = repository;
        }

        //GET Migration Details   
        public async Task<List<DataSourceMigrationVM>> GetAllMigrationsAsync(CancellationToken token)
        {
            
              var resultlist =  await repository.GetAllAsync(token);

                return resultlist;
            

        }
        //Add Migration  
        public async Task<int> AddMigrationAsync(MigrationsModel migration, CancellationToken token)
        {
           int id = await repository.AddAsync(migration, token);
            return id;
        }

        public async Task<int> AddDataSourceMigrationAsync(DataSourceMigrationVM migrationDatasource, CancellationToken token)
        {
           var newMigrationId = await AddMigrationAsync(migrationDatasource.MigrationsModel, token);
            if (newMigrationId > 0)
            {
                await repository.AddDataSourceAsync(migrationDatasource.SourcesModel, newMigrationId, token);
                await repository.AddDataSourceAsync(migrationDatasource.DestinationModel, newMigrationId, token);

            }
            return newMigrationId;
        }

        public async Task<DataSourceMigrationVM> GetDataSourceMigbyIdAsync(int id, CancellationToken token)
        {
            var migbyid = await repository.GetDataSourceMigrationbyIdAsync(id, token);
            return migbyid;
        }
        public async Task<DataSourceMigrationVM> UpdateDataSourceMigAsync(DataSourceMigrationVM migrationDatasource, CancellationToken token)
        {
           var resultcount = await repository.UpdateAsync(migrationDatasource.MigrationsModel,token);
            if (resultcount is not null)
            {
             await repository.UpdateDataSourceAsync(migrationDatasource.SourcesModel,token);
             await repository.UpdateDataSourceAsync(migrationDatasource.DestinationModel, token);

            }
            return migrationDatasource;
        }

        //Delete
        public async Task<int> DeleteDataSourcebyIdAsync(int id,CancellationToken token)
        {
            var result = await repository.DeletebyIdAsync(id, token);
           
            return id;

        }
    }
      
       
}
