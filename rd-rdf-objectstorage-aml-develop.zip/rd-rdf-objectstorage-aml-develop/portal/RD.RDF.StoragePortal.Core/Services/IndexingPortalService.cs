﻿using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Core.Services
{
    public class IndexingPortalService : IIndexingPortalService
    {
        private readonly IIndexingPortalRepository _indexing;
        public IndexingPortalService(IIndexingPortalRepository indexing)
        {
            _indexing = indexing;
        }

        public async Task<int> CreateIndexingAsync(IndexingModel input, CancellationToken token)
        {
            var responce = await _indexing.CreateIndexingAsync(input, token);
            return responce;
        }

        public async Task<IEnumerable<IndexingModel>> GetAllAsync(CancellationToken token)
        {
            return await _indexing.GetAllAsync(token);
        }

        public async Task<EditIndexingModel> GetIndexingByIdAsync(int indexingId, CancellationToken token)
        {
            return await _indexing.GetIndexingByIdAsync(indexingId, token);
        }

        public async Task UpdateIndexingByIdAsync(EditIndexingModel input, CancellationToken token)
        {
            await _indexing.UpdateIndexingByIdAsync(input, token);
        }
    }
}
