﻿using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Core.Services
{
    public class StorageWorkerClientService : IStorageWorkerClientService
    {
        private readonly IStorageContainerClientFactory clientFactory;


        public StorageWorkerClientService(IStorageContainerClientFactory clientFactory)
        {
            this.clientFactory = clientFactory;
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, CancellationToken token)
        {
            var filter = new PaginationFilter();
            var storageClient = clientFactory.GetStorageClient(container);

            if (storageClient == null)
            {
                return null;
            }

            return await storageClient.GetAllDataFromStorageAsync(container, filter, token);
        }

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            string versionId = "";
            var storageClient = this.clientFactory.GetStorageClient(container);
            var fileResource = new FileResource(fileName, folderName);
            FileResource fileInfo = new FileResource(fileResource.FileName)
            {
                FilePath = fileResource.IndexFilePath,
            };

            if (storageClient == null)
            {
                // log error
                return null;
            }

            return await storageClient.GetOneFileInformationWithVersionAsync(container, fileName,folderName,versionId, token);
        }

        public async Task<Stream> GetFileStreamAsync(ContainerResource containerInfo, FileResource fileInfo, CancellationToken token = default)
        {
            if (fileInfo is null)
            {
                //log error
                return null;
            }
            var storageClient = this.clientFactory.GetStorageClient(containerInfo);
            if (storageClient == null)
            {
                // log error
                return null;
            }

            var stream = await storageClient.DownloadObjectAsync(containerInfo, fileInfo, token);
            return stream;
        }

        public async Task<UploadFileResult> UploadFileToFolderAsync(ContainerResource container, string fileName, string folder, Stream fileData, CancellationToken token = default)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                return new UploadFileResult(UploadFileResultStatus.Error, "Storage client not available");
            }
            fileData.Position = 0;// to avoid file content position error.
            var uploaded = await storageClient.UploadObjectAsync(container, fileName, folder, fileData, token);

            return new UploadFileResult(uploaded,
                                        uploaded != null ? UploadFileResultStatus.Success : UploadFileResultStatus.Error,
                                        uploaded != null ? "Upload Successfull" : "Upload Failed");
        }
    }
}

