﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Messages;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Core.Services
{
    public class MigrationRunService : IMigrationRunService
    {
        private readonly IMigrationRunRepository migRunrepository;
        private readonly IMigrationsRepository migrationsRepository;
        private readonly ILogger<MigrationRunService> logger;
        private readonly MigrationKafkaConfiguration settings;
        private readonly JsonSerializerOptions jsonOptions;

        public MigrationRunService(IMigrationRunRepository migRunrepository, IMigrationsRepository migrationsRepository, IOptions<MigrationKafkaConfiguration> config, ILogger<MigrationRunService> logger,
            KafkaConfigurationKeyVaultProvider secretsProvider)
        {
            this.migRunrepository = migRunrepository;
            this.migrationsRepository = migrationsRepository;
            this.logger = logger;
            this.settings = config.Value;
            this.settings.MigrationRun = secretsProvider.AddSecretsFromKeyValut(this.settings.MigrationRun);
            this.jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = false,
                WriteIndented = true
            };
            this.jsonOptions.Converters.Add(new JsonStringEnumConverter());

        }
        
        public async Task<RunMigrationVM> AddMigrationRunDataSourceAsync(int migId, CancellationToken token)
        {
            int migrundatasourceId = await migRunrepository.AddMigRunDataSourceAsync(migId, token);
            RunMigrationVM migrunvm = await migRunrepository.GetDataSourceRunbyIdAsync(migrundatasourceId, token);
            // here we also push the message into Kafka
            migrunvm.MigrationModel = await migrationsRepository.GetByIdAsync(migId, token);
            await PublishMsgToKafka(migrunvm, token);

            return migrunvm;
        }

        public async Task<List<RunMigrationVM>> GetAllMigrationRunsAsync(int migdsid, CancellationToken token)
        {

            var resultlist = await migRunrepository.GetAllMigrationRunAsync(migdsid, token);

            return resultlist;


        }
        public async Task<List<MigrationRunObjectsModel>> GetMigRunObjectsAsync(int migrunId, CancellationToken token)
        {

            var runobjectlist = await migRunrepository.GetDataSourceRunObjectsAsync(migrunId, token);

            return runobjectlist;


        }

        public async Task<bool> PublishMsgToKafka(RunMigrationVM migrunvm, CancellationToken token)
        {
            logger.LogInformation($"Publishing to MigrationStart to Kafka topic {settings.MigrationRun.KafkaTopic} Started");
            try
            {
                var producerClient = GetKafkaProducer();
                var message = new MigrationRunEvent
                {
                    EventCreateDate = DateTime.UtcNow,
                    MigrationId = migrunvm.MigrationRunModel.MigrationId,
                    MigrationRunId = migrunvm.MigrationRunModel.Id,
                    MigrationRunStartDate = migrunvm.MigrationRunModel.RunStartDate,
                    MigrationType = MigrationTypeEnum.GDriveMigration, //TODO: Fix it in Migration model  Enum.Parse<MigrationTypeEnum>(migrunvm.MigrationModel.MigrationType, true),
                    MigrationRunStatus = MigrationRunStatusEnum.Start, // Enum.Parse<MigrationRunStatusEnum>(migrunvm.MigrationRunModel.RunStatus, true),
                    MigrationRunFinishDate = migrunvm.MigrationRunModel.RunFinishDate
                };

                string json = JsonSerializer.Serialize(message, jsonOptions);
                var msg = new Message<Null, string> { Value = json };
                var deliveryReport = await producerClient.ProduceAsync(settings.MigrationRun.KafkaTopic, msg, token);
                logger.LogInformation($"Publishing to MigrationStart to Kafka topic {settings.MigrationRun.KafkaTopic} to Kafka Completed");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Publishing to MigrationStart to Kafka topic {settings.MigrationRun.KafkaTopic} Error: {ex.Message}");
                return false;
            }
            return true;
        }

        private IProducer<Null, string> GetKafkaProducer()
        {
            var config = new ProducerConfig
            {
                SaslPassword = settings.MigrationRun.SaslPassword,
                BootstrapServers = settings.MigrationRun.KafkaServers,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = settings.MigrationRun.SaslUsername,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                Debug = "broker"
            };
            return new ProducerBuilder<Null, string>(config).SetKeySerializer(Serializers.Null).SetValueSerializer(Serializers.Utf8).Build();
        }

        public async Task<RunMigrationVM> GetMigrationRunByIdAsync(int migrunId, CancellationToken token)
        {

            var result = await migRunrepository.GetDataSourceRunbyIdAsync(migrunId, token);

            return result;


        }
    }
}
