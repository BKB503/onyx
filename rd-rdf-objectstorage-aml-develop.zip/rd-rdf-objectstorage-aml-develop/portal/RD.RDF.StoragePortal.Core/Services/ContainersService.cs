﻿using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Core.Services
{
    public class ContainersService : IContainerService
    {
        private readonly IContainersRepository _containers;
        public ContainersService(IContainersRepository _containers)
        {
            this._containers = _containers;
        }

        public async Task<int> CreateStorageContainerAsync(ContainersModel input, CancellationToken token)
        {
            var responce = await _containers.CreateStorageContainerAsync(input, token);


            return responce; 
           
        }

        public Task<bool> DeleteStorageContainerAsync(ContainersModel storageProperties, CancellationToken token)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<ContainersModel>> GetAllStorageContainersAsync(CancellationToken token)
        {
            return await _containers.GetAllStorageContainersAsync(token);
        }

      

        public async  Task<ContainersModel> GetStorageContainerByIdAsync(int id, CancellationToken token)
        {
            return await _containers.GetStorageContainerByIdAsync(id, token);
        }

        public async Task UpdateContainerAsync(ContainersModel container, CancellationToken token)
        {
            await _containers.UpdateContainerAsync(container, token);
           
        }


        public async Task<AudiencesModel> GetAudienceByIdAsync(int id, CancellationToken token)
        {
            return await _containers.GetAudienceByIdAsync(id, token);
        }

        public async Task UpdateAudienceByIdAsync(AudiencesModel input, CancellationToken token)
        {
            await _containers.UpdateAudienceByIdAsync(input, token);
        }

        public async Task<int> CreateAudienceRecordAsync(AudiencesModel input, CancellationToken token)
        {
            var responce = await _containers.CreateAudienceRecordAsync(input, token);


            return responce;
        }
    }
}
