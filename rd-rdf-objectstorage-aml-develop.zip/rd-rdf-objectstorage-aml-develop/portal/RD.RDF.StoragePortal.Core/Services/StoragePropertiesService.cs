﻿using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Core.Services
{
    public class StoragePropertiesService : IStoragePropertiesService
    {
        private readonly IStoragePropertiesRepository repository;
        private readonly IContainersRepository _containers;
        public StoragePropertiesService(IStoragePropertiesRepository repository)
        {
            this.repository = repository;
        }

        public async Task<StoragePropertiesModel> GetDefaultStoragePropertiesAsync(CancellationToken token)
        {
            var allResults = await repository.GetAllAsync(token);
            return allResults?.FirstOrDefault();
        }
    }
}
