using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Core.Services;
using RD.RDF.StoragePortal.DataAccess.ClientImpl;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.Messaging;
using RD.RDF.StoragePortal.DataAccess.Repository;
using RD.RDF.StoragePortal.DataAccess.Storage;
using RDF.Storage.MigrationAgentCore.Extensions;
using RDF.Storage.MigrationAgentCore.Workers;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace RDF.Storage.MigrationAgentGDrive
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var cts = new CancellationTokenSource();
            var hostBuilder = HostStartupExtension.CreateGenericHostBuilder(args, ConfigureServices);

            var host = hostBuilder.Build();
            await host.RunAsync(cts.Token).ConfigureAwait(false);
        }
        private static void ConfigureServices(HostBuilderContext hostCtx, IServiceCollection services)
        {
            string connectionString = hostCtx.Configuration.GetConnectionString("PortalDB");
#if DEBUG
            if (Debugger.IsAttached)
            {
                connectionString = hostCtx.Configuration.GetConnectionString("LocalPortalDB");
            }
#endif

            services.Configure<MigrationKafkaConfiguration>(hostCtx.Configuration.GetSection(MigrationKafkaConfiguration.KafkaSettings));
            services.AddSingleton<KafkaConfigurationKeyVaultProvider>();//it can be singleton
            services.AddTransient<KafkaWorkerLoop>();

            services.AddHostedService<GDriveMigrationWorker>();

            services.AddSingleton<IContainerConfigurationClient, ContainerConfigurationClient>();
            services.AddScoped<IMigrationRunRepository, MigrationRunRepository>();
            services.AddDbContext<StoragePortalDbContext>(options => options.UseSqlServer(connectionString, sqlOptions => { sqlOptions.CommandTimeout(60); }));
            services.AddTransient<IStorageContainerClientFactory, StorageContainerClientFactory>();
            services.AddTransient<IStorageWorkerClient, StorageAzureBlobWorkerClient>();
            services.AddTransient<IStorageWorkerClient, StorageAdlsServiceWorkerClient>();
            services.AddTransient<IStorageWorkerClient, StorageGcpClientWorkerClient>();
            services.AddTransient<IStorageWorkerClient, StorageObjectStorageWorkerClient>();
            services.AddSingleton<IStorageWorkerClientService, StorageWorkerClientService>();
            services.AddSingleton<MyHttpClientFactory>();

        }
    }
}
