using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.DataAccess.Messaging;
using RDF.Storage.MigrationAgentCore.Extensions;
using RDF.Storage.MigrationAgentCore.Workers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RDF.Storage.MigrationAgentCloudStorage
{ 
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var cts = new CancellationTokenSource();
            var hostBuilder = HostStartupExtension.CreateGenericHostBuilder(args, ConfigureServices);

            var host = hostBuilder.Build();
            await host.RunAsync(cts.Token).ConfigureAwait(false);
        }
        private static void ConfigureServices(HostBuilderContext hostCtx, IServiceCollection services)
        {
            services.Configure<MigrationKafkaConfiguration>(hostCtx.Configuration.GetSection(MigrationKafkaConfiguration.KafkaSettings));
            services.AddTransient<KafkaWorkerLoop>();
            services.AddHostedService<CloudMigrationWorker>();
        }
    }
}
