using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using RD.RDF.StoragePortal.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StoragePortal.DataAccessTests
{
    public class IndexingRepositoryTest
    {
        private StoragePortalDbContext dbContext;
        private IndexingRepository repository;
        public IndexingRepositoryTest()
        {
            var appSettingsStub = new Dictionary<string, string> {
                    {"PortalDb-Key", "AjmyVTDJmo7tkiQ7X/+wIwOKsTj5iL6Y1ZNp+sLkgUs="},
                    {"PortalDb-IV", "q4bWlLEgqzyIZ5bDOvMIoh=="}
                };

            var configuration = new ConfigurationBuilder()
                    .AddInMemoryCollection(appSettingsStub)
                    .Build();

            var dbName = $"StoragePortalDb_{DateTime.Now.ToFileTimeUtc()}";
            var dbContextOptions = new DbContextOptionsBuilder<StoragePortalDbContext>()
                .UseInMemoryDatabase(dbName)
                .Options;

            dbContext = new StoragePortalDbContext(dbContextOptions, configuration);
            repository = new IndexingRepository(dbContext);
        }

        IndexesDbModel inputRecord = new IndexesDbModel
        {
            Id = 1,
            RDFKafkaTopic = "RDFKafkaTopic",
            Type = "Type",
            RDFKafkaConnectionString = "RDFKafkaConnectionString",
            RDFKafkaKey = "RDFKafkaKey",
            KafkaServers = "KafkaServers",
            SaslUsername = "SaslUsername",
            IndexOdbcConnectionString = "IndexOdbcConnectionString",
            
        };

        IndexingModel insertRecord = new IndexingModel
        {
            IndexId = 1,
            RDFKafkaTopic = "RDFKafkaTopic_Update",
            Type = "Type_Updated",
            RDFKafkaConnectionString = "RDFKafkaConnectionString_Update",
            RDFKafkaKey = "RDFKafkaKey",
            KafkaServers = "KafkaServers",
            SaslUsername = "SaslUsername",
            IndexOdbcConnectionString = "IndexOdbcConnectionString",
        };

        IndexingModel updateRecord = new IndexingModel
        {
            IndexId = 1,
            RDFKafkaTopic = "RDFKafkaTopic_Update",
            Type = "Type_Updated",
            RDFKafkaConnectionString = "RDFKafkaConnectionString_Update",
            RDFKafkaKey = "RDFKafkaKey",
            KafkaServers = "KafkaServers",
            SaslUsername = "SaslUsername",
            IndexOdbcConnectionString = "IndexOdbcConnectionString",
        };

        [Fact]
        public async Task TestGetAll_NoResults()
        {
            var result = await repository.GetAllAsync(CancellationToken.None);
            Assert.Empty(result);
        }


        [Fact]
        public async Task TestGetAll_OneRow_Results()
        {
            await DataBaseContext();

            var result = await repository.GetAllAsync(CancellationToken.None);
            Assert.Equal(1, result.Count());

            var item = result.First();
            Assert.Equal("Type", item.Type);
            Assert.Equal(1, item.IndexId);
        }

        [Fact]
        public async Task Test_GetRecord_ById_Async_Result()
        {
            await DataBaseContext();

            var result = await repository.GetIndexingByIdAsync(1, CancellationToken.None);
            Assert.Equal("Type", result.Type);
            Assert.Equal(1, result.IndexId);
        }

        [Fact]
        public async Task Test_Update_Indexing_By_Id_Async_Result()
        {
            await DataBaseContext();

            var local = dbContext.Set<IndexesDbModel>().Local.FirstOrDefault(entry => entry.Id.Equals(1));

            if (local != null)
            {
                dbContext.Entry(local).State = EntityState.Detached;
            }

            var updateRecord1 = new EditIndexingModel
            {
                IndexId = 1,
                RDFKafkaTopic = "RDFKafkaTopic_Update",
                Type = "Type_Updated",
                RDFKafkaConnectionString = "RDFKafkaConnectionString_Update",
                RDFKafkaKey = "RDFKafkaKey",
                KafkaServers = "KafkaServers",
                SaslUsername = "SaslUsername",
                IndexOdbcConnectionString = "IndexOdbcConnectionString",
            };

            await repository.UpdateIndexingByIdAsync(updateRecord1, CancellationToken.None);

            var updatedRecord = await repository.GetIndexingByIdAsync(1, CancellationToken.None);
            Assert.Equal("Type_Updated", updatedRecord.Type);
        }

        [Fact]
        public async Task Test_Create_Indexing_Async_Result()
        {
          var result =  await  repository.CreateIndexingAsync(insertRecord, CancellationToken.None);

            Assert.Equal(1, result);
        }


        private async Task DataBaseContext()
        {
            await dbContext.Indexes.AddAsync(inputRecord);
            dbContext.SaveChanges();
        }
    }
}
