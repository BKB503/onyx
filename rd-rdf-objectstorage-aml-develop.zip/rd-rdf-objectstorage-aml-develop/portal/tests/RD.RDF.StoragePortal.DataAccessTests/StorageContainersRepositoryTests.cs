﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using RD.RDF.StoragePortal.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StoragePortal.DataAccessTests
{
    public class StorageContainersRepositoryTests
    {
        private StoragePortalDbContext dbContext;
        private StorageContainersRepository repository;
        public StorageContainersRepositoryTests()
        {
            var appSettingsStub = new Dictionary<string, string> {
                    {"PortalDb-Key", "AjmyVTDJmo7tkiQ7X/+wIwOKsTj5iL6Y1ZNp+sLkgUs="},
                    {"PortalDb-IV", "q4bWlLEgqzyIZ5bDOvMIoh=="}
                };

            var configuration = new ConfigurationBuilder()
                    .AddInMemoryCollection(appSettingsStub)
                    .Build();



            var dbName = $"StoragePortalDb_{DateTime.Now.ToFileTimeUtc()}";
            var dbContextOptions = new DbContextOptionsBuilder<StoragePortalDbContext>()
                .UseInMemoryDatabase(dbName)
                .Options;

            dbContext = new StoragePortalDbContext(dbContextOptions, configuration);
            repository = new StorageContainersRepository(dbContext);
        }

        ContainersDbModel containersRecord = new ContainersDbModel
        {
            Id = 1,
            Name = "testName",
            AllianceTagName = "testalliancetagname",
            ContainerAccountName = "testcontaccountname",
            ContainerAccountUrl = "testaccounturl",
            ContainerConnectionString = "testconnectionstring",
            ContainerKey = "testkey",
            ContainerType = "testcontainertype",
            ContainerName = "testconatinername",
            ContainerUserId = "testcontaineruserId",
            ProxyUrl = "testproxyurl",
            ValidateAudience = true

        };
        AudiencesDbModel audienceRecord = new AudiencesDbModel
        {
            Id = 1,
            ContainerId = 1,
            ValidAudience = "testvalidaudience",
            CreateDate = DateTime.Now
        };

        ContainersModel containersInsertRecord = new ContainersModel
        {
            ContainerId = 1,
            Name = "Nameinsert",
            AllianceTagName = "alliancetagnameinsert",
            ContainerAccountName = "contaccountnameinsert",
            ContainerAccountUrl = "accounturlinsert",
            ContainerConnectionString = "connectionstringinsert",
            ContainerKey = "testkeyinsert",
            ContainerName = "conatinernameinsert",
            ContainerUserId = "containeruserIdinsert",
            ProxyUrl = "proxyurlinsert",
            ValidateAudience = true
        };
        AudiencesModel audiencesInsertRecord = new AudiencesModel
        {
            Id = 1,
            ContainerId = 1,
            ValidAudience = "testvalidaudience",
        };

        [Fact]
        public async Task TestGetAll_NoResults()
        {
            var result = await repository.GetAllStorageContainersAsync(CancellationToken.None);
            Assert.Empty(result);
        }


        [Fact]

        public async Task TestInsertAudiencesResult()
        {
            var result = await repository.CreateAudienceRecordAsync(audiencesInsertRecord, CancellationToken.None);

            Assert.Equal(1, result);
        }

        [Fact]
        public async Task TestInsertContainersResult()
        {
            var result = await repository.CreateStorageContainerAsync(containersInsertRecord, CancellationToken.None);

            Assert.Equal(1, result);
        }


        private async Task DataBaseContext()
        {
            await dbContext.Containers.AddAsync(containersRecord);
            dbContext.SaveChanges();
            await dbContext.Audiences.AddAsync(audienceRecord);
            dbContext.SaveChanges();
        }
    }
}