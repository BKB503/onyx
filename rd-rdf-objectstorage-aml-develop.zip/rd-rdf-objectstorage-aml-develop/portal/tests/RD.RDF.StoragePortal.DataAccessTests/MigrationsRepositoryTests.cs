﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using RD.RDF.StoragePortal.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StoragePortal.DataAccessTests
{
    public class MigrationsRepositoryTests
    {
        private StoragePortalDbContext dbContext;
        private MigrationsRepository repository;
        public MigrationsRepositoryTests()
        {
            var appSettingsStub = new Dictionary<string, string> {
                    {"PortalDb-Key", "AjmyVTDJmo7tkiQ7X/+wIwOKsTj5iL6Y1ZNp+sLkgUs="},
                    {"PortalDb-IV", "q4bWlLEgqzyIZ5bDOvMIoh=="}
                };

            var configuration = new ConfigurationBuilder()
                    .AddInMemoryCollection(appSettingsStub)
                    .Build();

            var dbName = $"StoragePortalDb_{DateTime.Now.ToFileTimeUtc()}";
            var dbContextOptions = new DbContextOptionsBuilder<StoragePortalDbContext>()
                .UseInMemoryDatabase(dbName)
                .Options;
            
            dbContext = new StoragePortalDbContext(dbContextOptions, configuration);
            repository = new MigrationsRepository(dbContext);
        }

        MigrationsDbModel migRecord = new MigrationsDbModel
        {
            Id = 1,
            Name = "testname",
            Description = "testdesc",
            MigrationType = MigrationType.GDriveMigration,
            LastMigrationRunDate = DateTime.UtcNow,
            LastMigrationFinishDate = DateTime.Today,
            MigrationStatus = 0,
            MigrationRunActive = false,
            MigrationRunCount = 1

        };
        MigrationDataSourcesDbModel migdsrecord = new MigrationDataSourcesDbModel
        {
            Id = 1,
            MigrationId = 1,
            ContainerAccountName = "testaccountname",
            ContainerConnectionString = "containerconnectionstring",
            ContainerKey = "key",
            ContainerAccountUrl = "testurl",
            ContainerName = "testcontainer",
            ContainerType = StoragePortalContainerType.objectstorage,
            ProxyUrl = "testproxyurl",
            ContainerUserId = "testuserId"
        };

        MigrationsModel migInsertRecord = new MigrationsModel
        {
            Id = 1,
            Name = "testnameinsert",
            Description = "testdescinsert",
            MigrationType = MigrationType.GDriveMigration,
            LastMigrationRunDate = DateTime.UtcNow,
            LastMigrationFinishDate = DateTime.Today,
            MigrationStatus = 0,
            MigrationRunActive = false,
            MigrationRunCount = 1
        };
        MigrationDataSourcesModel migdsInsertRecord = new MigrationDataSourcesModel
        {
            Id = 1,
            MigrationId = 1,
            ContainerAccountName = "testaccountnameinsert",
            ContainerConnectionString = "containerconnectionstringinsert",
            ContainerKey = "key",
            ContainerAccountUrl = "testurlinsert",
            ContainerName = "testcontainerinsert",
            ContainerType = StoragePortalContainerType.objectstorage,
            ProxyUrl = "testproxyurl",
            ContainerUserId = "testuserId"
        };

        [Fact]
        public async Task TestGetAll_NoResults()
        {
            var result = await repository.GetAllAsync(CancellationToken.None);
            Assert.Empty(result);
        }

        [Fact]
        public async Task TestGetAll_OneRow_Results()
        {
            await DataBaseContext();

            var result = await repository.GetAllAsync(CancellationToken.None);
            Assert.Single(result);
            var item = result.First();
            Assert.Equal("testname", item.MigrationsModel.Name);
            Assert.Equal(1, item.MigrationsModel.Id);
            Assert.Equal(1, item.SourcesModel.MigrationId);
            Assert.Equal(StoragePortalContainerType.objectstorage, item.SourcesModel.ContainerType);


        }
        [Fact]
        public async Task TestInsertMigrationResult()
        {
            var result = await repository.AddAsync(migInsertRecord, CancellationToken.None);

            Assert.Equal(1, result);
        }

        [Fact]

        public async Task TestInsertMigrationDataSourceResult()
        {
            var result = await repository.AddDataSourceAsync(migdsInsertRecord, migInsertRecord.Id, CancellationToken.None);

            Assert.Equal(1, result);
        }


        [Fact]
        public async Task TestUpdateMigrationResult()
        {
            await DataBaseContext();

            var testRecord = dbContext.Set<MigrationsDbModel>().Local.FirstOrDefault(x => x.Id.Equals(1));

            if (testRecord != null)
            {
                dbContext.Entry(testRecord).State = EntityState.Detached;
            }

            MigrationsModel updateRecord = new MigrationsModel
            {
                Id = 1,
                Name = "testnameupdate",
                Description = "testdescupdate",
                MigrationType = MigrationType.GDriveMigration,
                LastMigrationRunDate = DateTime.UtcNow,
                LastMigrationFinishDate = DateTime.Today,
                MigrationStatus = 0,
                MigrationRunActive = false,
                MigrationRunCount = 1
            };

            await repository.UpdateAsync(updateRecord, CancellationToken.None);

            var updatedRecord = await repository.GetDataSourceMigrationbyIdAsync(1, CancellationToken.None);
            Assert.Equal("testdescupdate", updatedRecord.MigrationsModel.Description);
        }

        [Fact]
        public async Task TestUpdateMigdatasourceResult()
        {
            await DataBaseContext();

            var testdsRecord = dbContext.Set<MigrationDataSourcesDbModel>().Local.FirstOrDefault(x => x.Id.Equals(1));

            if (testdsRecord != null)
            {
                dbContext.Entry(testdsRecord).State = EntityState.Detached;
            }

            MigrationDataSourcesModel updatedsRecord = new MigrationDataSourcesModel
            {
                Id = 1,
                MigrationId = 1,
                ContainerAccountName = "testaccountnameupdate",
                ContainerConnectionString = "containerconnectionstringupdate",
                ContainerKey = "key",
                ContainerAccountUrl = "testurlupdate",
                ContainerName = "testcontainerupdate",
                ContainerType = StoragePortalContainerType.objectstorage,
                ProxyUrl = "testproxyurl",
                ContainerUserId = "testuserId"
            };

            await repository.UpdateDataSourceAsync(updatedsRecord, CancellationToken.None);

            var updateddsRecord = await repository.GetDataSourceMigrationbyIdAsync(1, CancellationToken.None);
            Assert.Equal("testaccountnameupdate", updateddsRecord.SourcesModel.ContainerAccountName);
        }

        private async Task DataBaseContext()
        {
            await dbContext.Migrations.AddAsync(migRecord);
            dbContext.SaveChanges();
            await dbContext.MigrationDataSources.AddAsync(migdsrecord);
            dbContext.SaveChanges();
        }
    }
}