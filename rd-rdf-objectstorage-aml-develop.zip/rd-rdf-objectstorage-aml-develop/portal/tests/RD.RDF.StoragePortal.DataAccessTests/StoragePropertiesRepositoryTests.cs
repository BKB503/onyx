using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StoragePortal.DataAccessTests
{
    public class StoragePropertiesRepositoryTests
    {
        private StoragePortalDbContext dbContext;
        private StoragePropertiesRepository repository;
        public StoragePropertiesRepositoryTests()
        {
            var appSettingsStub = new Dictionary<string, string> {
                    {"PortalDb-Key", "AjmyVTDJmo7tkiQ7X/+wIwOKsTj5iL6Y1ZNp+sLkgUs="},
                    {"PortalDb-IV", "q4bWlLEgqzyIZ5bDOvMIoh=="}
                };

            var configuration = new ConfigurationBuilder()
                    .AddInMemoryCollection(appSettingsStub)
                    .Build();

            var dbName = $"StoragePortalDb_{DateTime.Now.ToFileTimeUtc()}";
            var dbContextOptions = new DbContextOptionsBuilder<StoragePortalDbContext>()
                .UseInMemoryDatabase(dbName)
                .Options;

            dbContext = new StoragePortalDbContext(dbContextOptions,configuration);
            repository = new StoragePropertiesRepository(dbContext);
        }

        [Fact]
        public async Task TestGetAll_NoResults()
        { 
            var result = await repository.GetAllAsync(CancellationToken.None);
            Assert.Empty(result);
        }


        [Fact]
        public async Task TestGetAll_OneRow_Results()
        {
            dbContext.StorageProperties.Add(new DataAccess.DbModel.StoragePropertiesDbModel() { DefaultIndex = "indx", DefaultContainer = "dc" });
            dbContext.SaveChanges();

           var result = await repository.GetAllAsync(CancellationToken.None);
            Assert.Equal(1, result.Count());
            var item = result.First();
            Assert.Equal("indx", item.DefaultIndex);
            Assert.Equal("dc", item.DefaultContainer);
            Assert.Equal(1, item.Id);
        }





    }
}
