
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Web.Controllers;
using RD.RDF.StoragePortal.Web.Models;
using System;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StoragePortal.WebTests
{
    public class HomeControllerTests
    { 

        [Fact]
        public async Task IsActionAliasAvailableAsync()
        {
            string userName = "xx12345";
            string userEmail = "xx12345@gsk.com";
            //user mock
            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[] {
                                        new Claim(ClaimTypes.Name, userName),
                                        new Claim(ClaimTypes.Email,userEmail)
                                        // other required and custom claims
                                   }, "TestAuthentication"));
              
            var loggerMock = new Mock<ILogger<HomeController>>();
            var sp = new Mock<IStoragePropertiesService>(); 

            var controller = new HomeController(loggerMock.Object, sp.Object);
            controller.ControllerContext = new ControllerContext();
            controller.ControllerContext.HttpContext = new DefaultHttpContext { User = user };
            var cts = new CancellationTokenSource();
            // call
            var result = await controller.Index(cts.Token);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<IndexViewModel>(viewResult.ViewData.Model);
            Assert.Equal(true, model.IsAuthenticated);
            Assert.Equal(userName, model.UserName);
            Assert.Equal(userEmail, model.UserEmail);
        }
    }
}
