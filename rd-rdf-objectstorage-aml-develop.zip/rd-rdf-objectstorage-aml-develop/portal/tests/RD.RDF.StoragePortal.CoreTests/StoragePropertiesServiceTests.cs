using Moq;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Core.Services;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StoragePortal.CoreTests
{
    public class StoragePropertiesServiceTests
    {
        private readonly Mock<IStoragePropertiesRepository> mockedRepository;
        private readonly StoragePropertiesService service;

        public StoragePropertiesServiceTests()
        {
            mockedRepository = new Mock<IStoragePropertiesRepository>();
            service = new StoragePropertiesService(mockedRepository.Object);
        }

        [Fact]
        public async Task Test_NoResult()
        {
            var result = await service.GetDefaultStoragePropertiesAsync(CancellationToken.None);
            Assert.Null(result);
        }

        [Fact]
        public async Task Test_ProperResult()
        {
            var resultList = new List<StoragePropertiesModel>
            {
               new StoragePropertiesModel
               {
                   Id = 2,
                   DefaultContainer = "cont",
                   DefaultIndex = "index"
               },
                new StoragePropertiesModel
               {
                   Id = 6,
                   DefaultContainer = "cont6",
                   DefaultIndex = "index6"
               }
            };
            mockedRepository.Setup(fun => fun.GetAllAsync(It.IsAny<CancellationToken>())).ReturnsAsync(resultList);


            var result = await service.GetDefaultStoragePropertiesAsync(CancellationToken.None);
            Assert.NotNull(result);
            Assert.Equal(2, result.Id);
            Assert.Equal("cont", result.DefaultContainer);
            Assert.Equal("index", result.DefaultIndex);
        }

    }
}
