﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Messages;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using RD.RDF.StoragePortal.DataAccess.Messaging;
using RDF.Storage.MigrationAgentCore.Extensions;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace RDF.Storage.MigrationAgentCore.Workers
{
    public class MigrationPrepareWorker : BackgroundService
    {
        private readonly ILogger<MigrationPrepareWorker> logger;
        private readonly KafkaWorkerLoop workerLoop;
        private readonly KafkaConfiguration kafkaConfig;
        private readonly IContainerConfigurationClient container;
        private readonly IStorageWorkerClientService storageWorkerClientService;
        private readonly IMigrationRunObjectsService migrationRunObjects;




        public MigrationPrepareWorker(ILogger<MigrationPrepareWorker> logger,
                                      IOptions<MigrationKafkaConfiguration> workerKafkaConfigurationOpt,
                                      KafkaConfigurationKeyVaultProvider secretsProvider,
                                      KafkaWorkerLoop workerLoop,
                                      IContainerConfigurationClient container,
                                      IStorageWorkerClientService storageWorkerClientService,
                                      IMigrationRunObjectsService migrationRunObjects)
        {
            this.logger = logger;
            this.workerLoop = workerLoop;
            this.kafkaConfig = workerKafkaConfigurationOpt.Value.MigrationRun;
            this.kafkaConfig = secretsProvider.AddSecretsFromKeyValut(this.kafkaConfig);
            this.container = container;
            this.storageWorkerClientService = storageWorkerClientService;
            this.migrationRunObjects = migrationRunObjects;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            logger.LogInformation($"{nameof(MigrationPrepareWorker)} running at: {DateTimeOffset.Now}");
            try
            {
                await workerLoop.SubscribeAndHandleAsync<MigrationRunEvent>(this.kafkaConfig, StartReadingAsync, stoppingToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }

        }

        private async Task<bool> StartReadingAsync(MigrationRunEvent message)
        {
            if (message.MigrationRunStatus == MigrationRunStatusEnum.Stop)
            {
                logger.LogWarning($"Stop msg send for migration id = {message.MigrationId} migrationRun = {message.MigrationRunId} {DateTime.UtcNow}");
                return true;
            }

            logger.LogInformation($"Start of work for message for migration id = {message.MigrationId} migrationRun = {message.MigrationRunId} {DateTime.UtcNow}");

            var stoppingToken = new CancellationToken();

            var containerInfo = await this.container.RetriveContainerConfigurationAsync(message.MigrationRunId, stoppingToken);

            var info = await this.container.RetriveMigrationRunInformationAsync(message.MigrationId);

            var pagedData = await this.storageWorkerClientService.GetAllDataFromStorageAsync(containerInfo, stoppingToken);

            await this.migrationRunObjects.InsertRunObjectsRecords(pagedData, info, stoppingToken);

            logger.LogInformation($"End of work message for migration id = {message.MigrationId}  migrationRun = {message.MigrationRunId} {DateTime.UtcNow}");

            return true;
        }
    }
}
