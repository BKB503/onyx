﻿using Amazon.S3.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Messages;
using RD.RDF.StoragePortal.DataAccess.Messaging;
using RTools_NTS.Util;
using System;
using System.IO;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using static Google.Apis.Storage.v1.Data.Bucket.LifecycleData;

namespace RDF.Storage.MigrationAgentCore.Workers
{
    public class GDriveMigrationWorker : BackgroundService
    {
        private readonly ILogger<GDriveMigrationWorker> logger;
        private readonly KafkaWorkerLoop workerLoop;
        private readonly KafkaConfiguration kafkaConfig;
        private readonly IContainerConfigurationClient container;
        private readonly IStorageWorkerClientService storageWorkerClientService;
        private readonly IMigrationRunObjectsService migrationRunObjects;


        public GDriveMigrationWorker(ILogger<GDriveMigrationWorker> logger,
                                      IOptions<MigrationKafkaConfiguration> workerKafkaConfigurationOpt,
                                      KafkaConfigurationKeyVaultProvider secretsProvider,
                                      KafkaWorkerLoop workerLoop,
                                      IContainerConfigurationClient container,
                                      IStorageWorkerClientService storageWorkerClientService

            )
        {
            this.logger = logger;
            this.workerLoop = workerLoop;
            this.kafkaConfig = workerKafkaConfigurationOpt.Value.MigrationRunObjects;
            this.kafkaConfig = secretsProvider.AddSecretsFromKeyValut(this.kafkaConfig);
            this.container = container;
            this.storageWorkerClientService = storageWorkerClientService;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                logger.LogInformation($"{nameof(GDriveMigrationWorker)} running at: {DateTimeOffset.Now}");

                try
                {
                    await workerLoop.SubscribeAndHandleAsync<MigrationRunObjectEvent>(this.kafkaConfig, StartReadingAsync, stoppingToken);
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, ex.Message);
                }

                await Task.Delay(1000, stoppingToken);
            }
        }

        private async Task<bool> StartReadingAsync(MigrationRunObjectEvent message)
        {
            if (message.MigrationRunId == 0)
            {
                logger.LogWarning($"Stop msg send for migration id = {message.MigrationId} migrationRun = {message.MigrationRunId} {DateTime.UtcNow}");
                return true;
            }

            logger.LogInformation($"Start of work for message for migration id = {message.MigrationId} migrationRun = {message.MigrationRunId} {DateTime.UtcNow}");

            var stoppingToken = new CancellationToken();

            string fileName = message.MigrationObject.FileName;
            string folderName = message.MigrationObject.FolderName;

            var containerInfo = await this.container.RetriveContainerConfigurationAsync(message.MigrationRunId, stoppingToken);

            var fileInfo = await this.storageWorkerClientService.GetOneFileInformationAsync(containerInfo, fileName, folderName, stoppingToken);

            long totalBytes = 0;
            bool fileAvailable = false;

            if (fileInfo != null && fileInfo.FileSize.GetValueOrDefault() > 0)
            {
                totalBytes = fileInfo.FileSize.GetValueOrDefault();
                Stream fileStream = await storageWorkerClientService.GetFileStreamAsync(containerInfo, fileInfo, stoppingToken);
                fileAvailable = true;
                //Update File upload current status into MigrationRunObjects Left to implement

                var uploaded = await storageWorkerClientService.UploadFileToFolderAsync(containerInfo, fileName, folderName, fileStream, stoppingToken);

                //Update File upload current status into MigrationRunObjects Left to implement
            }
            else
            {
                string[] msg = { $"File {fileName} was not found in Container {containerInfo}. Folder {fileInfo.FolderName}" };
                logger.LogWarning(msg[0]);
            }

            logger.LogInformation($"End of work message for migration id = {message.MigrationId}  migrationRun = {message.MigrationRunId} {DateTime.UtcNow}");

            return true;
        }
    }
}
