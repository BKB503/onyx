﻿using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.IO;
using System.Reflection;

namespace RDF.Storage.MigrationAgentCore.Extensions
{

    public static class HostStartupExtension
    {
        public static IHostBuilder CreateGenericHostBuilder(string[] args, Action<HostBuilderContext, IServiceCollection> configureDelegate)
        {
            return Host.CreateDefaultBuilder(args)
                       .UseContentRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location))
                       .ConfigureAppConfiguration((ctx, builder) =>
                       {
                           builder.AddCommandLine(args);
                           var builtConfig = builder.Build();
                           string kv = builtConfig["KeyVaultName"];
                           if (!string.IsNullOrEmpty(kv))
                           {
                               var secretClient = new SecretClient(new Uri($"https://{kv}.vault.azure.net/"), new DefaultAzureCredential());
                               builder.AddAzureKeyVault(secretClient, new KeyVaultSecretManager());
                           }
                       })
                       .ConfigureServices(configureDelegate);
        }

    }
}
