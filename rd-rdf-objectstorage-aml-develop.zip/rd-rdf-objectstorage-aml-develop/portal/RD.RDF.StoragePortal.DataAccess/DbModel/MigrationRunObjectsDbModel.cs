﻿using RD.RDF.StoragePortal.Contracts.Model;

namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class MigrationRunObjectsDbModel : BaseDbModel
    { 
        public MigrationRunsDbModel MigrationRun { get; set; }
        
        public int MigrationRunId { get; set; }

        public int MigrationRunDataSourceId { get; set; }

        public int MigrationRunDataDestinationId { get; set; }

        public string FileName { get; set; }

        public string FilePath { get; set; }

        public long FileSize { get; set; }

        public FileMigrationStatus FileMigrationStatus { get; set; }

    }
}
