﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class ContainersDbModel : BaseDbModel
    { 
        public string Name { get; set; }
        public string ContainerType { get; set; }
        public string ContainerAccountName { get; set; }
        public string ContainerAccountUrl { get; set; }
        public string ContainerName { get; set; }
        [Encrypted]
        public string ContainerConnectionString { get; set; }
        [Encrypted]
        public string ContainerKey { get; set; }
        public string ContainerUserId { get; set; }
        public string AllianceTagName { get; set; }
        public bool ValidateAudience { get; set; }
        public List<AudiencesDbModel> Audiences { get; set; }
        public string ProxyUrl { get; set; }
        public int IndexId { get; set; }
        public IndexesDbModel Index { get; set; }
    }
}
