﻿namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class AudiencesDbModel : BaseDbModel
    { 
        public string ValidAudience { get; set; }
        public int ContainerId { get; set; }
        public ContainersDbModel StorageContainers { get; set; }
    }
}
