﻿using RD.RDF.StoragePortal.Contracts.Model;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class MigrationDataSourcesDbModel : BaseDbModel
    { 
        public MigrationsDbModel Migration { get; set; }
        
        public int MigrationId { get; set; }

        public DataSourceType DataSourceType { get; set; }
        public StoragePortalContainerType ContainerType { get; set; }

        public string ContainerAccountName { get; set; }

        public string ContainerAccountUrl { get; set; }

        public string ContainerName { get; set; }

        [Encrypted]
        public string ContainerConnectionString { get; set; }

        [Encrypted]
        public string ContainerKey { get; set; }

        public string ContainerUserId { get; set; }

        public string ProxyUrl { get; set; }
    }

    
}
