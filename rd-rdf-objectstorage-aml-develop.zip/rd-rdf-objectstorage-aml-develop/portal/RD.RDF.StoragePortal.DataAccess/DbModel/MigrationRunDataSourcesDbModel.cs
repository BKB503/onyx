﻿using RD.RDF.StoragePortal.Contracts.Model;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class MigrationRunDataSourcesDbModel : BaseDbModel
    {
        public int Id { get; set; }
      
        public MigrationRunsDbModel MigrationRun { get; set; }
  
        public int MigrationRunId { get; set; }

        public DataSourceType DataSourceType { get; set; }


        public StoragePortalContainerType ContainerType { get; set; }

        public string ContainerAccountName { get; set; }

        public string ContainerAccountUrl { get; set; }

        public string ContainerName { get; set; }
        
        [Encrypted]
        public string ContainerConnectionString { get; set; }

        [Encrypted]
        public string ContainerKey { get; set; }

        public string ContainerUserId { get; set; }

        public string ProxyUrl { get; set; }       
    }
}
