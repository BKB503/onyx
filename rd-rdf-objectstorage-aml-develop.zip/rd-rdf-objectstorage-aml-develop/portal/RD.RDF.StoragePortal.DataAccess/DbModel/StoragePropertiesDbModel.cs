﻿namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class StoragePropertiesDbModel
    {
        /// <summary>
        /// id of storage properties settings
        /// </summary>
        public int Id { get; set; }


        /// <summary>
        /// default container
        /// </summary>
        public string DefaultContainer { get; set; }

        /// <summary>
        /// default indexing settings 
        /// </summary>
        public string DefaultIndex { get; set; }
    }
}
