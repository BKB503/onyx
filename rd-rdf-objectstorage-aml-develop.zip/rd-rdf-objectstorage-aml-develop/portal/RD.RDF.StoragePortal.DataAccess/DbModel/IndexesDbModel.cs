﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class IndexesDbModel : BaseDbModel
    {
        public string RDFKafkaTopic { get; set; }
        public string Type { get; set; }
        [Encrypted]
        public string RDFKafkaConnectionString { get; set; }
        [Encrypted]
        public string RDFKafkaKey { get; set; }
        public string KafkaServers { get; set; }
        public string SaslUsername { get; set; }
        [Encrypted]
        public string IndexOdbcConnectionString { get; set; }
        public List<ContainersDbModel> Containers { get; set; }
    }
}
