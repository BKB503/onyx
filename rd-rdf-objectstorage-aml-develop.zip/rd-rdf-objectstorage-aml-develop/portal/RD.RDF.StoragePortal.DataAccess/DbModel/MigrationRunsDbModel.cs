﻿using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;

namespace RD.RDF.StoragePortal.DataAccess.DbModel
{
    public class MigrationRunsDbModel : BaseDbModel
    { 
        public MigrationsDbModel Migration { get; set; }
        public int MigrationId { get; set; }

        public DateTime RunStartDate { get; set; }
        public DateTime ? RunFinishDate { get; set; }
        public RunStatusEnum RunStatus { get; set; }

        public RunStageEnum RunStage { get; set; }
        public long RunObjectsCount { get; set; }
        public long RunObjectsMigrated { get; set; }
        public MigrationType MigrationType { get; set; }

        public List<MigrationRunObjectsDbModel>RunObjects { get; set; }


    }

}
