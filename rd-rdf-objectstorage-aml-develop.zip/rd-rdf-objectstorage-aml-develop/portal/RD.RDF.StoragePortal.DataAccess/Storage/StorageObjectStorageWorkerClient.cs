﻿using Amazon.Runtime;
using Amazon.S3;
using Google.Cloud.Storage.V1;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3.Model;
using System.IO;
using Google.Api.Gax.ResourceNames;
using Microsoft.Extensions.Options;
using Amazon.S3.Transfer;

namespace RD.RDF.StoragePortal.DataAccess.Storage
{
    public class StorageObjectStorageWorkerClient : IStorageWorkerClient
    {
        private readonly ILogger<StorageObjectStorageWorkerClient> logger;
        private readonly MyHttpClientFactory clientFactory;

        public StorageContainerType StorageClientType => StorageContainerType.objectstorage;

        public StorageObjectStorageWorkerClient(ILogger<StorageObjectStorageWorkerClient> logger, MyHttpClientFactory clientFactory)
        {
            this.logger = logger;
            this.clientFactory = clientFactory;
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            string folderName = string.Empty;
            List<FileResource> fr = new List<FileResource>();
            AmazonS3Client s3Clinet = CreateS3Client(container);
            var storageFolder = HandleFolderName(folderName);

            FileResource currentFileResource = null;
            var currentToken = DecodeToken(filter.ContinuationToken);

            string nextToken = null;
            try
            {
                var listObjects = await s3Clinet.ListObjectsAsync(container.Configuration.ContainerName, token);
                foreach (var s3Object in listObjects.S3Objects)
                {
                    currentFileResource = CreateFileInfo(s3Object);
                    fr.Add(currentFileResource);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }

            return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, null);

        }

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);
        }

        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string versionId, CancellationToken token)
        {
            AmazonS3Client s3Client = CreateS3Client(container);
            var storageFolder = HandleFolderName(folderName);
            var listRequest = new ListVersionsRequest()
            {
                BucketName = container.Configuration.ContainerName,
                Delimiter = "/",
                Prefix = storageFolder + fileName
            };
            ListVersionsResponse listResponse;
            FileResource currentFileResource = null;
            try
            {
                do
                {
                    listResponse = await s3Client.ListVersionsAsync(listRequest);

                    if (listResponse.HttpStatusCode != System.Net.HttpStatusCode.OK)
                    {
                        logger.LogError($"ListVersions for OneFile returned {listResponse.HttpStatusCode} code.");
                        break;
                    }
                    foreach (var s3Object in listResponse.Versions)
                    {
                        if (versionId == null)
                        {
                            if (currentFileResource == null)
                            {
                                currentFileResource = CreateFileResource(s3Object);
                            }
                            AddVersinToFileResource(currentFileResource, s3Object);
                        }
                        else if (versionId == s3Object.VersionId)
                        {
                            //one version will be returned
                            currentFileResource = CreateFileResource(s3Object);
                            AddVersinToFileResource(currentFileResource, s3Object);
                        }
                    }
                    listRequest.KeyMarker = listResponse.NextKeyMarker;
                    listRequest.VersionIdMarker = listResponse.NextVersionIdMarker;
                } while (listResponse.IsTruncated);

                var metadataCollection = await GetMetadataObjectAsync(s3Client, container, fileName, folderName);
                currentFileResource.FileGuid = GetFilGuidFromMeatadata(metadataCollection);
                currentFileResource.Metadata = GetMetadataDictionaryObject(metadataCollection);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return currentFileResource;
        }

        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }

        public AmazonS3Client CreateS3Client(ContainerResource container)
        {
            var config = new AmazonS3Config()
            {
                ForcePathStyle = true,
                SignatureVersion = "2",
                ServiceURL = container.Configuration.ContainerAccountUrl,
                SignatureMethod = SigningAlgorithm.HmacSHA1,
                UseHttp = false,
                HttpClientFactory = clientFactory
            };
            var credentials = new BasicAWSCredentials(container.Configuration.ContainerUserId, container.Configuration.ContainerKey);
            return new AmazonS3Client(credentials, config);
        }

        private static FileResource CreateFileResource(S3ObjectVersion s3Object)
        {
            var fr = new FileResource(GetFileNameFromKey(s3Object.Key))
            {
                ModifiedTime = s3Object.LastModified,
                CreationTime = s3Object.LastModified,
                FileContentHash = s3Object.ETag,
                FileBlobType = s3Object.StorageClass.Value,
                // FileContentType = s3Object.,
                FileETag = s3Object.ETag,
                FileVersionId = s3Object.VersionId,
                FileVersions = new List<VersionDetails>(),
                //FileGuid = s3Object.VersionId,
                FilePath = s3Object.Key,
                FileSize = s3Object.Size,
                Metadata = new MetadataDictionary(),
                FolderName = GetFolderFromKey(s3Object.Key)
            };

            return fr;
        }

        private static string GetFileNameFromKey(string key)
        {
            return Path.GetFileName(key);
        }

        private static string GetFolderFromKey(string key)
        {
            return Path.GetDirectoryName(key);
        }

        private static void AddVersinToFileResource(FileResource file, S3ObjectVersion s3ObjectVersion)
        {
            file.FileVersions.Add(new VersionDetails
            {
                //FileGuid = s3ObjectVersion.VersionId,
                FileVersionId = s3ObjectVersion.VersionId,
                FileETag = s3ObjectVersion.ETag,
                FileContentHash = s3ObjectVersion.ETag,
                CreationTime = s3ObjectVersion.LastModified,
                FileSize = s3ObjectVersion.Size,
                IsLatestVersion = s3ObjectVersion.IsLatest
            });

        }

        private async Task<MetadataCollection> GetMetadataObjectAsync(AmazonS3Client s3Clinet, ContainerResource container, string fileName, string folderName)
        {
            var storageFolder = HandleFolderName(folderName);
            var metadataObject = await s3Clinet.GetObjectMetadataAsync(
                        new GetObjectMetadataRequest() { BucketName = container.Configuration.ContainerName, Key = storageFolder + fileName });
            return metadataObject.Metadata;
        }

        private static string GetFilGuidFromMeatadata(MetadataCollection metadataObject)
        {
            string fileGuid = null;

            if (metadataObject != null)
            {
                fileGuid = metadataObject["x-amz-meta-fileguid"];
            }
            return fileGuid;
        }

        private static MetadataDictionary GetMetadataDictionaryObject(MetadataCollection metadataObject)
        {
            MetadataDictionary keyValuePairs = new MetadataDictionary();
            if (metadataObject is null)
            {
                return keyValuePairs;
            }
            foreach (var metadata in metadataObject.Keys)
            {
                string key = metadata.Replace("x-amz-meta-", "");
                keyValuePairs.Add(key, metadataObject[metadata]);
            }

            return keyValuePairs;
        }

        private static IOptions<Tuple<string, string>> DecodeToken(string inputToken)
        {
            try
            {
                byte[] data = Convert.FromBase64String(inputToken);
                string decodedString = Encoding.UTF8.GetString(data);
                string[] split = decodedString.Split('|', StringSplitOptions.RemoveEmptyEntries);
                return Options.Create(new Tuple<string, string>(split[0], split[1]));
            }
            catch
            {
                return Options.Create<Tuple<string, string>>(null);
            }
        }
        private static string EncodeToken(string tokenPart1, string tokenPart2)
        {
            string token = $"{tokenPart1}|{tokenPart2}";
            byte[] data = Encoding.UTF8.GetBytes(token);
            return Convert.ToBase64String(data);
        }

        private static FileResource CreateFileInfo(S3Object s3Object)
        {
            var fr = new FileResource(GetFileNameFromKey(s3Object.Key))
            {
                ModifiedTime = s3Object.LastModified,
                CreationTime = s3Object.LastModified,
                FileContentHash = s3Object.ETag,
                FileBlobType = s3Object.StorageClass.Value,
                FileETag = s3Object.ETag,
                FileVersions = new List<VersionDetails>(),
                FilePath = s3Object.Key,
                FileSize = s3Object.Size,
                Metadata = new MetadataDictionary(),
                FolderName = GetFolderFromKey(s3Object.Key)
            };

            return fr;
        }

        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            Stream responseStream = null;
            var s3Clinet = CreateS3Client(container);
            try
            {
                var request = new GetObjectRequest()
                {
                    BucketName = container.Configuration.ContainerName,
                    Key = file.FilePath,
                    VersionId = file.FileVersionId,
                };
                GetObjectResponse response = await s3Clinet.GetObjectAsync(request);
                responseStream = response.ResponseStream;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return responseStream;
        }

        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folder, Stream fileData, CancellationToken token)
        {
            FileResource newFileInfo = null;
            int maxLength = 256;
            try
            {
                var s3 = CreateS3Client(container);
                var fileTransferUtility = new TransferUtility(s3);
                string key = HandleFolderName(folder) + fileName;
                var uploadRequest = new TransferUtilityUploadRequest()
                {
                    BucketName = container.Configuration.ContainerName,
                    InputStream = fileData,
                    AutoResetStreamPosition = true,
                    AutoCloseStream = true,
                    StorageClass = S3StorageClass.Standard,
                    PartSize = 1024 * 1024 * 2, // 2MB
                    Key = key,
                };

                await fileTransferUtility.UploadAsync(uploadRequest);

                newFileInfo = await GetOneFileInformationWithVersionAsync(container, fileName, folder, null, token);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return newFileInfo;
        }


    }

    public class MyHttpClientFactory : HttpClientFactory
    {
        private readonly ILogger<MyHttpClientFactory> logger;

        public MyHttpClientFactory(ILogger<MyHttpClientFactory> logger)
        {
            this.logger = logger;
        }

        public override HttpClient CreateHttpClient(IClientConfig clientConfig)
        {
            var httpMessageHandler = new HttpClientHandler();
            //we don't validate the cert of server
            httpMessageHandler.ServerCertificateCustomValidationCallback = (_, _, _, _) => true;
            if (clientConfig.MaxConnectionsPerServer != null)
            {
                httpMessageHandler.MaxConnectionsPerServer = clientConfig.MaxConnectionsPerServer.Value;
            }
            try
            {
                // If HttpClientHandler.AllowAutoRedirect is set to true (default value),
                // redirects for GET requests are automatically followed and redirects for POST
                // requests are thrown back as exceptions.
                // If HttpClientHandler.AllowAutoRedirect is set to false (e.g. S3),
                // redirects are returned as responses.
                httpMessageHandler.AllowAutoRedirect = clientConfig.AllowAutoRedirect;

                // Disable automatic decompression when Content-Encoding header is present
                httpMessageHandler.AutomaticDecompression = DecompressionMethods.None;
            }
            catch (PlatformNotSupportedException pns)
            {
                logger.LogDebug(pns, $"The current runtime does not support modifying the configuration of HttpClient.");
            }
            try
            {
                var proxy = clientConfig.GetWebProxy();
                if (proxy != null)
                {
                    httpMessageHandler.Proxy = proxy;
                }

                if (httpMessageHandler.Proxy != null && clientConfig.ProxyCredentials != null)
                {
                    httpMessageHandler.Proxy.Credentials = clientConfig.ProxyCredentials;
                }
            }
            catch (PlatformNotSupportedException pns)
            {
                logger.LogDebug(pns, $"The current runtime does not support modifying proxy settings of HttpClient.");
            }

            var httpClient = new HttpClient(httpMessageHandler);

            if (clientConfig.Timeout != null)
            {
                // Timeout value is set to ClientConfig.MaxTimeout for S3 and Glacier.
                // Use default value (100 seconds) for other services.
                httpClient.Timeout = clientConfig.Timeout.Value;
            }

            return httpClient;
        }
    }
}
