﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Messages;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Storage
{
    public class MigrationRunObjectsServiceClient : IMigrationRunObjectsService
    {
        private readonly IServiceScopeFactory scopeFactory;
        private readonly ILogger<MigrationRunObjectsServiceClient> logger;
        private readonly MigrationKafkaConfiguration settings;
        private readonly JsonSerializerOptions jsonOptions;

        public MigrationRunObjectsServiceClient
            (
                IServiceScopeFactory scopeFactory,
                ILogger<MigrationRunObjectsServiceClient> logger,
                IOptions<MigrationKafkaConfiguration> config,
                KafkaConfigurationKeyVaultProvider secretsProvider
            )
        {
            this.scopeFactory = scopeFactory;
            this.logger = logger;
            this.settings = config.Value;
            this.settings.MigrationRunObjects = secretsProvider.AddSecretsFromKeyValut(this.settings.MigrationRunObjects);
            this.jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = false,
                WriteIndented = true
            };
            this.jsonOptions.Converters.Add(new JsonStringEnumConverter());
        }

        public async Task<bool> InsertRunObjectsRecords(PagedApiResponse<List<FileResource>> pagedData, MigrationRunInfoModel runInfo, CancellationToken token)
        {
            int objectId;

            foreach (var item in pagedData.Data)
            {
                var objectInfo = new MigrationRunObjectsModel
                {
                    MigrationRunId = runInfo.MigrationRunId,
                    MigrationRunDataSourceId = runInfo.MigrationRunDataSourceId,
                    MigrationRunDataDestinationId = runInfo.MigrationRunDataDestinationId,
                    FileName = item.FileName,
                    FilePath = item.FilePath,
                    FileSize = (int)item.FileSize,
                    CreateDate = DateTime.Parse(item.CreationTime.ToString()),
                    UpdateDate = DateTime.Parse(item.ModifiedTime.ToString())
                };
                var migrationObject = new MigrationObject
                {
                    FileName = item.FileName,
                    FolderName = item.FolderName,
                    FilePath = item.FilePath,
                    FileBlobType = item.FileBlobType,
                    FileContentType = item.FileContentType,
                    FileVersionId = item.FileVersionId,
                    FileGuid = item.FileGuid,
                    FileContentHash = item.FileContentHash,
                    FileETag = item.FileETag,
                    FileSize = item.FileSize,
                    CreationTime = item.CreationTime,
                    ModifiedTime = item.ModifiedTime,
                    Metadata = new MigrationObjectMetadata(item.Metadata),
                };

                using (var scope = this.scopeFactory.CreateScope())
                {
                    var repository = scope.ServiceProvider.GetRequiredService<IMigrationRunObjectsRepository>();
                    objectId = await repository.InsertRunObjectsRecord(objectInfo, token);
                }
                if (objectId > 0)
                {
                    await PublishMsgToKafka(runInfo, objectId, migrationObject, token);
                }
            }

            return true;
        }

        private async Task<bool> PublishMsgToKafka(MigrationRunInfoModel runInfo, int objectId, MigrationObject fileResource, CancellationToken token)
        {
            logger.LogInformation($"Publishing to MigrationStart to Kafka topic {settings.MigrationRunObjects.KafkaTopic} Started");
            try
            {
                var producerClient = GetKafkaProducer();
                var message = new MigrationRunObjectEvent
                {
                    MigrationRunObjectId = objectId,
                    EventCreateDate = DateTime.UtcNow,
                    MigrationId = runInfo.MigrationRunId,
                    MigrationRunId = runInfo.MigrationRunId,
                    MigrationType = MigrationTypeEnum.GDriveMigration,
                    MigrationObject = fileResource
                };

                string json = JsonSerializer.Serialize(message, jsonOptions);
                var msg = new Message<Null, string> { Value = json };
                var deliveryReport = await producerClient.ProduceAsync(settings.MigrationRunObjects.KafkaTopic, msg, token);
                logger.LogInformation($"Publishing to MigrationStart to Kafka topic {settings.MigrationRunObjects.KafkaTopic} to Kafka Completed");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Publishing to MigrationStart to Kafka topic {settings.MigrationRunObjects.KafkaTopic} Error: {ex.Message}");
                return false;
            }
            return true;
        }

        private IProducer<Null, string> GetKafkaProducer()
        {
            var config = new ProducerConfig
            {
                SaslPassword = settings.MigrationRunObjects.SaslPassword,
                BootstrapServers = settings.MigrationRunObjects.KafkaServers,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = settings.MigrationRunObjects.SaslUsername,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                Debug = "broker"
            };
            return new ProducerBuilder<Null, string>(config).SetKeySerializer(Serializers.Null).SetValueSerializer(Serializers.Utf8).Build();
        }
    }
}
