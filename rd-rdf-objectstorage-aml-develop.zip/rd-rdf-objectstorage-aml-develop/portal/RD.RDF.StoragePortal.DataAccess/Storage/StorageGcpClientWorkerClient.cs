﻿using Google.Api.Gax;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Http;
using Google.Cloud.Storage.V1;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Extensions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Storage
{
    public class StorageGcpClientWorkerClient : IStorageWorkerClient
    {
        private readonly ConcurrentDictionary<string, StorageClient> Services = new ConcurrentDictionary<string, StorageClient>();

        private readonly ILogger<StorageGcpClientWorkerClient> logger;

        public StorageContainerType StorageClientType => StorageContainerType.googleblob;

        public StorageGcpClientWorkerClient(ILogger<StorageGcpClientWorkerClient> logger)
        {
            this.logger = logger;
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            string folderName = string.Empty;
            List<FileResource> fr = new List<FileResource>();
            var storageFolder = HandleFolderName(folderName);
            var containerClient = GetServiceClient(container);
            var listOptions = new ListObjectsOptions
            {
                UserProject = container.Configuration.ContainerAccountName,
                Versions = true,
                Delimiter = "/",
                IncludeTrailingDelimiter = true,
                PageToken = filter.ContinuationToken,
            };

            try
            {
                var resultSegment = containerClient.ListObjectsAsync(container.Configuration.ContainerName, storageFolder, listOptions);//.GetAsyncEnumerator(token);

                await foreach (var resource in resultSegment)
                {
                    string fileGuid = null;
                    if (resource.Metadata != null)
                    {
                        resource.Metadata.TryGetValue("FileGuid", out fileGuid);
                    }
                    fr.Add(new FileResource(resource.Name)
                    {
                        ModifiedTime = resource.Updated,
                        CreationTime = resource.TimeCreated,
                        FileContentHash = resource.Md5Hash,
                        FileBlobType = resource.ContentType,
                        FileContentType = resource.ContentType,
                        FileETag = resource.ETag,
                        FileVersionId = Convert.ToString(resource.Generation),
                        FileGuid = fileGuid,
                        FilePath = resource.Name,
                        FileSize = (long)resource.Size,
                        FolderName = (resource.Name.Contains('/') ? resource.Name.Substring(0, resource.Name.LastIndexOf('/', 0)) : string.Empty),
                        Metadata = new MetadataDictionary(resource.Metadata)
                    });
                }

                //read one page and break

                return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, null);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<List<FileResource>>(ex.Message, filter.ContinuationToken, filter.Limit);
            }
        }
        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }

        private StorageClient GetServiceClient(ContainerResource container)
        {
            if (!Services.TryGetValue(container.ContainerName, out StorageClient serviceClient))
            {
                var credential = GoogleCredential.FromJson(container?.Configuration?.ContainerConnectionString);
                if (!string.IsNullOrEmpty(container.Configuration.ProxyUrl))
                {
                    IWebProxy webProxy = new WebProxy(container.Configuration.ProxyUrl);
                    var factory = HttpClientFactory.ForProxy(webProxy);
                    credential = credential.CreateWithHttpClientFactory(factory);
                }

                serviceClient = StorageClient.Create(credential);
                Services.TryAdd(container.ContainerName, serviceClient);
            }
            return serviceClient;
        }

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            // passing null version id to fetch the latest version (default)
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);
        }

        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token)
        {
            var parentFolder = GetParentFolder(container, folderName);
            var objectName = string.IsNullOrEmpty(parentFolder.FolderName) ? fileName : $"{parentFolder.FolderName}{Path.AltDirectorySeparatorChar}{fileName}";
            var containerClient = GetServiceClient(container);
            var props = await containerClient.GetObjectAsync(container.Configuration.ContainerName, objectName, null, token);

            string fileGuid = null;
            if (props.Metadata != null)
            {
                props.Metadata.TryGetValue("FileGuid", out fileGuid);
            }

            var fileResource = new FileResource(fileName)
            {
                FileSize = (long)props.Size,
                ModifiedTime = DateTimeOffset.Parse(props.Updated.ToString()),
                CreationTime = props.TimeCreated,
                FileContentHash = props.Md5Hash,
                FileBlobType = props.ContentType,
                FileContentType = props.ContentType,
                FileETag = props.ETag,
                FileVersionId = Convert.ToString(props.Generation),
                FileVersions = await GetFileVersionsAsync(container, containerClient, objectName, token),
                FileGuid = fileGuid,
                FilePath = objectName,
                FolderName = folderName,
                Metadata = new MetadataDictionary(props.Metadata)

            };

            return fileResource;
        }
        private static FolderResource GetParentFolder(ContainerResource container, string folderName)
        {
            FolderResource parentFolder = new FolderResource(string.Empty);
            if (!string.IsNullOrEmpty(folderName))
            {
                parentFolder = FolderResource.CreateEmptyFolder(HandleFolderName(folderName));
            }

            return parentFolder;
        }

        private static async Task<List<VersionDetails>> GetFileVersionsAsync(ContainerResource container, StorageClient containerClient,
                                       string blobName, CancellationToken token)
        {

            List<VersionDetails> versions = new List<VersionDetails>();
            var listOptions = new ListObjectsOptions
            {
                UserProject = container.Configuration.ContainerAccountName,
                Versions = true,
                Delimiter = "/",
                IncludeTrailingDelimiter = true,

            };

            bool isLatestVersion = false;
            string nextToken = null;
            var resultSegment = containerClient.ListObjectsAsync(container.Configuration.ContainerName, blobName, listOptions);
            var pageResult = await resultSegment.ReadPageAsync(100, token);
            var latestObjectInfo = pageResult.OrderBy(x => x.Id).LastOrDefault();

            foreach (var version in pageResult)
            {
                if (version.Id == latestObjectInfo.Id)
                {
                    isLatestVersion = true;
                }
                versions.Add(new VersionDetails
                {
                    FileVersionId = version.Id,
                    FileETag = version.ETag,
                    FileSize = (long)version.Size,
                    FileContentHash = version.Md5Hash,
                    CreationTime = version.TimeCreated,
                    IsLatestVersion = isLatestVersion

                });
            }

            return versions;
        }

        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            var containerClient = GetServiceClient(container);
            Stream stream = new MemoryStream();
            long? versionId = string.IsNullOrEmpty(file.FileVersionId) ? null : long.Parse(file.FileVersionId);

            var options = new DownloadObjectOptions
            {
                Generation = versionId
            };

            await containerClient.DownloadObjectAsync(container.Configuration.ContainerName, file.FilePath, stream, options, token);
            stream.Seek(0, SeekOrigin.Begin);

            return stream;
        }

        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folderName, Stream fileData, CancellationToken token)
        {
            int maxLength = 256;
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var filePath = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var storageClient = GetServiceClient(container);

            var uploadRequest = new Google.Apis.Storage.v1.Data.Object()
            {
                Bucket = container.Configuration.ContainerName,
                Name = filePath,
                Metadata = new Dictionary<string, string>()
            };

            string fileGuid = uploadRequest.Metadata.Where(x => x.Key == Common.FileGuid).Any() ? uploadRequest.Metadata.Where(x => x.Key == Common.FileGuid).Select(x => x.Value).FirstOrDefault() : "";
            if (string.IsNullOrEmpty(fileGuid))
            {
                logger.LogError("No FileGuid found in the metadata list");
            }
            uploadRequest.Metadata[Common.FileGuid] = fileGuid;
            UploadObjectOptions uploadObjectOptions = new UploadObjectOptions();

            await storageClient.UploadObjectAsync(uploadRequest, fileData, uploadObjectOptions, token);

            return await GetOneFileInformationAsync(container, fileName, folderName, token);
        }


    }
}
