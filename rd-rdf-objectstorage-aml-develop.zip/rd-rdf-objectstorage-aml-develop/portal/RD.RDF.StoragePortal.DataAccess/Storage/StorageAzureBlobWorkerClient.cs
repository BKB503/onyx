﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Extensions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using static Azure.Core.HttpHeader;

namespace RD.RDF.StoragePortal.DataAccess.Storage
{
    public class StorageAzureBlobWorkerClient : IStorageWorkerClient
    {
        private readonly ConcurrentDictionary<string, BlobServiceClient> Services = new ConcurrentDictionary<string, BlobServiceClient>();
        private readonly ILogger<StorageAzureBlobWorkerClient> logger;

        public StorageContainerType StorageClientType => StorageContainerType.azureblob;

        public StorageAzureBlobWorkerClient(ILogger<StorageAzureBlobWorkerClient> logger)
        {
            this.logger = logger;
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            List<FileResource> fr = new List<FileResource>();
            var containerClient = GetBlobContainerClient(container);
            try
            {
                var resultSegment = containerClient.GetBlobsAsync(BlobTraits.Metadata | BlobTraits.Tags, cancellationToken: token)
                                           .AsPages(filter.ContinuationToken, filter.Limit);
                await foreach (Page<BlobItem> blobPage in resultSegment)
                {
                    foreach (var item in blobPage.Values)
                    {
                        if (!item.Deleted)
                        {
                            if (!item.Name.StartsWith(".index/") && !item.Name.StartsWith(".metadata/"))
                            {
                                var props = item.Properties;
                                string fileGuid = null;
                                item.Metadata.TryGetValue("FileGuid", out fileGuid);
                                if (fileGuid == null && item.Tags != null)
                                {
                                    item.Tags.TryGetValue("FileGuid", out fileGuid);
                                }
                                fr.Add(new FileResource(item.Name)
                                {
                                    ModifiedTime = props.LastModified,
                                    CreationTime = props.CreatedOn,
                                    FileContentHash = GetContentHash(props.ContentHash),
                                    FileBlobType = props.BlobType.ToString(),
                                    FileContentType = props.ContentType,
                                    FileETag = props.ETag?.ToString("G"),
                                    FileVersionId = item.VersionId,
                                    FileGuid = fileGuid,
                                    FilePath = item.Name,
                                    FileSize = item.Properties.ContentLength,
                                    Metadata = new MetadataDictionary(item.Metadata)
                                });
                            }
                        }
                    }
                }
                return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, null);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<List<FileResource>>(ex.Message, filter.ContinuationToken, filter.Limit);
            }

        }

        private BlobContainerClient GetBlobContainerClient(ContainerResource container)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetBlobContainerClient(container.Configuration.ContainerName);
            return containerClient;
        }

        private BlobServiceClient GetServiceClient(ContainerResource container)
        {
            if (!Services.TryGetValue(container.ContainerName, out BlobServiceClient serviceClient))
            {
                serviceClient = new BlobServiceClient(container?.Configuration?.ContainerConnectionString);
                Services.TryAdd(container.ContainerName, serviceClient);
            }
            return serviceClient;
        }

        private static string GetContentHash(byte[] contentHash)
        {
            return contentHash != null ? Convert.ToBase64String(contentHash) : null;
        }


        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            // passing null version id to fetch the latest version (default)
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);

        }

        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var containerClient = GetBlobContainerClient(container);
            var blobClient = containerClient.GetBlobClient(blobName).WithVersion(VersionId);
            try
            {
                var props = await blobClient.GetPropertiesAsync(cancellationToken: token);
                props.Value.Metadata.TryGetValue("FileGuid", out string fileGuid);
                if (fileGuid == null && props.Value.TagCount > 0)
                {
                    var tags = await blobClient.GetTagsAsync(cancellationToken: token);
                    tags.Value.Tags.TryGetValue("FileGuid", out fileGuid);
                }
                return new FileResource(fileName)
                {
                    FileSize = props.Value.ContentLength,
                    ModifiedTime = props.Value.LastModified,
                    CreationTime = props.Value.CreatedOn,
                    FileContentHash = GetContentHash(props.Value.ContentHash),
                    FileBlobType = props.Value.BlobType.ToString(),
                    FileContentType = props.Value.ContentType,
                    FileETag = props.Value.ETag.ToString("G"),
                    FileVersionId = props.Value.VersionId,
                    FileVersions = await GetFileVersionsAsync(containerClient, blobClient.Name, token),
                    FileGuid = fileGuid,
                    FilePath = blobName,
                    FolderName = folderName,
                    Metadata = new MetadataDictionary(props.Value.Metadata)
                };
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return null;
            }
        }

        private static FolderResource GetParentFolder(ContainerResource container, string folderName)
        {
            FolderResource parentFolder = new FolderResource(string.Empty);
            if (!string.IsNullOrEmpty(folderName))
            {
                parentFolder = FolderResource.CreateEmptyFolder(HandleFolderName(folderName));
            }

            return parentFolder;
        }

        private static async Task<List<VersionDetails>> GetFileVersionsAsync(BlobContainerClient blobContainerClient,
                                         string blobName, CancellationToken token)
        {
            List<VersionDetails> versions = new List<VersionDetails>();
            var blobVersions = blobContainerClient.GetBlobsAsync(BlobTraits.None, BlobStates.Version, blobName, token);
            await foreach (var version in blobVersions)
            {
                versions.Add(new VersionDetails
                {
                    FileVersionId = version.VersionId,
                    FileETag = version.Properties.ETag?.ToString("G"),
                    FileSize = version.Properties.ContentLength,
                    FileContentHash = GetContentHash(version.Properties.ContentHash),
                    CreationTime = version.Properties.CreatedOn,
                    IsLatestVersion = version.IsLatestVersion ?? false
                });
            }
            return versions;
        }

        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }


        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            var blobClient = GetBlobClientWithVersion(container, file);
            var downloadStream = await blobClient.DownloadStreamingAsync(cancellationToken: token);
            return downloadStream.Value.Content;
        }

        private BlobClient GetBlobClientWithVersion(ContainerResource container, FileResource fileInfo)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetBlobContainerClient(container.Configuration.ContainerName);

            return containerClient.GetBlobClient(fileInfo.FilePath).WithVersion(fileInfo.FileVersionId);
        }

        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folderName, Stream fileData, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var fileInfo = new FileResource(fileName) { FilePath = blobName };
            var blobClient = GetBlobClient(container, fileInfo);
            BlobUploadOptions blobUploadOptions = new BlobUploadOptions();
           
            await blobClient.UploadAsync(fileData, blobUploadOptions, token);

            var returnFileInfo = await GetOneFileInformationAsync(container, fileName, folderName, token);
            return returnFileInfo;
        }

        private BlobClient GetBlobClient(ContainerResource container, FileResource fileInfo)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetBlobContainerClient(container.Configuration.ContainerName);
            return containerClient.GetBlobClient(fileInfo.FilePath);
        }

        public MetadataDictionary SetTags(MetadataCollections valuePairs)
        {
            MetadataDictionary correctedMetadataDic = new MetadataDictionary();
            if (valuePairs is null)
            {
                return correctedMetadataDic;
            }

            int maxLength = 256;

            Regex allowedPattern = new Regex("[^a-zA-Z0-9\\ +./:=_]");

            //Allowed tags are 10. SetTagsAsync takes only first 10 values by default
            foreach (var item in valuePairs.Items.Where(x => x.IsIndexed == true).Take(9))
            {
                if (item.Value == null)
                {
                    item.Value = "";
                }

                //allows only 256 characater
                string modifiedValue = item.Value.Length < maxLength ? item.Value : item.Value.Substring(0, maxLength);
                if (allowedPattern.IsMatch(modifiedValue))
                {
                    modifiedValue = allowedPattern.Replace(modifiedValue, ":");
                    correctedMetadataDic.Add(item.Key, modifiedValue);
                }
                else { correctedMetadataDic.Add(item.Key, modifiedValue); }
            }
            string fileGuid = valuePairs.Items.Where(x => x.Key == RD.RDF.StoragePortal.Contracts.Model.Common.FileGuid).Any() ? valuePairs.Items.Where(x => x.Key == RD.RDF.StoragePortal.Contracts.Model.Common.FileGuid).Select(x => x.Value).FirstOrDefault() : "";
            if (string.IsNullOrEmpty(fileGuid))
            {
                logger.LogError("No FileGuid found in the metadata list");
            }
            correctedMetadataDic[RD.RDF.StoragePortal.Contracts.Model.Common.FileGuid] = fileGuid;
            return correctedMetadataDic;
        }

    }
}
