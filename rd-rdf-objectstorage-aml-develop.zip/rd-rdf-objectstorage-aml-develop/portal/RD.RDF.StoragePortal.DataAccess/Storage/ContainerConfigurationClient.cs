﻿using Confluent.Kafka;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Messages;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Storage
{
    public class ContainerConfigurationClient : IContainerConfigurationClient
    {
        private readonly IServiceScopeFactory scopeFactory;
        private readonly IConfiguration configuration;
        private readonly ILogger<ContainerConfigurationClient> logger;
        private readonly MigrationKafkaConfiguration settings;
        private readonly JsonSerializerOptions jsonOptions;

        public ContainerConfigurationClient
            (
                IServiceScopeFactory scopeFactory,
                IConfiguration configuration,
                ILogger<ContainerConfigurationClient> logger,
                IOptions<MigrationKafkaConfiguration> config,
                KafkaConfigurationKeyVaultProvider secretsProvider
            )
        {
            this.scopeFactory = scopeFactory;
            this.configuration = configuration;
            this.logger = logger;
            this.settings = config.Value;
            this.settings.MigrationRunObjects = secretsProvider.AddSecretsFromKeyValut(this.settings.MigrationRunObjects);
            this.jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = false,
                WriteIndented = true
            };
            this.jsonOptions.Converters.Add(new JsonStringEnumConverter());
        }

        public RunMigrationVM migrationInfo = new RunMigrationVM();
        public async Task<ContainerResource> RetriveContainerConfigurationAsync(int migrationId, CancellationToken token)
        {

            using (var scope = this.scopeFactory.CreateScope())
            {
                var repository = scope.ServiceProvider.GetRequiredService<IMigrationRunRepository>();
                var container = await repository.GetDataSourceRunbyIdAsync(migrationId, token);
                if (container != null)
                {
                    migrationInfo = container;
                }
                else
                {
                    return null;
                }
            }

            return GetAllContainersAdminAsync(migrationInfo);
        }

        public async Task<MigrationRunInfoModel> RetriveMigrationRunInformationAsync(int MigrationId)
        {
            var info = new MigrationRunInfoModel
            {
                MigrationRunDataSourceId = migrationInfo.SourcesRunModel.Id,
                MigrationRunDataDestinationId = migrationInfo.DestinationRunModel.Id,
                MigrationRunId = migrationInfo.SourcesRunModel.MigrationRunId,
                MigrationId = MigrationId
            };

            return info;
        }

        public ContainerResource GetAllContainersAdminAsync(RunMigrationVM input)
        {
            var container = new StorageContainerConfiguration
            {
                Name = input.SourcesRunModel.Name,
                Type = (StorageContainerType)(int)input.SourcesRunModel.ContainerType,
                ContainerAccountName = input.SourcesRunModel.ContainerAccountName,
                ContainerConnectionString = input.SourcesRunModel.ContainerConnectionString,
                ContainerKey = input.SourcesRunModel.ContainerKey,
                ContainerAccountUrl = input.SourcesRunModel.ContainerAccountUrl,
                ContainerName = input.SourcesRunModel.ContainerName,
                ProxyUrl = input.SourcesRunModel.ProxyUrl,
                ContainerUserId = input.SourcesRunModel.ContainerUserId,
            };
            
            var containerInfo = Convert(container);
            return containerInfo;
        }

        private static ContainerResource Convert(StorageContainerConfiguration item)
        {
            return new ContainerResource(item.Name) { Configuration = item };
        }
    }
}
