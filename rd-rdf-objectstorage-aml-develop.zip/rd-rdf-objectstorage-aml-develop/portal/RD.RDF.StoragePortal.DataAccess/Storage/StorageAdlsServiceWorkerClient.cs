﻿using Azure;
using Azure.Storage.Files.DataLake;
using Azure.Storage.Files.DataLake.Models;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Filters;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Storage
{
    public class StorageAdlsServiceWorkerClient : IStorageWorkerClient
    {
        private readonly ConcurrentDictionary<string, DataLakeServiceClient> Services = new ConcurrentDictionary<string, DataLakeServiceClient>();
        private readonly ILogger<StorageAdlsServiceWorkerClient> logger;

        public StorageContainerType StorageClientType => StorageContainerType.azureadls;

        public StorageAdlsServiceWorkerClient(ILogger<StorageAdlsServiceWorkerClient> logger)
        {
            this.logger = logger;
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            List<FileResource> fr = new List<FileResource>();
            var containerClient = GetFileSystemClient(container);
            try
            {
                var resultSegment = containerClient.GetPathsAsync();

                await foreach (PathItem pathItem in resultSegment)
                {
                    fr.Add(new FileResource(pathItem.Name)
                    {
                        ModifiedTime = pathItem.LastModified,
                        CreationTime = pathItem.CreatedOn,
                        FileBlobType = pathItem.GetType().ToString(),
                        FileGuid = pathItem.CreatedOn.ToString(),
                        FilePath = pathItem.Name,
                        FolderName = (pathItem.Name.Contains('/') ? pathItem.Name.Substring(0, pathItem.Name.LastIndexOf('/', 0)) : string.Empty),
                        FileETag = pathItem.ETag.ToString(),
                        FileSize = pathItem.ContentLength
                    });

                }
                return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, null);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<List<FileResource>>(ex.Message, filter.ContinuationToken, filter.Limit);
            }
        }

        private DataLakeFileSystemClient GetFileSystemClient(ContainerResource container)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetFileSystemClient(container.Configuration.ContainerName);
            return containerClient;
        }

        private DataLakeServiceClient GetServiceClient(ContainerResource container)
        {
            if (!Services.TryGetValue(container.ContainerName, out DataLakeServiceClient serviceClient))
            {
                serviceClient = new DataLakeServiceClient(container?.Configuration?.ContainerConnectionString);
                Services.TryAdd(container.ContainerName, serviceClient);
            }
            return serviceClient;
        }

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            // passing null version id to fetch the latest version (default)
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);

        }

        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = string.IsNullOrEmpty(parentFolder.FolderName) ? fileName : $"{parentFolder.FolderName}{Path.AltDirectorySeparatorChar}{fileName}";
            var containerClient = GetFileSystemClient(container);
            var adlsClient = containerClient.GetFileClient(blobName);
            try
            {
                var props = await adlsClient.GetPropertiesAsync(default, cancellationToken: token);
                props.Value.Metadata.TryGetValue("FileGuid", out string fileGuid);
                return new FileResource(fileName)
                {
                    FileSize = props.Value.ContentLength,
                    ModifiedTime = props.Value.LastModified,
                    CreationTime = props.Value.CreatedOn,
                    FileContentType = props.Value.ContentType,
                    FileETag = props.Value.ETag.ToString("G"),
                    FileVersionId = props.Value.CreatedOn.ToString(),
                    FileVersions = new List<VersionDetails>
                    {
                        new VersionDetails
                    {
                      FileSize = props.Value.ContentLength,
                      CreationTime = props.Value.CreatedOn,
                      FileETag = props.Value.ETag.ToString("G"),
                      FileVersionId = props.Value.CreatedOn.ToString(),
                      FileGuid = props.Value.CreatedOn.ToString()
                    }
                    },
                    FileGuid = props.Value.CreatedOn.ToString(),
                    FilePath = blobName,
                    FolderName = folderName,
                    Metadata = new MetadataDictionary(props.Value.Metadata)
                };
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return null;
            }
        }

        private static FolderResource GetParentFolder(ContainerResource container, string folderName)
        {
            FolderResource parentFolder = new FolderResource(string.Empty);
            if (!string.IsNullOrEmpty(folderName))
            {
                parentFolder = FolderResource.CreateEmptyFolder(HandleFolderName(folderName));
            }

            return parentFolder;
        }

        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }

        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            var adlsClient = GetFileClient(container, file);
            var downloadStream = await adlsClient.ReadAsync(cancellationToken: token);
            return downloadStream.Value.Content;
        }

        private DataLakeFileClient GetFileClient(ContainerResource container, FileResource fileInfo)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetFileSystemClient(container.Configuration.ContainerName);
            return containerClient.GetFileClient(fileInfo.FilePath);
        }

        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folderName, Stream fileData, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = string.IsNullOrEmpty(parentFolder.FolderName) ? fileName : $"{parentFolder.FolderName}{Path.AltDirectorySeparatorChar}{fileName}";

            var fileInfo = new FileResource(fileName) { FilePath = blobName };
            var adlsClient = GetFileClient(container, fileInfo);

            DataLakeFileUploadOptions dataLakeFileUploadOptions = new DataLakeFileUploadOptions();
            
            await adlsClient.UploadAsync(fileData, dataLakeFileUploadOptions, token);

            var returnFileInfo = await GetOneFileInformationAsync(container, fileName, folderName, token);
            return returnFileInfo;

        }

    }
}
