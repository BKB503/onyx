﻿using Microsoft.EntityFrameworkCore;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Context
{
    public class ContainersDbContext: DbContext
    {
        public ContainersDbContext(DbContextOptions<ContainersDbContext> contextOptions) : base(contextOptions)
        {
        }

        public DbSet<ContainersPropertiesDbModel> StorageProperties { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //setting the  db Model requirements
            modelBuilder.Entity<ContainersPropertiesDbModel>().HasKey(key => key.ContainerId);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.Name).HasMaxLength(150);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ContainerType).HasMaxLength(30);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ContainerAccountName).HasMaxLength(250);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ContainerAccountUrl).HasMaxLength(150);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ContainerConnectionString).HasMaxLength(150);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ContainerKey).HasMaxLength(30);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ContainerUserId).HasMaxLength(250);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.AllianceTagName).HasMaxLength(150);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.IsValidateAudience).(150);
            //modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ValidAudiences).HasMaxLength(30);
            modelBuilder.Entity<ContainersPropertiesDbModel>().Property(p => p.ProxyUrl).HasMaxLength(250);
        }
    }
}
