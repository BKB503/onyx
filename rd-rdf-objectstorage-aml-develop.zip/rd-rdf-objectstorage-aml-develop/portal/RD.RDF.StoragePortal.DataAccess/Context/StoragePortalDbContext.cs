﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.DataEncryption;
using Microsoft.EntityFrameworkCore.DataEncryption.Providers;
using Microsoft.Extensions.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;

namespace RD.RDF.StoragePortal.DataAccess.Context
{

    // If you need a migration to be added in VS Package Management console window - with Default Project set to RD.RDF.StoragePortal.DataAccess
    // Add-Migration <name of migration>


    public class StoragePortalDbContext : DbContext
    { 
        private readonly byte[] _encryptionKey;
        private readonly byte[] _encryptionIV;
        private readonly IEncryptionProvider _provider;
         
        public StoragePortalDbContext(DbContextOptions<StoragePortalDbContext> contextOptions, IConfiguration configuration) : base(contextOptions)
        { 
            // key and IV has to be stored in Azure Key Vault as Base64 encrypted values
            this._encryptionKey = Convert.FromBase64String(configuration["PortalDb-Key"]);
            this._encryptionIV = Convert.FromBase64String(configuration["PortalDb-IV"]); 
            this._provider = new AesProvider(this._encryptionKey, this._encryptionIV);
        }

        public DbSet<StoragePropertiesDbModel> StorageProperties { get; set; }
        public DbSet<MigrationsDbModel> Migrations { get; set; }
        public DbSet<MigrationDataSourcesDbModel> MigrationDataSources { get; set; }
        public DbSet<ContainersDbModel> Containers { get; set; }
        public DbSet<AudiencesDbModel> Audiences { get; set; }

        public DbSet<MigrationRunsDbModel> MigrationRuns { get; set; }
        public DbSet<MigrationRunDataSourcesDbModel> MigrationRunDataSources { get; set; }
        public DbSet<MigrationRunObjectsDbModel> MigrationRunObjects { get; set; }
        public DbSet<IndexesDbModel> Indexes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.UseEncryption(this._provider);


            //setting the  db Model requirements
            modelBuilder.Entity<StoragePropertiesDbModel>().HasKey(key => key.Id);
            //both of those properties has to be aligned to name length in Index and container name
            modelBuilder.Entity<StoragePropertiesDbModel>().Property(p => p.DefaultContainer).HasMaxLength(150);
            modelBuilder.Entity<StoragePropertiesDbModel>().Property(p => p.DefaultIndex).HasMaxLength(150);


            //setting the  MigrationDbModel properties
            modelBuilder.Entity<MigrationsDbModel>().HasKey(key => key.Id);
            modelBuilder.Entity<MigrationsDbModel>().Property(key => key.Name).IsRequired().HasMaxLength(150);
            modelBuilder.Entity<MigrationsDbModel>().Property(key => key.Description).HasMaxLength(2000);
            modelBuilder.Entity<MigrationsDbModel>().Property(key => key.IsDeleted).IsRequired();
            modelBuilder.Entity<MigrationsDbModel>().Property(key => key.MigrationRunActive).IsRequired();
            modelBuilder.Entity<MigrationsDbModel>().Property(key => key.MigrationType).HasMaxLength(30);
            modelBuilder.Entity<MigrationsDbModel>().Property(p => p.CreateDate).IsRequired();

            modelBuilder.Entity<MigrationsDbModel>().Property(key => key.MigrationType)
            .HasConversion(p => p.ToString(), p => (MigrationType)Enum.Parse(typeof(MigrationType), p));

            //setting the  MigrationRunsDbModel properties
            modelBuilder.Entity<MigrationRunsDbModel>().Property(key => key.RunStatus).HasConversion(
            p => p.ToString(), p => (RunStatusEnum)Enum.Parse(typeof(RunStatusEnum), p));

            modelBuilder.Entity<MigrationRunsDbModel>().Property(key => key.RunStage).HasConversion(
            p => p.ToString(), p => (RunStageEnum)Enum.Parse(typeof(RunStageEnum), p));

            modelBuilder.Entity<MigrationRunsDbModel>().Property(key => key.MigrationType).HasMaxLength(30);

            modelBuilder.Entity<MigrationRunsDbModel>().Property(key => key.MigrationType)
           .HasConversion(p => p.ToString(), p => (MigrationType)Enum.Parse(typeof(MigrationType), p));

            //setting the  MigrationDataSourcesDbModel properties
            modelBuilder.Entity<MigrationDataSourcesDbModel>().HasKey(key => key.Id);
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.CreateDate).IsRequired();
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.MigrationId).IsRequired();
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.DataSourceType).IsRequired();
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.ContainerType).HasMaxLength(30);
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.ContainerUserId).HasMaxLength(150);
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.ProxyUrl).HasMaxLength(1024);
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(p => p.CreateDate).IsRequired();
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(p => p.ContainerConnectionString).HasColumnType("text");
            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(p => p.ContainerKey).HasColumnType("text");

            modelBuilder.Entity<MigrationDataSourcesDbModel>().HasOne(fk => fk.Migration)
                                                              .WithMany(m => m.MigrationDataSources)
                                                              .HasForeignKey(key => key.MigrationId)
                                                              .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.ContainerType).HasConversion(
            p => p.ToString(), p => (StoragePortalContainerType)Enum.Parse(typeof(StoragePortalContainerType), p));

            modelBuilder.Entity<MigrationDataSourcesDbModel>().Property(key => key.DataSourceType).HasConversion(
            p => p.ToString(), p => (DataSourceType)Enum.Parse(typeof(DataSourceType), p));

            //setting the  MigrationRunDataSourcesDbModel properties
            modelBuilder.Entity<MigrationRunDataSourcesDbModel>().Property(key => key.ContainerType).HasConversion(
            p => p.ToString(), p => (StoragePortalContainerType)Enum.Parse(typeof(StoragePortalContainerType), p));

            modelBuilder.Entity<MigrationRunDataSourcesDbModel>().Property(key => key.DataSourceType).HasConversion(
            p => p.ToString(), p => (DataSourceType)Enum.Parse(typeof(DataSourceType), p));

            //setting the  MigrationRunObjectsDbModel properties
            modelBuilder.Entity<MigrationRunObjectsDbModel>().Property(key => key.FileMigrationStatus).HasConversion(
            p => p.ToString(), p => (FileMigrationStatus)Enum.Parse(typeof(FileMigrationStatus), p));

            modelBuilder.Entity<MigrationRunDataSourcesDbModel>().Property(p => p.ContainerConnectionString).HasColumnType("text");
            modelBuilder.Entity<MigrationRunDataSourcesDbModel>().Property(p => p.ContainerKey).HasColumnType("text");


            //setting the  ContainersDbModel properties
            modelBuilder.Entity<ContainersDbModel>().HasKey(key => key.Id);
            modelBuilder.Entity<ContainersDbModel>().Property(key => key.Id).HasColumnName("ContainerId");
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.Name).HasMaxLength(150);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ContainerType).HasMaxLength(30);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ContainerAccountName).HasMaxLength(250);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ContainerAccountUrl).HasMaxLength(150);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ContainerConnectionString).HasColumnType("text");
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ContainerKey).HasColumnType("text");
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ContainerUserId).HasMaxLength(250);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.AllianceTagName).HasMaxLength(150);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ValidateAudience).HasDefaultValue(false);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.ProxyUrl).HasMaxLength(250);
            modelBuilder.Entity<ContainersDbModel>().Property(p => p.CreateDate).IsRequired();

            modelBuilder.Entity<AudiencesDbModel>().HasKey(key => key.Id);
            modelBuilder.Entity<AudiencesDbModel>().Property(p => p.ValidAudience).HasMaxLength(250);
            modelBuilder.Entity<AudiencesDbModel>().HasIndex(p => p.ContainerId);
            modelBuilder.Entity<AudiencesDbModel>().HasOne(x => x.StorageContainers).WithMany(x => x.Audiences).HasForeignKey(x => x.ContainerId);
            modelBuilder.Entity<AudiencesDbModel>().Property(p => p.CreateDate).IsRequired();

            //setting the  IndexingDbModel properties
            modelBuilder.Entity<IndexesDbModel>().HasKey(key => key.Id);
            modelBuilder.Entity<IndexesDbModel>().Property(key => key.Id).HasColumnName("IndexId");
            modelBuilder.Entity<IndexesDbModel>().Property(p => p.RDFKafkaTopic).HasMaxLength(150);
            modelBuilder.Entity<IndexesDbModel>().Property(p => p.Type).HasMaxLength(150).IsRequired();
            modelBuilder.Entity<IndexesDbModel>().Property(p => p.RDFKafkaConnectionString).HasColumnType("text");
            modelBuilder.Entity<IndexesDbModel>().Property(p => p.RDFKafkaKey).HasMaxLength(150);
            modelBuilder.Entity<IndexesDbModel>().Property(p => p.SaslUsername).HasMaxLength(150);
            modelBuilder.Entity<IndexesDbModel>().Property(p => p.IndexOdbcConnectionString).HasColumnType("text");
            modelBuilder.Entity<IndexesDbModel>().Property(p => p.CreateDate).IsRequired();
            modelBuilder.Entity<IndexesDbModel>().HasMany(p => p.Containers).WithOne(c => c.Index).IsRequired();
        }
    }
}
