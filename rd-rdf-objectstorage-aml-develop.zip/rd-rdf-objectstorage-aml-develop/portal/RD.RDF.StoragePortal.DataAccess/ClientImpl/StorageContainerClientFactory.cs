﻿
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.ClientImpl
{
    public class StorageContainerClientFactory : IStorageContainerClientFactory
    {
        private readonly Dictionary<StorageContainerType, IStorageWorkerClient> ClientsDictionary;

        public StorageContainerClientFactory(IEnumerable<IStorageWorkerClient> clients)
        {
            ClientsDictionary = clients.ToDictionary(item => item.StorageClientType);
        }

        public IStorageWorkerClient GetStorageClient(ContainerResource container)
        {
            ClientsDictionary.TryGetValue(container.Configuration.Type, out IStorageWorkerClient client);
            return client;
        }
    }
}
