﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;


namespace RD.RDF.StoragePortal.DataAccess.Messaging
{
    public class KafkaConsumerClient : IDisposable 
    {
        private readonly ConsumerConfig config;

        private readonly IConsumer<Ignore, string> consumer;
        private readonly ILogger<KafkaConsumerClient> logger;

        public KafkaConsumerClient(ConsumerConfig config, ILogger<KafkaConsumerClient> logger)
        {
            if (config is null)
            {
                throw new ArgumentNullException(nameof(config));
            }            
            this.consumer = new ConsumerBuilder<Ignore, string>(config)                                     
                                    .SetErrorHandler((msg, e) => logger.LogError(e.Reason))                                    
                                    .Build();
            this.logger = logger;
        }

        public void Subscribe(string topic)
        {
            consumer.Subscribe(topic);
        }

        public ConsumeResult<Ignore, string> Consume(CancellationToken cancellationToken)
        {
            return consumer.Consume(cancellationToken);
        }

        public void StoreOffset(TopicPartitionOffset topicPartitionOffset)
        {
            consumer.StoreOffset(topicPartitionOffset);
        }  

        public void Dispose()
        {
            try
            {
                if (this.consumer != null)
                {
                    this.consumer.Close();
                    this.consumer.Dispose();
                }
            }
            catch
            {                
            }
        }
    }
}
