﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Configuration;
using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Messaging
{
    public class KafkaWorkerLoop
    {
        private readonly ILogger<KafkaWorkerLoop> logger;
        private readonly ILoggerFactory loggerFactory;
        private readonly JsonSerializerOptions serializerOptions;

        public KafkaWorkerLoop(ILogger<KafkaWorkerLoop> logger, ILoggerFactory loggerFactory)
        {
            if (logger is null)
            {
                throw new ArgumentNullException(nameof(logger));
            }

            this.logger = logger;
            this.loggerFactory = loggerFactory;
            this.serializerOptions = new JsonSerializerOptions()
            {
                PropertyNameCaseInsensitive = true 
            };
            this.serializerOptions.Converters.Add(new JsonStringEnumConverter());
        }


        public async Task SubscribeAndHandleAsync<TValue>(KafkaConfiguration kafkaConfiguration, Func<TValue, Task<bool>> handler, CancellationToken cancellationToken) where TValue : class
        {
            bool cancelled = cancellationToken.IsCancellationRequested;
            var config = Convert(kafkaConfiguration);
            var kafkaLowLeverLogger = loggerFactory.CreateLogger<KafkaConsumerClient>();
            using (var consumer = new KafkaConsumerClient(config, kafkaLowLeverLogger))
            {
                consumer.Subscribe(kafkaConfiguration.KafkaTopic);
                while (!cancelled)
                {
                    try
                    {
                        var consumeResult = consumer.Consume(cancellationToken);
                        string msgBody = consumeResult?.Message?.Value;
                        TValue value = JsonSerializer.Deserialize<TValue>(msgBody, serializerOptions);
                            // handle consumed message
                        bool result = await handler(value);
                            if (result)
                            {
                                consumer.StoreOffset(consumeResult.TopicPartitionOffset);
                            }
                            else
                            {
                                // log the
                            }
                        
                        cancelled = cancellationToken.IsCancellationRequested;
                    }
                    catch (Exception ex)
                    {
                        this.logger.LogError(ex, ex.Message);
                    }
                }
            }
        }

        private static ConsumerConfig Convert(KafkaConfiguration kafkaConfiguration)
        {
            return new ConsumerConfig
            {
                SaslPassword = kafkaConfiguration.SaslPassword,
                BootstrapServers = kafkaConfiguration.KafkaServers,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = kafkaConfiguration.SaslUsername,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                // SslCaLocation = container.indexingConfiguration.SslCaLocation,
                Debug = "consumer",// "security,broker,protocol",
                //set defaults 
                StatisticsIntervalMs = 5000,
                SessionTimeoutMs = 6000,
                AutoOffsetReset = AutoOffsetReset.Earliest,
                EnableAutoCommit = true,
                EnableAutoOffsetStore = false,
                EnablePartitionEof = false,
                GroupId = kafkaConfiguration.KafkaGroupId
            };
        }


    }
}
