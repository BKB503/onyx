﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RD.RDF.StoragePortal.DataAccess.Migrations
{
    public partial class Migrationtbl : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Migrations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(2000)", nullable: true),
                    LastMigrationRunDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastMigrationFinishDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MigrationRunCount = table.Column<int>(type: "int", nullable: false),
                    MigrationStatus = table.Column<int>(type: "int", nullable: false),
                    MigrationType = table.Column<string>(type: "nvarchar(30)", nullable: true),
                    MigrationRunActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Migrations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MigrationDataSources",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MigrationId = table.Column<int>(type: "int", nullable: false),
                    DataSourceType = table.Column<bool>(type: "bit", nullable: false),
                    ContainerType = table.Column<string>(type: "nvarchar(30)", nullable: true),
                    ContainerAccountName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerAccountUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerConnectionString = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerKey = table.Column<int>(type: "int", nullable: false),
                    ContainerUserId = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    ProxyUrl = table.Column<string>(type: "nvarchar(1024)", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MigrationDataSources", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MigrationDataSources_Migrations_MigrationId",
                        column: x => x.MigrationId,
                        principalTable: "Migrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MigrationDataSources_MigrationId",
                table: "MigrationDataSources",
                column: "MigrationId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MigrationDataSources");

            migrationBuilder.DropTable(
                name: "Migrations");
        }
    }
}
