﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RD.RDF.StoragePortal.DataAccess.Migrations
{
    public partial class migrationtablesadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Migrations",
                type: "nvarchar(150)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldNullable: true);

            migrationBuilder.AlterColumn<short>(
                name: "MigrationStatus",
                table: "Migrations",
                type: "smallint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<short>(
                name: "MigrationRunCount",
                table: "Migrations",
                type: "smallint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateTable(
                name: "MigrationRuns",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MigrationId = table.Column<int>(type: "int", nullable: false),
                    RunStartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RunFinishDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RunStatus = table.Column<string>(type: "nvarchar(30)", nullable: true),
                    RunStage = table.Column<string>(type: "nvarchar(30)", nullable: true),
                    RunObjectsCount = table.Column<long>(type: "bigint", nullable: false),
                    RunObjectsMigrated = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MigrationRuns", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MigrationRuns_Migrations_MigrationId",
                        column: x => x.MigrationId,
                        principalTable: "Migrations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MigrationRunDataSources",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MigrationId = table.Column<int>(type: "int", nullable: false),
                    MigrationRunId = table.Column<int>(type: "int", nullable: false),
                    DataSourceType = table.Column<bool>(type: "bit", nullable: false),
                    ContainerType = table.Column<string>(type: "nvarchar(30)", nullable: false),
                    ContainerAccountName = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    ContainerAccountUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerConnectionString = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerKey = table.Column<int>(type: "int", nullable: false),
                    ContainerUserId = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    ProxyUrl = table.Column<string>(type: "nvarchar(1024)", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MigrationRunDataSources", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MigrationRunDataSources_MigrationRuns_MigrationRunId",
                        column: x => x.MigrationRunId,
                        principalTable: "MigrationRuns",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);                     
                });

            migrationBuilder.CreateIndex(
                name: "IX_MigrationRunDataSources_MigrationId",
                table: "MigrationRunDataSources",
                column: "MigrationId");

            migrationBuilder.CreateIndex(
                name: "IX_MigrationRunDataSources_MigrationRunId",
                table: "MigrationRunDataSources",
                column: "MigrationRunId");

            migrationBuilder.CreateIndex(
                name: "IX_MigrationRuns_MigrationId",
                table: "MigrationRuns",
                column: "MigrationId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MigrationRunDataSources");

            migrationBuilder.DropTable(
                name: "MigrationRuns");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "Migrations",
                type: "nvarchar(150)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)");

            migrationBuilder.AlterColumn<int>(
                name: "MigrationStatus",
                table: "Migrations",
                type: "int",
                nullable: false,
                oldClrType: typeof(short),
                oldType: "smallint");

            migrationBuilder.AlterColumn<int>(
                name: "MigrationRunCount",
                table: "Migrations",
                type: "int",
                nullable: false,
                oldClrType: typeof(short),
                oldType: "smallint");
        }
    }
}
