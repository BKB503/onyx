﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RD.RDF.StoragePortal.DataAccess.Migrations
{
    public partial class Add_Indexes_table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Indexes",
                columns: table => new
                {
                    IndexId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RDFKafkaTopic = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    Type = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    RDFKafkaConnectionString = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    RDFKafkaKey = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    KafkaServers = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SaslUsername = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    IndexOdbcConnectionString = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    ContainerId = table.Column<int>(type: "int", maxLength: 150, nullable: false),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Indexes", x => x.IndexId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Indexes");
        }
    }
}
