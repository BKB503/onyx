﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RD.RDF.StoragePortal.DataAccess.Migrations
{
    public partial class FixingModelAndAddingMissingMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {            
            migrationBuilder.DropIndex(
                name: "IX_MigrationRunDataSources_MigrationId",
                table: "MigrationRunDataSources");

            migrationBuilder.DropColumn(
                name: "MigrationId",
                table: "MigrationRunDataSources");

            migrationBuilder.AlterColumn<int>(
                name: "MigrationStatus",
                table: "Migrations",
                type: "int",
                nullable: false,
                oldClrType: typeof(short),
                oldType: "smallint");

            migrationBuilder.AlterColumn<int>(
                name: "MigrationRunCount",
                table: "Migrations",
                type: "int",
                nullable: false,
                oldClrType: typeof(short),
                oldType: "smallint");

            migrationBuilder.AddColumn<DateTime>(
                name: "CreateDate",
                table: "Migrations",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdateDate",
                table: "Migrations",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RunStatus",
                table: "MigrationRuns",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RunStage",
                table: "MigrationRuns",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)",
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreateDate",
                table: "MigrationRuns",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdateDate",
                table: "MigrationRuns",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "UpdateDate",
                table: "MigrationRunDataSources",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.AlterColumn<string>(
                name: "ProxyUrl",
                table: "MigrationRunDataSources",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(1024)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContainerUserId",
                table: "MigrationRunDataSources",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContainerType",
                table: "MigrationRunDataSources",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)");

            migrationBuilder.AlterColumn<string>(
                name: "ContainerAccountName",
                table: "MigrationRunDataSources",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(250)",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "UpdateDate",
                table: "MigrationDataSources",
                type: "datetime2",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "datetime2");

            migrationBuilder.CreateTable(
                name: "Containers",
                columns: table => new
                {
                    ContainerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    ContainerType = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    ContainerAccountName = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    ContainerAccountUrl = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    ContainerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ContainerConnectionString = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    ContainerKey = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    ContainerUserId = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    AllianceTagName = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    ValidateAudience = table.Column<bool>(type: "bit", nullable: false, defaultValue: false),
                    ProxyUrl = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Containers", x => x.ContainerId);
                });

            migrationBuilder.CreateTable(
                name: "MigrationRunObjects",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MigrationRunId = table.Column<int>(type: "int", nullable: false),
                    MigrationRunDataSourceId = table.Column<int>(type: "int", nullable: false),
                    MigrationRunDataDestinationId = table.Column<int>(type: "int", nullable: false),
                    FileName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FilePath = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FileSize = table.Column<int>(type: "int", nullable: false),
                    FileMigrationStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MigrationRunObjects", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MigrationRunObjects_MigrationRuns_MigrationRunId",
                        column: x => x.MigrationRunId,
                        principalTable: "MigrationRuns",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Audiences",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ValidAudience = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    ContainerId = table.Column<int>(type: "int", nullable: false),
                    CreateDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdateDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Audiences", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Audiences_Containers_ContainerId",
                        column: x => x.ContainerId,
                        principalTable: "Containers",
                        principalColumn: "ContainerId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Audiences_ContainerId",
                table: "Audiences",
                column: "ContainerId");

            migrationBuilder.CreateIndex(
                name: "IX_MigrationRunObjects_MigrationRunId",
                table: "MigrationRunObjects",
                column: "MigrationRunId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Audiences");

            migrationBuilder.DropTable(
                name: "MigrationRunObjects");

            migrationBuilder.DropTable(
                name: "Containers");

            migrationBuilder.DropColumn(
                name: "CreateDate",
                table: "Migrations");

            migrationBuilder.DropColumn(
                name: "UpdateDate",
                table: "Migrations");

            migrationBuilder.DropColumn(
                name: "CreateDate",
                table: "MigrationRuns");

            migrationBuilder.DropColumn(
                name: "UpdateDate",
                table: "MigrationRuns");

            migrationBuilder.AlterColumn<short>(
                name: "MigrationStatus",
                table: "Migrations",
                type: "smallint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<short>(
                name: "MigrationRunCount",
                table: "Migrations",
                type: "smallint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "RunStatus",
                table: "MigrationRuns",
                type: "nvarchar(30)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RunStage",
                table: "MigrationRuns",
                type: "nvarchar(30)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "UpdateDate",
                table: "MigrationRunDataSources",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ProxyUrl",
                table: "MigrationRunDataSources",
                type: "nvarchar(1024)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContainerUserId",
                table: "MigrationRunDataSources",
                type: "nvarchar(150)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContainerType",
                table: "MigrationRunDataSources",
                type: "nvarchar(30)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContainerAccountName",
                table: "MigrationRunDataSources",
                type: "nvarchar(250)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MigrationId",
                table: "MigrationRunDataSources",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<DateTime>(
                name: "UpdateDate",
                table: "MigrationDataSources",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "datetime2",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_MigrationRunDataSources_MigrationId",
                table: "MigrationRunDataSources",
                column: "MigrationId");             
        }
    }
}
