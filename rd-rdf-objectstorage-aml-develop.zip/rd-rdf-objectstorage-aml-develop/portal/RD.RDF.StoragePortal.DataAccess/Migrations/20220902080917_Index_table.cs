﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RD.RDF.StoragePortal.DataAccess.Migrations
{
    public partial class Index_table : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ContainerId",
                table: "Indexes");

            migrationBuilder.AddColumn<int>(
                name: "IndexId",
                table: "Containers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Containers_IndexId",
                table: "Containers",
                column: "IndexId");

            migrationBuilder.AddForeignKey(
                name: "FK_Containers_Indexes_IndexId",
                table: "Containers",
                column: "IndexId",
                principalTable: "Indexes",
                principalColumn: "IndexId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Containers_Indexes_IndexId",
                table: "Containers");

            migrationBuilder.DropIndex(
                name: "IX_Containers_IndexId",
                table: "Containers");

            migrationBuilder.DropColumn(
                name: "IndexId",
                table: "Containers");

            migrationBuilder.AddColumn<int>(
                name: "ContainerId",
                table: "Indexes",
                type: "int",
                maxLength: 150,
                nullable: false,
                defaultValue: 0);
        }
    }
}
