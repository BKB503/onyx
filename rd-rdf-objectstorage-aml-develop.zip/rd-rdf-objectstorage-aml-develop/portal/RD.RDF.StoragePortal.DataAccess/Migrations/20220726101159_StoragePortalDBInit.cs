﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RD.RDF.StoragePortal.DataAccess.Migrations
{
    public partial class StoragePortalDBInit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "StorageProperties",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DefaultContainer = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true),
                    DefaultIndex = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StorageProperties", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StorageProperties");
        }
    }
}
