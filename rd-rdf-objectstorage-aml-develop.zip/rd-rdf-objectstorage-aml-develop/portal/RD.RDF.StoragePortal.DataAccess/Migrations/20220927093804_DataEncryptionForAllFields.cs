﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RD.RDF.StoragePortal.DataAccess.Migrations
{
    public partial class DataEncryptionForAllFields : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "FileSize",
                table: "MigrationRunObjects",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");
             
            migrationBuilder.DropColumn(
                name: "ContainerKey",
                table: "MigrationRunDataSources"
                );

            migrationBuilder.AddColumn<string>(
                name: "ContainerKey",
                table: "MigrationRunDataSources",
                type: "text",
                nullable: true);
            
            migrationBuilder.AlterColumn<string>(
                name: "ContainerConnectionString",
                table: "MigrationRunDataSources",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
             
            migrationBuilder.DropColumn(
              name: "ContainerKey",
              table: "MigrationDataSources"
              );

            migrationBuilder.AddColumn<string>(
                name: "ContainerKey",
                table: "MigrationDataSources",
                type: "text",
                nullable: true);
             

            migrationBuilder.AlterColumn<string>(
                name: "ContainerConnectionString",
                table: "MigrationDataSources",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RDFKafkaConnectionString",
                table: "Indexes",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IndexOdbcConnectionString",
                table: "Indexes",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(150)",
                oldMaxLength: 150,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContainerKey",
                table: "Containers",
                type: "text",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(30)",
                oldMaxLength: 30,
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "FileSize",
                table: "MigrationRunObjects",
                type: "int",
                nullable: false,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.DropColumn(
               name: "ContainerKey",
               table: "MigrationRunDataSources"
               );

            migrationBuilder.AddColumn<string>(
                name: "ContainerKey",
                table: "MigrationRunDataSources",
                type: "int",
                nullable: false,
                defaultValue: 0); 

            migrationBuilder.AlterColumn<string>(
                name: "ContainerConnectionString",
                table: "MigrationRunDataSources",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.DropColumn(
               name: "ContainerKey",
               table: "MigrationDataSources"
               );

            migrationBuilder.AddColumn<string>(
                name: "ContainerKey",
                table: "MigrationDataSources",
                type: "int",
                nullable: false,
                defaultValue: 0);
              
            migrationBuilder.AlterColumn<string>(
                name: "ContainerConnectionString",
                table: "MigrationDataSources",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "RDFKafkaConnectionString",
                table: "Indexes",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "IndexOdbcConnectionString",
                table: "Indexes",
                type: "nvarchar(150)",
                maxLength: 150,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ContainerKey",
                table: "Containers",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "text",
                oldNullable: true);
        }
    }
}
