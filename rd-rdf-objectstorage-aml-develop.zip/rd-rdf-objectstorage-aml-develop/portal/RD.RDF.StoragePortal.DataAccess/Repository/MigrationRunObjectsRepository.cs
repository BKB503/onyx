﻿using Confluent.Kafka;
using EFCore.BulkExtensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Contracts.Messages;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Model.Wrappers;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Repository
{
    public class MigrationRunObjectsRepository : IMigrationRunObjectsRepository
    {
        private readonly StoragePortalDbContext dbContext;
        public MigrationRunObjectsRepository(StoragePortalDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<int> InsertRunObjectsRecord(MigrationRunObjectsModel input, CancellationToken token)
        {
            var objectInfo = RevMap(input);
            await this.dbContext.MigrationRunObjects.AddAsync(objectInfo, token);
            await this.dbContext.SaveChangesAsync();

            return objectInfo.Id;
        }

        private static MigrationRunObjectsDbModel RevMap(MigrationRunObjectsModel input)
        {
            return new MigrationRunObjectsDbModel
            {
                Id = input.Id,
                MigrationRunId = input.MigrationRunId,
                MigrationRunDataSourceId = input.MigrationRunDataSourceId,
                MigrationRunDataDestinationId = input.MigrationRunDataDestinationId,
                FileName = input.FileName,
                FilePath = input.FilePath,
                FileMigrationStatus = input.FileMigrationStatus,
                FileSize = input.FileSize
            };
        }
    }
}
