﻿using Microsoft.EntityFrameworkCore;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Repository
{
    public class MigrationsRepository : IMigrationsRepository
    {
        private readonly StoragePortalDbContext dbContext;
        public MigrationsRepository(StoragePortalDbContext dbContext)
        {
            this.dbContext = dbContext;
        }


        public async Task<int> AddAsync(MigrationsModel dbModel, CancellationToken token)
        {
            var entity = Map(dbModel);
            await dbContext.Migrations.AddAsync(entity, token);
            await dbContext.SaveChangesAsync();
            int id = entity.Id;
            return id;
        }

        public async Task<int> AddDataSourceAsync(MigrationDataSourcesModel dbModel1, int migrationId, CancellationToken token)
        {
            dbModel1.MigrationId = migrationId;
            var entitydatasource = MapDataSource(dbModel1);
            await dbContext.MigrationDataSources.AddAsync(entitydatasource, token);
            await dbContext.SaveChangesAsync();
            return entitydatasource.Id;

        }

        private static MigrationsDbModel Map(MigrationsModel dbModel)
        {
            return new MigrationsDbModel
            {
                Id = dbModel.Id,
                Name = dbModel.Name,
                Description = dbModel.Description,
                IsDeleted = dbModel.IsDeleted,
                MigrationStatus = dbModel.MigrationStatus,
                MigrationRunActive = dbModel.MigrationRunActive,
                MigrationRunCount = dbModel.MigrationRunCount,
                MigrationType = dbModel.MigrationType,
                LastMigrationFinishDate = dbModel.LastMigrationFinishDate,
                LastMigrationRunDate = dbModel.LastMigrationRunDate,
                Actions = dbModel.Actions,
                Summary = dbModel.Summary

            };
        }

        private static MigrationDataSourcesDbModel MapDataSource(MigrationDataSourcesModel dbsourceModel)
        {

            return new MigrationDataSourcesDbModel
            {
                Id = dbsourceModel.Id,
                MigrationId = dbsourceModel.MigrationId,
                CreateDate = dbsourceModel.CreateDate,
                UpdateDate = dbsourceModel.UpdateDate,
                DataSourceType = dbsourceModel.DataSourceType,
                ContainerType = dbsourceModel.ContainerType,
                ContainerAccountName = dbsourceModel.ContainerAccountName,
                ContainerAccountUrl = dbsourceModel.ContainerAccountUrl,
                ContainerName = dbsourceModel.ContainerName,
                ContainerConnectionString = dbsourceModel.ContainerConnectionString,
                ContainerKey = dbsourceModel.ContainerKey,
                ContainerUserId = dbsourceModel.ContainerUserId,
                ProxyUrl = dbsourceModel.ProxyUrl


            };
        }

        public async Task<List<DataSourceMigrationVM>> GetAllAsync(CancellationToken token)
        {
            
            var result = await dbContext.MigrationDataSources.Include(x => x.Migration).ToListAsync(token);

            List<DataSourceMigrationVM> lstviewmodel = new List<DataSourceMigrationVM>();
            var previousMigid = 0;
            Boolean addtolist = false;
            DataSourceMigrationVM dsmigrationvm = null;
            foreach (var item in result)
            {
                if (item.MigrationId != previousMigid)
                {
                    addtolist = true;
                    dsmigrationvm = new DataSourceMigrationVM();
                    previousMigid = item.MigrationId;
                }
                    if (DataSourceType.Source == item.DataSourceType)
                    {
                        dsmigrationvm.SourcesModel = new MigrationDataSourcesModel
                        {
                            Id = item.Id,
                            MigrationId = item.MigrationId,
                            DataSourceType = item.DataSourceType,
                            ContainerAccountName = item.ContainerAccountName,
                            ContainerAccountUrl = item.ContainerAccountUrl,
                            ContainerConnectionString = item.ContainerConnectionString,
                            ContainerKey = item.ContainerKey,
                            ContainerName = item.ContainerName,
                            ContainerType = item.ContainerType,
                            ContainerUserId = item.ContainerUserId,
                            CreateDate = item.CreateDate,
                            UpdateDate = item.UpdateDate,
                            ProxyUrl = item.ProxyUrl
                        };
                    }

                    else if (DataSourceType.Destination == item.DataSourceType)
                    {
                        dsmigrationvm.DestinationModel = new MigrationDataSourcesModel
                        {
                            Id = item.Id,
                            MigrationId = item.MigrationId,
                            DataSourceType = item.DataSourceType,
                            ContainerAccountName = item.ContainerAccountName,
                            ContainerAccountUrl = item.ContainerAccountUrl,
                            ContainerConnectionString = item.ContainerConnectionString,
                            ContainerKey = item.ContainerKey,
                            ContainerName = item.ContainerName,
                            ContainerType = item.ContainerType,
                            ContainerUserId = item.ContainerUserId,
                            CreateDate = item.CreateDate,
                            UpdateDate = item.UpdateDate,
                            ProxyUrl = item.ProxyUrl
                        };
                    }
                        
                                
                    dsmigrationvm.MigrationsModel = new MigrationsModel
                    {
                        Id = item.Migration.Id,
                        Name = item.Migration.Name,
                        Description = item.Migration.Description,
                        LastMigrationFinishDate = item.Migration.LastMigrationFinishDate,
                        LastMigrationRunDate = item.Migration.LastMigrationRunDate,
                        MigrationRunActive = item.Migration.MigrationRunActive,
                        MigrationRunCount = item.Migration.MigrationRunCount,
                        MigrationStatus = item.Migration.MigrationStatus,
                        MigrationType = item.Migration.MigrationType,
                        IsDeleted = item.Migration.IsDeleted
                    };

                if (addtolist)
                {
                    addtolist = false;
                    lstviewmodel.Add(dsmigrationvm);
                }
            }
            return lstviewmodel;


        }

        public async Task<DataSourceMigrationVM> GetDataSourceMigrationbyIdAsync(int id, CancellationToken token)
        {

            var result = dbContext.MigrationDataSources.Include(x => x.Migration).Where(x => x.MigrationId == id);
            var dsmigrationvm = new DataSourceMigrationVM();

            foreach (var item in result)
            {
                
                    dsmigrationvm.SourcesModel = new MigrationDataSourcesModel
                    {
                        Id = item.Id,
                        MigrationId = item.MigrationId,
                        DataSourceType = item.DataSourceType,
                        ContainerAccountName = item.ContainerAccountName,
                        ContainerAccountUrl = item.ContainerAccountUrl,
                        ContainerConnectionString = item.ContainerConnectionString,
                        ContainerKey = item.ContainerKey,
                        ContainerName = item.ContainerName,
                        ContainerType = item.ContainerType,
                        ContainerUserId = item.ContainerUserId,
                        CreateDate = item.CreateDate,
                        UpdateDate = item.UpdateDate,
                        ProxyUrl = item.ProxyUrl
                    };
               
                
                    dsmigrationvm.DestinationModel = new MigrationDataSourcesModel
                    {
                        Id = item.Id,
                        MigrationId = item.MigrationId,
                        DataSourceType = item.DataSourceType,
                        ContainerAccountName = item.ContainerAccountName,
                        ContainerAccountUrl = item.ContainerAccountUrl,
                        ContainerConnectionString = item.ContainerConnectionString,
                        ContainerKey = item.ContainerKey,
                        ContainerName = item.ContainerName,
                        ContainerType = item.ContainerType,
                        ContainerUserId = item.ContainerUserId,
                        CreateDate = item.CreateDate,
                        UpdateDate = item.UpdateDate,
                        ProxyUrl = item.ProxyUrl
                    };
                
                    
                dsmigrationvm.MigrationsModel = new MigrationsModel
                {
                    Id = item.Migration.Id,
                    Name = item.Migration.Name,
                    Description = item.Migration.Description,
                    LastMigrationFinishDate = item.Migration.LastMigrationFinishDate,
                    LastMigrationRunDate = item.Migration.LastMigrationRunDate,
                    MigrationRunActive = item.Migration.MigrationRunActive,
                    MigrationRunCount = item.Migration.MigrationRunCount,
                    MigrationStatus = item.Migration.MigrationStatus,
                    MigrationType = item.Migration.MigrationType,
                    IsDeleted = item.Migration.IsDeleted
                };


            }
            return dsmigrationvm;
        }
        public async Task<MigrationsModel> UpdateAsync(MigrationsModel migmodel, CancellationToken token)
        {
            var entity = Map(migmodel);
            var obj = await dbContext.Migrations.SingleOrDefaultAsync(m => m.Id == entity.Id, token);
            if (obj is not null)
            {
                obj.Name = entity.Name;
                obj.Description = entity.Description;
                obj.LastMigrationFinishDate = entity.LastMigrationFinishDate;
                obj.LastMigrationRunDate = entity.LastMigrationRunDate;
                obj.MigrationRunActive = entity.MigrationRunActive;
                obj.MigrationRunCount = entity.MigrationRunCount;
                obj.MigrationStatus = entity.MigrationStatus;
                obj.MigrationType = entity.MigrationType;
                obj.IsDeleted = entity.IsDeleted;
            }
            dbContext.SaveChanges();
            return migmodel;
        }

        public async Task<MigrationDataSourcesModel> UpdateDataSourceAsync(MigrationDataSourcesModel migDsmodel, CancellationToken token)
        {
            var entitydatasource = MapDataSource(migDsmodel);
            var objdatasource = await dbContext.MigrationDataSources.SingleOrDefaultAsync(m => m.Id == entitydatasource.Id, token);
            if (objdatasource is not null)
            {
                objdatasource.MigrationId = entitydatasource.MigrationId;
                objdatasource.DataSourceType = entitydatasource.DataSourceType;
                objdatasource.ContainerType = entitydatasource.ContainerType;
                objdatasource.ContainerAccountName = entitydatasource.ContainerAccountName;
                objdatasource.ContainerAccountUrl = entitydatasource.ContainerAccountUrl;
                objdatasource.ContainerConnectionString = entitydatasource.ContainerConnectionString;
                objdatasource.ContainerName = entitydatasource.ContainerName;
                objdatasource.ContainerKey = entitydatasource.ContainerKey;
                objdatasource.ContainerUserId = entitydatasource.ContainerUserId;
                objdatasource.CreateDate = entitydatasource.CreateDate;
                objdatasource.UpdateDate = entitydatasource.UpdateDate;
            }
            dbContext.SaveChanges();
            return migDsmodel;
        }

        public async Task<MigrationsModel> GetByIdAsync(int migrationId, CancellationToken token)
        {
            var result = await dbContext.Migrations.Include(inc => inc.MigrationDataSources).FirstOrDefaultAsync(key => key.Id == migrationId, token);
            return MapDbModel(result);
        }


        private static MigrationsModel MapDbModel(MigrationsDbModel dbModel)
        {
            var mm = new MigrationsModel
            {
                Id = dbModel.Id,
                Name = dbModel.Name,
                Description = dbModel.Description,
                IsDeleted = dbModel.IsDeleted,
                MigrationStatus = dbModel.MigrationStatus,
                MigrationRunActive = dbModel.MigrationRunActive,
                MigrationRunCount = dbModel.MigrationRunCount,
                MigrationType = dbModel.MigrationType,
                LastMigrationFinishDate = dbModel.LastMigrationFinishDate,
                LastMigrationRunDate = dbModel.LastMigrationRunDate,
                Actions = dbModel.Actions,
                Summary = dbModel.Summary,
                DataSources = dbModel?.MigrationDataSources?.Select(el => MapDbModel(el))?.ToList() ?? new List<MigrationDataSourcesModel>()
            };
            return mm;
        }

        public static MigrationDataSourcesModel MapDbModel(MigrationDataSourcesDbModel item)
        {
            return new MigrationDataSourcesModel
            {
                Id = item.Id,
                MigrationId = item.MigrationId,
                DataSourceType = item.DataSourceType,
                ContainerAccountName = item.ContainerAccountName,
                ContainerAccountUrl = item.ContainerAccountUrl,
                ContainerConnectionString = item.ContainerConnectionString,
                ContainerKey = item.ContainerKey,
                ContainerName = item.ContainerName,
                ContainerType = item.ContainerType,
                ContainerUserId = item.ContainerUserId,
                CreateDate = item.CreateDate,
                UpdateDate = item.UpdateDate,
                ProxyUrl = item.ProxyUrl                
            };
        }

        public async Task<int> DeletebyIdAsync(int id,CancellationToken token)
        {
            var result = dbContext.Migrations.Include(x=>x.MigrationDataSources).Where(x => x.Id == id);
            dbContext.RemoveRange(result);
            dbContext.SaveChanges();
            return id;
        }

    }
}
