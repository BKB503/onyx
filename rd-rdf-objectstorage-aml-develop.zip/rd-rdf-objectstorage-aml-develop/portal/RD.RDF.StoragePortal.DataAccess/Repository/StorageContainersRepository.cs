﻿using Microsoft.EntityFrameworkCore;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Repository
{
    public class StorageContainersRepository : IContainersRepository
    {
        private readonly StoragePortalDbContext dbContext;

        public StorageContainersRepository(StoragePortalDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<int> CreateStorageContainerAsync(ContainersModel input, CancellationToken token)
        {
            var revMap = RevMap(input);
            revMap.CreateDate = DateTime.UtcNow;

            await this.dbContext.Containers.AddAsync(revMap, token);
            await this.dbContext.SaveChangesAsync();

            return revMap.Id;

        }

        public Task<bool> DeleteStorageContainerAsync(ContainersModel storageProperties, CancellationToken token)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<ContainersModel>> GetAllStorageContainersAsync(CancellationToken token)
        {
            var containers = await this.dbContext.Containers
                                        .Include(c => c.Audiences)
                                        .Include(i=>i.Index).ToListAsync(token);

            return containers.Select(Map);
        }

        public async Task<ContainersModel> GetStorageContainerByIdAsync(int id, CancellationToken token)
        {
            var dbResutls = await this.dbContext.Containers.Include(c => c.Audiences).FirstOrDefaultAsync(x => x.Id == id, token);
            var result = Map(dbResutls);
            return result;
        }

        public async Task UpdateContainerAsync(ContainersModel container, CancellationToken token)
        {
            var containerUpdate = RevMap(container);
            containerUpdate.UpdateDate = DateTime.UtcNow;
            await this.dbContext.Containers.AddAsync(containerUpdate, token);
            this.dbContext.Entry(containerUpdate).State = EntityState.Modified;
            await this.dbContext.SaveChangesAsync();
        }

        public async Task<AudiencesModel> GetAudienceByIdAsync(int id, CancellationToken token)
        {
            var dbResutls = await this.dbContext.Audiences.FirstOrDefaultAsync(x => x.Id.Equals(id), token);
            var result = MapAudienceRecord(dbResutls);
            return result;
        }

        public async Task UpdateAudienceByIdAsync(AudiencesModel input, CancellationToken token)
        {
            var audienceUpdate = RevMapAudienceRecordUpdate(input);

            await this.dbContext.Audiences.AddAsync(audienceUpdate, token);
            this.dbContext.Entry(audienceUpdate).State = EntityState.Modified;
            await this.dbContext.SaveChangesAsync();
        }

        public async Task<int> CreateAudienceRecordAsync(AudiencesModel input, CancellationToken token)
        {
            var revMap = RevMapAudienceRecordAdd(input);

            await this.dbContext.Audiences.AddAsync(revMap, token);
            await this.dbContext.SaveChangesAsync();

            return revMap.Id;
        }

        private static ContainersModel Map(ContainersDbModel dbModel)
        {
            return new ContainersModel
            {
                ContainerId = dbModel.Id,
                Name = dbModel.Name,
                ContainerType = Enum.Parse<StoragePortalContainerType>(dbModel.ContainerType),
                ContainerAccountName = dbModel.ContainerAccountName,
                ContainerAccountUrl = dbModel.ContainerAccountUrl,
                ContainerName = dbModel.ContainerName,
                ContainerConnectionString = dbModel.ContainerConnectionString,
                ContainerKey = dbModel.ContainerKey,
                ContainerUserId = dbModel.ContainerUserId,
                AllianceTagName = dbModel.AllianceTagName,
                ValidateAudience = dbModel.ValidateAudience,
                ValidAudiences = MapAudience(dbModel.Audiences),
                ProxyUrl = dbModel.ProxyUrl,
                IndexId = dbModel.IndexId,
                Indexing= MapIndexing(dbModel.Index)
            };
        }
        private static IndexingModel MapIndexing(IndexesDbModel index)
        {
            var indexing = new IndexingModel();

            if (index != null)
            {
                indexing.IndexId = index.Id;
                indexing.RDFKafkaTopic = index.RDFKafkaTopic;
                indexing.Type = index.Type;
                indexing.RDFKafkaConnectionString = index.RDFKafkaConnectionString;
                indexing.RDFKafkaKey = index.RDFKafkaKey;
                indexing.KafkaServers = index.KafkaServers;
                indexing.SaslUsername = index.SaslUsername;
                indexing.IndexOdbcConnectionString = index.IndexOdbcConnectionString;
            };

            return indexing;
        }

        private static List<AudiencesModel> MapAudience(List<AudiencesDbModel> dbModel)
        {
            var audienceList = new List<AudiencesModel>();
            if (dbModel == null)
            {
                return audienceList;
            }
            foreach (var item in dbModel)
            {
                var audience = new AudiencesModel
                {
                    Id = item.Id,
                    ValidAudience = item.ValidAudience,
                    ContainerId = item.ContainerId
                };
                audienceList.Add(audience);
            }
            return audienceList;
        }

        private static ContainersDbModel RevMap(ContainersModel input)
        {
            var containersPropertiesDbModel =
             new ContainersDbModel
             {
                 Id = input.ContainerId,
                 Name = input.Name,
                 ContainerType = input.ContainerType.ToString(),
                 ContainerAccountName = input.ContainerAccountName,
                 ContainerAccountUrl = input.ContainerAccountUrl,
                 ContainerName = input.ContainerName,
                 ContainerConnectionString = input.ContainerConnectionString,
                 ContainerKey = input.ContainerKey,
                 ContainerUserId = input.ContainerUserId,
                 AllianceTagName = input.AllianceTagName,
                 ValidateAudience = input.ValidateAudience,
                 Audiences = input.ValidAudiences != null ? RevMapAudience(input) : null,
                 ProxyUrl = input.ProxyUrl,
                 CreateDate = DateTime.UtcNow,
                 UpdateDate = input.ContainerId != 0 ? DateTime.UtcNow : null,
                 IndexId = input.IndexId
             };

            return containersPropertiesDbModel;
        }

        private static List<AudiencesDbModel> RevMapAudience(ContainersModel container)
        {
            var audienceList = new List<AudiencesDbModel>();

            if (container.ValidAudiences != null)
            {
                foreach (var item in container.ValidAudiences)
                {
                    var audience = new AudiencesDbModel();

                    audience.Id = item.Id;
                    audience.ValidAudience = item.ValidAudience;
                    audience.ContainerId = item.ContainerId;
                    audience.CreateDate = DateTime.UtcNow;
                    audience.UpdateDate = item.Id != 0 ? DateTime.UtcNow : null;

                    audienceList.Add(audience);
                }
            }

            return audienceList;
        }

        private static AudiencesModel MapAudienceRecord(AudiencesDbModel dbModel)
        {
            var audience = new AudiencesModel();
            if (dbModel != null)
            {
                return new AudiencesModel
                {
                    Id = dbModel.Id,
                    ContainerId = dbModel.ContainerId,
                    ValidAudience = dbModel.ValidAudience
                };
            }
            else
            {
                return audience;
            }
        }

        private static AudiencesDbModel RevMapAudienceRecordUpdate(AudiencesModel dbModel)
        {
            return new AudiencesDbModel
            {
                Id = dbModel.Id,
                ValidAudience = dbModel.ValidAudience,
                ContainerId = dbModel.ContainerId,
                UpdateDate = dbModel.Id != 0 ? DateTime.UtcNow : null
            };
        }

        private static AudiencesDbModel RevMapAudienceRecordAdd(AudiencesModel input)
        {
            return new AudiencesDbModel
            {
                ValidAudience = input.ValidAudience,
                CreateDate = DateTime.UtcNow,
                ContainerId = input.Id
            };
        }
    }
}
