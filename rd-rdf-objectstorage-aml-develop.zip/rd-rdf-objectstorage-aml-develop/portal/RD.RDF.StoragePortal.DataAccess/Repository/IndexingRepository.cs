﻿using Microsoft.EntityFrameworkCore;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Repository
{
    public class IndexingRepository :  IIndexingPortalRepository
    {
        private readonly StoragePortalDbContext dbContext;

        public IndexingRepository(StoragePortalDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<int> CreateIndexingAsync(IndexingModel input, CancellationToken token)
        {
            var revMap = RevMapRecordAdd(input);
            revMap.CreateDate = DateTime.UtcNow;
            await this.dbContext.Indexes.AddAsync(revMap, token);
            await this.dbContext.SaveChangesAsync();

            return revMap.Id;
        }

        public async Task<IEnumerable<IndexingModel>> GetAllAsync(CancellationToken token)
        {
            var dbResutls = await this.dbContext.Indexes.ToListAsync(token);

            return dbResutls.Select(MapIndexingRecord);
        }

        public async Task<EditIndexingModel> GetIndexingByIdAsync(int indexingId, CancellationToken token)
        {
            var dbResutls = await this.dbContext.Indexes.FirstOrDefaultAsync(x => x.Id.Equals(indexingId), token);

            return MapEditIndexingRecord(dbResutls);
        }

        private static IndexingModel MapIndexingRecord(IndexesDbModel dbModel)
        {
            var index = new IndexingModel();
            if (dbModel != null)
            {
                index.IndexId = dbModel.Id;
                index.RDFKafkaTopic = dbModel.RDFKafkaTopic;
                index.Type = dbModel.Type;
                index.RDFKafkaConnectionString = dbModel.RDFKafkaConnectionString;
                index.RDFKafkaKey = dbModel.RDFKafkaKey;
                index.KafkaServers = dbModel.KafkaServers;
                index.SaslUsername = dbModel.SaslUsername;
                index.IndexOdbcConnectionString = dbModel.IndexOdbcConnectionString;
            }

            return index;
        }

        private static EditIndexingModel MapEditIndexingRecord(IndexesDbModel dbModel)
        {
            var index = new EditIndexingModel();
            if (dbModel != null)
            {
                index.IndexId = dbModel.Id;
                index.RDFKafkaTopic = dbModel.RDFKafkaTopic;
                index.Type = dbModel.Type;
                index.RDFKafkaConnectionString = dbModel.RDFKafkaConnectionString;
                index.RDFKafkaKey = dbModel.RDFKafkaKey;
                index.KafkaServers = dbModel.KafkaServers;
                index.SaslUsername = dbModel.SaslUsername;
                index.IndexOdbcConnectionString = dbModel.IndexOdbcConnectionString;
            }

            return index;
        }

        private static IndexesDbModel RevMapRecordAdd(IndexingModel input)
        {
            var indexingDbModel =
             new IndexesDbModel
             {
                 Id = input.IndexId,
                 RDFKafkaTopic = input.RDFKafkaTopic,
                 Type = input.Type,
                 RDFKafkaConnectionString = input.RDFKafkaConnectionString,
                 RDFKafkaKey = input.RDFKafkaKey,
                 KafkaServers = input.KafkaServers,
                 SaslUsername = input.SaslUsername,
                 IndexOdbcConnectionString = input.IndexOdbcConnectionString,
                 CreateDate = DateTime.UtcNow,
                 UpdateDate = input.UpdateDate
             };

            return indexingDbModel;
        }

        private static IndexesDbModel RevMapRecordUpdate(IndexingModel input)
        {
            var indexingDbModel =
             new IndexesDbModel
             {
                 Id = input.IndexId,
                 RDFKafkaTopic = input.RDFKafkaTopic,
                 Type = input.Type,
                 RDFKafkaConnectionString = input.RDFKafkaConnectionString,
                 RDFKafkaKey = input.RDFKafkaKey,
                 KafkaServers = input.KafkaServers,
                 SaslUsername = input.SaslUsername,
                 IndexOdbcConnectionString = input.IndexOdbcConnectionString,
                 UpdateDate = DateTime.UtcNow
             };

            return indexingDbModel;
        }

        public async Task UpdateIndexingByIdAsync(EditIndexingModel input, CancellationToken token)
        {
            var dbResults = await this.dbContext.Indexes.FirstOrDefaultAsync(k => k.Id == input.IndexId, token);
            if (dbResults != null)
            {
                dbResults.UpdateDate = DateTime.UtcNow;
                dbResults.KafkaServers = input.KafkaServers;
                dbResults.RDFKafkaTopic = input.RDFKafkaTopic;
                dbResults.Type = input.Type;
                // if password is null from input model
                if(input.IndexOdbcConnectionStringChanged)
                {
                    dbResults.IndexOdbcConnectionString = input.IndexOdbcConnectionString;
                }
                if (input.RDFKafkaKeyChanged)
                {
                    dbResults.RDFKafkaKey = input.RDFKafkaKey;
                }
                if (input.RDFKafkaConnectionStringChanged)
                {
                    dbResults.RDFKafkaConnectionString = input.RDFKafkaConnectionString;
                }
                this.dbContext.Indexes.Update(dbResults);                   
                await this.dbContext.SaveChangesAsync();
            }
        }
    }
}
