﻿using Microsoft.EntityFrameworkCore;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Repository
{
    public class StoragePropertiesRepository : IStoragePropertiesRepository
    {
        private readonly StoragePortalDbContext dbContext;

        public StoragePropertiesRepository(StoragePortalDbContext dbContext)
        {
            this.dbContext = dbContext;
        }


        public Task<int> CreateStoragePropertiesAsync(StoragePropertiesModel newStorageProperties, CancellationToken token)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteStoragePropertiesAsync(StoragePropertiesModel storageProperties, CancellationToken token)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<StoragePropertiesModel>> GetAllAsync(CancellationToken token)
        {
            var dbResutls = await this.dbContext.StorageProperties.ToListAsync(token);
            return dbResutls.Select(Map);
        }

        public Task<StoragePropertiesModel> GetStoragePropertiesByIdAsync(int id, CancellationToken token)
        {
            throw new NotImplementedException();
        }

        private static StoragePropertiesModel Map(StoragePropertiesDbModel dbModel)
        {
            return new StoragePropertiesModel
            {
                Id = dbModel.Id,
                DefaultContainer = dbModel.DefaultContainer,
                DefaultIndex = dbModel.DefaultIndex
            };
        }
    }
}
