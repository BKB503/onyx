﻿using Microsoft.EntityFrameworkCore;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.DataAccess.Repository
{
    public class MigrationRunRepository : IMigrationRunRepository
    {
        private readonly StoragePortalDbContext dbContext;
        public MigrationRunRepository(StoragePortalDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        private List<MigrationDataSourcesDbModel> getDataSourceMigrationbyId(int id)
        {
            var result = dbContext.MigrationDataSources.Where(y => y.MigrationId == id);
            List<MigrationDataSourcesDbModel> lstmigdsdbmodel = new List<MigrationDataSourcesDbModel>();
            foreach (var item in result)
            {
                var dsdbmodel = new MigrationDataSourcesDbModel();

                dsdbmodel.MigrationId = item.MigrationId;
                dsdbmodel.DataSourceType = item.DataSourceType;
                dsdbmodel.ContainerAccountName = item.ContainerAccountName;
                dsdbmodel.ContainerAccountUrl = item.ContainerAccountUrl;
                dsdbmodel.ContainerConnectionString = item.ContainerConnectionString;
                dsdbmodel.ContainerKey = item.ContainerKey;
                dsdbmodel.ContainerName = item.ContainerName;
                dsdbmodel.ContainerType = item.ContainerType;
                dsdbmodel.ContainerUserId = item.ContainerUserId;
                dsdbmodel.CreateDate = item.CreateDate;
                dsdbmodel.UpdateDate = item.UpdateDate;
                dsdbmodel.ProxyUrl = item.ProxyUrl;

                dsdbmodel.MigrationId = item.MigrationId;
                dsdbmodel.DataSourceType = item.DataSourceType;
                dsdbmodel.ContainerAccountName = item.ContainerAccountName;
                dsdbmodel.ContainerAccountUrl = item.ContainerAccountUrl;
                dsdbmodel.ContainerConnectionString = item.ContainerConnectionString;
                dsdbmodel.ContainerKey = item.ContainerKey;
                dsdbmodel.ContainerName = item.ContainerName;
                dsdbmodel.ContainerType = item.ContainerType;
                dsdbmodel.ContainerUserId = item.ContainerUserId;
                dsdbmodel.CreateDate = item.CreateDate;
                dsdbmodel.UpdateDate = item.UpdateDate;
                dsdbmodel.ProxyUrl = item.ProxyUrl;

                lstmigdsdbmodel.Add(dsdbmodel);

            }
            return lstmigdsdbmodel;

        }

        public async Task<RunMigrationVM> GetDataSourceRunbyIdAsync(int migdsId, CancellationToken token)
        {

            var result = dbContext.MigrationRunDataSources.Include(x => x.MigrationRun).Include(x => x.MigrationRun.Migration).Where(x => x.MigrationRun.Id == migdsId);

            var dsrunmigrationvm = new RunMigrationVM();

            foreach (var item in result)
            {
                if (item.DataSourceType == DataSourceType.Source)
                {
                    dsrunmigrationvm.SourcesRunModel = new MigrationRunDataSourcesModel
                    {
                        Id = item.Id,
                        DataSourceType = item.DataSourceType,
                        ContainerAccountName = item.ContainerAccountName,
                        ContainerAccountUrl = item.ContainerAccountUrl,
                        ContainerConnectionString = item.ContainerConnectionString,
                        ContainerKey = item.ContainerKey,
                        ContainerName = item.ContainerName,
                        ContainerType = item.ContainerType,
                        ContainerUserId = item.ContainerUserId,
                        CreateDate = item.CreateDate,
                        UpdateDate = item.UpdateDate,
                        ProxyUrl = item.ProxyUrl,
                        Name = item.ContainerName

                    };
                }

                if (item.DataSourceType == DataSourceType.Destination)
                {
                    dsrunmigrationvm.DestinationRunModel = new MigrationRunDataSourcesModel
                    {
                        Id = item.Id,
                        DataSourceType = item.DataSourceType,
                        ContainerAccountName = item.ContainerAccountName,
                        ContainerAccountUrl = item.ContainerAccountUrl,
                        ContainerConnectionString = item.ContainerConnectionString,
                        ContainerKey = item.ContainerKey,
                        ContainerName = item.ContainerName,
                        ContainerType = item.ContainerType,
                        ContainerUserId = item.ContainerUserId,
                        CreateDate = item.CreateDate,
                        UpdateDate = item.UpdateDate,
                        ProxyUrl = item.ProxyUrl,
                        Name = item.ContainerName
                    };
                }

                dsrunmigrationvm.MigrationRunModel = new MigrationRunsModel
                {
                    Id = item.MigrationRun.Id,
                    MigrationId = item.MigrationRun.MigrationId,
                    RunStartDate = item.MigrationRun.RunStartDate,
                    RunFinishDate = item.MigrationRun.RunFinishDate,
                    RunStatus = item.MigrationRun.RunStatus,
                    RunStage = item.MigrationRun.RunStage,
                    RunObjectsCount = item.MigrationRun.RunObjectsCount,
                    RunObjectsMigrated = item.MigrationRun.RunObjectsMigrated,
                    CreateDate = item.MigrationRun.CreateDate,
                    UpdateDate = item.MigrationRun.UpdateDate,
                };
                dsrunmigrationvm.MigrationModel = new MigrationsModel
                {
                    Id = item.MigrationRun.Migration.Id,
                    Name = item.MigrationRun.Migration.Name,
                    Description = item.MigrationRun.Migration.Description,
                    LastMigrationFinishDate = item.MigrationRun.Migration.LastMigrationFinishDate,
                    LastMigrationRunDate = item.MigrationRun.Migration.LastMigrationRunDate,
                    MigrationRunActive = item.MigrationRun.Migration.MigrationRunActive,
                    MigrationRunCount = item.MigrationRun.Migration.MigrationRunCount,
                    MigrationStatus = item.MigrationRun.Migration.MigrationStatus,
                    MigrationType = item.MigrationRun.Migration.MigrationType,
                    IsDeleted = item.MigrationRun.Migration.IsDeleted
                };

            }
            return dsrunmigrationvm;
        }

        public async Task<List<MigrationRunObjectsModel>> GetDataSourceRunObjectsAsync(int migrunId, CancellationToken token)
        {
            var result = await dbContext.MigrationRunObjects.Include(x => x.MigrationRun).Where(x => x.MigrationRunId == migrunId).ToListAsync(token);
            List<MigrationRunObjectsModel> lstmigrunobj = new();

            foreach (var item in result)
            {

                MigrationRunObjectsModel dsmigrunobj = new MigrationRunObjectsModel
                {
                    Id = item.Id,
                    MigrationRunId = item.MigrationRunId,
                    MigrationRunDataSourceId = item.MigrationRunDataSourceId,
                    MigrationRunDataDestinationId = item.MigrationRunDataDestinationId,
                    FileName = item.FileName,
                    FilePath = item.FilePath,
                    FileMigrationStatus = item.FileMigrationStatus,
                    FileSize = item.FileSize
                };

                lstmigrunobj.Add(dsmigrunobj);

            }

            return lstmigrunobj;
        }
        public async Task<int> AddMigRunDataSourceAsync(int migId, CancellationToken token)
        {
            var entity = Map(migId);
            await this.dbContext.MigrationRuns.AddAsync(entity, token);
            await this.dbContext.SaveChangesAsync();
            int MigId = entity.MigrationId;
            int Id = entity.Id;
            List<MigrationDataSourcesDbModel> migdsmodel = getDataSourceMigrationbyId(migId);

            foreach (var item in migdsmodel)
            {
                if (item.DataSourceType == 0)
                {
                    var entitydatasource = MapDataSource(Id, item);
                    await this.dbContext.MigrationRunDataSources.AddAsync(entitydatasource, token);
                }
                else
                {
                    var entitydatasource = MapDataSource(Id, item);
                    await this.dbContext.MigrationRunDataSources.AddAsync(entitydatasource, token);
                }

            }

            await this.dbContext.SaveChangesAsync();
            return Id;

        }

        public async Task<List<RunMigrationVM>> GetAllMigrationRunAsync(int migdsid, CancellationToken token)
        {
            var result = await dbContext.MigrationRunDataSources.Include(x => x.MigrationRun).Include(x => x.MigrationRun.Migration).Where(x => x.MigrationRun.MigrationId == migdsid).ToListAsync(token);
            List<RunMigrationVM> lstviewmodel = new List<RunMigrationVM>();
            var previousRunid = 0;
            Boolean addtorunlist = false;
            RunMigrationVM runmigrationvm = null;

            foreach (var item in result)
            {
                if (item.MigrationRunId != previousRunid)
                {
                    addtorunlist = true;
                    runmigrationvm = new RunMigrationVM();
                    previousRunid = item.MigrationRunId;
                }
                if (DataSourceType.Source == item.DataSourceType)
                {
                    runmigrationvm.SourcesRunModel = new MigrationRunDataSourcesModel
                    {
                        Id = item.Id,
                        DataSourceType = item.DataSourceType,
                        ContainerAccountName = item.ContainerAccountName,
                        ContainerAccountUrl = item.ContainerAccountUrl,
                        ContainerConnectionString = item.ContainerConnectionString,
                        ContainerKey = item.ContainerKey,
                        ContainerName = item.ContainerName,
                        ContainerType = item.ContainerType,
                        ContainerUserId = item.ContainerUserId,
                        CreateDate = item.CreateDate,
                        UpdateDate = item.UpdateDate,
                        ProxyUrl = item.ProxyUrl,
                        Name = item.ContainerName
                    };
                }
                else if (DataSourceType.Destination == item.DataSourceType)
                {
                    runmigrationvm.DestinationRunModel = new MigrationRunDataSourcesModel
                    {

                        Id = item.Id,
                        DataSourceType = item.DataSourceType,
                        ContainerAccountName = item.ContainerAccountName,
                        ContainerAccountUrl = item.ContainerAccountUrl,
                        ContainerConnectionString = item.ContainerConnectionString,
                        ContainerKey = item.ContainerKey,
                        ContainerName = item.ContainerName,
                        ContainerType = item.ContainerType,
                        ContainerUserId = item.ContainerUserId,
                        CreateDate = item.CreateDate,
                        UpdateDate = item.UpdateDate,
                        ProxyUrl = item.ProxyUrl,
                        Name = item.ContainerName
                    };
                }
                runmigrationvm.MigrationRunModel = new MigrationRunsModel
                {
                    Id = item.MigrationRun.Id,
                    MigrationId = item.MigrationRun.MigrationId,
                    RunStartDate = item.MigrationRun.RunStartDate,
                    RunFinishDate = item.MigrationRun.RunFinishDate,
                    RunStatus = item.MigrationRun.RunStatus,
                    RunStage = item.MigrationRun.RunStage,
                    RunObjectsCount = item.MigrationRun.RunObjectsCount,
                    RunObjectsMigrated = item.MigrationRun.RunObjectsMigrated,
                    CreateDate = item.MigrationRun.CreateDate,
                    UpdateDate = item.MigrationRun.UpdateDate,
                    
                };
                runmigrationvm.MigrationModel = new MigrationsModel
                {
                    Id = item.MigrationRun.Migration.Id,
                    Name = item.MigrationRun.Migration.Name,
                    Description = item.MigrationRun.Migration.Description,
                    LastMigrationFinishDate = item.MigrationRun.Migration.LastMigrationFinishDate,
                    LastMigrationRunDate = item.MigrationRun.Migration.LastMigrationRunDate,
                    MigrationRunActive = item.MigrationRun.Migration.MigrationRunActive,
                    MigrationRunCount = item.MigrationRun.Migration.MigrationRunCount,
                    MigrationStatus = item.MigrationRun.Migration.MigrationStatus,
                    MigrationType = item.MigrationRun.Migration.MigrationType,
                    IsDeleted = item.MigrationRun.Migration.IsDeleted
                };

                if (addtorunlist)
                {
                    addtorunlist = false;
                    lstviewmodel.Add(runmigrationvm);
                }

            }
            return lstviewmodel;

        }

        private static MigrationRunsDbModel Map(int id)
        {
            return new MigrationRunsDbModel
            {
                MigrationId = id,
                RunStartDate = DateTime.UtcNow,
                RunStatus = RunStatusEnum.Start,
                RunStage = RunStageEnum.Reading,
                RunObjectsCount = 0,
                RunObjectsMigrated = 0,
                CreateDate = DateTime.UtcNow,
                MigrationType = MigrationType.StorageAPIMigration

            };
        }

        private static MigrationRunDataSourcesDbModel MapDataSource(int id, MigrationDataSourcesDbModel migdatasource)
        {

            return new MigrationRunDataSourcesDbModel
            {

                MigrationRunId = id,
                CreateDate = (DateTime)migdatasource.CreateDate,
                UpdateDate = migdatasource.UpdateDate,
                DataSourceType = migdatasource.DataSourceType,
                ContainerType = migdatasource.ContainerType,
                ContainerAccountName = migdatasource.ContainerAccountName,
                ContainerAccountUrl = migdatasource.ContainerAccountUrl,
                ContainerName = migdatasource.ContainerName,
                ContainerConnectionString = migdatasource.ContainerConnectionString,
                ContainerKey = migdatasource.ContainerKey,
                ContainerUserId = migdatasource.ContainerUserId,
                ProxyUrl = migdatasource.ProxyUrl


            };
        }

        
    }
}