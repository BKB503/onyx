# RDF Storage-API\portal

Folder contains Asp.Net Core 6.0 StorageAPI Portal Web application as well as Migration Tool Worker services

Solution name : [RD.RDF.StoragePortal.sln](RD.RDF.StoragePortal.sln)
