﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Web.Controllers
{
    [Authorize]
    public class AudienceController : Controller
    {
        private readonly ILogger<AudienceController> _logger;
        private readonly IContainerService _containerService;

        public AudienceController(ILogger<AudienceController> logger, IContainerService containersService)
        {
            this._logger = logger;
            this._containerService = containersService;
        }

        // GET: AudienceController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AudienceController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(AudiencesModel input, CancellationToken token)
        {
            var routeValues = new RouteValueDictionary { { "id", input.Id } };
            var result = await _containerService.CreateAudienceRecordAsync(input, token);

            return RedirectToAction("Edit", "Container", routeValues);

        }

        // GET: AudienceController/Edit/5
        public async Task<ActionResult> Edit(int id, CancellationToken cancellationToken)
        {
            var result = await _containerService.GetAudienceByIdAsync(id, cancellationToken);

            return View(result);

        }

        // POST: AudienceController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(AudiencesModel audienceInput, CancellationToken cancellationToken)
        {
            try
            {
                var routeValues = new RouteValueDictionary { { "id", audienceInput.ContainerId } };
                await _containerService.UpdateAudienceByIdAsync(audienceInput, cancellationToken);

                return RedirectToAction("Edit", "Container", routeValues);
            }
            catch
            {
                return View();
            }
        }

        // GET: AudienceController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: AudienceController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
