﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Web.Controllers
{
    [Authorize]
    public class MigrationController : Controller
    {
        private readonly ILogger<MigrationController> logger;
        private readonly IMigrationService migrationService;

        public MigrationController(ILogger<MigrationController> logger, IMigrationService migrationService)
        {
            this.logger = logger;
            this.migrationService = migrationService;
        }
        public async Task<ActionResult> Index(CancellationToken cancellationToken)
        {
            var model = new List<DataSourceMigrationVM>();
            if (User.Identity.IsAuthenticated)

            {
                var lstvm = await migrationService.GetAllMigrationsAsync(cancellationToken);

                return View(lstvm);
            }
            return View(model);

        }
        public async Task<ActionResult> AddMigration(DataSourceMigrationVM migrationsVM, CancellationToken cancellationToken)
        {
            var createMig = await migrationService.AddDataSourceMigrationAsync(migrationsVM, cancellationToken);
            return RedirectToAction("Index");
        }
        public async Task<ActionResult> DisplayAddMigration(DataSourceMigrationVM migrationsVM, CancellationToken cancellationToken)
        {
            return View("AddMigration");


        }
        public async Task<ActionResult> GetDataSourceMigrationbyId(int id, CancellationToken cancellationToken)
        {
            var datasourcemigid = await migrationService.GetDataSourceMigbyIdAsync(id,cancellationToken);
            return View("Edit", datasourcemigid);
        }
        public async Task<ActionResult> ViewMigrationbyId(int id, CancellationToken cancellationToken)
        {
            var datasourcemigid = await migrationService.GetDataSourceMigbyIdAsync(id, cancellationToken);
            return View("ViewMigration", datasourcemigid);
        }

        public async Task<ActionResult> UpdateDataSourceMig(DataSourceMigrationVM migrationsVM, CancellationToken cancellationToken)
        {            
            var updateMig = await migrationService.UpdateDataSourceMigAsync(migrationsVM, cancellationToken);
            return RedirectToAction("Index"); ;
        }
        public async Task<ActionResult> DeleteMigration(int id, CancellationToken cancellationToken)
        {
            var deleteMig = await migrationService.DeleteDataSourcebyIdAsync(id,cancellationToken);
            return RedirectToAction("Index");
        }

    }
}
