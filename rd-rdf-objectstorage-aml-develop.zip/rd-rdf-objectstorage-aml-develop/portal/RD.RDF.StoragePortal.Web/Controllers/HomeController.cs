﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Web.Models;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Web.Controllers
{

    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> logger;
        private readonly IStoragePropertiesService storagePropertiesService;

        public HomeController(ILogger<HomeController> logger, IStoragePropertiesService storagePropertiesService)
        {
            this.logger = logger;
            this.storagePropertiesService = storagePropertiesService;
        }

        public async Task<IActionResult> Index(CancellationToken cancellationToken)
        {
            var model = new IndexViewModel();
            if (User.Identity.IsAuthenticated)
            {
                model.IsAuthenticated = true;
                model.UserName = User.Identity.Name;
                model.UserEmail = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
            }
            return View(model);
        }

        [HttpGet]
        public IActionResult Login(string returnUrl = "/")
        {
            returnUrl = Url.Content("~" + returnUrl);
            return Challenge(new AuthenticationProperties() { RedirectUri = returnUrl }, "Ping");
        }


        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
