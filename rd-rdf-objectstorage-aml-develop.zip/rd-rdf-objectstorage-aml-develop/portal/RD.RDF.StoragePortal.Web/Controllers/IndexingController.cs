﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Web.Controllers
{
    [Authorize]
    public class IndexingController : Controller
    {
        private readonly ILogger<IndexingController> _logger;
        private readonly IIndexingPortalService _indexingService;

        public IndexingController(ILogger<IndexingController> logger, IIndexingPortalService indexingService)
        {
            _logger = logger;
            _indexingService = indexingService;
        }

        // GET: IndexingController
        public async Task<ActionResult> Index(CancellationToken token)
        {
            var model = new List<IndexingModel>();
            if (User.Identity.IsAuthenticated)
            {
                var result = await _indexingService.GetAllAsync(token);

                return View(result);
            }

            return View(model);
        }

        // GET: IndexingController/Create
        public async Task<ActionResult> Create()
        {
            return View();
        }

        // POST: IndexingController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(IndexingModel input, CancellationToken token)
        {
            if (input.IndexId == 0)
            {
                var result = await _indexingService.CreateIndexingAsync(input, token);
                return RedirectToAction(nameof(Index));
            }
            else
            {
                return View();
            }
        }

        // GET: IndexingController/Edit/5
        public async Task<ActionResult> Edit(int id, CancellationToken token)
        {
            var result = await _indexingService.GetIndexingByIdAsync(id, token);
            return View(result);
        }

        // POST: IndexingController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(EditIndexingModel input, CancellationToken token)
        {
            // simple way to update Passwords
            input.RDFKafkaKeyChanged = (input.RDFKafkaKey != null);
            input.RDFKafkaConnectionStringChanged = (input.RDFKafkaConnectionString != null);
            input.IndexOdbcConnectionStringChanged = (input.IndexOdbcConnectionString != null);


            await _indexingService.UpdateIndexingByIdAsync(input, token);
            return RedirectToAction(nameof(Index));
        }
    }
}
