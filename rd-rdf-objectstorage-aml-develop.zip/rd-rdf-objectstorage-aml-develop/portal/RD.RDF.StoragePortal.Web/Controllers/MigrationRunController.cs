﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Web.Controllers
{
    [Authorize]
    public class MigrationRunController : Controller
    {
        private readonly ILogger<MigrationRunController> logger;
        private readonly IMigrationRunService migrationRunService;
        public MigrationRunController(ILogger<MigrationRunController> logger, IMigrationRunService migrationRunService)
        {
            this.logger = logger;
            this.migrationRunService = migrationRunService;
        }
        
        public async Task<ActionResult>DisplayAddMigrationRun(int migId, CancellationToken cancellationToken)
        {
            RunMigrationVM migrunvm = await migrationRunService.AddMigrationRunDataSourceAsync(migId, cancellationToken);

            return View("MigrationRun", migrunvm);


        }
        [HttpGet]
        public async Task<ActionResult> MigrationRunObjects(int migrunId, CancellationToken cancellationToken)
        {
            var migrunobjects = await migrationRunService.GetMigRunObjectsAsync(migrunId, cancellationToken);
            
            return View("MigrationRunObject", migrunobjects);

        }
        public async Task<ActionResult>ListMigrationRun(int migdsid, CancellationToken cancellationToken)
        {
            var lstvm = await migrationRunService.GetAllMigrationRunsAsync(migdsid, cancellationToken);
            
            return  View("MigrationRunsList", lstvm); ;

        }
        public async Task<ActionResult> ViewMigrationRun(int migrunId, CancellationToken cancellationToken)
        {
            var migrundata = await migrationRunService.GetMigrationRunByIdAsync(migrunId, cancellationToken);
            return View("MigrationRun", migrundata);

        }

        [HttpGet]
        public async Task<ActionResult> ViewMigrationRunobjects(int migrunId, CancellationToken cancellationToken)
        {
            if (HttpContext.Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            return PartialView("_MigrationRunObjects", migrationRunService.GetMigRunObjectsAsync(migrunId, cancellationToken));
            
            return View("MigrationRun");

        }

    }
}
