﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StoragePortal.Web.Controllers
{
    [Authorize]
    public class ContainerController : Controller
    {
        private readonly ILogger<ContainerController> _logger;
        private readonly IContainerService _containerService;
        private readonly IIndexingPortalService _indexingService;

        public ContainerController(ILogger<ContainerController> logger, IContainerService containersService, IIndexingPortalService indexingService)
        {
            this._logger = logger;
            this._containerService = containersService;
            this._indexingService = indexingService;
        }

        // GET: ContainersController
        public async Task<ActionResult> Index(CancellationToken cancellationToken)
        {
            var model = new List<ContainersModel>();
            if (User.Identity.IsAuthenticated)
            {
                var result = await _containerService.GetAllStorageContainersAsync(cancellationToken);

                return View(result);

            }


            return View(model);
        }

        // GET: ContainersController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ContainersController/Create
        public async Task< ActionResult> Create(CancellationToken cancellationToken)
        {
            var items = await _indexingService.GetAllAsync(cancellationToken);
            
            if (items != null)
            {
                ViewBag.Indexes = items;
            }
            return View();
        }

        // POST: ContainersController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(ContainersModel input, CancellationToken cancellationToken)
        {
            try
            {
                if (input.ContainerId == 0)
                {
                    var result = await _containerService.CreateStorageContainerAsync(input, cancellationToken);
                    return RedirectToAction(nameof(Index));
                }

                else
                    return View();

            }
            catch
            {
                return View();
            }
        }

        // GET: ContainersController/Edit/5
        public async Task<ActionResult> Edit(int id, CancellationToken cancellationToken)
        {
            var items = await _indexingService.GetAllAsync(cancellationToken);

            if (items != null)
            {
                ViewBag.Indexes = items;
            }

            var result = await _containerService.GetStorageContainerByIdAsync(id, cancellationToken);

            return View(result);
        }
        


        // POST: ContainersController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(ContainersModel input, CancellationToken cancellationToken)
        {
            try
            {
                await _containerService.UpdateContainerAsync(input, cancellationToken);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
