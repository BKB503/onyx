﻿using System.Collections.Generic;

namespace RD.RDF.StoragePortal.Web.Models
{
    public class IndexViewModel
    {
        public bool IsAuthenticated { get; set; }

        public string UserName { get; set; }

        public string UserEmail { get; set; }

        public List<string> UserRoles { get; set; } = new List<string>();
    }
}
