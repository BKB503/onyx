﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using RD.RDF.StoragePortal.Contracts.Configuration;
using RD.RDF.StoragePortal.Core.Services;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.Repository;
using System.Diagnostics;

namespace RD.RDF.StoragePortal.Web.Helpers
{
    public static class StartupConfigureExtensions
    {
        public static IServiceCollection InitConfiguration(this IServiceCollection services, IConfiguration Configuration)
        {
            services.Configure<PingIdConfiguration>(Configuration.GetSection(PingIdConfiguration.PingId));
            services.Configure<MigrationKafkaConfiguration>(Configuration.GetSection(MigrationKafkaConfiguration.KafkaSettings));
            services.AddSingleton<KafkaConfigurationKeyVaultProvider>();//it can be singleton
            return services;
        }

        public static IServiceCollection ConfigureDBContext(this IServiceCollection services, IConfiguration Configuration)
        {
            string connectionString = Configuration.GetConnectionString("PortalDB");
            // if we are locally running it on dev box

#if DEBUG
            if (Debugger.IsAttached)
            {
                connectionString = Configuration.GetConnectionString("LocalPortalDB");
            }
#endif

            //configure sql server
            services.AddDbContext<StoragePortalDbContext>(options =>
                options.UseSqlServer(connectionString, sqlOptions =>
                {
                    sqlOptions.CommandTimeout(120);
                })
            );
            services.AddScoped<IStoragePropertiesRepository, StoragePropertiesRepository>();
            services.AddScoped<IStoragePropertiesService, StoragePropertiesService>();

            services.AddScoped<IMigrationsRepository, MigrationsRepository>();
            services.AddScoped<IMigrationService, MigrationService>();

            services.AddScoped<IMigrationRunRepository, MigrationRunRepository>();
            services.AddScoped<IMigrationRunService, MigrationRunService>();

            services.AddScoped<IContainersRepository, StorageContainersRepository>();
            services.AddScoped<IContainerService, ContainersService>();

            services.AddScoped<IIndexingPortalRepository, IndexingRepository>();
            services.AddScoped<IIndexingPortalService, IndexingPortalService>();

            return services;
        }

    }
}
