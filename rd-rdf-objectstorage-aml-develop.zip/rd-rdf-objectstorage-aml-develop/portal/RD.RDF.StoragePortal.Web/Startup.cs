using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.Web.Helpers;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Claims;
using System.Text.Json;

namespace RD.RDF.StoragePortal.Web
{
    public class Startup
    {
        private readonly string pathBase = "/";
        private readonly string callbackPath = "/signin-ping";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            if (!string.IsNullOrEmpty(configuration["ASPNETCORE_BASE_PATH"]))
            {
                pathBase = configuration["ASPNETCORE_BASE_PATH"];           
            }
            FullVersionName = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion;
            ProductVersionName = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
            VersionName = Assembly.GetEntryAssembly().GetName().Version.ToString();
        }

        public IConfiguration Configuration { get; }
        public static string EnvironmentName { get; internal set; }
        public static string ProductVersionName { get; internal set; }
        public static string FullVersionName { get; internal set; }
        public static string VersionName { get; internal set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.InitConfiguration(Configuration)
                     .ConfigureDBContext(Configuration);


            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = "PingCookie";
                options.DefaultSignInScheme = "PingCookie";
                options.DefaultChallengeScheme = "Ping";
            }).AddCookie("PingCookie", options =>
            {
                options.Cookie.MaxAge = new TimeSpan(0, 29, 0);
                options.ExpireTimeSpan = new TimeSpan(0, 29, 0);

            }).AddOAuth("Ping", options =>
            {
                options.ClientId = Configuration["PingId:ClientId"];
                options.ClientSecret = Configuration["PingId:ClientSecret"];

                options.CallbackPath = new PathString(callbackPath);

                options.Scope.Add("openid profile email roles groups");
                options.UsePkce = true;
                options.SaveTokens = true;

                options.AuthorizationEndpoint = Configuration["PingId:AuthorizationEndpoint"];
                options.TokenEndpoint = Configuration["PingId:TokenEndpoint"];
                options.UserInformationEndpoint = Configuration["PingId:UserInformationEndpoint"];

                options.ClaimActions.MapJsonKey(ClaimTypes.Name, "immutable_id");
                options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "immutable_id");
                options.ClaimActions.MapJsonKey(ClaimTypes.GivenName, "given_name");
                options.ClaimActions.MapJsonKey(ClaimTypes.Surname, "family_name");
                options.ClaimActions.MapJsonKey(ClaimTypes.Email, "email");

                options.ClaimActions.MapJsonKey("urn:openid:groups", "groups");


                options.Events = new OAuthEvents
                {
                    OnCreatingTicket = async context =>
                    {
                        var request = new HttpRequestMessage(HttpMethod.Get, context.Options.UserInformationEndpoint);
                        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", context.AccessToken);

                        var response = await context.Backchannel.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, context.HttpContext.RequestAborted);
                        response.EnsureSuccessStatusCode();

                        var responseText = await response.Content.ReadAsStringAsync();

                        var user = JsonDocument.Parse(responseText);
                        context.RunClaimActions(user.RootElement);
                        string token = context.AccessToken;
                    }
                };
            });

            services.AddControllersWithViews();
            services.AddHttpContextAccessor();

            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders = ForwardedHeaders.All;
                options.KnownNetworks.Clear();
                options.KnownProxies.Clear();
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, StoragePortalDbContext dataContext, ILogger<Startup> logger)
        {
            logger.LogInformation($"Startup.Configure: app.UsePathBase(\"{pathBase}\");");
            var fwdOptions = new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.All
            };
            fwdOptions.KnownNetworks.Clear();
            fwdOptions.KnownProxies.Clear();
            // This is needed if running behind a reverse proxy            
            app.UseForwardedHeaders(fwdOptions);
            if (!string.IsNullOrEmpty(pathBase) && pathBase.Length > 1)
            {
                var pbs = new PathString(pathBase);
                app.UsePathBase(pbs);
                app.Use((context, next) =>
                {
                    context.Request.PathBase = pbs;
                    return next();
                });
            } 
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                // when in develop we can do migrations
#if DEBUG
                if (Debugger.IsAttached)
                {
                    //dataContext.Database.EnsureCreated();
                    dataContext.Database.Migrate();
                }
#endif
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
