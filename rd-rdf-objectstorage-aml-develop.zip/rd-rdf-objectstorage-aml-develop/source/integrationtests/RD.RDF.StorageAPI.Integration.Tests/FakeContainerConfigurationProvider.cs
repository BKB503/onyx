﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Extensions.Configuration;
using Confluent.Kafka;
using System.Linq;
using Microsoft.EntityFrameworkCore.Update.Internal;
using System;
using System.ComponentModel;
using Microsoft.AspNetCore.Hosting;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;

namespace RD.RDF.StorageAPI.Integration.Tests
{
    public class FakeContainerConfigurationProvider : IContainerConfigurationProvider
    {
        private readonly IConfiguration configuration;
        private readonly string environment;
        private readonly string gcpProxy;

        private IList<ContainerResource> config = new List<ContainerResource>();

        public FakeContainerConfigurationProvider(IConfiguration configuration, IHostingEnvironment he)
        {
            this.configuration = configuration;
            //depended on environment we need to have different set of container configs
            environment = configuration["ASPNETCORE_ENVIRONMENT"] ?? he.EnvironmentName;
            gcpProxy = configuration["GCP_PROXY"];
            PrepareConfig(environment);

        }

        private void PrepareConfig(string environment)
        {
            var indexConfig = new KafkaConfiguration
            {
                EventHubKey = configuration["RDFKafkaKey"],
                EventHubConnectionString = configuration["RDFKafkaConnectionString"],
                Topic = configuration["RDFKafkaTopicFiles"],
                KafkaServers = configuration["RDFKafkaServers"],
                IndexOdbcConnectionString = configuration["IndexOdbcConnectionString"],
                SaslUsername = configuration["RDFKafkaUserName"],
                Type = "KafkaTopic-supplementarydatain"
            };

            ContainerResource azureBlobStorage = null;
            string azureBlobStorageName = string.Empty;

            ContainerResource gcpBlobStorage = null;
            string gcpBlobStorageName = string.Empty;

            switch (environment)
            {
                case "Development":
                case "DevTest":
                    {
                        azureBlobStorageName = "storage-api-dev";
                        azureBlobStorage = new ContainerResource(azureBlobStorageName)
                        {
                            Configuration = new StorageContainerConfiguration
                            {
                                Name = azureBlobStorageName,
                                Type = StorageContainerType.azureblob,
                                ContainerAccountName = "rdrdfstorageblobdev",
                                ContainerAccountUrl = "https://rdrdfstorageblobdev.blob.core.windows.net",
                                ContainerName = azureBlobStorageName,
                                AllianceTagName = "AgreementPacket",
                                ValidateAudience = false
                            }
                        };

                        gcpBlobStorageName = "storage-api-dev-gcp";
                        gcpBlobStorage = new ContainerResource(gcpBlobStorageName)
                        {
                            Configuration = new StorageContainerConfiguration
                            {
                                Name = gcpBlobStorageName,
                                Type = StorageContainerType.googleblob,
                                ContainerAccountName = "gsk-rd-rdf-dev",
                                ContainerAccountUrl = "https://console.cloud.google.com/storage/browser/euwest1-rdf-dev-gsb-00001-coldline",
                                ContainerName = "euwest1-rdf-dev-gsb-00001-coldline",
                                AllianceTagName = "AgreementPacket",
                                ValidateAudience = false,
                                ProxyUrl = gcpProxy
                            }
                        };
                    }
                    break;
                case "Uat":
                    {
                        azureBlobStorageName = "storage-api-uat";
                        azureBlobStorage = new ContainerResource(azureBlobStorageName)
                        {
                            Configuration = new StorageContainerConfiguration
                            {
                                Type = StorageContainerType.azureblob,
                                ContainerAccountName = "rdrdfstorageblobuat01",
                                ContainerAccountUrl = "https://rdrdfstorageblobuat01.blob.core.windows.net",
                                ContainerName = azureBlobStorageName,
                                AllianceTagName = "AgreementPacket",
                                ValidateAudience = false
                            }
                        };
                        //gcpBlobStorageName = "storage-api-uat-gcp";
                        //gcpBlobStorage = new ContainerResource(gcpBlobStorageName)
                        //{
                        //    Configuration = new StorageContainerConfiguration
                        //    {
                        //        Name = gcpBlobStorageName,
                        //        Type = StorageContainerType.googleblob,
                        //        ContainerAccountName = "gsk-rd-rdf-uat",
                        //        ContainerAccountUrl = "https://console.cloud.google.com/storage/browser/euwest1-rdf-dev-gsb-00001-coldline",
                        //        ContainerName = "euwest1-rdf-dev-gsb-00001-coldline",
                        //        AllianceTagName = "AgreementPacket",
                        //        ValidateAudience = false,
                        //        ProxyUrl = "stvsiww056.corpnet2.com:800" // that line is for runing the test locally
                        //    }
                        //};
                    }
                    break;
                case "Prod":
                    {
                        azureBlobStorageName = "storage-api-prod";
                        azureBlobStorage = new ContainerResource(azureBlobStorageName)
                        {
                            Configuration = new StorageContainerConfiguration
                            {
                                Type = StorageContainerType.azureblob,
                                ContainerAccountName = "rdrdfstorageblobprod01",
                                ContainerAccountUrl = "https://rdrdfstorageblobprod01.blob.core.windows.net",
                                ContainerName = azureBlobStorageName,
                                AllianceTagName = "AgreementPacket",
                                ValidateAudience = false
                            }
                        };
                        //gcpBlobStorageName = "storage-api-prod-gcp";
                        //gcpBlobStorage = new ContainerResource(gcpBlobStorageName)
                        //{
                        //    Configuration = new StorageContainerConfiguration
                        //    {
                        //        Name = gcpBlobStorageName,
                        //        Type = StorageContainerType.googleblob,
                        //        ContainerAccountName = "gsk-rd-rdf-dev",
                        //        ContainerAccountUrl = "https://console.cloud.google.com/storage/browser/euwest1-rdf-dev-gsb-00001-coldline",
                        //        ContainerName = "euwest1-rdf-dev-gsb-00001-coldline",
                        //        AllianceTagName = "AgreementPacket",
                        //        ValidateAudience = false,
                        //        ProxyUrl = "stvsiww056.corpnet2.com:800" // that line is for runing the test locally
                        //    }
                        //};
                    }
                    break;
                default:
                    break;
            }
            azureBlobStorage.Configuration.ContainerKey = configuration[$"{azureBlobStorageName}-ContainerKey"];
            azureBlobStorage.Configuration.ContainerConnectionString = configuration[$"{azureBlobStorageName}-ContainerConnectionString"];
            azureBlobStorage.Configuration.IndexingConfiguration = indexConfig;
            azureBlobStorage.Configuration.IsConnectionAvailable = true;
            azureBlobStorage.Configuration.IsVersionEnabled = true;
            config.Add(azureBlobStorage);

            if (!string.IsNullOrEmpty(gcpBlobStorageName))
            {
                gcpBlobStorage.Configuration.ContainerKey = configuration[$"{gcpBlobStorageName}-ContainerKey"];
                gcpBlobStorage.Configuration.ContainerConnectionString = configuration[$"{gcpBlobStorageName}-ContainerConnectionString"];
                gcpBlobStorage.Configuration.IndexingConfiguration = indexConfig;
                gcpBlobStorage.Configuration.IsConnectionAvailable = true;
                gcpBlobStorage.Configuration.IsVersionEnabled = true;
                config.Add(gcpBlobStorage);
            }
        }

        public Task<IList<ContainerResource>> GetAllContainersAdminAsync(CancellationToken token = default)
        {
            return Task.FromResult(config);
        }

        public Task<IList<ContainerResource>> GetAllContainersAsync(CancellationToken token = default)
        {
            return Task.FromResult(config);
        }

        public Task<ContainerResource> GetContainerByNameAdminAsync(string containerName, CancellationToken token = default)
        {
            return Task.FromResult(config.FirstOrDefault(c => c.ContainerName == containerName));
        }

        public Task<ContainerResource> GetContainerByNameAsync(string containerName, CancellationToken token = default)
        {
            return Task.FromResult(config.FirstOrDefault(c => c.ContainerName == containerName));
        }
    }


}
