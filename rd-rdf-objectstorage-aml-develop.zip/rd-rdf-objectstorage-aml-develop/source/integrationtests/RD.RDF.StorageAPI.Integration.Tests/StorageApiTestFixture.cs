﻿using System;

namespace RD.RDF.StorageAPI.Integration.Tests
{
    public class StorageApiTestFixture : IDisposable
    {
        public StorageApiTestFixture()
        {
            TestRunId = DateTime.UtcNow.ToString("u");
            Instances++;
        }

        public string TestRunId { get; }

        public static int Instances { get; private set; }

        public string Environment { get; set; }

        public string TestContainerName { get; set; }


        public void Dispose()
        {

        }
    }

}
