﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace RD.RDF.StorageAPI.Integration.Tests
{
    public class ContainersAllowedClientIdGenerator : IEnumerable<object[]>
    {
        private readonly string environment;
        private readonly Dictionary<string, List<string>> dictinaryClientIds;
        public ContainersAllowedClientIdGenerator()
        {
            environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development";

            dictinaryClientIds = new Dictionary<string, List<string>>
            {
                {
                    "Development",
                    new List<string>
                        {
                           "52d67d421dd44b3dad950adc12513fb2",
                           // "ce85d31f462a4fdf917e94cbee2ef392"

                        }
                },
                {
                    "DevTest",
                    new List<string>
                        {
                           "52d67d421dd44b3dad950adc12513fb2",
                            "ce85d31f462a4fdf917e94cbee2ef392"

                        }
                },
                 {
                    "Uat",
                    new List<string>
                        {
                           "app:snbapp:stage",
                           "8160384d43e6460a81854515d069b2f6"
                        }
                },
                 {
                    "Prod",
                    new List<string>
                        {
                           "app:snbapp:prod",
                           "5ec8d1a7be9f4ac18f92aeb85fad1b4d"
                        }
                },


            };
        }
        public IEnumerator<object[]> GetEnumerator()
        {

            if (dictinaryClientIds.TryGetValue(environment, out List<string> elements))
            {
                return elements.Select(item => new object[] { item }).GetEnumerator();
            }
            else
            {
                return null;
            }

        }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

    }


}
