﻿using Microsoft.AspNetCore.Mvc.Testing;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using Xunit;
using FluentAssertions;
using Xunit.Abstractions;
using Microsoft.AspNetCore.Hosting;
using System.Text.Json.Serialization;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using RD.RDF.StorageAPI.Service;
using RD.RDF.StorageAPI.Contracts.Model;
using Microsoft.Extensions.DependencyInjection;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using System.Text;

namespace RD.RDF.StorageAPI.Integration.Tests
{
    [Collection("IntegrationTestCollection")]
    public class StorageApiIntegrationTest : IClassFixture<StorageApiTestFactory<Startup>>
    {
        private readonly HttpClient client;
        private readonly JsonSerializerOptions serializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

        private readonly string testContainerName;
        public static string EnvironmentRun;
        private readonly StorageApiTestFixture testCollection;
        private readonly ITestOutputHelper output;


        public StorageApiIntegrationTest(StorageApiTestFixture testCollection, StorageApiTestFactory<Startup> factory, ITestOutputHelper output)
        {
            client = factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
            client.BaseAddress = new Uri("http://localhost:5001");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var he = (IHostingEnvironment)factory.Services.GetService(typeof(IHostingEnvironment));
            testContainerName = Environment.GetEnvironmentVariable("TEST_CONTAINER_NAME") ?? "storage-api-dev";  //"storage-api-dev-gcp"  "storage-api-dev"
            EnvironmentRun = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? he.EnvironmentName;
            this.testCollection = testCollection;
            this.output = output;
            output.WriteLine($"TEST_CONTAINER_NAME = {testContainerName}");
            output.WriteLine($"ASPNETCORE_ENVIRONMENT = {EnvironmentRun}");
            testCollection.TestContainerName = testContainerName;
            testCollection.Environment = EnvironmentRun;
            serializerOptions.Converters.Add(new JsonStringEnumConverter());

            var ccp = factory.Services.GetService<IContainerConfigurationProvider>();
            var allConfigsTask = ccp.GetAllContainersAdminAsync();
            allConfigsTask.Wait();
            var allConfig = allConfigsTask.Result;
            foreach (var config in allConfig)
            {
                config.Configuration.IsConnectionAvailable = true;
                config.Configuration.IsVersionEnabled = true;
            }
        }

        private dynamic PrepareToken(string clientId, string issuer = "https://federation-qa.gsk.com", string mudId = default, string email = default)
        {

            JwtSecurityTokenHandler jwt = new JwtSecurityTokenHandler();


            dynamic data = new ExpandoObject();
            data.role = new[] { "test", "roles", "no_meaning" };
            if (clientId != null)
            {
                data.client_id = clientId;
                data.aud = clientId;
            }
            data.iss = issuer;
            if (mudId != null)
            {
                data.sub = mudId;
                data.unique_name = mudId;
                //data.nameidentifier = mudId;
                //data.immutable_id = mudId;
                data.email = email;
            }
            return data;
        }



        [Fact]
        public async Task Test_GetAllContainersAnyClientId()
        {
            output.WriteLine($"Starting Test_GetAllContainersAnyClientId TestRunId: {testCollection.TestRunId}");

            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("AnyClientId"));

            var response = await client.GetAsync("/api/v1/containers");
            var responseString = await response.Content.ReadAsStringAsync();
            Assert.NotNull(response.EnsureSuccessStatusCode());
            responseString.Should().NotBeNull();
            var contResp = JsonSerializer.Deserialize<PagedApiResponse<IList<string>>>(responseString, serializerOptions);
            contResp.Should().NotBeNull()
                    .And.Match(el => ((PagedApiResponse<IList<string>>)el).Succeeded == true);
            contResp.Data
                    .Should().NotBeEmpty()
                    .And.HaveCountGreaterThan(1)
                    .And.Contain(el => el == testContainerName);
        }



        [Theory]
        [ClassData(typeof(ContainersAllowedClientIdGenerator))]
        public async Task Test_GetAllContainersAllowedClientId(string clientId)
        {
            output.WriteLine($"Starting Test_GetAllContainersAllowedClientId TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken(clientId));

            var response = await client.GetAsync("/api/v1/containers");
            var responseString = await response.Content.ReadAsStringAsync();
            Assert.NotNull(response.EnsureSuccessStatusCode());


            Assert.NotNull(responseString);
            var contResp = JsonSerializer.Deserialize<PagedApiResponse<IList<string>>>(responseString, serializerOptions);
            contResp.Should().NotBeNull()
                        .And.Match(el => ((PagedApiResponse<IList<string>>)el).Succeeded == true);
            contResp.Data
                    .Should().NotBeEmpty()
                    .And.HaveCountGreaterThan(0)
                    .And.Contain(el => el == testContainerName);
        }


        [Fact]
        public async Task Test_GetTestContainerDetails()
        {
            output.WriteLine($"Starting Test_GetTestContainerDetails TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            var response = await client.GetAsync($"/api/v1/container/{testContainerName}");
            var responseString = await response.Content.ReadAsStringAsync();
            output.WriteLine($"Call to /api/v1/container/{testContainerName} {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");
            Assert.NotNull(response.EnsureSuccessStatusCode());
            responseString.Should().NotBeNull();
            var continerDetails = JsonSerializer.Deserialize<ApiResponse<ContainerResource>>(responseString, serializerOptions);
            continerDetails.Should().NotBeNull()
                           .And.Match(el => ((ApiResponse<ContainerResource>)el).Succeeded == true);
            continerDetails.Data.Should().NotBeNull();
            continerDetails.Data.ContainerName.Should().Be(testContainerName);
            continerDetails.Data.Configuration.Should().NotBeNull();
            continerDetails.Data.Configuration.Name.Should().Be(testContainerName);
            continerDetails.Data.Configuration.IsVersionEnabled.Should().BeTrue();
            continerDetails.Data.Configuration.IsConnectionAvailable.Should().BeTrue();
            continerDetails.Data.Configuration.ValidateAudience.Should().BeFalse();
            continerDetails.Data.Configuration.IndexingConfiguration.Should().NotBeNull();
        }



        [Fact]
        public async Task Test_GetTestContainerContents()
        {
            output.WriteLine($"Starting Test_GetTestContainerContents TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            var response = await client.GetAsync($"/api/v1/container/{testContainerName}/contents");
            var responseString = await response.Content.ReadAsStringAsync();
            output.WriteLine($"Call to /api/v1/container/{testContainerName}/contents {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");
            Assert.NotNull(response.EnsureSuccessStatusCode());
            responseString.Should().NotBeNull();
            var contents = JsonSerializer.Deserialize<ContainerContents>(responseString, serializerOptions);
            contents.Should().NotBeNull();
            contents.Succeeded.Should().BeTrue();
            contents.ContainerName.Should().Be(testContainerName);
        }

        [Fact]
        public async Task Test_UploadDataWithMetadataGSKProprietaryAlliance()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadataNoAlliance TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/GSK Proprietary/TestImage.png";
            string fileMetadataPath = "TestData/GSK Proprietary/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/GSK Proprietary";

            var uploadResult = await UploadFileAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );
        }

        [Fact]
        public async Task Test_UploadDataWithMetadata3MAlliance()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadataNoAlliance TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "jxs6719", email: "jxs6719@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/3M/TestImage.png";
            string fileMetadataPath = "TestData/3M/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/3M";

            var uploadResult = await UploadFileAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("3M");


            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

        }


        [Fact]
        public async Task Test_UploadDataWithObjectGSKProprietaryAlliance()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadataNoAlliance TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            string fileName = "TestImage-object.png";
            string filePath = "TestData/GSK Proprietary/TestImage.png";
            string fileMetadataPath = "TestData/GSK Proprietary/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/GSK Proprietary";

            var uploadResult = await UploadFileObjectAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

        }

        [Fact]
        public async Task Test_UploadDataWithObject3MAlliance()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadataNoAlliance TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "jxs6719", email: "jxs6719@gsk.com"));

            string fileName = "TestImage-object.png";
            string filePath = "TestData/3M/TestImage.png";
            string fileMetadataPath = "TestData/3M/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/3M";

            var uploadResult = await UploadFileObjectAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("3M");


            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

        }





        [Fact]
        public async Task Test_UploadDataWithMetadata_VersionsSaving()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadataNoAlliance TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/GSK Proprietary/TestImage.png";
            string fileMetadataPath = "TestData/GSK Proprietary/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/VersionSaving";

            var uploadResult = await UploadFileAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

            //saving second version

            var uploadResult2 = await UploadFileAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult2.Should().NotBeNull();
            uploadResult2.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult2.FileInformation.Should().NotBeNull();
            uploadResult2.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult2.FileInformation.FileName.Should().Be(fileName);
            uploadResult2.FileInformation.FolderName.Should().Be(folder);
            uploadResult2.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult2.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult2 = await GetFileInfoAsync(fileName, folder, uploadResult2.FileInformation.FileGuid);
            fileInfoResult2.Should().BeEquivalentTo(uploadResult2.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );


            var fileInfoResult1Again = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);
            fileInfoResult1Again.Should().NotBeNull().And.BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                                      .Excluding(r => r.FileVersions)
                                                );


        }

        [Fact]
        public async Task Test_UploadDataWithObject_VersionsSaving()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadataNoAlliance TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/GSK Proprietary/TestImage.png";
            string fileMetadataPath = "TestData/GSK Proprietary/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/VersionSavingObj";

            var uploadResult = await UploadFileObjectAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

            //saving second version

            var uploadResult2 = await UploadFileObjectAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult2.Should().NotBeNull();
            uploadResult2.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult2.FileInformation.Should().NotBeNull();
            uploadResult2.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult2.FileInformation.FileName.Should().Be(fileName);
            uploadResult2.FileInformation.FolderName.Should().Be(folder);
            uploadResult2.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult2.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult2 = await GetFileInfoAsync(fileName, folder, uploadResult2.FileInformation.FileGuid);
            fileInfoResult2.Should().BeEquivalentTo(uploadResult2.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );


            var fileInfoResult1Again = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);
            fileInfoResult1Again.Should().NotBeNull().And.BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                                      .Excluding(r => r.FileVersions)
                                                );


        }


        [Fact]
        public async Task Test_UploadDataWithMetadata_VersionsSaving_SlashAtTheEnd()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadata_VersionsSaving_SlashAtTheEnd TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/GSK Proprietary/TestImage.png";
            string fileMetadataPath = "TestData/GSK Proprietary/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/VersionSaving1/";

            var uploadResult = await UploadFileAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder.Substring(0, folder.Length - 1));
            uploadResult.FileInformation.FilePath.Should().Be(folder + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

            //saving second version

            var uploadResult2 = await UploadFileObjectAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult2.Should().NotBeNull();
            uploadResult2.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult2.FileInformation.Should().NotBeNull();
            uploadResult2.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult2.FileInformation.FileName.Should().Be(fileName);
            uploadResult2.FileInformation.FolderName.Should().Be(folder.Substring(0, folder.Length - 1));
            uploadResult2.FileInformation.FilePath.Should().Be(folder + fileName);
            uploadResult2.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult2 = await GetFileInfoAsync(fileName, folder, uploadResult2.FileInformation.FileGuid);
            fileInfoResult2.Should().BeEquivalentTo(uploadResult2.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );


            var fileInfoResult1Again = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);
            fileInfoResult1Again.Should().NotBeNull().And.BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                                      .Excluding(r => r.FileVersions)
                                                );


        }


        [Fact]
        public async Task Test_UploadDataWith_UnicodeChars()
        {
            output.WriteLine($"Starting Test_UploadDataWith_UnicodeChars TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/GSK Proprietary/TestImage.png";
            string fileMetadataPath = "TestData/GSK Proprietary/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/Holidays–🏝";

            var uploadResult = await UploadFileAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );
        }


        [Fact]
        public async Task Test_VerifyReading_RestrictedAlliance()
        {
            output.WriteLine($"Starting Test_UploadDataWithMetadata3MAlliance_VerifyAllianceReading TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "text123", email: "jxs123@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/3M/TestImage.png";
            string fileMetadataPath = "TestData/3M/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/3Ma";

            var uploadResult = await UploadFileAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("3M");


            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeNull();

            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "jxs6719", email: "jxs6719@gsk.com"));
            var fileInfoResult1 = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);
            fileInfoResult1.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

        }




        private async Task<UploadFileResult> UploadFileAsync(string fileName, string filePath, string metadataPath, string folder)
        {
            string uploadFile = $"api/v1/upload/{testContainerName}/file";
            if (!string.IsNullOrEmpty(folder))
            {
                uploadFile += $"?folder={folder}";
            }
            using (var content = new MultipartFormDataContent())
            {
                var fi = new FileInfo(filePath);
                var fiMetadata = new FileInfo(metadataPath);
                using var fileStream = fi.OpenRead();
                using var metadataStream = fiMetadata.OpenRead();

                var fileContent = new StreamContent(fileStream);
                var fileContentMetadata = new StreamContent(metadataStream);
                content.Add(fileContent, "file", fileName);
                content.Add(fileContentMetadata, "metadata", fileName + "-metadata.json");
                var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile)
                {
                    Content = content
                };
                requestUpload.Headers.Add("accept", "application/json");

                var response = await client.SendAsync(requestUpload);
                var responseString = await response.Content.ReadAsStringAsync();

                output.WriteLine($"Call to {uploadFile} {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");

                return JsonSerializer.Deserialize<UploadFileResult>(responseString, serializerOptions);
            }

        }


        private async Task<UploadFileResult> UploadFileObjectAsync(string fileName, string filePath, string metadataPath, string folder)
        {
            string uploadFile = $"api/v1/upload/{testContainerName}/fileObj";
            if (!string.IsNullOrEmpty(folder))
            {
                uploadFile += $"?folder={folder}";
            }
            using (var content = new MultipartFormDataContent())
            {
                var fi = new FileInfo(filePath);
                var fiMetadata = new FileInfo(metadataPath);
                using var fileStream = fi.OpenRead();
                var fileContent = new StreamContent(fileStream);
                content.Add(fileContent, "file", fileName);
                using var metadataStream = fiMetadata.OpenRead();
                var dict = JsonSerializer.Deserialize<MetadataDictionary>(metadataStream, serializerOptions);
                MetadataCollections collection = new MetadataCollections(dict);
                foreach (var item in collection.Items)
                {
                    // JSON Format eg: "{\"key\": \"string\",\"value\": \"string\", \"isIndexed\": true}";
                    content.Add(new StringContent(JsonSerializer.Serialize(item)), $"Metadata.Items");
                }


                var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile)
                {
                    Content = content
                };
                requestUpload.Headers.Add("accept", "application/json");

                var response = await client.SendAsync(requestUpload);
                var responseString = await response.Content.ReadAsStringAsync();

                output.WriteLine($"Call to {uploadFile} {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");

                return JsonSerializer.Deserialize<UploadFileResult>(responseString, serializerOptions);
            }

        }


        private async Task<FileResource> GetFileInfoAsync(string fileName, string folder, string fileGuid)
        {
            //get container contents            
            string queryString = null;
            if (!string.IsNullOrEmpty(folder))
            {
                queryString = $"?folder={folder}";
            }
            if (!string.IsNullOrEmpty(fileGuid))
            {
                queryString = $"{queryString}{(queryString == null ? "?" : "&")}fileGuid={fileGuid}";
            }
            string getfileInfo = $"api/v1/container/{testContainerName}/contents/{fileName}{queryString}";
            using (var request = new HttpRequestMessage(HttpMethod.Get, getfileInfo))
            {

                var response = await client.SendAsync(request);
                var responseString = await response.Content.ReadAsStringAsync();
                output.WriteLine($"Call to {getfileInfo} {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");
                if (response.StatusCode == HttpStatusCode.OK)
                {

                    return JsonSerializer.Deserialize<FileResource>(responseString, serializerOptions);
                }
                else
                {
                    return null;
                }
            }

        }

        [Fact]
        public async Task Test_UploadInChunksAsync()
        {
            output.WriteLine($"Starting Test_UploadInChunksAsync TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));

            string fileName = "testUpload.zip";
            string folder = "TestRuns/" + testCollection.TestRunId + "/PartialUpload";

            string filePath = "TestData/PartialUpload/testUpload.zip";
            string metadataPath = "TestData/PartialUpload/Testlargeupload.json";
            // int filePartNumber = 0;
            var fileInfo = new FileInfo(filePath);
            int filePartSize = 1024 * 1024; // 1mb part 
            long fileTotalSize = fileInfo.Length;
            int chunks = (int)Math.Ceiling((decimal)fileTotalSize / (decimal)filePartSize);

            var uploadpartinit = await UploadPartsInitAsync(fileName, folder);

            uploadpartinit.Should().NotBeNull();
            uploadpartinit.Status.Should().Be(UploadFileResultStatus.Success);
            uploadpartinit.UploadSessionId.Should().NotBeNullOrWhiteSpace();

            var uploadSessionId = uploadpartinit.UploadSessionId;

            List<UploadPartResult> uploadResult = new List<UploadPartResult>();
            using var fs = fileInfo.OpenRead();
            for (int filePartNumber = 0; filePartNumber < chunks; filePartNumber++)
            {
                long remainingBytes = fileTotalSize - (filePartNumber * filePartSize);
                int blockSize = (int)Math.Min(remainingBytes, filePartSize);
                byte[] block = new byte[blockSize];
                int bytesRead = fs.Read(block, 0, blockSize);
                using var partStream = new MemoryStream(block);
                partStream.Seek(0, SeekOrigin.Begin);
                var partUploadResult = await UploadPartFileAsync(fileName, partStream, folder, uploadSessionId, filePartNumber + 1, filePartSize, fileTotalSize);
                partUploadResult.Should().NotBeNull();
                partUploadResult.Status.Should().Be(UploadFileResultStatus.Success);
                uploadResult.Add(partUploadResult);

            }
            var partsList = new UploadPartCommitCollection();
            for (int i = 0; i < uploadResult.Count; i++)
            {
                partsList.Items.Add(new UploadPartCommitItem(i + 1, uploadResult[i].PartGuid));
            }
            // metadata collection
            var fiMetadata = new FileInfo(metadataPath);
            using var metadataStream = fiMetadata.OpenRead();
            var metadataDict = JsonSerializer.Deserialize<MetadataDictionary>(metadataStream, serializerOptions);
            var metadataCollection = new MetadataCollections(metadataDict);

            var commitUpload = await UploadPartsCommitAsync(fileName, folder, uploadpartinit.UploadSessionId, partsList, metadataCollection);
            commitUpload.Should().NotBeNull();
            commitUpload.Status.Should().Be(UploadFileResultStatus.Success);
            commitUpload.FileInformation.Should().NotBeNull();

            commitUpload.FileInformation.Should().NotBeNull();
            commitUpload.FileInformation.FileGuid.Should().NotBeNull();
            commitUpload.FileInformation.FileName.Should().Be(fileName);
            commitUpload.FileInformation.FolderName.Should().Be(folder);
            commitUpload.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            commitUpload.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");

            commitUpload.FileInformation.FileSize.Should().Be(fileTotalSize);

        }
        private async Task<UploadPartsInitResult> UploadPartsInitAsync(string fileName, string folder)
        {
            string uploadFile = $"api/v1/uploadPartsInit/{testContainerName}/file/{fileName}";
            if (!string.IsNullOrEmpty(folder))
            {
                uploadFile += $"?folder={folder}";
            }
            var requestUpload = new HttpRequestMessage(HttpMethod.Get, uploadFile);
            var response = await client.SendAsync(requestUpload);
            var responseString = await response.Content.ReadAsStringAsync();
            output.WriteLine($"Call to {uploadFile} {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");
            return JsonSerializer.Deserialize<UploadPartsInitResult>(responseString, serializerOptions);
        }
        private async Task<UploadPartResult> UploadPartFileAsync(string fileName,
                                                                 Stream partStream,
                                                                 string folder,
                                                                 string uploadSessionId,
                                                                 int filePartNumber,
                                                                 long filePartSize,
                                                                 long fileTotalSize)

        {
            string uploadFile = $"api/v1/uploadPart/{testContainerName}/file/{fileName}/ts/{fileTotalSize}/ps/{filePartSize}/pn/{filePartNumber}";
            if (!string.IsNullOrEmpty(folder))
            {
                uploadFile += $"?folder={folder}";
            }
            using (var content = new MultipartFormDataContent())
            {
                var partContent = new StreamContent(partStream);
                content.Add(partContent, "FilePart", fileName);
                content.Add(new StringContent(uploadSessionId), "UploadSessionId");
                var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile)
                {
                    Content = content
                };
                requestUpload.Headers.Add("accept", "application/json; charset=utf8");
                var response = await client.SendAsync(requestUpload);
                var responseString = await response.Content.ReadAsStringAsync();
                output.WriteLine($"Call to {uploadFile} {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");

                return JsonSerializer.Deserialize<UploadPartResult>(responseString, serializerOptions);

            }
        }

        private async Task<UploadPartCommitResult> UploadPartsCommitAsync(string fileName,
                                                                          string folder,
                                                                          string uploadSessionId,
                                                                          UploadPartCommitCollection parts,
                                                                          MetadataCollections metadata)
        {
            string uploadFile = $"api/v1/uploadPartsCommit/{testContainerName}/file/{fileName}";
            if (!string.IsNullOrEmpty(folder))
            {
                uploadFile += $"?folder={folder}";
            }
            var uploadComitRequest = new UploadPartCommitRequest
            {
                UploadSessionId = uploadSessionId,
                Metadata = metadata,
                Parts = parts
            };


            var json = JsonSerializer.Serialize(uploadComitRequest);
            var data = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(uploadFile, data);
            var responseString = await response.Content.ReadAsStringAsync();
            output.WriteLine($"Call to {uploadFile} {Environment.NewLine}Result string:{Environment.NewLine}{responseString}");

            return JsonSerializer.Deserialize<UploadPartCommitResult>(responseString, serializerOptions);
        }
 
        [Fact]
        public async Task Test_UploadDataWithObject_GermanLettersInAuthor()
        {
            output.WriteLine($"Starting Test_UploadDataWithObject_GermanLettersInAuthor TestRunId: {testCollection.TestRunId}");
            //set fake authentication
            client.SetFakeBearerToken((object)PrepareToken("clientId", mudId: "tst12345", email: "tst@gsk.com"));
            string fileName = "TestImage.png";
            string filePath = "TestData/WrongTexts/TestImage.png";
            string fileMetadataPath = "TestData/WrongTexts/TestImage.json";
            string folder = "TestRuns/" + testCollection.TestRunId + "/WrongTexts";

            var uploadResult = await UploadFileObjectAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult.Should().NotBeNull();
            uploadResult.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult.FileInformation.Should().NotBeNull();
            uploadResult.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult.FileInformation.FileName.Should().Be(fileName);
            uploadResult.FileInformation.FolderName.Should().Be(folder);
            uploadResult.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);

            fileInfoResult.Should().BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );

            //saving second version

            var uploadResult2 = await UploadFileObjectAsync(fileName, filePath, fileMetadataPath, folder);
            uploadResult2.Should().NotBeNull();
            uploadResult2.Status.Should().Be(UploadFileResultStatus.Success);
            uploadResult2.FileInformation.Should().NotBeNull();
            uploadResult2.FileInformation.FileGuid.Should().NotBeNull();
            uploadResult2.FileInformation.FileName.Should().Be(fileName);
            uploadResult2.FileInformation.FolderName.Should().Be(folder);
            uploadResult2.FileInformation.FilePath.Should().Be(folder + "/" + fileName);
            uploadResult2.FileInformation.Metadata["AgreementPacket"].Should().NotBeNull()
                                                                    .And.Be("GSK Proprietary");
            var fileInfoResult2 = await GetFileInfoAsync(fileName, folder, uploadResult2.FileInformation.FileGuid);
            fileInfoResult2.Should().BeEquivalentTo(uploadResult2.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                );


            var fileInfoResult1Again = await GetFileInfoAsync(fileName, folder, uploadResult.FileInformation.FileGuid);
            fileInfoResult1Again.Should().NotBeNull().And.BeEquivalentTo(uploadResult.FileInformation,
                                                    options => options.Excluding(r => r.AllianceAccessVerification)
                                                                      .Excluding(r => r.AgreementPacketName)
                                                                      .Excluding(r => r.FileAvailable)
                                                                      .Excluding(r => r.FileVersions)
                                                );


        }
    }
}
