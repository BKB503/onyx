﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.DataAccess.Providers;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Service;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading;
using System.Threading.Tasks;
using WebMotions.Fake.Authentication.JwtBearer;
using RD.RDF.StorageAPI.Core.Services;
using RD.RDF.StorageAPI.DataAccess.Repositories;

namespace RD.RDF.StorageAPI.Integration.Tests
{
    public class StorageApiTestFactory<TEntryPoint> : WebApplicationFactory<Startup> where TEntryPoint : Startup
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureTestServices(services =>
            {
                services.AddAuthentication(opt =>
                {
                    opt.DefaultAuthenticateScheme = FakeJwtBearerDefaults.AuthenticationScheme;
                    opt.DefaultChallengeScheme = FakeJwtBearerDefaults.AuthenticationScheme;
                }).AddFakeJwtBearer();


                services.AddSingleton<IAllianceInformationProvider, FakeAllianceInformationProvider>();
                services.AddSingleton<IContainerConfigurationProvider, FakeContainerConfigurationProvider>();


                var serviceDescriptor = services.FirstOrDefault(descriptor => descriptor.ImplementationType == typeof(VersionEnabledCheckService));
                if (serviceDescriptor != null) services.Remove(serviceDescriptor);
                serviceDescriptor = null;
                serviceDescriptor = services.FirstOrDefault(descriptor => descriptor.ImplementationType == typeof(KafkaIndexingRepository));
                if (serviceDescriptor != null) services.Remove(serviceDescriptor);

                //services.AddAuthentication("Test")
                //    .AddScheme<AuthenticationSchemeOptions, StorageApiAuthHandler>(
                //        "Test", options => { });
            });
        }
    }




}
