﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Integration.Tests
{
    public class FakeAllianceInformationProvider : IAllianceInformationProvider
    {
        private readonly IConfiguration configuration;
        private readonly string environment;
        private List<AllianceModel> allAlliances = new List<AllianceModel>();

        public FakeAllianceInformationProvider(IConfiguration configuration, IHostingEnvironment he)
        {
            this.configuration = configuration;
            //depended on environment we need to have different set of container configs
            environment = configuration["ASPNETCORE_ENVIRONMENT"] ?? he.EnvironmentName;
            ConfigureAlliances(environment);
        }

        private void ConfigureAlliances(string environment)
        {
            allAlliances.Add(new AllianceModel
            {
                AgreementContractId = 1,
                Name = "3M",
                Code = 102,
                CreationDate = DateTimeOffset.Parse("2008-09-26 11:22:58.000"),
                IsActive = true,
                IsRestricted = true,
                LongName = "3M",
                TeamMember = "jxs6719"
            });
        }

        public Task<List<AllianceModel>> GetAllAllianceSecurity(ContainerResource container, CancellationToken cancellationToken)
        {
            return Task.FromResult(allAlliances);
        }

        public Task<AllianceModel> GetAllianceSecurityOfUserAsync(ContainerResource container, string userName, string allianceAgreement, CancellationToken cancellationToken)
        {
            return Task.FromResult(allAlliances.FirstOrDefault(al => al.Name == allianceAgreement && al.TeamMember == userName));
        }

        public Task<AllianceModel> GetOneAllianceAgreementDetails(ContainerResource container, string allianceAgreement, CancellationToken cancellationToken)
        {
            return Task.FromResult(allAlliances.FirstOrDefault(al => al.Name == allianceAgreement));
        }
    }



}
