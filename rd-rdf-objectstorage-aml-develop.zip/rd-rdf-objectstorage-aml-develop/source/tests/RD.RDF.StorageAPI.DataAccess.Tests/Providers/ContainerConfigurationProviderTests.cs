﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.DataAccess.Providers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.DataAccess.Tests.Providers
{
    //public class ContainerConfigurationProviderTests
    //{
    //    private readonly Mock<IMemoryCache> cachetest;
    //    private readonly Mock<StorageConfiguration> MockConfig;
    //    private readonly Mock<IUserRepository> MockuserRepository;
    //    private readonly Mock<ILogger<ContainerConfigurationProvider>> Mocklogger;
    //    private readonly ContainerConfigurationProvider containerConfigurationProvider;
    //    private readonly Mock<IOptions<StorageConfiguration>> mockOptions;
    //    private readonly Mock<IConfiguration> mockConfig;
    //    private StorageConfiguration storageConfiguration;
    //    private readonly Mock<IServiceScopeFactory> mockScopeFactory;


    //    public ContainerConfigurationProviderTests()
    //    {
    //        cachetest = new Mock<IMemoryCache>();
    //        MockConfig = new Mock<StorageConfiguration>();
    //        MockuserRepository = new Mock<IUserRepository>();
    //        Mocklogger = new Mock<ILogger<ContainerConfigurationProvider>>();
    //        mockOptions = new Mock<IOptions<StorageConfiguration>>();
    //        mockConfig = new Mock<IConfiguration>();
    //        //setting up Ioption so that contructor won't fail.
    //        storageConfiguration = GetStorageConfiguration();
    //        mockOptions.Setup(x => x.Value).Returns(storageConfiguration);
    //        mockScopeFactory = new Mock<IServiceScopeFactory>();
    //    }

    //    [Fact]
    //    public async void GetAllContainersAsync_WhenUserHaveAccessToAllContainers()
    //    {
    //        var memCache = new MemoryCache(new MemoryCacheOptions());
    //        //One true audience and other 2 false
    //        storageConfiguration.Containers[0].ValidateAudience = true;

    //        //User Client ID Matching in container
    //        MockuserRepository.Setup(x => x.GetCurrentUserClientId()).Returns("User123sjsussnla45");
    //        var containerConfigurationProvider = new ContainerConfigurationProvider(mockOptions.Object, mockConfig.Object, MockuserRepository.Object, Mocklogger.Object, mockScopeFactory.Object, memCache);

    //        var result = await containerConfigurationProvider.GetAllContainersAsync();

    //        Assert.NotNull(result);
    //        Assert.Equal(3,result.Count);
    //    }

    //    [Fact]
    //    public async void GetAllContainersAsync_WhenUserHaveNoAccessToOneConatiner()
    //    {
    //        var memCache = new MemoryCache(new MemoryCacheOptions());
    //        //One true audience and other 2 false
    //        storageConfiguration.Containers[0].ValidateAudience = true;

    //        //User Client ID Matching in container
    //        MockuserRepository.Setup(x => x.GetCurrentUserClientId()).Returns("TestClientId");
    //        var containerConfigurationProvider = new ContainerConfigurationProvider(mockOptions.Object, mockConfig.Object, MockuserRepository.Object, Mocklogger.Object, mockScopeFactory.Object, memCache);

    //        var result = await containerConfigurationProvider.GetAllContainersAsync();

    //        Assert.NotNull(result);
    //        Assert.Equal(2, result.Count);
    //    }

    //    [Fact]
    //    public async void GetAllContainersAsync_WhenUserHaveNoAccessToNoConatiners()
    //    {
    //        var memCache = new MemoryCache(new MemoryCacheOptions());

    //        //All 3 true audience setting
    //        storageConfiguration.Containers[0].ValidateAudience = true;
    //        storageConfiguration.Containers[1].ValidateAudience = true;
    //        storageConfiguration.Containers[2].ValidateAudience = true;

    //        string clientId = "TestClientId";
    //        //User Client ID Matching in container
    //        MockuserRepository.Setup(x => x.GetCurrentUserClientId()).Returns(clientId);
    //        var containerConfigurationProvider = new ContainerConfigurationProvider(mockOptions.Object, mockConfig.Object, MockuserRepository.Object, Mocklogger.Object, mockScopeFactory.Object, memCache);

    //        var result = await containerConfigurationProvider.GetAllContainersAsync();
    //        Mocklogger.Verify(x => x.Log(LogLevel.Warning ,
    //           It.IsAny<EventId>(),
    //           It.IsAny<It.IsAnyType>(),
    //           It.IsAny<Exception>(),
    //           (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()),
    //           Times.Exactly(3));

    //        //No container should be returned
    //        Assert.Equal(false,result.Any());
    //    }

    //    [Fact]
    //    public async void GetContainerByNameAsync_WhenUserHaveAccessToRequestedContainer()
    //    {
    //        var memCache = new MemoryCache(new MemoryCacheOptions());
    //        string containerName = "TestContainer0";
    //        //One true audience and other 2 false
    //        storageConfiguration.Containers[0].ValidateAudience = true;

    //        //User Client ID Matching in container
    //        MockuserRepository.Setup(x => x.GetCurrentUserClientId()).Returns("User123sjsussnla45");
    //        var containerConfigurationProvider = new ContainerConfigurationProvider(mockOptions.Object, mockConfig.Object, MockuserRepository.Object, Mocklogger.Object, mockScopeFactory.Object, memCache);

    //        var result = await containerConfigurationProvider.GetContainerByNameAsync(containerName);

    //        Assert.NotNull(result);
    //        Assert.Equal(containerName, result.ContainerName);
    //    }

    //    [Fact]
    //    public async void GetContainerByNameAsync_WhenUserHaveNoAccessToRequestedContainer()
    //    {
    //        var memCache = new MemoryCache(new MemoryCacheOptions());
    //        string containerName = "TestContainer0";
    //        //One true audience and other 2 false
    //        storageConfiguration.Containers[0].ValidateAudience = true;

    //        //User Client ID Matching in container
    //        MockuserRepository.Setup(x => x.GetCurrentUserClientId()).Returns("TestClientId");
    //        var containerConfigurationProvider = new ContainerConfigurationProvider(mockOptions.Object, mockConfig.Object, MockuserRepository.Object, Mocklogger.Object, mockScopeFactory.Object, memCache);

    //        var result = await containerConfigurationProvider.GetContainerByNameAsync(containerName);

    //        Assert.Null(result);
    //    }

    //    [Fact]
    //    public async void GetContainerByNameAsync_WhenUserHaveTryToAccessContainerWithNoValidateAudienceFalse()
    //    {
    //        var memCache = new MemoryCache(new MemoryCacheOptions());

    //        //All 3 validate is false in storageConfiguration
    //        string containerName = "TestContainer1";

    //        //User Client ID Matching in container
    //        MockuserRepository.Setup(x => x.GetCurrentUserClientId()).Returns("TestClientId");
    //        var containerConfigurationProvider = new ContainerConfigurationProvider(mockOptions.Object, mockConfig.Object, MockuserRepository.Object, Mocklogger.Object, mockScopeFactory.Object, memCache);

    //        var result = await containerConfigurationProvider.GetContainerByNameAsync(containerName);

    //        Assert.NotNull(result);
    //        Assert.Equal(containerName, result.ContainerName);
    //    }

    //    /// <summary>
    //    /// Function to create the storage configuration, this needs to be added to Ioption mock, 
    //    /// so tht constructor is not failing while assigning
    //    /// </summary>
    //    /// <returns></returns>
    //    private StorageConfiguration GetStorageConfiguration()
    //    {
    //        StorageConfiguration storageConfiguration = new StorageConfiguration();
    //        List<StorageContainerConfiguration> storageContainerConfigurations = new List<StorageContainerConfiguration>();
    //        for(int i = 0; i < 3; i++)
    //        {
    //            var storage = new StorageContainerConfiguration
    //            {
    //                ContainerName = $"TestContainer{i}",
    //                IsConnectionAvailable = true,
    //                IsVersionEnabled = true,
    //                ContainerAccountName = $"TestContainer{i}",
    //                Name = $"TestContainer{i}",
    //                ValidateAudience = false,
    //                ValidAudiences = new string[] { "User123sjsussnla45", "User97bwh27sna"}
    //        };
    //            storageContainerConfigurations.Add(storage);
    //        }
    //        storageConfiguration.Containers = storageContainerConfigurations;
    //        storageConfiguration.Indexing = new List<KafkaConfiguration>();

    //        return storageConfiguration;
    //    }
    //}
}
