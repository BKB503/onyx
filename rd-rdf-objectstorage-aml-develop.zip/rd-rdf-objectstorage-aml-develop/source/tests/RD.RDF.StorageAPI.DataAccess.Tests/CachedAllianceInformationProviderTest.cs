﻿using System.Collections.Generic;
using RD.RDF.StorageAPI.Contracts.Model;
using Microsoft.Extensions.Caching.Memory;
using Xunit;
using Moq;
using System.Threading;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.DataAccess.Providers;
using RD.RDF.StorageAPI.Contracts.Configuration;

namespace RD.RDF.StorageAPI.DataAccess.Tests
{
    public class CachedAllianceInformationProviderTest
    {
        private readonly Mock<IMemoryCache> cachetest;
        private readonly Mock<IAllianceConfigurationProvider> cacheconfiguration;
        private readonly Mock<ILogger<OdbcAllianceInformationProvider>> logger;
        private readonly Mock<IAllianceInformationProvider> allianceInformationProvider;
        private readonly Mock<AllianceConfiguration> allianceConfiguration;

        public CachedAllianceInformationProviderTest()
        {
            cachetest = new Mock<IMemoryCache>();
            logger = new Mock<ILogger<OdbcAllianceInformationProvider>>();
            cacheconfiguration = new Mock<IAllianceConfigurationProvider>();
            allianceInformationProvider = new Mock<IAllianceInformationProvider>();
            allianceConfiguration = new Mock<AllianceConfiguration>();

        }
        [Fact]
        public async Task AllianceCachingTest()
        {
            var am = new AllianceModel
            {
                Name = "RestrictedAlliance",
                IsActive = true,
                IsRestricted = true,
                TeamMember = "oterId123"
            };
            List<AllianceModel> allianceModels = new List<AllianceModel>();
            allianceModels.Add(am);
            CancellationTokenSource source = new CancellationTokenSource();
            CancellationToken token = source.Token;
            var containerRes = new ContainerResource("Dummy1")
            {
                Configuration = new StorageContainerConfiguration
                {
                    Type = StorageContainerType.azureblob
                }
            };

            var allianconfig = new AllianceConfiguration
            {
                CacheTimeSeconds = 2
            };
            cacheconfiguration.Setup(fun => fun.GetAllianceConfiguration()).Returns(allianconfig);
            allianceInformationProvider.Setup(fun => fun.GetAllAllianceSecurity(containerRes, token)).ReturnsAsync(allianceModels);
            var memCache = new MemoryCache(new MemoryCacheOptions());
            CachedAllianceInformationProvider obj = new CachedAllianceInformationProvider(allianceInformationProvider.Object, memCache, cacheconfiguration.Object);
            // reading alliances for the first time
            var result1 = await obj.GetAllAllianceSecurity(containerRes, token);
            // method should be executed only once
            allianceInformationProvider.Verify(fun => fun.GetAllAllianceSecurity(containerRes, token), Times.Once());
            // reading alliances for the second time - this time from mem cache
            var result2 = await obj.GetAllAllianceSecurity(containerRes, token);
            // method is still executed only 1
            allianceInformationProvider.Verify(fun => fun.GetAllAllianceSecurity(containerRes, token), Times.Once());
            // sleep for 5 seconds - mem cache should expire
            Thread.Sleep(5000);
            // reading alliances for the third time 
            var result3 = await obj.GetAllAllianceSecurity(containerRes, token);
            // now it should be called at least 2
            Assert.Equal(2, allianceInformationProvider.Invocations.Count);
            Assert.Throws<MockException>(() => allianceInformationProvider.Verify(fun => fun.GetAllAllianceSecurity(containerRes, token), Times.Once()));
        }

        [Fact]
        public async Task AllianceCachingRefreshTest()
        {
            // in this test please start with some alliance model list - like above
            // then verify if it's taken from cache - set cache timeout to 5s
            // and then add new model into the list and check if it's still returning the old model from cache
            // wait for 5s and then read the all aliance information again
            // the cache should have new model

            var am = new AllianceModel
            {
                Name = "RestrictedAlliance",
                IsActive = true,
                IsRestricted = true,
                TeamMember = "oterId123"
            };


            List<AllianceModel> allianceModels = new List<AllianceModel>();
            allianceModels.Add(am);

            CancellationTokenSource source = new CancellationTokenSource();
            CancellationToken token = source.Token;
            var containerRes = new ContainerResource("Dummy1")
            {
                Configuration = new StorageContainerConfiguration
                {
                    Type = StorageContainerType.azureblob
                }
            };

            var allianconfig = new AllianceConfiguration
            {
                CacheTimeSeconds = 5
            };
            cacheconfiguration.Setup(fun => fun.GetAllianceConfiguration()).Returns(allianconfig);
            allianceInformationProvider.Setup(fun => fun.GetAllAllianceSecurity(containerRes, token)).ReturnsAsync(allianceModels);
            var memCache = new MemoryCache(new MemoryCacheOptions());
            CachedAllianceInformationProvider obj = new CachedAllianceInformationProvider(allianceInformationProvider.Object, memCache, cacheconfiguration.Object);

            var result1 = await obj.GetAllAllianceSecurity(containerRes, token);

            allianceInformationProvider.Verify(fun => fun.GetAllAllianceSecurity(containerRes, token), Times.Once());

            var result2 = await obj.GetAllAllianceSecurity(containerRes, token);
            allianceInformationProvider.Verify(fun => fun.GetAllAllianceSecurity(containerRes, token), Times.Once());

            Thread.Sleep(5000);
            //allianceModels.RemoveAt(0);
            var am2 = new AllianceModel
            {
                Name = "RestrictedAlliancetest",
                IsActive = true,
                IsRestricted = true,
                TeamMember = "oterId123"
            };

            allianceModels.Add(am2);
            allianceInformationProvider.Setup(fun => fun.GetAllAllianceSecurity(containerRes, token)).ReturnsAsync(allianceModels);

            var result3 = await obj.GetAllAllianceSecurity(containerRes, token);
            Assert.Equal(2, result3.Count);

        }



    }
}
