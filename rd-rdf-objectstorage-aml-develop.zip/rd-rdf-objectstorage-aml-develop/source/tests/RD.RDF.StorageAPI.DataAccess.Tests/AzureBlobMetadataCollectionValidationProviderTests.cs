﻿using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.DataAccess.Providers;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace RD.RDF.StorageAPI.DataAccess.Tests
{
    public class AzureBlobMetadataCollectionValidationProviderTests
    {
        private readonly Mock<ILogger<AzureBlobMetadataCollectionValidationProvider>> mockLogger;
        AzureBlobMetadataCollectionValidationProvider azureBlobStorageClient;

        public AzureBlobMetadataCollectionValidationProviderTests()
        {
            mockLogger = new Mock<ILogger<AzureBlobMetadataCollectionValidationProvider>>();
            azureBlobStorageClient = new AzureBlobMetadataCollectionValidationProvider(mockLogger.Object);
        }

        [Fact]
        public void SetTags_TestFileGuidAddingToTags_with_FILEGuidPresent()
        {
            string fileGuid = "asdfghjk12345";
            //Test Data
            MetadataCollections metadataCollections = CreateMetadataCollection(10);

            MetadataItem metadataItem = new MetadataItem
            { Key = Common.FileGuid, Value = "asdfghjk12345", IsIndexed = false };
            metadataCollections.Items.Add(metadataItem);

            var result = azureBlobStorageClient.GetIndexingTagsFromInputCollection(metadataCollections);

            Assert.NotNull(result);
            Assert.Equal(6, result.Count);
            Assert.Equal(fileGuid, result[Common.FileGuid]);
        }

        [Fact]
        public void SetTags_TestFileGuidAddingToTags_with_FileGuiNotdPresent()
        {
            //TODOD : Correct the below test case
            string fileGuid = "asdfghjk12345";
            //Test Data
            MetadataCollections metadataCollections = CreateMetadataCollection(10);

            var result = azureBlobStorageClient.GetIndexingTagsFromInputCollection(metadataCollections);

            Assert.NotNull(result);
            Assert.Equal(string.Empty, result[Common.FileGuid]);

        }


        [Fact]
        public void SetTags_TestFileGuidAddingToTags_MoreThan9TrueScenarios()
        {
            string fileGuid = "asdfghjk12345";
            //Test Data
            MetadataCollections metadataCollections = CreateMetadataCollection(20);

            MetadataItem metadataItem = new MetadataItem
            { Key = Common.FileGuid, Value = "asdfghjk12345", IsIndexed = false };
            metadataCollections.Items.Add(metadataItem);

            var result = azureBlobStorageClient.GetIndexingTagsFromInputCollection(metadataCollections);

            Assert.NotNull(result);
            Assert.Equal(10, result.Count);
        }

        [Fact]
        public void SetTags_TestFileGuidAddingToTags_NoTrueScenarios()
        {
            string fileGuid = "asdfghjk12345";
            //Test Data
            MetadataCollections metadataCollections = CreateMetadataCollection(8);
            metadataCollections.Items.ForEach(x => x.IsIndexed = false);
            MetadataItem metadataItem = new MetadataItem
            { Key = Common.FileGuid, Value = "asdfghjk12345", IsIndexed = false };
            metadataCollections.Items.Add(metadataItem);

            var result = azureBlobStorageClient.GetIndexingTagsFromInputCollection(metadataCollections);

            Assert.NotNull(result);
            Assert.Equal(1, result.Count);
        }

        [Fact]
        public void SetTags_RegexPatternCheck()
        {
            string fileGuid = "$Test";
            //Test Data
            MetadataCollections metadataCollections = CreateMetadataCollection(8);
            metadataCollections.Items.ForEach(x => x.IsIndexed = false);
            MetadataItem metadataItem = new MetadataItem

            { Key = "Test", Value = "$Test", IsIndexed = true };
            metadataCollections.Items.Add(metadataItem);
            var result = azureBlobStorageClient.GetIndexingTagsFromInputCollection(metadataCollections);
            var resultelement = result["Test"];

            Assert.Equal(":Test", resultelement);

        }


        [Fact]
        public void SetTags_MetadataDictionaryIsNullCheck()
        {
            var result = azureBlobStorageClient.GetIndexingTagsFromInputCollection(null);

            Assert.False(result.Any());
        }

        private MetadataCollections CreateMetadataCollection(int count)
        {
            MetadataCollections metadataCollections = new MetadataCollections();
            List<MetadataItem> metadataItems = new List<MetadataItem>();
            for (int i = 0; i < count; i++)
            {
                MetadataItem metadataItem = new MetadataItem
                { Key = $"TestKey{i}", Value = $"TestValue{i}", IsIndexed = i % 2 == 0 ? true : false };
                metadataItems.Add(metadataItem);
            }
            metadataCollections.Items = metadataItems;
            return metadataCollections;
        }

        [Theory]
        [InlineData("Test No Replace \\ +./:=_-", "Test No Replace : +./:=_-")]
        [InlineData("ąśćż$abcdABCD", ":::::abcdABCD")]
        [InlineData(null, "")]
        [InlineData("", "")]
        [InlineData("In Review – Scientific Review", "In Review : Scientific Review")]
        public void SetTags_TestCharacters_Replacement(string inputStr, string outputStr)
        {
            //string inputStr = "ąśćż$abcdABCD";
            //string outputStr = ":::::abcdABCD";
            //Test Data
            MetadataCollections metadataCollections = new MetadataCollections()
            {
                Items = new List<MetadataItem>()
            };

            var metadataItem = new MetadataItem
            {
                Key = $"TestKey",
                Value = inputStr,
                IsIndexed = true
            };
            metadataCollections.Items.Add(metadataItem);


            var result = azureBlobStorageClient.GetIndexingTagsFromInputCollection(metadataCollections);

            Assert.NotNull(result);
            Assert.Equal(2, result.Count); // empty guid is added

            var resultValue = result["TestKey"];
            Assert.Equal(outputStr, resultValue);

        }

    }
}