using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.DataAccess.ClientImpl;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using System.Collections.Generic;
using Xunit;

namespace RD.RDF.StorageAPI.DataAccess.Tests
{
    public class StorageClientFactoryTests
    {

        public StorageClientFactoryTests()
        {

        }

        [Theory]
        [InlineData(StorageContainerType.azureadls)]
        [InlineData(StorageContainerType.azureblob)]
        [InlineData(StorageContainerType.googleblob)]
        [InlineData(StorageContainerType.objectstorage)]
        public void VerifyEmptyFactoryTest(StorageContainerType type)
        {
            var clientFactory = new StorageClientFactory(new List<IStorageClient>());
            var containerRes = new ContainerResource("Dummy1")
            {
                Configuration = new StorageContainerConfiguration
                {
                    Type = type
                }
            };
            var result = clientFactory.GetStorageClient(containerRes);
            Assert.Null(result);
        }



        [Theory]
        [InlineData(StorageContainerType.azureadls, false)]
        [InlineData(StorageContainerType.azureblob, true)]
        [InlineData(StorageContainerType.googleblob, false)]
        [InlineData(StorageContainerType.objectstorage, false)]
        public void VerifyOneClientInFactoryTest(StorageContainerType type, bool exists)
        {
            var dummyClient = new Moq.Mock<IStorageClient>();
            dummyClient.Setup(action => action.StorageClientType).Returns(StorageContainerType.azureblob);

            var clientFactory = new StorageClientFactory(new List<IStorageClient>() { dummyClient.Object });
            var containerRes = new ContainerResource("Dummy1")
            {
                Configuration = new StorageContainerConfiguration
                {
                    Type = type
                }
            };
            var result = clientFactory.GetStorageClient(containerRes);
            if (exists)
            {
                Assert.NotNull(result);
                Assert.Equal(dummyClient.Object, result);
            }
            else
            {
                Assert.Null(result);
            }
        }


    }
}