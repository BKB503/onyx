﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Service.Controllers;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.Service.Tests
{
    public class ReadControllerTests
    {
        private readonly Mock<IMetadataService> mockMetadataService;
        private Mock<IDataStorageService> mockDataStorageService;
        private readonly Mock<ILogger<ReadController>> mockLogger;
        private readonly Mock<IEventsTracker> mockEventsTracker;
        private readonly Mock<IMetricsTracker> mockMetricsTracker;
        private readonly Mock<IAllianceSecurityService> mockAllianceSecurityService;
        private readonly ReadController readController;
        public ReadControllerTests()
        {
            mockMetadataService = new Mock<IMetadataService>();
            mockDataStorageService = new Mock<IDataStorageService>();
            mockLogger = new Mock<ILogger<ReadController>>();
            mockEventsTracker = new Mock<IEventsTracker>();
            mockMetricsTracker = new Mock<IMetricsTracker>();
            mockAllianceSecurityService = new Mock<IAllianceSecurityService>();
            readController = new ReadController(mockMetadataService.Object, mockDataStorageService.Object, mockLogger.Object, mockEventsTracker.Object, mockMetricsTracker.Object, mockAllianceSecurityService.Object);

            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, "example name"),
                    new Claim(ClaimTypes.NameIdentifier, "1"),
                    new Claim("custom-claim", "example claim value"),
                }, "mock"));


            readController.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user }
            };

        }

        [Fact]
        public async Task GetFileInformationAPI_ApiPositiveStatusCodeCheck_Test()
        {
            FileIndexModel fileIndexModel = new FileIndexModel
            {
                FileGuid = "ASDFG1",
                FileName = "test.png",
                FolderName = "abc"
            };
            FileResource fileResource = new FileResource("test.png")
            {
                FolderName = "abc",
                FileGuid = "ASDFG1"
            };

            string name = "TestContainer";
            string fileName = "test.png";
            string folderName = "abc";
            string fileGuid = "ASDFG1";
            mockDataStorageService.Setup(a => a.DownloadFileIndexModelAsync(It.IsAny<string>(), It.IsAny<FileResource>(), CancellationToken.None)).ReturnsAsync(fileIndexModel);
            mockMetadataService.Setup(a => a.GetFileResourceFromIndexModel(It.IsAny<FileIndexModel>(), It.IsAny<string>())).Returns(fileResource);

            IActionResult results = await readController.GetFileInformationAsync(name, fileName, folderName, fileGuid, CancellationToken.None);

            Assert.NotNull(results);

            var redirectToActionResult = Assert.IsType<OkObjectResult>(results);
            var contentResult = redirectToActionResult.Value as FileResource;

            Assert.Equal(200, redirectToActionResult.StatusCode);
        }

        [Fact]
        public async Task GetFileInformationAPI_ApiNegativeStatusCodeCheck_Test()
        {
            string name = "TestContainer";
            string fileName = "test.png";
            string folderName = "abc";
            string fileGuid = "ASDFG1";
            var errorMessage = $"No matching file details found for the provided fileName: {fileName} folder: {folderName} fileGuid: {fileGuid}";
            mockDataStorageService.Setup(a => a.DownloadFileIndexModelAsync(It.IsAny<string>(), It.IsAny<FileResource>(), CancellationToken.None));
            mockMetadataService.Setup(a => a.GetFileResourceFromIndexModel(It.IsAny<FileIndexModel>(), It.IsAny<string>()));

            IActionResult results = await readController.GetFileInformationAsync(name, fileName, folderName, fileGuid, CancellationToken.None);

            Assert.NotNull(results);

            var redirectToActionResult = Assert.IsType<NotFoundObjectResult>(results);
            var contentResult = redirectToActionResult.Value as string;
            Assert.Equal(404, redirectToActionResult.StatusCode);
            Assert.Equal(errorMessage, contentResult);
        }

        [Fact]
        public async Task GetFileInformationAPI_ApiPositiveValueCheck_Test()
        {
            FileIndexModel fileIndexModel = new FileIndexModel
            {
                FileGuid = "ASDFG1",
                FileName = "test.png",
                FolderName = "abc"
            };
            FileResource fileResource = new FileResource("test.png")
            {
                FolderName = "abc",
                FileGuid = "ASDFG1"
            };

            string name = "TestContainer";
            string fileName = "test.png";
            string folderName = "abc";
            string fileGuid = "ASDFG1";
            mockDataStorageService.Setup(a => a.DownloadFileIndexModelAsync(It.IsAny<string>(), It.IsAny<FileResource>(), CancellationToken.None)).ReturnsAsync(fileIndexModel);
            mockMetadataService.Setup(a => a.GetFileResourceFromIndexModel(It.IsAny<FileIndexModel>(), It.IsAny<string>())).Returns(fileResource);

            IActionResult results = await readController.GetFileInformationAsync(name, fileName, folderName, fileGuid, CancellationToken.None);

            Assert.NotNull(results);

            var redirectToActionResult = Assert.IsType<OkObjectResult>(results);
            var contentResult = redirectToActionResult.Value as FileResource;

            Assert.Equal(fileName, contentResult.FileName);
            Assert.Equal(fileGuid, contentResult.FileGuid);
        }

        [Fact]
        public async Task GetContainers_UserHasContainerNoAccess_Test()
        {
            PaginationFilter filter = new PaginationFilter();
            string error = "No data available";
            mockMetadataService.Setup(a => a.GetAllContainersAsync(It.IsAny<PaginationFilter>(), CancellationToken.None)).ReturnsAsync(new PagedApiResponse<IList<string>>("No data available", filter.ContinuationToken, filter.Limit));

            var results = await readController.GetContainersAsync(filter, CancellationToken.None);

            Assert.NotNull(results);
            Assert.Equal(error, results.Message);
        }

        [Fact]
        public async Task GetContainerByName_UserHasNoContainerAccess_Test()
        {
            PaginationFilter filter = new PaginationFilter();
            string error = "Container does not exists.";
            mockMetadataService.Setup(a => a.GetContainerByNameAsync(It.IsAny<string>(), CancellationToken.None)).Returns(Task.FromResult<ContainerResource>(null));

            var results = await readController.GetContainerByNameAsync("TestContainer", CancellationToken.None);

            Assert.NotNull(results);
            Assert.Equal(error, results.Message);
        }

        [Fact]
        public async Task GetContainerContentsAsync_UserHasNoContainerAccess_Test()
        {
            PaginationFilter filter = new PaginationFilter();
            string error = "Container does not exists.";
            mockMetadataService.Setup(a => a.GetContainerContentsAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<PaginationFilter>(), CancellationToken.None)).Returns(Task.FromResult<ContainerContents>(null));

            var results = await readController.GetContainerContentsAsync("TestContainer", "Test", filter, CancellationToken.None);
            var objectResult = Assert.IsType<ObjectResult>(results);
            Assert.NotNull(results);
            Assert.Equal(error, objectResult.Value);
            Assert.Equal(StatusCodes.Status401Unauthorized, objectResult.StatusCode);
        }

    }

}
