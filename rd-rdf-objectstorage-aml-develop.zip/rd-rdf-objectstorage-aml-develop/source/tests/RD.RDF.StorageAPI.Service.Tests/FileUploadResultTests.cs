using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Service.ViewModel;
using Xunit;

namespace RD.RDF.StorageAPI.Service.Tests
{
    public class FileUploadResultTests
    {
        [Fact]
        public void NoSuccessUploadResultTest()
        {
            var result = new FileUploadResult();
            Assert.False(result.Success);
            Assert.Null(result.Message);
            Assert.Null(result.Data);
        }

        [Fact]
        public void NoSuccessUploadResultWithMessageTest()
        {
            var result = new FileUploadResult(message: "msg");
            Assert.False(result.Success);
            Assert.Equal("msg", result.Message);
            Assert.Null(result.Data);
        }

        [Fact]
        public void SuccessUploadResultTest()
        {
            var result = new FileUploadResult(new FileResource("name"));
            Assert.True(result.Success);
            Assert.Null(result.Message);
            Assert.NotNull(result.Data);
        }

        [Fact]
        public void SuccessUploadResultWithMessageTest()
        {
            var result = new FileUploadResult(new FileResource("name"), "msg");
            Assert.True(result.Success);
            Assert.Equal("msg", result.Message);
            Assert.NotNull(result.Data);
        }
    }
}
