﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using RD.RDF.StorageAPI.Service.Controllers;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.Service.Tests
{
    public class WriteControllerTests
    {

        private Mock<IDataStorageService> mockDataStorageService;
        private readonly Mock<ILogger<WriteController>> mockLogger;
        private readonly Mock<IEventsTracker> mockEventsTracker;
        private readonly Mock<IMetricsTracker> mockMetricsTracker;
        private readonly Mock<IMetadataParsingService> mockMetadataParsingService;
        
        private readonly WriteController writeController;
        public WriteControllerTests()
        {
            mockMetadataParsingService = new Mock<IMetadataParsingService>();
            mockDataStorageService = new Mock<IDataStorageService>();
            mockLogger = new Mock<ILogger<WriteController>>();
            mockEventsTracker = new Mock<IEventsTracker>();
            mockMetricsTracker = new Mock<IMetricsTracker>();
          
            writeController = new WriteController(mockDataStorageService.Object, mockLogger.Object, mockEventsTracker.Object, mockMetricsTracker.Object, mockMetadataParsingService.Object);
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        }

        //[Fact]
        //public async Task UploadFile_WithMetadataCollectionObject_Test()
        //{

        //    UploadFileFormModel uploadFileFormModel = new UploadFileFormModel
        //    {
        //        File = CreateFormFileMock(),
        //        Metadata = CreateMetadataCollection(12)
        //    };

        //    FileResource fileResource = new FileResource("test.png")
        //    {
        //        FolderName = "abc",
        //        FileGuid = "ASDFG1"
        //    };
        //    UploadFileResult fileResult = new UploadFileResult(fileResource, UploadFileResultStatus.Success);
        //    string container = "TestContainer";
        //    string folderName = "abc";
        //    mockDataStorageService.Setup(a => a.UploadFileWithMetadataAsync(It.IsAny<string>(), It.IsAny<string>(),
        //        It.IsAny<string>(), It.IsAny<Stream>(), It.IsAny<MetadataCollections>(), CancellationToken.None)).ReturnsAsync(fileResult);
        //    mockDataStorageService.Setup(a => a.DownloadFileIndexModelAsync(It.IsAny<string>(), It.IsAny<FileResource>(), CancellationToken.None)).ReturnsAsync(new FileIndexModel());

        //    //mockIndexingService.Setup(a => a.WriteFileIndexAsync(It.IsAny<FileResource>(), It.IsAny<FileIndexModel>(), It.IsAny<string>(), CancellationToken.None));
        //    //mockMetadataService.Setup(met => met.GetFileResourceFromIndexModel(It.IsAny<FileIndexModel>(), It.IsAny<string>())).Returns(new FileResource());
        //    var results = await writeController.UploadFileObject(container, folderName, uploadFileFormModel, CancellationToken.None);
        //    Assert.True(results is ObjectResult);
        //    var statusResult = results as ObjectResult;
        //    Assert.True(statusResult.Value is UploadFileResult);
        //    var value = statusResult.Value as UploadFileResult;

        //    Assert.NotNull(value.FileInformation);

        //    Assert.Equal(200, value.StatusCode);
        //}


        private MetadataCollections CreateMetadataCollection(int count)
        {
            MetadataCollections metadataCollections = new MetadataCollections();
            List<MetadataItem> metadataItems = new List<MetadataItem>();
            for (int i = 0; i < count; i++)
            {
                MetadataItem metadataItem = new MetadataItem
                { Key = $"TestKey{i}", Value = $"TestValue{i}", IsIndexed = i % 2 == 0 ? true : false };
                metadataItems.Add(metadataItem);
            }
            metadataCollections.Items = metadataItems;
            return metadataCollections;
        }

        private IFormFile CreateFormFileMock()
        {
            var content = "Hello World from a Fake File";
            var fileName = "test.pdf";
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(content);
            writer.Flush();
            stream.Position = 0;

            //create FormFile with desired data
            IFormFile file = new FormFile(stream, 0, stream.Length, "id_from_form", fileName);

            return file;
        }
    }
}
