﻿using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Core.Services;
using RD.RDF.StorageAPI.Service.Controllers;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.Service.Tests
{
    public class SearchControllerTests
    {
        private readonly Mock<IMetadataService> metadataServiceMock;
        private readonly Mock<ILogger<ReadController>> loggerMock;
        private readonly Mock<IEventsTracker> eventsTrackerMock;
        private readonly Mock<IMetricsTracker> metricsTrackerMock;
        private readonly Mock<IOdbcFileIndexSearchService> odbcFileIndexSearchService;
        private readonly SearchController controller;

        public SearchControllerTests()
        {
            metadataServiceMock = new Mock<IMetadataService>();
            loggerMock = new Mock<ILogger<ReadController>>();
            eventsTrackerMock = new Mock<IEventsTracker>();
            metricsTrackerMock = new Mock<IMetricsTracker>();
            odbcFileIndexSearchService = new Mock<IOdbcFileIndexSearchService>();
            controller = new SearchController(metadataServiceMock.Object, loggerMock.Object, eventsTrackerMock.Object, metricsTrackerMock.Object, odbcFileIndexSearchService.Object);
        }

        [Fact]
        public async Task NullResutlsTest()
        {
            string msg = "No search results";
            string containerName = "name";
            string searchString = @"""Name""='Test'";
            var results = await controller.SearchFilesAsync(containerName, searchString);
            Assert.NotNull(results);
            Assert.False(results.Succeeded);
            Assert.NotNull(results.Message);
            Assert.Equal(msg, results.Message);
        }


        [Fact]
        public async Task NoSearchResutlsTest()
        {
            metadataServiceMock.Setup(fun => fun.SearchFilesByTagsAsync(It.IsAny<string>(), It.IsAny<string>(), CancellationToken.None))
                               .ReturnsAsync(new SearchFilesByTagResults(new List<FileResource>()));
            string msg = "No search results";
            string containerName = "name";
            string searchString = @"""Name""='Test'";
            var results = await controller.SearchFilesAsync(containerName, searchString);
            Assert.NotNull(results);
            Assert.True(results.Succeeded);
            Assert.Null(results.Message);

        }

        [Fact]
        public async Task NoContainerTest()
        {
            string properContainerName = "properContainer";
            metadataServiceMock.Setup(fun => fun.SearchFilesByTagsAsync(properContainerName, It.IsAny<string>(), CancellationToken.None))
                               .ReturnsAsync(new SearchFilesByTagResults(new List<FileResource>()));
            string msg = "No search results";
            string containerName = "name";
            string searchString = @"""Name""='Test'";
            var results = await controller.SearchFilesAsync(containerName, searchString);
            Assert.NotNull(results);
            Assert.False(results.Succeeded);
            Assert.NotNull(results.Message);
            Assert.Equal(msg, results.Message);
        }

        [Fact]
        public async Task SuccessfullSearchResultTest()
        {
            string containerName = "name";
            string fileName = "test.png";
            string searchString = @"""Name""='test.png'";

            metadataServiceMock.Setup(fun => fun.SearchFilesByTagsAsync(containerName, It.IsAny<string>(), CancellationToken.None))
                               .ReturnsAsync(new SearchFilesByTagResults(new List<FileResource>() { new FileResource(fileName) }));

            var results = await controller.SearchFilesAsync(containerName, searchString);
            Assert.NotNull(results);
            Assert.True(results.Succeeded);
            Assert.Null(results.Message);
            Assert.Equal(1, results.Data.Count);
            Assert.Equal(fileName, results.Data[0].FileName);
        }

        [Fact]
        public async Task SearchErrorFromAPIContainerTest()
        {
            string containerName = "name";
            string errorMsg = "ErrorMsg";
            metadataServiceMock.Setup(fun => fun.SearchFilesByTagsAsync(containerName, It.IsAny<string>(), CancellationToken.None))
                               .ReturnsAsync(new SearchFilesByTagResults(message: errorMsg));
            string searchString = @"""Name""='Test'";
            var results = await controller.SearchFilesAsync(containerName, searchString);
            Assert.NotNull(results);
            Assert.False(results.Succeeded);
            Assert.NotNull(results.Message);
            Assert.Equal(errorMsg, results.Message);
        }

    }
}
