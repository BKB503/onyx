﻿using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Core.Services;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.Core.Tests
{
    public class AllianceSecurityServiceTests
    {
        private readonly Mock<IContainerConfigurationProvider> containerConfigurationProvider;
        private readonly Mock<IAllianceInformationProvider> allianceInformationProvider;
        private readonly Mock<ILogger<AllianceSecurityService>> logger;
        private readonly Mock<IFilesRepository> filesRepository;
        private readonly Mock<IFoldersRepository> foldersRepository;
        private readonly Mock<ISearchProviderFactory> searchProviderFactory;
        private readonly AllianceSecurityService service;

        public AllianceSecurityServiceTests()
        {
            containerConfigurationProvider = new Mock<IContainerConfigurationProvider>();
            allianceInformationProvider = new Mock<IAllianceInformationProvider>();
            logger = new Mock<ILogger<AllianceSecurityService>>();
            service = new AllianceSecurityService(allianceInformationProvider.Object, containerConfigurationProvider.Object, logger.Object);
        }

        [Fact]
        public void GetAllianceAgreementFromIndexModelTest()
        {
            var cr = new ContainerResource("name")
            {
                Configuration = new StorageContainerConfiguration
                {
                    //AllianceTagName = "AgreementPacket"
                }
            };


            var result1 = service.GetAllianceAgreementFromIndexModel(cr, null);
            Assert.Null(result1);
            cr.Configuration.AllianceTagName = "AgreementPacket";
            //still null as there is no tag with that 
            var result2 = service.GetAllianceAgreementFromIndexModel(cr, null);
            Assert.Null(result2);

            var fileModelNoMetadata = new FileIndexModel();
            //still null as there is no tag with that 
            var result3 = service.GetAllianceAgreementFromIndexModel(cr, fileModelNoMetadata);
            Assert.Null(result3);

            var fileIndexModel = new FileIndexModel()
            {
                Metadata = new List<MetadataKeyValue>()
            };
            //still null as there is no tag with that 
            var result4 = service.GetAllianceAgreementFromIndexModel(cr, fileIndexModel);
            Assert.Null(result4);


            var fileIndexModel2 = new FileIndexModel()
            {
                Metadata = new List<MetadataKeyValue>()
                {
                    new MetadataKeyValue
                    {
                        Key ="OtherKey",
                        Value= "Value"
                    }
                }
            };
            //still null as there is no tag with that 
            var result5 = service.GetAllianceAgreementFromIndexModel(cr, fileIndexModel2);
            Assert.Null(result5);

            var fileIndexModel3 = new FileIndexModel()
            {
                Metadata = new List<MetadataKeyValue>()
                {
                    new MetadataKeyValue
                    {
                        Key ="OtherKey",
                        Value= "Value"
                    },
                    new MetadataKeyValue
                    {
                        Key ="AgreementPacket",
                        Value= "packet"
                    }
                }
            };
            //still null as there is no tag with that 
            var result6 = service.GetAllianceAgreementFromIndexModel(cr, fileIndexModel3);
            Assert.NotNull(result6);
            Assert.Equal("packet", result6);

        }
        [Fact]
        public async Task CheckUserSecurityNoContainerTest()
        {
            var fi = new FileIndexModel()
            {
                Metadata = new List<MetadataKeyValue>()
                {
                    new MetadataKeyValue
                    {
                        Key = "OtherKey",
                        Value= "Value"
                    },

                }
            };
            var result = await service.CheckUserAccessAsync(null, null, fi, CancellationToken.None);
            Assert.Null(result);

        }


        [Theory]
        [InlineData("container", null, null, true, false, "test123", null, AllianceAccessVerificationEnum.AllowedNoAlliance)]
        [InlineData("container", "AgreementPacket", null, true, false, "test123", "RestrictedAlliance", AllianceAccessVerificationEnum.AllowedNoAllianceFoundInDatabase)]
        [InlineData("container", "AgreementPacket", null, true, false, "test123", AllianceSecurityService.GSKProprietary, AllianceAccessVerificationEnum.AllowedGSKProprietary)]
        [InlineData("container", "AgreementPacket", "RestrictedAlliance", true, false, "test123", "RestrictedAlliance", AllianceAccessVerificationEnum.NotAllowed)]
        [InlineData("container", "AgreementPacket", "RestrictedAlliance", true, true, "test123", "RestrictedAlliance", AllianceAccessVerificationEnum.AllowedUserAlliance)]
        [InlineData("container", "AgreementPacket", "UnRestrictedAlliance", false, false, "test123", "UnRestrictedAlliance", AllianceAccessVerificationEnum.AllowedNotRestrictedAlliance)]
        public async Task CheckUserSecurityTest(string containerName,
                                                string allianceTagName,
                                                string allianceName,
                                                bool isRestricted,
                                                bool isUserAlliance,
                                                string userName,
                                                string allianceNameInFile,
                                                AllianceAccessVerificationEnum expectedResult)
        {
            PrepareTest(containerName, allianceTagName, allianceName, isRestricted, isUserAlliance, userName);

            var fi = new FileIndexModel()
            {
                Metadata = new List<MetadataKeyValue>()
                {
                    new MetadataKeyValue
                    {
                        Key = "OtherKey",
                        Value= "Value"
                    },

                }
            };

            if (allianceNameInFile != null)
            {
                fi.Metadata.Add(new MetadataKeyValue
                {
                    Key = allianceTagName == null ? "tag" : allianceTagName,
                    Value = allianceNameInFile
                });

            }
            var result = await service.CheckUserAccessAsync(containerName, userName, fi, CancellationToken.None);

            Assert.NotNull(result);
            Assert.Equal(expectedResult, result.Result);
            if (allianceName != null)
            {
                Assert.Equal(allianceName, result.AllianceName);
            }
            if (isUserAlliance)
            {
                Assert.Equal(userName, result.Alliance.TeamMember);
            }
            else if (result.Alliance != null)
            {
                Assert.Equal("oterId123", result.Alliance.TeamMember);
            }
        }

        private void PrepareTest(string containerName, string allianceTagName, string allianceName, bool isRestricted, bool isUserAlliance, string userName)
        {
            if (containerName != null)
            {
                var cr = new ContainerResource(containerName)
                {
                    Configuration = new StorageContainerConfiguration(),
                    //IndexingConfiguration = new KafkaConfiguration()

                };
                if (allianceTagName != null)
                {
                    cr.Configuration.AllianceTagName = allianceTagName;
                }
                containerConfigurationProvider.Setup(fun => fun.GetContainerByNameAsync(containerName, It.IsAny<CancellationToken>()))
                                              .ReturnsAsync(cr);
            }
            var am = new AllianceModel
            {
                Name = allianceName,
                IsActive = true,
                IsRestricted = isRestricted,
                TeamMember = isUserAlliance ? userName : "oterId123"
            };
            if (isUserAlliance)
            {
                allianceInformationProvider.Setup(fun => fun.GetAllianceSecurityOfUserAsync(It.IsAny<ContainerResource>(), userName, allianceName, It.IsAny<CancellationToken>()))
                                           .ReturnsAsync(am);

            }
            else if (allianceName != null)
            {
                allianceInformationProvider.Setup(fun => fun.GetOneAllianceAgreementDetails(It.IsAny<ContainerResource>(), allianceName, It.IsAny<CancellationToken>()))
                                           .ReturnsAsync(am);
            }
        }




    }
}
