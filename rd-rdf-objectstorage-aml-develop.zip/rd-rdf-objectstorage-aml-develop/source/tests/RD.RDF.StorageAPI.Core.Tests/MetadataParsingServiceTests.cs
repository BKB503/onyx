﻿using Microsoft.Extensions.Logging;
using Moq;
using System.IO;
using Xunit;
using System;
using RD.RDF.StorageAPI.Core.Services;

namespace RD.RDF.StorageAPI.Core.Tests
{
    public class MetadataParsingServiceTests
    {
        private readonly Mock<ILogger<MetadataParsingService>> loggerMock;
        private readonly MetadataParsingService service;

        public MetadataParsingServiceTests()
        {
            loggerMock = new Mock<ILogger<MetadataParsingService>>();
            service = new MetadataParsingService(loggerMock.Object);
        }

        [Fact]
        public void ParseMetadataFieldFormatTest()
        {
            string jsonStr =
 @"{
 ""metaData"": {
                ""Language"": ""English"",
                ""Format"": ""application/json"",
                ""InformationCategory"": ""Confidential"",
                ""OriginatingOrganization"": ""GlaxoSmithKline""
                }
}";

            MemoryStream jsonStream = new MemoryStream();
            StreamWriter sw = new StreamWriter(jsonStream);
            sw.Write(jsonStr);
            sw.Flush();
            jsonStream.Seek(0, SeekOrigin.Begin);
            var result = service.ReadTheMetadataJsonFile(jsonStream);

            Assert.NotNull(result);
            Assert.NotNull(result.MetaDataDictionary);
            Assert.Equal(4, result.MetaDataDictionary.Count);

            Assert.Equal("English", result.MetaDataDictionary["Language"]);
            Assert.Equal("Confidential", result.MetaDataDictionary["InformationCategory"]);
            Assert.Equal("GlaxoSmithKline", result.MetaDataDictionary["OriginatingOrganization"]);
            Assert.Equal("application/json", result.MetaDataDictionary["Format"]);
        }

        [Fact]
        public void ParseSignalsMetadataFieldFormatTest()
        {
            string jsonStr =
 @"{  
                ""Language"": ""English"",
                ""Format"": ""application/json"",
                ""InformationCategory"": ""Confidential"",
                ""OriginatingOrganization"": ""GlaxoSmithKline""                 
}";

            MemoryStream jsonStream = new MemoryStream();
            StreamWriter sw = new StreamWriter(jsonStream);
            sw.Write(jsonStr);
            sw.Flush();
            jsonStream.Seek(0, SeekOrigin.Begin);
            var result = service.ReadTheMetadataJsonFile(jsonStream);

            Assert.NotNull(result);
            Assert.NotNull(result.MetaDataDictionary);
            Assert.Equal(4, result.MetaDataDictionary.Count);

            Assert.Equal("English", result.MetaDataDictionary["Language"]);
            Assert.Equal("Confidential", result.MetaDataDictionary["InformationCategory"]);
            Assert.Equal("GlaxoSmithKline", result.MetaDataDictionary["OriginatingOrganization"]);
            Assert.Equal("application/json", result.MetaDataDictionary["Format"]);
        }

        [Fact]
        public void ParseOtherMetadataFieldFormatTest()
        {
            string jsonStr =
 @"{  
                ""Language"": {
                ""Format"": ""application/json"",
                ""InformationCategory"": ""Confidential"",
                ""OriginatingOrganization"": ""GlaxoSmithKline""         
}
}";

            MemoryStream jsonStream = new MemoryStream();
            StreamWriter sw = new StreamWriter(jsonStream);
            sw.Write(jsonStr);
            sw.Flush();
            jsonStream.Seek(0, SeekOrigin.Begin);
            var result = service.ReadTheMetadataJsonFile(jsonStream);

            Assert.NotNull(result);
            Assert.Null(result.MetaDataDictionary);
        }



        [Fact]
        public void SerializeAndDeserializeTest1()
        {
            string jsonStr =
@"{
 ""metaData"": {
                ""Language"": ""English"",
                ""Format"": ""application/json"",
                ""InformationCategory"": ""Confidential"",
                ""OriginatingOrganization"": ""GlaxoSmithKline""
                }
}";

            MemoryStream jsonStream = new MemoryStream();
            StreamWriter sw = new StreamWriter(jsonStream);
            sw.Write(jsonStr);
            sw.Flush();
            jsonStream.Seek(0, SeekOrigin.Begin);
            var resultFirst = service.ReadTheMetadataJsonFile(jsonStream);
            var outputStream = service.SerializeToStream(resultFirst);
            Assert.NotNull(outputStream);
            Assert.Equal(0, outputStream.Position);

            var result = service.ReadTheMetadataJsonFile(outputStream);

            Assert.NotNull(result);
            Assert.NotNull(result.MetaDataDictionary);
            Assert.Equal(4, result.MetaDataDictionary.Count);

            Assert.Equal("English", result.MetaDataDictionary["Language"]);
            Assert.Equal("Confidential", result.MetaDataDictionary["InformationCategory"]);
            Assert.Equal("GlaxoSmithKline", result.MetaDataDictionary["OriginatingOrganization"]);
            Assert.Equal("application/json", result.MetaDataDictionary["Format"]);

            outputStream.Seek(0, SeekOrigin.Begin);
            var streamReader = new StreamReader(outputStream);
            var outputString = streamReader.ReadToEnd();
            Assert.Equal(RemoveWhiteChars(jsonStr), RemoveWhiteChars(outputString));
        }


        [Fact]
        public void SerializeAndDeserializeTest2()
        {
            string jsonStr =
@"{
  
                ""Language"": ""English"",
                ""Format"": ""application/json"",
                ""InformationCategory"": ""Confidential"",
                ""OriginatingOrganization"": ""GlaxoSmithKline""
               
}";


            string expectedJsonStr =
@"{
 ""metaData"": {
                ""Language"": ""English"",
                ""Format"": ""application/json"",
                ""InformationCategory"": ""Confidential"",
                ""OriginatingOrganization"": ""GlaxoSmithKline""
                }
}";

            MemoryStream jsonStream = new MemoryStream();
            StreamWriter sw = new StreamWriter(jsonStream);
            sw.Write(jsonStr);
            sw.Flush();
            jsonStream.Seek(0, SeekOrigin.Begin);
            var resultFirst = service.ReadTheMetadataJsonFile(jsonStream);
            var outputStream = service.SerializeToStream(resultFirst);
            Assert.NotNull(outputStream);
            Assert.Equal(0, outputStream.Position);

            var result = service.ReadTheMetadataJsonFile(outputStream);

            Assert.NotNull(result);
            Assert.NotNull(result.MetaDataDictionary);
            Assert.Equal(4, result.MetaDataDictionary.Count);

            Assert.Equal("English", result.MetaDataDictionary["Language"]);
            Assert.Equal("Confidential", result.MetaDataDictionary["InformationCategory"]);
            Assert.Equal("GlaxoSmithKline", result.MetaDataDictionary["OriginatingOrganization"]);
            Assert.Equal("application/json", result.MetaDataDictionary["Format"]);


            outputStream.Seek(0, SeekOrigin.Begin);
            var streamReader = new StreamReader(outputStream);
            var outputString = streamReader.ReadToEnd();
            Assert.Equal(RemoveWhiteChars(expectedJsonStr), RemoveWhiteChars(outputString));

        }


        private static string RemoveWhiteChars(string inputString)
        {
            return inputString.Replace(Environment.NewLine, "").Replace(" ", "");
        }
    }
}
