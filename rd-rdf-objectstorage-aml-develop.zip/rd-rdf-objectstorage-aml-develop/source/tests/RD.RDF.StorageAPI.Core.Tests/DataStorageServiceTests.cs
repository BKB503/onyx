using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Core.Services;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.Core.Tests
{
    public class DataStorageServiceTests
    {
        private Mock<IContainerConfigurationProvider> containerConfigurationProviderMock;
        private Mock<IDataStorageRepository> dataStorageRepositoryMock;
        private Mock<IFilesRepository> filesRepositoryMock;
        private Mock<ILogger<DataStorageService>> loggerMock;


        private   Mock<IMetadataService> mockMetadataService;
        private   Mock<IIndexingService> mockIndexingService;

        public DataStorageServiceTests()
        {
            InitTest();
        }

        private void InitTest()
        {
            containerConfigurationProviderMock = new Mock<IContainerConfigurationProvider>();
            dataStorageRepositoryMock = new Mock<IDataStorageRepository>();
            filesRepositoryMock = new Mock<IFilesRepository>();
            loggerMock = new Mock<ILogger<DataStorageService>>();
            mockMetadataService = new Mock<IMetadataService>();
            mockIndexingService = new Mock<IIndexingService>();
        }


        [Fact]
        public async Task NoContainerFileDownloadTest()
        {

            var dss = new DataStorageService(containerConfigurationProviderMock.Object,
                                             dataStorageRepositoryMock.Object,                                            
                                             loggerMock.Object, mockMetadataService.Object, mockIndexingService.Object);
            //container was not mocked 
            var result = await dss.GetFileStreamAsync("DummyContainer", null, CancellationToken.None);
            Assert.Null(result);
        }

        [Fact]
        public async Task GetFileStreamAsyncTest()
        {
            var knownContainerName = "KnownContainer";
            var unKnownContainerName = "DummyContainer";

            var knownFileName = "file.txt";
            var unKnownFileName = "nofile.txt";
            var knownFileInfo = new FileResource(knownFileName);
            var knownContainer = new ContainerResource(knownContainerName);
            var fileMockedStream = new MemoryStream();
            containerConfigurationProviderMock.Setup(fun => fun.GetContainerByNameAsync(knownContainerName, It.IsAny<CancellationToken>()))
                                              .ReturnsAsync(knownContainer);
            filesRepositoryMock.Setup(fun => fun.GetFileByNameAndVersionAsync(knownContainer, knownFileName, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<CancellationToken>()))
                                            .ReturnsAsync(knownFileInfo);
            dataStorageRepositoryMock.Setup(fun => fun.GetFileStreamAsync(knownContainer, knownFileInfo, It.IsAny<CancellationToken>()))
                                     .ReturnsAsync(fileMockedStream);

            var dss = new DataStorageService(containerConfigurationProviderMock.Object,
                                             dataStorageRepositoryMock.Object,
                                             loggerMock.Object, mockMetadataService.Object, mockIndexingService.Object);

            //container was not mocked 
            var result = await dss.GetFileStreamAsync(unKnownContainerName, knownFileInfo, CancellationToken.None);
            Assert.Null(result);

            //container was mocked but file name is not found 
            var result2 = await dss.GetFileStreamAsync(knownContainerName, null, CancellationToken.None);
            Assert.Null(result2);

            //container was mocked and file name  found 
            var result3 = await dss.GetFileStreamAsync(knownContainerName, knownFileInfo, CancellationToken.None);
            Assert.NotNull(result3);
            Assert.Equal(fileMockedStream, result3);
        }

        [Fact]
        public async Task UploadFileWithMetadataAsyncTest()
        {
            var knownContainerName = "KnownContainer";
            var unKnownContainerName = "DummyContainer";

            var knownFileName = "file.txt";
            var unKnownFileName = "nofile.txt";
            var knownFileInfo = new UploadFileResult(new FileResource(knownFileName), UploadFileResultStatus.Success);
            var knownContainer = new ContainerResource(knownContainerName)
            {
                Configuration = new Contracts.Configuration.StorageContainerConfiguration() { IsVersionEnabled = true, IsConnectionAvailable = true }
            };
            var fileMockedStream = new MemoryStream();
            containerConfigurationProviderMock.Setup(fun => fun.GetContainerByNameAsync(knownContainerName, It.IsAny<CancellationToken>()))
                                              .ReturnsAsync(knownContainer);

            dataStorageRepositoryMock.Setup(fun => fun.UploadFileToFolderAsync(knownContainer, knownFileName, It.IsAny<string>(), fileMockedStream, It.IsAny<MetadataCollections>(), It.IsAny<CancellationToken>()))
                                     .ReturnsAsync(knownFileInfo);

            var dss = new DataStorageService(containerConfigurationProviderMock.Object,
                                             dataStorageRepositoryMock.Object,
                                             loggerMock.Object, mockMetadataService.Object, mockIndexingService.Object);

            //container was not mocked 
            var result = await dss.UploadFileWithMetadataAsync(unKnownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None); ;
            Assert.Null(result.FileInformation);

            //container was mocked but file Name was wrong (for any reason) 
            var result2 = await dss.UploadFileWithMetadataAsync(knownContainerName, unKnownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.Null(result2);

            //container was mocked but file stream is empty
            var result3 = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, null, null, CancellationToken.None);
            Assert.Null(result3);


            //container was mocked and file name  found 
            var result4 = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.NotNull(result4.FileInformation);
            Assert.Equal(knownFileInfo.FileInformation, result4.FileInformation);
        }

        [Fact]
        public async Task UploadFileWithMetadataAsync_ContainerVersionAndConnectionEnabledTest()
        {
            var knownContainerName = "KnownContainer";
            var unKnownContainerName = "DummyContainer";

            var knownFileName = "file.txt";
            var unKnownFileName = "nofile.txt";
            var knownFileInfo = new UploadFileResult(new FileResource(knownFileName), UploadFileResultStatus.Success);
            var knownContainer = new ContainerResource(knownContainerName)
            {
                Configuration = new Contracts.Configuration.StorageContainerConfiguration() { IsVersionEnabled = true, IsConnectionAvailable = true }
            };
            var fileMockedStream = new MemoryStream();
            containerConfigurationProviderMock.Setup(fun => fun.GetContainerByNameAsync(knownContainerName, It.IsAny<CancellationToken>()))
                                              .ReturnsAsync(knownContainer);

            dataStorageRepositoryMock.Setup(fun => fun.UploadFileToFolderAsync(knownContainer, knownFileName, It.IsAny<string>(), fileMockedStream, It.IsAny<MetadataCollections>(), It.IsAny<CancellationToken>()))
                                     .ReturnsAsync(knownFileInfo);

            var dss = new DataStorageService(containerConfigurationProviderMock.Object,
                                             dataStorageRepositoryMock.Object,
                                             loggerMock.Object, mockMetadataService.Object, mockIndexingService.Object);

            //container was not mocked 
            var result = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.NotNull(result.FileInformation);

            //container was not mocked 
            var result1 = await dss.UploadFileWithMetadataAsync(unKnownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.Null(result1.FileInformation);

            //container was mocked but file Name was wrong (for any reason) 
            var result2 = await dss.UploadFileWithMetadataAsync(knownContainerName, unKnownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.Null(result2);

            //container was mocked but file stream is empty
            var result3 = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, null, null, CancellationToken.None);
            Assert.Null(result3);


            //container was mocked and file name  found 
            var result4 = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.NotNull(result4.FileInformation);
            Assert.Equal(200, result4.StatusCode);
            Assert.Equal(knownFileInfo.FileInformation, result4.FileInformation);
        }

        [Fact]
        public async Task UploadFileWithMetadataAsync_ContainerVersionDisabledTest()
        {
            var knownContainerName = "KnownContainer";
            var unKnownContainerName = "DummyContainer";

            var knownFileName = "file.txt";
            var unKnownFileName = "nofile.txt";
            var knownFileInfo = new UploadFileResult(new FileResource(knownFileName), UploadFileResultStatus.VersioningNotEnabled);
            var knownContainer = new ContainerResource(knownContainerName)
            {
                Configuration = new Contracts.Configuration.StorageContainerConfiguration() { IsVersionEnabled = false, IsConnectionAvailable = true }
            };
            var fileMockedStream = new MemoryStream();
            containerConfigurationProviderMock.Setup(fun => fun.GetContainerByNameAsync(knownContainerName, It.IsAny<CancellationToken>()))
                                              .ReturnsAsync(knownContainer);

            dataStorageRepositoryMock.Setup(fun => fun.UploadFileToFolderAsync(knownContainer, knownFileName, It.IsAny<string>(), fileMockedStream, It.IsAny<MetadataCollections>(), It.IsAny<CancellationToken>()))
                                     .ReturnsAsync(knownFileInfo);

            var dss = new DataStorageService(containerConfigurationProviderMock.Object,
                                             dataStorageRepositoryMock.Object,
                                             loggerMock.Object, mockMetadataService.Object, mockIndexingService.Object);


            var result = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.Null(result.FileInformation);
            Assert.Equal(400, result.StatusCode);
            Assert.Equal(UploadFileResultStatus.VersioningNotEnabled, result.Status);
        }

        [Fact]
        public async Task UploadFileWithMetadataAsync_ContainerConnectionTest_False()
        {
            var knownContainerName = "KnownContainer";
            var unKnownContainerName = "DummyContainer";

            var knownFileName = "file.txt";
            var unKnownFileName = "nofile.txt";
            var knownFileInfo = new UploadFileResult(new FileResource(knownFileName), UploadFileResultStatus.ConnectionNotActive);
            var knownContainer = new ContainerResource(knownContainerName)
            {
                Configuration = new Contracts.Configuration.StorageContainerConfiguration() { IsVersionEnabled = true, IsConnectionAvailable = false }
            };
            var fileMockedStream = new MemoryStream();
            containerConfigurationProviderMock.Setup(fun => fun.GetContainerByNameAsync(knownContainerName, It.IsAny<CancellationToken>()))
                                              .ReturnsAsync(knownContainer);

            dataStorageRepositoryMock.Setup(fun => fun.UploadFileToFolderAsync(knownContainer, knownFileName, It.IsAny<string>(), fileMockedStream, It.IsAny<MetadataCollections>(), It.IsAny<CancellationToken>()))
                                     .ReturnsAsync(knownFileInfo);

            var dss = new DataStorageService(containerConfigurationProviderMock.Object,
                                             dataStorageRepositoryMock.Object,
                                             loggerMock.Object, mockMetadataService.Object, mockIndexingService.Object);
            // if connection is false
            var result = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.Null(result.FileInformation);
            Assert.Equal(UploadFileResultStatus.ConnectionNotActive, result.Status);
            Assert.Equal(400, result.StatusCode);

            knownContainer.Configuration.IsConnectionAvailable = null;
            // if connection is null
            var result2 = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.Null(result2.FileInformation);
            Assert.Equal(UploadFileResultStatus.ConnectionNotActive, result2.Status);
            Assert.Equal(400, result2.StatusCode);
        }

        [Fact]
        public async Task UploadFileWithMetadataAsync_ContainerConnectionTest_True()
        {
            var knownContainerName = "KnownContainer";
            var unKnownContainerName = "DummyContainer";

            var knownFileName = "file.txt";
            var unKnownFileName = "nofile.txt";
            var knownFileInfo = new UploadFileResult(new FileResource(knownFileName), UploadFileResultStatus.Success);
            var knownContainer = new ContainerResource(knownContainerName)
            {
                Configuration = new Contracts.Configuration.StorageContainerConfiguration() { IsVersionEnabled = true, IsConnectionAvailable = true }
            };
            var fileMockedStream = new MemoryStream();
            containerConfigurationProviderMock.Setup(fun => fun.GetContainerByNameAsync(knownContainerName, It.IsAny<CancellationToken>()))
                                              .ReturnsAsync(knownContainer);

            dataStorageRepositoryMock.Setup(fun => fun.UploadFileToFolderAsync(knownContainer, knownFileName, It.IsAny<string>(), fileMockedStream, It.IsAny<MetadataCollections>(), It.IsAny<CancellationToken>()))
                                     .ReturnsAsync(knownFileInfo);

            var dss = new DataStorageService(containerConfigurationProviderMock.Object,
                                             dataStorageRepositoryMock.Object,
                                             loggerMock.Object, mockMetadataService.Object, mockIndexingService.Object);
            // if connection is true
            var result = await dss.UploadFileWithMetadataAsync(knownContainerName, knownFileName, null, fileMockedStream, null, CancellationToken.None);
            Assert.NotNull(result.FileInformation);
            Assert.Equal(200, result.StatusCode);

        }

    }
}