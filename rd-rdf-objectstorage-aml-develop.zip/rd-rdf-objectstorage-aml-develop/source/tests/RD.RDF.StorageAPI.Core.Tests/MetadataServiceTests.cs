﻿using Microsoft.Extensions.Logging;
using Moq;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using FluentAssertions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Core.Services;

namespace RD.RDF.StorageAPI.Core.Tests
{
    public class MetadataServiceTests
    {
        private readonly Mock<IContainerConfigurationProvider> containerConfigurationProvider;
        private readonly Mock<IFilesRepository> filesRepository;
        private readonly Mock<IFoldersRepository> foldersRepository;
        private readonly Mock<ISearchProviderFactory> searchProviderFactory;
        private readonly MetadataService metadataService;
        private readonly Mock<ILogger<MetadataService>> mockLogger;

        public MetadataServiceTests()
        {
            containerConfigurationProvider = new Mock<IContainerConfigurationProvider>();
            filesRepository = new Mock<IFilesRepository>();
            foldersRepository = new Mock<IFoldersRepository>();
            searchProviderFactory = new Mock<ISearchProviderFactory>();
            mockLogger = new Mock<ILogger<MetadataService>>();
            metadataService = new MetadataService(containerConfigurationProvider.Object, filesRepository.Object, foldersRepository.Object, searchProviderFactory.Object, mockLogger.Object);
        }

        [Fact]
        public void GetFileResourceFromIndexModel_PositiveTest()
        {
            string fileGuid = "ASDFG1";
            FileIndexModel fileIndexModel = new FileIndexModel
            {
                FileGuid = fileGuid,
                FileName = "test.png",
                FolderName = "abc",
                Versions = new List<Versions>
                {
                    new Versions
                    {
                        FileGuid = fileGuid,
                        FileName = "test.png",
                        FolderName = "abc"
                    }
                }
            };
            string indexFilePath = ".index/" + fileIndexModel.FolderName + "/" + fileIndexModel.FileName + ".json";
            string indexFolder = ".index/" + fileIndexModel.FolderName;

            var result = metadataService.GetFileResourceFromIndexModel(fileIndexModel, fileGuid);

            Assert.NotNull(result);
            Assert.Equal(fileIndexModel.FileName, result.FileName);
            Assert.Equal(fileIndexModel.FileGuid, result.FileGuid);
            Assert.Equal(fileIndexModel.FileName + ".json", result.IndexFileName);
            Assert.Equal(indexFilePath, result.IndexFilePath);
            Assert.Equal(indexFolder, result.IndexFolder);

        }

        [Fact]
        public void GetVersionIdFromIndexModel_GuidIsOfCurrenTVersion()
        {

            FileIndexModel fileIndexModel = new FileIndexModel
            {
                FileGuid = "ASDFG1",
                FileName = "test.png",
                FolderName = "abc",
                FileVersionId = "10"
            };
            string fileGuid = "ASDFG1";

            var result = metadataService.GetVersionIdFromIndexModel(fileIndexModel, fileGuid);

            Assert.NotNull(result);
            Assert.Equal("10", result);

        }

        [Fact]
        public void GetVersionIdFromIndexModel_GuidIsNotOfCurrentVersion()
        {

            FileIndexModel fileIndexModel = new FileIndexModel
            {
                FileGuid = "uyibcs",
                FileName = "test.png",
                FolderName = "abc",
                FileVersionId = "15",
                Versions = new List<Versions>
                {
                    new Versions{FileGuid="xyskll",FileVersionId ="1"},
                    new Versions{FileGuid="uyibcs",FileVersionId ="15"},
                    new Versions{FileGuid="ASDFG1",FileVersionId ="10"}
                }
            };
            string fileGuid = "ASDFG1";

            var result = metadataService.GetVersionIdFromIndexModel(fileIndexModel, fileGuid);

            Assert.NotNull(result);
            Assert.Equal("10", result);

        }

        [Fact]
        public async Task GetAllContainersAsync_NoPermissionToContainerAsync()
        {

            PaginationFilter filter = new PaginationFilter();
            string error = "No data available";
            containerConfigurationProvider.Setup(a => a.GetAllContainersAsync(CancellationToken.None)).Returns(Task.FromResult<IList<ContainerResource>>(null));

            var result = await metadataService.GetAllContainersAsync(filter, CancellationToken.None);

            Assert.NotNull(result);
            Assert.Equal(error, result.Message);

        }

        [Fact]
        public async Task GetContainerContentsAsync_NoPermissionToContainerAsync()
        {

            PaginationFilter filter = new PaginationFilter();
            containerConfigurationProvider.Setup(a => a.GetContainerByNameAsync(It.IsAny<string>(), CancellationToken.None)).Returns(Task.FromResult<ContainerResource>(null));

            var result = await metadataService.GetContainerByNameAsync("TestContainer", CancellationToken.None);

            Assert.Null(result);

        }

        [Fact]
        public async Task GetContainerByNameAsync_NoPermissionToContainerAsync()
        {
            PaginationFilter filter = new PaginationFilter();
            containerConfigurationProvider.Setup(a => a.GetContainerByNameAsync(It.IsAny<string>(), CancellationToken.None)).Returns(Task.FromResult<ContainerResource>(null));

            var result = await metadataService.GetContainerByNameAsync("TestContainer", CancellationToken.None);

            Assert.Null(result);

        }

        [Fact]
        public async Task FilterSystemDirectoriesTest_NoChange()
        {
            var input = new ContainerContents();
            input.ContainerName = "testContainer";
            input.Files = new List<FileResource> { new FileResource("test.xls", null), new FileResource("folder1/test3.xls", "folder1"), new FileResource("folder2/test2.xls", "folder2") };
            input.Folders = new List<FolderResource> { new FolderResource("folder1"), new FolderResource("folder2"), new FolderResource("folder3") };
            var output = metadataService.FilterSystemData(input);
            output.Should().BeEquivalentTo(input);
            output.Files.Should().NotBeEmpty().And.HaveCount(3);
            output.Folders.Should().NotBeEmpty().And.HaveCount(3);

        }


        [Fact]
        public async Task FilterSystemDirectoriesTest_RemoveSystemFolders()
        {
            var input = new ContainerContents();
            input.ContainerName = "testContainer";
            input.Files = new List<FileResource> { new FileResource("folder1/test.xls", "folder1"), new FileResource("folder1/test3.xls", "folder1"), new FileResource("folder2/test2.xls", "folder2") };
            input.Folders = new List<FolderResource> { new FolderResource(".index"), new FolderResource(".metadata"), new FolderResource("folder1"), new FolderResource("folder2"), new FolderResource("folder3") };
            var output = metadataService.FilterSystemData(input);
            output.Should().BeEquivalentTo(input);
            output.Files.Should().NotBeEmpty().And.HaveCount(3);
            output.Folders.Should().NotBeEmpty().And.HaveCount(3);
        }


        [Fact]
        public async Task FilterSystemDirectoriesTest_RemoveSystemFiles()
        {
            var input = new ContainerContents();
            input.ContainerName = "testContainer";
            input.Files = new List<FileResource> { new FileResource(".index/test.xls.json", ".index"), new FileResource(".metadata/test.xls.json", ".metadata"), new FileResource("test2.xls", "folder2") };
            input.Folders = new List<FolderResource> { new FolderResource(".index"), new FolderResource(".metadata"), new FolderResource("folder2"), new FolderResource("folder3") };
            var output = metadataService.FilterSystemData(input);
            output.Should().BeEquivalentTo(input);
            output.Files.Should().NotBeEmpty().And.HaveCount(1);
            output.Folders.Should().NotBeEmpty().And.HaveCount(2);
        }
    }
}
