using RD.RDF.StorageAPI.Contracts.Configuration;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.Contracts.Tests
{
    public class TokenValidationParameterSettingsTests
    {
        [Fact]
        public async Task CheckDefaultFlagsTest()
        {
            var tvps = new TokenValidationParameterSettings();
            Assert.True(tvps.ValidateAudience);
            Assert.True(tvps.ValidateActor);
            Assert.True(tvps.ValidateIssuer);
            Assert.True(tvps.ValidateIssuerSigningKey);
            Assert.True(tvps.ValidateLifetime);
            Assert.True(tvps.ValidateTokenReplay);
            Assert.Null(tvps.ValidAudiences);
        }
    }
}