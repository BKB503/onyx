﻿using RD.RDF.StorageAPI.Contracts.Model;
using Xunit;

namespace RD.RDF.StorageAPI.Contracts.Tests
{
    public class FileResourceTests
    {
        [Fact]
        public void VerifyFolderNullTest()
        {
            var fr = new FileResource("folderWithFile/fileName.json");
            Assert.Equal("fileName.json", fr.FileName);
            Assert.Null(fr.FolderName);

        }


        [Fact]
        public void VerifyFolderPathEndingTest()
        {
            var fr1 = new FileResource("folderWithFile/fileName.json", "folder");
            Assert.NotNull(fr1.FolderName);
            Assert.Equal("fileName.json", fr1.FileName);
            Assert.Equal("folder", fr1.FolderName);

            var fr2 = new FileResource("fileName.json", "folder/");
            Assert.NotNull(fr2.FolderName);
            Assert.Equal("fileName.json", fr2.FileName);
            Assert.Equal("folder", fr2.FolderName);


            var fr3 = new FileResource("fileName.json", "folder/");
            Assert.NotNull(fr3.FolderName);
            Assert.Equal("fileName.json", fr3.FileName);
            Assert.Equal("folder", fr3.FolderName);


            var fr4 = new FileResource("fileName.json", "folder/sub/folder/");
            Assert.NotNull(fr4.FolderName);
            Assert.Equal("fileName.json", fr4.FileName);
            Assert.Equal("folder/sub/folder", fr4.FolderName);

        }
    }
}