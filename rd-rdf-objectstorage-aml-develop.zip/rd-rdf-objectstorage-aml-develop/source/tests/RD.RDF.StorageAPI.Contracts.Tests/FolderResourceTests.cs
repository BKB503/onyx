﻿using RD.RDF.StorageAPI.Contracts.Model;
using Xunit;

namespace RD.RDF.StorageAPI.Contracts.Tests
{
    public class FolderResourceTests
    {
        [Fact]
        public void VerifyFolderNullTest()
        {
            var fr = new FolderResource(null);
            Assert.Null(fr.FolderName);
        }


        [Fact]
        public void VerifyFolderPathEndingTest()
        {


            var fr3 = new FolderResource("folder/");
            Assert.NotNull(fr3.FolderName);
            Assert.Equal("folder", fr3.FolderName);


            var fr4 = new FolderResource("folder/sub/folder/");
            Assert.NotNull(fr4.FolderName);
            Assert.Equal("folder/sub/folder", fr4.FolderName);

        }
    }
}