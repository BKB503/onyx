﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using Xunit;
using RD.RDF.StorageAPI.Contracts.Model;

namespace RD.RDF.StorageAPI.Contracts.Tests
{

    public class MetadataCollectionTests
    {
        [Fact]
        public void TestCollectionCreationFromMeatadaDictionary()
        {
            Dictionary<string, string> keyValuePairs = new Dictionary<string, string>();
            keyValuePairs.Add("Test1", "Value1");
            keyValuePairs.Add("Test2", "Value2");
            keyValuePairs.Add("Test3", "Value3");
            keyValuePairs.Add("Test4", "Value4");
            MetadataDictionary metadataDictionary = new MetadataDictionary(keyValuePairs, false);
            MetadataCollections collections = new MetadataCollections(metadataDictionary);

            Assert.NotNull(collections);
            Assert.Equal(4, collections.Items.Count);
        }
    }
}
