﻿using RD.RDF.StorageAPI.Contracts.Model.Filters;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.Contracts.Tests
{
    public class PaginationFilterTests
    {
        [Fact]
        public async Task VerifyDefaultPaginationValuesTest()
        {
            var pagination = new PaginationFilter();
            Assert.Null(pagination.ContinuationToken);
            Assert.Equal(PaginationFilter.MaxLimit, pagination.Limit);
        }

        [Fact]
        public async Task VerifyPaginationValuesTest()
        {
            var pagination = new PaginationFilter("token", 20);
            Assert.Equal("token", pagination.ContinuationToken);
            Assert.Equal(20, pagination.Limit);
        }


        [Fact]
        public async Task VerifyOutOfScalePaginationValuesTest()
        {
            var pagination = new PaginationFilter("-100", 5000000);
            Assert.Equal("-100", pagination.ContinuationToken);
            Assert.Equal(PaginationFilter.MaxLimit, pagination.Limit);
        }

        [Fact]
        public async Task VerifyOutOfScalePaginationValues2Test()
        {
            var pagination = new PaginationFilter("token", -5000000);
            Assert.Equal("token", pagination.ContinuationToken);
            Assert.Equal(PaginationFilter.MaxLimit, pagination.Limit);
        }
    }
}