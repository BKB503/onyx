﻿using RD.RDF.StorageAPI.Contracts.Extensions;
using Xunit;

namespace RD.RDF.StorageAPI.Contracts.Tests
{
    public class PathExtensionsTests
    {
        [Fact]
        public void TestRemoveWindowsSeparator()
        {
            string inputPath = @"test\path\";
            string expectedPath = @"test/path/";

            Assert.EndsWith(expectedPath, PathExtensions.ReplaceWindowsSeparator(inputPath));
        }

        [Fact]
        public void TestRemoveWindowsSeparator_null_inputValue()
        {
            Assert.Null(PathExtensions.ReplaceWindowsSeparator(null));
        }

        [Fact]
        public void TestRemoveWindowsSeparator_Empty_inputValue()
        {
            Assert.Equal(string.Empty, PathExtensions.ReplaceWindowsSeparator(string.Empty));
        }


        [Fact]
        public void TestCombinePath_null_inputValue()
        {
            Assert.Null(PathExtensions.CombineBlobPath(null));
        }

        [Fact]
        public void TestCombinePath_Empty_inputValue()
        {
            Assert.Equal(string.Empty, PathExtensions.CombineBlobPath(string.Empty));
        }


        [Fact]
        public void TestCombinePath_ProperJoin1_inputValue()
        {
            string part1 = "test\\path";
            string part2 = null;
            string part3 = "more\\subFolders/";
            string part4 = "test2/file.txt";

            string expected = "test/path/more/subFolders/test2/file.txt";

            Assert.Equal(expected, PathExtensions.CombineBlobPath(part1, part2, part3, part4));
        }

        [Fact]
        public void TestCombinePath_ProperJoin2_inputValue()
        {
            string part1 = null;
            string part2 = string.Empty;
            string part3 = "more\\subFolders/";
            string part4 = "test2/file.txt";

            string expected = "more/subFolders/test2/file.txt";

            Assert.Equal(expected, PathExtensions.CombineBlobPath(part1, part2, part3, part4));
        }


        [Fact]
        public void TestCombinePath_JustFileName_inputValue()
        {
            string part4 = "file.txt";
            string expected = "file.txt";
            Assert.Equal(expected, PathExtensions.CombineBlobPath(part4));
        }
    }
}