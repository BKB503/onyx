﻿using RD.RDF.StorageAPI.Contracts.Model;

namespace RD.RDF.StorageAPI.Service.ViewModel
{
    public class FileUploadResult
    {
        public FileUploadResult(FileResource file = null, string message = default)
        {
            Success = file != null;
            Data = file;
            Message = message;
        }

        public string Message { get; set; }

        public bool Success { get; set; }

        public FileResource Data { get; set; }

    }
}
