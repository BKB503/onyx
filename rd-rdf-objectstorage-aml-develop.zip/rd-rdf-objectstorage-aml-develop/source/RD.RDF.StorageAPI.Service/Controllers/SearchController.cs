﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using RD.RDF.StorageAPI.Core.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO.Abstractions;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Service.Controllers
{
    [Authorize]
    [Route("api/v1")]
    [ApiController]
    public class SearchController : ControllerBase
    {
        private readonly IMetadataService metadataService;
        private readonly ILogger<ReadController> logger;
        private readonly IEventsTracker eventsTracker;
        private readonly IMetricsTracker metricsTracker;
        private readonly IOdbcFileIndexSearchService odbcFileIndexSearchService;

        public SearchController(IMetadataService metadataService,
                                ILogger<ReadController> logger,
                                IEventsTracker eventsTracker,
                                IMetricsTracker metricsTracker, 
                                IOdbcFileIndexSearchService odbcFileIndexSearchService)
        {
            this.metadataService = metadataService;
            this.logger = logger;
            this.eventsTracker = eventsTracker;
            this.metricsTracker = metricsTracker;
            this.odbcFileIndexSearchService = odbcFileIndexSearchService;
        }


        /// <summary>
        /// Search files by tags using ANSI like query
        /// See 
        /// </summary>
        /// <param name="container">Container name</param>
        /// <param name="tagSearchQuery"> Tag search query  <br/>
        /// The following operators are supported: =, >, >=, <, <=, AND. Example expression: "tagKey"='tagValue'. <br />
        /// @container operator is not supported - as it will search in configured container <br />
        /// Example : <br />
        /// "ExperimentId" > 'ELN1234' AND "AllianceId" = 'GSK' <br/>
        /// <b>URI parameter must be properly URI encoded</b>
        /// </param>    
        /// <param name="cancellationToken"></param>
        /// <returns>Search result or empty result set</returns>
        [HttpGet]
        [Route("search/{container}/files/byTags/{tagSearchQuery}")]
        [ProducesResponseType(typeof(ApiResponse<IList<FileResource>>), 200)]
        [ProducesResponseType(500)]
        public async Task<ApiResponse<IList<FileResource>>> SearchFilesAsync(string container, string tagSearchQuery, CancellationToken cancellationToken = default)
        {
            var startupTick = Environment.TickCount;
            int resultsFound = 0;
            bool searchResultAvailable = false;
            ApiResponse<IList<FileResource>> result;
            var searchResult = await metadataService.SearchFilesByTagsAsync(container, tagSearchQuery, cancellationToken);
            if (searchResult != null && searchResult.Success)
            {
                searchResultAvailable = true;
                resultsFound = searchResult.Results.Count;
                result = new ApiResponse<IList<FileResource>>(searchResult.Results);
            }
            else
            {
                result = new ApiResponse<IList<FileResource>>(searchResult == null ? "No search results" : searchResult.Message);
            }
            TrackActionCall(container, tagSearchQuery, searchResultAvailable, resultsFound, startupTick);
            return result;
        }

        /// <summary>
        /// Search files by Metadata 
        /// See 
        /// </summary>
        /// <param name="container">Container Name</param>
        /// <param name="metaDataKey "> Meta Data Key </param>
        /// <param name="metaDataValue  "> Meta Data Value </param>
        /// "folder" ='folder1' <br/>
        /// "metaDataKey" ='OriginatingOrganization' AND "metaDataValue" = 'GlaxoSmithKline' <br/>
        /// <b>URI parameter must be properly URI encoded</b>
        /// <param name="cancellationToken"></param>
        /// <returns>Search result or empty result set</returns>
        [HttpGet]
        [Route("search/files/{container}/metaDataKey/{metaDataKey}/metaDataValue/{metaDataValue}")]
        [ProducesResponseType(typeof(ApiResponse<List<FileIndexModel>>), 200)]
        [ProducesResponseType(500)]
        public async Task<PagedOffsetApiResponse<List<FileIndexModel>>> SearchFilesByMetaDataAsync([Required] string container, [Required] string metaDataKey, [Required] string metaDataValue, [FromQuery] string folder, [FromQuery] OffsetPagPaginationFilter filter, CancellationToken cancellationToken = default)
        {
            var searchResult = await odbcFileIndexSearchService.GetIndexSearchResultAsync(container, metaDataKey, metaDataValue, folder, filter, cancellationToken);
            return searchResult;
        }

        /// <summary>
        /// Search files by Metadata 
        /// See 
        /// </summary>
        /// <param name="container">Container Name</param>
        /// <param name="folder "> Folder Name </param>
        /// <param name="metaDataKey ">Meta Data Key </param>
        /// <param name="metaDataValue">Meta Data Value </param>
        /// "metaDataKey" ='OriginatingOrganization' AND "metaDataValue" = 'GlaxoSmithKline' <br/>
        /// <b>URI parameter must be properly URI encoded</b>
        /// <param name="cancellationToken"></param>
        /// <returns>Search result or empty result set</returns>
        [HttpGet]
        [Route("search/files/{container}/folder/{folder}")]
        [ProducesResponseType(typeof(ApiResponse<List<FileIndexModel>>), 200)]
        [ProducesResponseType(500)]
        public async Task<PagedOffsetApiResponse<List<FileIndexModel>>> SearchFilesByFolderNameAsync([Required] string container, [Required] string folder, [FromQuery] string metaDataKey, [FromQuery] string metaDataValue, [FromQuery] OffsetPagPaginationFilter filter, CancellationToken cancellationToken = default)
        {
            var searchResult = await odbcFileIndexSearchService.GetIndexSearchByFolderNameAsync(container, folder, metaDataKey, metaDataValue, filter, cancellationToken);
            return searchResult;
        }

        private void TrackActionCall(string container, string tagSearchQuery, bool searchResultAvailable, int resultsFound, int startupTick)
        {
            try
            {
                var totalMs = Environment.TickCount - startupTick;
                double totalS = totalMs / 1000.00;

                var metric = new DiagnosticMetric(ApiDiagnosticMetrics.SearchByTag, totalS);
                metricsTracker.Track(metric);
                eventsTracker.Track(new DiagnosticEvent(ApiDiagnosticEvents.SearchByTag)
                {
                    Metrics = new List<DiagnosticMetric> { metric },
                    Properties = new Dictionary<string, string>()
                 {
                     {"TagSearchQuery", tagSearchQuery},
                     {"SearchResultAvailable", searchResultAvailable.ToString()},
                     {"TotalResultsFound", resultsFound.ToString()},
                     {"TotalTimeMS", totalMs.ToString()},
                     {"ContainerName", container}
                 }
                });
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
        }

      
    }
}