﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Service.Controllers
{
    [Authorize]
    [Route("api/v1")]
    [ApiController]
    public class ManagementController : ControllerBase
    {
        private readonly IReindexingService reindexingService;

        public ManagementController(IReindexingService reindexingService)
        {
            this.reindexingService = reindexingService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="containerName">name of container</param>
        /// <param name="useFileVersionsAsGuids">if checked the File versions of existing not indexed files will be used as FileGuid
        /// </param> Leaving that off would cause FileGuids to be generated again
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet]
        [Route("management/reindex")]
        public async Task<ReindexingStatusModel> StartReindexingProcessAsync(string containerName, bool useFileVersionsAsGuids, CancellationToken cancellationToken)
        {
            ReindexingStatusModel result = await reindexingService.StartReindexingProcessAsync(containerName, useFileVersionsAsGuids, cancellationToken);
            return result;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet]
        [Route("management/reindex-status/{taskKey}")]
        public async Task<ReindexingStatusModel> GetReindexingStatusAsync(string taskKey, CancellationToken cancellationToken)
        {
            ReindexingStatusModel result = await reindexingService.GetReindexingStatusAsync(taskKey, cancellationToken);
            return result;
        }


    }
}
