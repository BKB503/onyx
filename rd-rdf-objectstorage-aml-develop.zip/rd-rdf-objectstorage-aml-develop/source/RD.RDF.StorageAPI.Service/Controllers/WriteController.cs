﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Service.ViewModel;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IdentityModel.OidcClient;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using System.Net;

namespace RD.RDF.StorageAPI.Service.Controllers
{
    [Authorize]
    [Route("api/v1")]
    [ApiController]
    [Produces("application/json")]
    public class WriteController : ControllerBase
    {
        private readonly IDataStorageService dataStorageService;
        private readonly ILogger<WriteController> logger;
        private readonly IEventsTracker eventsTracker;
        private readonly IMetricsTracker metricsTracker;
        private readonly IMetadataParsingService metadataParsing;
       
        public WriteController(IDataStorageService dataStorageService,
                               ILogger<WriteController> logger,
                               IEventsTracker eventsTracker,
                               IMetricsTracker metricsTracker,
                               IMetadataParsingService metadataParsing)
        {
            this.dataStorageService = dataStorageService;
            this.logger = logger;
            this.eventsTracker = eventsTracker;
            this.metricsTracker = metricsTracker;
            this.metadataParsing = metadataParsing;            
        }


        /// <summary>
        /// Action for upload file and a metadata file
        /// </summary> 
        /// <param name="container">Container name</param>        
        /// <param name="folder">Optional Sub folder name</param>
        /// <param name="file">File contents</param>
        /// <param name="metadata">Metadata file contents - json file format <br/>
        /// <pre>
        /// {
        ///     "metaData": {
        ///          "Language": "English",
        ///          "Format": "application/json",
        ///          "InformationCategory": "Confidential",
        ///          "OriginatingOrganization": "GlaxoSmithKline"
        ///          }
        ///  }
        ///  </pre>
        /// </param>            
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns></returns>
        /// <response code="200">Success</response>
        /// <response code="400">Connection to container not available or Versioning not enabled</response>
        /// <response code="404">Container not exists or is not available for the client</response>
        /// <response code="500">Error occured - see Message property in response</response>      
        [HttpPost]
        [Route("upload/{container}/file")]
        [ProducesResponseType(typeof(UploadFileResult), 200)]
        [ProducesResponseType(typeof(UploadFileResult), 400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public async Task<IActionResult> UploadFile([Required] string container,
                                                    [FromQuery] string folder,
                                                    [Required] IFormFile file,
                                                    IFormFile metadata,
                                                    CancellationToken cancellationToken)
        {
            UploadFileResult result;
            try
            {
                var startupTick = Environment.TickCount;               
                //Parsing the json file
                Stream metadataStream = null;
                MetadataModel metadataDict;
                if (metadata != null)
                {
                    Stream metadataStreamInner = metadata.OpenReadStream();
                    metadataDict = metadataParsing.ReadTheMetadataJsonFile(metadataStreamInner);
                }
                else
                {
                    metadataDict = new MetadataModel();
                }
                MetadataCollections metadataModel = new MetadataCollections(metadataDict.MetaDataDictionary);
                metadataStream = metadataParsing.SerializeToStream(metadataDict);
                string fileName = file?.FileName;
                long fileSize = (file?.Length).GetValueOrDefault();
                bool fileAvailable = fileSize > 0;
                Stream fileStream = file?.OpenReadStream();
                result = await dataStorageService.UploadFileToStorageAsync(container, folder, fileName, fileSize, fileStream, metadataModel, cancellationToken);
                TrackActionCall(ApiDiagnosticEvents.UploadFile, container, fileName, folder, result?.FileInformation?.FileGuid, fileSize, fileAvailable, startupTick);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                result = new UploadFileResult(UploadFileResultStatus.Error, ex.Message);
            }
            return StatusCode(result.StatusCode, result);
        }


        /// <summary>
        /// Action for upload file and a metadata object
        /// </summary> 
        /// <param name="container">Container name</param>        
        /// <param name="folder">Optional Sub folder name</param>
        /// <param name="fileObj">File contents</param>
        /// <param name="metadata">Metadata file contents - json file format <br/>
        /// </param>            
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns></returns>       
        /// <response code="200">Success</response>
        /// <response code="400">Connection to container not available or Versioning not enabled</response>
        /// <response code="404">Container not exists or is not available for the client</response>
        /// <response code="500">Error occured - see Message property in response</response>
        [HttpPost]
        [Route("upload/{container}/fileObj")]
        [ProducesResponseType(typeof(UploadFileResult), 200)]
        [ProducesResponseType(typeof(UploadFileResult), 400)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public async Task<IActionResult> UploadFileObject([Required] string container,
                                                    [FromQuery] string folder,
                                                    [FromForm] UploadFileFormModel fileObj,
                                                    CancellationToken cancellationToken)
        {
            UploadFileResult result = null;
            string msg = "No file provided";
            try
            {
                var startupTick = Environment.TickCount;
                var inputMetadata = fileObj.Metadata;
                if (inputMetadata == null)
                    inputMetadata = new MetadataCollections();
                Stream metadataStream = metadataParsing.SerializeToStream(new MetadataModel(inputMetadata));
                string fileName = fileObj?.File?.FileName;
                long fileSize = (fileObj?.File?.Length).GetValueOrDefault();
                Stream fileStream = fileObj?.File?.OpenReadStream();
                bool fileAvailable = fileSize > 0;
                result = await dataStorageService.UploadFileToStorageAsync(container, folder, fileName, fileSize, fileStream, inputMetadata, cancellationToken);
                TrackActionCall(ApiDiagnosticEvents.UploadFile, container, fileName, folder, result?.FileInformation?.FileGuid, fileSize, fileAvailable, startupTick);                  
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                msg = ex.Message;
                result = new UploadFileResult(UploadFileResultStatus.Error, msg);
            }
            return StatusCode(result.StatusCode, result);
        }

        /// <summary>
        /// Action for upload file in parts initialization of session
        /// </summary> 
        /// <param name="container">Container name</param>        
        /// <param name="folder">Optional Sub Folder name</param>
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>       
        /// <param name="cancellationToken"></param>
        /// <returns> UploadSessionId  </returns>
        /// <response code="200">Success</response>
        /// <response code="400">Connection to container not available or Versioning not enabled</response>
        /// <response code="404">Container not exists or is not available for the client</response>
        /// <response code="500">Error occured - see Message property in response</response>
        [HttpGet]
        [Route("uploadPartsInit/{container}/file/{fileName}")]
        [ProducesResponseType(typeof(UploadPartsInitResult), 200)]
        [ProducesResponseType(typeof(UploadPartsInitResult), 400)]
        [ProducesResponseType(typeof(UploadPartsInitResult), 404)]
        [ProducesResponseType(typeof(UploadPartsInitResult), 500)]
        public async Task<IActionResult> UploadPartsInitAsync([Required] string container,
                                                              [FromQuery] string folder,
                                                              [Required] string fileName,
                                                              CancellationToken cancellationToken)
        {
            UploadPartsInitResult result = await dataStorageService.UploadPartsInitAsync(container, fileName, folder, cancellationToken);
            return StatusCode((int)result.Status, result);
        }



        /// <summary>
        /// Action for upload file in part 
        /// </summary> 
        /// <param name="container">Container name</param>        
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>     
        /// <param name="folder">Optional Sub folder name</param>
        /// <param name="filePartNumber">File part number</param>
        /// <param name="filePartSize">Maximum file part size - last part in upload session might have less bytes. The parameter has to be constant in the whole upload session</param>
        /// <param name="fileTotalSize">File total bytes</param>
        /// <param name="uploadPart">File part model stream</param>
        /// <param name="cancellationToken"></param>
        /// <returns>Status of the uploaded part</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Connection to container not available or Versioning not enabled</response>
        /// <response code="404">Container not exists or is not available for the client</response>
        /// <response code="500">Error occured - see Message property in response</response>
        [HttpPost]
        [Route("uploadPart/{container}/file/{fileName}/ts/{fileTotalSize:long}/ps/{filePartSize:long}/pn/{filePartNumber:int}")]
        [ProducesResponseType(typeof(UploadPartResult), 200)]
        [ProducesResponseType(typeof(UploadPartResult), 400)]
        [ProducesResponseType(typeof(UploadPartResult), 404)]
        [ProducesResponseType(typeof(UploadPartResult), 500)]
        public async Task<IActionResult> UploadPartFileAsync([Required] string container,
                                                        [Required] string fileName,
                                                        [FromQuery] string folder,
                                                        [Required] int filePartNumber,
                                                        [Required] long filePartSize,
                                                        [Required] long fileTotalSize,
                                                        [FromForm, Required] UploadPartFormModel uploadPart,
                                                        CancellationToken cancellationToken)
        {
            var startupTick = Environment.TickCount;
            Stream filePartStream = uploadPart?.FilePart?.OpenReadStream();
            long filePartStreamLenght = (uploadPart?.FilePart?.Length).GetValueOrDefault(0);
            bool fileAvailable = filePartStreamLenght > 0;
            var uploadPartModel = new UploadPartFileModel(container, uploadPart.UploadSessionId, filePartStream, filePartStreamLenght, fileName, folder, filePartNumber, filePartSize, fileTotalSize);
            UploadPartResult result = await dataStorageService.UploadPartFileAsync(uploadPartModel, cancellationToken);
            TrackActionCall(ApiDiagnosticEvents.UploadFilePart, container, fileName, folder, result?.PartGuid, filePartStreamLenght, fileAvailable, startupTick);
            return StatusCode((int)result.Status, result);
        }

        /// <summary>
        /// Action for commiting upload file in parts
        /// </summary> 
        /// <param name="container">Container name</param>        
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>      
        /// <param name="uploadRequest">Upload commit request object</param>
        /// <param name="folder">Optional Sub folder name</param>       
        /// <param name="cancellationToken"></param>
        /// <returns>Status of the uploaded part</returns>
        /// <response code="200">Success</response>
        /// <response code="400">Connection to container not available or Versioning not enabled</response>
        /// <response code="404">Container not exists or is not available for the client</response>
        /// <response code="500">Error occured - see Message property in response</response>
        [HttpPost]
        [Route("uploadPartsCommit/{container}/file/{fileName}")]
        [ProducesResponseType(typeof(UploadPartCommitResult), 200)]
        [ProducesResponseType(typeof(UploadPartCommitResult), 400)]
        [ProducesResponseType(typeof(UploadPartCommitResult), 404)]
        [ProducesResponseType(typeof(UploadPartCommitResult), 500)]
        public async Task<IActionResult> UploadPartsCommitAsync([Required] string container,
                                                                [Required] string fileName,
                                                                [Required] UploadPartCommitRequest uploadRequest,
                                                                [FromQuery] string folder,
                                                                CancellationToken cancellationToken)
        {
            UploadPartCommitResult result = await dataStorageService.UploadPartsCommitAsync(container, uploadRequest.UploadSessionId, fileName, folder, uploadRequest.Parts, uploadRequest.Metadata, cancellationToken);
            return StatusCode((int)result.Status, result);
        }




       

        private void TrackActionCall(ApiDiagnosticEvents eventType, string container, string fileName, string folder, string fileGuid, long totalBytes, bool fileAvailable, int startupTick)
        {
            try
            {
                var totalMs = Environment.TickCount - startupTick;
                double totalS = totalMs / 1000.00;
                double bps = totalBytes / totalS;
                var metric = new DiagnosticMetric(ApiDiagnosticMetrics.UploadFileBytesPerSecond, bps);
                metricsTracker.Track(metric);
                eventsTracker.Track(new DiagnosticEvent(eventType)
                {
                    Metrics = new List<DiagnosticMetric> { metric },
                    Properties = new Dictionary<string, string>()
                 {
                     {"FileName", fileName},
                     {"FileAvailable", fileAvailable.ToString()},
                     {"TotalBytes", totalBytes.ToString()},
                     {"TotalTimeMS", totalMs.ToString()},
                     {"ContainerName", container},
                     {"FolderName", folder},
                     {"FileGuid", fileGuid},
                 }
                });
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
        }
    }
}