﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Service.Controllers
{
    [Authorize]
    [Route("api/v1")]
    [ApiController]
    public class ReadController : ControllerBase
    {
        private readonly IMetadataService metadataService;
        private readonly IDataStorageService dataStorageService;
        private readonly ILogger<ReadController> logger;
        private readonly IEventsTracker eventsTracker;
        private readonly IMetricsTracker metricsTracker;
        private readonly IAllianceSecurityService allianceSecurityService;

        public ReadController(IMetadataService metadataService,
                              IDataStorageService dataStorageService,
                              ILogger<ReadController> logger,
                              IEventsTracker eventsTracker,
                              IMetricsTracker metricsTracker,
                              IAllianceSecurityService allianceSecurityService)
        {
            this.metadataService = metadataService;
            this.dataStorageService = dataStorageService;
            this.logger = logger;
            this.eventsTracker = eventsTracker;
            this.metricsTracker = metricsTracker;
            this.allianceSecurityService = allianceSecurityService;
        }

        /// <summary>
        /// Get all containers available
        /// </summary>       
        [HttpGet]
        [Route("containers")]
        public async Task<PagedApiResponse<IList<string>>> GetContainersAsync([FromQuery] PaginationFilter filter, CancellationToken cancellationToken)
        {
            var result = await metadataService.GetAllContainersAsync(filter, cancellationToken);
            return result;
        }

        /// <summary>
        /// Get one container information
        /// </summary> 
        /// <param name="containerName">Name of container</param>
        /// <param name="cancellationToken"></param>
        [HttpGet]
        [Route("container/{containerName}")]
        public async Task<ApiResponse<ContainerResource>> GetContainerByNameAsync(string containerName, CancellationToken cancellationToken)
        {
            var result = await metadataService.GetContainerByNameAsync(containerName, cancellationToken);
            if (result is null)
            {
                return new ApiResponse<ContainerResource>("Container does not exists.");
            }
            return new ApiResponse<ContainerResource>(result);
        }

        /// <summary>
        /// Gets contents (files and folders) of the container and filters it by User Alliance access
        /// </summary>
        /// <remarks>
        /// Important note: This API accepts only Tokens with User MudID from Authorization Code flow. Other tokens will be rejected with status 400
        /// </remarks>
        /// <param name="containerName">Name of the container</param>
        /// <param name="folder">Folder to browse</param>
        /// <param name="filter">Filter results</param>
        /// <param name="cancellationToken"></param>        
        /// <returns></returns>
        /// <response code="200">Container information retrieved</response>
        /// <response code="400">Authorization Token error - no user id in token.</response>                
        /// <response code="500">Internal Server error</response>
        [HttpGet]
        [Route("container/{containerName}/contents")]
        [ProducesResponseType(typeof(ContainerContents), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)] // User mudid has to be provided in the token
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetContainerContentsAsync(string containerName,
                                                                  [FromQuery] string folder,
                                                                  [FromQuery] PaginationFilter filter,
                                                                  CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(User.Identity.Name))
            {
                return StatusCode(StatusCodes.Status400BadRequest, $"No MudID in OAuth2 token. Authorization Code flow has to be used in order to download the data.");
            }

            var containerContents = await metadataService.GetContainerContentsAsync(containerName, folder, filter, cancellationToken);
            if (containerContents is null)
            {
                return StatusCode(StatusCodes.Status401Unauthorized, $"Container does not exists.");
            }
            //filter the contents
            containerContents = await allianceSecurityService.FilterContainerContentsAsync(containerContents, User.Identity.Name, cancellationToken);
            return Ok(containerContents);
        }

        /// <summary>
        /// Gets information of a single file from storage layer
        /// </summary>
        /// <remarks>
        /// Important note: This API accepts only Tokens with User MudID from Authorization Code flow. Other tokens will be rejected with status 400
        /// </remarks>
        /// <param name="containerName">Container Name</param>
        /// <param name="fileName">File Name</param>
        /// <param name="folder">Folder Name</param>
        /// <param name="fileGuid">File GUID</param>
        /// <param name="cancellationToken"></param>        
        /// <returns></returns>
        /// <response code="200">File information retrieved</response>
        /// <response code="400">Authorization Token error - no user id in token.</response>
        /// <response code="403">File access forbidden</response>
        /// <response code="404">File not found</response>
        /// <response code="500">Internal Server error</response>
        [HttpGet]
        [Route("container/{containerName}/contents/{fileName}")]
        [ProducesResponseType(typeof(FileResource), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status403Forbidden)] // alliance security applied
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)] // file not found 
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)] // User mudid has to be provided in the token
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetFileInformationAsync(string containerName,
                                                                 string fileName,
                                                                  [FromQuery] string folder,
                                                                  [FromQuery] string fileGuid,
                                                                  CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(User.Identity.Name))
            {
                return StatusCode(StatusCodes.Status400BadRequest, $"No MudID in OAuth2 token. Authorization Code flow has to be used in order to download the data.");
            }

            var fileResource = new FileResource(fileName, folder);
            var fileIndexModel = await dataStorageService.DownloadFileIndexModelAsync(containerName, fileResource, cancellationToken);
            var result = metadataService.GetFileResourceFromIndexModel(fileIndexModel, fileGuid);
            if (result is null)
            {
                var msg = $"No matching file details found for the provided fileName: {fileName} folder: {folder} fileGuid: {fileGuid}";
                logger.LogError(msg);
                return NotFound(msg);
            }

            // validate the alliance access to the file information
            var accessValidationResult = await allianceSecurityService.CheckUserAccessAsync(containerName, User.Identity.Name, fileIndexModel, cancellationToken);
            if (accessValidationResult != null && accessValidationResult.Result == AllianceAccessVerificationEnum.NotAllowed)
            {
                string[] msg = { $"File {fileName} in Container {containerName} Folder {folder} with FileGuid {fileGuid} is not accessible for the user {User.Identity.Name} AgreementPacket {accessValidationResult?.AllianceName} Reason {accessValidationResult.ResultMessage}" };
                logger.LogWarning(msg[0]);
                return StatusCode(StatusCodes.Status403Forbidden, msg[0]);
            }
            //instead of 403 we return object with reason and agreement name
            result.AgreementPacketName = accessValidationResult?.AllianceName;
            result.AllianceAccessVerification = accessValidationResult?.Result;
            return Ok(result);
        }

        /// <summary>
        /// Action for downloading a file. It returns a stream that can be read.
        /// </summary>
        /// <remarks>
        /// Important note: This API accepts only Tokens with User MudID from Authorization Code flow. Other tokens will be rejected with status 400
        /// </remarks>
        /// <param name="containerName">Container Name</param>
        /// <param name="fileName">File Name</param>
        /// <param name="folder">Folder Name</param>
        /// <param name="fileGuid">File GUID</param>
        /// <param name="cancellationToken"></param>
        /// <returns>A file stream or error message</returns>
        /// <response code="200">File retrieved</response>
        /// <response code="400">Authorization Token error - no user id in token.</response>
        /// <response code="403">File access forbidden</response>
        /// <response code="404">File not found</response>
        /// <response code="500">Internal Server error</response>
        [HttpGet]
        [Route("download/{containerName}/file")]
        [ProducesResponseType(typeof(FileStreamResult), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status403Forbidden)] // alliance security applied
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)] // file not found 
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)] // User mudid has to be provided in the token
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> DownloadFileAsync(string containerName,
                                                      [FromQuery, Required] string fileName,
                                                      [FromQuery] string folder,
                                                      [FromQuery, Required] string fileGuid,
                                                      CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(User.Identity.Name))
            {
                return StatusCode(StatusCodes.Status400BadRequest, $"No MudID in OAuth2 token. Authorization Code flow has to be used in order to download the data.");
            }

            IActionResult actionResult;
            var startupTick = Environment.TickCount;
            long totalBytes = 0;
            bool fileAvailable = false;
            FileResource fileResource = new FileResource(fileName, folder);
            var fileIndexModel = await dataStorageService.DownloadFileIndexModelAsync(containerName, fileResource, cancellationToken);
            string versionId = metadataService.GetVersionIdFromIndexModel(fileIndexModel, fileGuid);
            if (versionId is null)
            {
                string[] msg = { $"File {fileName} was not found in Container {containerName} Folder {folder}. Please check the GUID or fileName." };
                logger.LogWarning(msg[0]);
                return NotFound(msg[0]);
            }
            // validate the alliance access to the file
            var accessValidationResult = await allianceSecurityService.CheckUserAccessAsync(containerName, User.Identity.Name, fileIndexModel, cancellationToken);
            if (accessValidationResult != null && accessValidationResult.Result == AllianceAccessVerificationEnum.NotAllowed)
            {
                string[] msg = { $"File {fileName} in Container {containerName} Folder {folder} with FileGuid {fileGuid} is not accessible for the user {User.Identity.Name} AgreementPacket {accessValidationResult?.AllianceName} Reason {accessValidationResult.ResultMessage}" };
                logger.LogWarning(msg[0]);
                return StatusCode(StatusCodes.Status403Forbidden, msg[0]);
            }

            var fileInfo = await metadataService.GetFileByNameAndVersionAsync(containerName, fileName, folder, versionId, cancellationToken);
            if (fileInfo != null && fileInfo.FileSize.GetValueOrDefault() > 0)
            {
                totalBytes = fileInfo.FileSize.GetValueOrDefault();
                Stream fileStream = await dataStorageService.GetFileStreamAsync(containerName, fileInfo, cancellationToken);
                fileAvailable = true;
                actionResult = File(fileStream, MediaTypeNames.Application.Octet, fileInfo.FileName);
            }
            else
            {
                string[] msg = { $"File {fileName} was not found in Container {containerName}. Folder {folder}" };
                logger.LogWarning(msg[0]);
                actionResult = NotFound(msg);
            }
            TrackActionCall(containerName, fileName, folder, fileGuid, totalBytes, fileAvailable, startupTick);
            return actionResult;
        }

        private void TrackActionCall(string container, string fileName, string folder, string fileGuid, long totalBytes, bool fileAvailable, int startupTick)
        {
            try
            {
                var totalMs = Environment.TickCount - startupTick;
                double totalS = totalMs / 1000.00;
                double bps = totalBytes / totalS;
                var metric = new DiagnosticMetric(ApiDiagnosticMetrics.DownloadFileBytesPerSecond, bps);
                metricsTracker.Track(metric);
                eventsTracker.Track(new DiagnosticEvent(ApiDiagnosticEvents.DownloadFile)
                {
                    Metrics = new List<DiagnosticMetric> { metric },
                    Properties = new Dictionary<string, string>()
                 {
                     {"FileName", fileName},
                     {"FileAvailable", fileAvailable.ToString()},
                     {"TotalBytes", totalBytes.ToString()},
                     {"TotalTimeMS", totalMs.ToString()},
                     {"ContainerName", container},
                     {"FolderName", folder},
                     {"FileGuid", fileGuid},
                 }
                });
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
        }
    }
}