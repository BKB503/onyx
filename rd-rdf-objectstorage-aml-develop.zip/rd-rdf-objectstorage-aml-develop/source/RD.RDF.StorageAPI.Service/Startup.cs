﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerUI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security.Claims;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using RD.RDF.StorageAPI.Service.Extensions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Core.Helpers;
using Microsoft.Graph;
using Microsoft.Identity.Web;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Protocols;
using System.Threading;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Net.Http.Headers;
using System.IdentityModel.Tokens.Jwt;

namespace RD.RDF.StorageAPI.Service
{

    public class Startup
    {
        private string pathBase = "/";

        private string kongHostName = null;
        private bool apiKeyEnabled = false;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            if (!string.IsNullOrEmpty(Configuration["ASPNETCORE_BASE_PATH"]))
            {
                pathBase = Configuration["ASPNETCORE_BASE_PATH"];
            }
            if (!string.IsNullOrEmpty(Configuration["KongHostName"]))
            {
                kongHostName = Configuration["KongHostName"];
                apiKeyEnabled = true;
            }
            FullVersionName = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion;
            ProductVersionName = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
            VersionName = Assembly.GetEntryAssembly().GetName().Version.ToString();
        }

        public IConfiguration Configuration { get; }
        public static string EnvironmentName { get; internal set; }
        public static string ProductVersionName { get; internal set; }
        public static string FullVersionName { get; internal set; }
        public static string VersionName { get; internal set; }

        private PingIdConfiguration identityProvider;
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            identityProvider = Configuration.GetSection("PingId").Get<PingIdConfiguration>();
            services.InitConfiguration(Configuration)
                    .InitDataAccess(Configuration)
                    .InitServices(Configuration);
                    //.ConfigureDBContext(Configuration);
            services.AddHealthChecks().AddCheck<ReadinessHealthCheck>("ReadyHC", tags: new List<string> { "Readiness" });
            ConfigureAuthentication(services);
            services.AddMemoryCache();
            services.AddControllers()
                .AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                    options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
                });

            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders = ForwardedHeaders.All;
                options.KnownNetworks.Clear();
                options.KnownProxies.Clear();
            });

            services.AddCors(options =>
            {
                options.AddPolicy("AnyOrigin", builder =>
                {
                    builder.AllowAnyOrigin()
                           .AllowAnyMethod();
                });
            });

            //Upload size limit 
            services.Configure<FormOptions>(options =>
            {
                options.ValueLengthLimit = int.MaxValue;
                options.MultipartBodyLengthLimit = long.MaxValue;
                options.MemoryBufferThreshold = int.MaxValue;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            var fwdOptions = new ForwardedHeadersOptions
            {
                ForwardedHeaders = ForwardedHeaders.All
            };
            fwdOptions.KnownNetworks.Clear();
            fwdOptions.KnownProxies.Clear();
            // This is needed if running behind a reverse proxy            
            app.UseForwardedHeaders(fwdOptions);
            if (!string.IsNullOrEmpty(pathBase) && pathBase.Length > 1)
            {
                var pbs = new Microsoft.AspNetCore.Http.PathString(pathBase);
                app.UsePathBase(pbs);
                app.Use((context, next) =>
                {
                    context.Request.PathBase = pbs;
                    return next();
                });
            }

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors("AnyOrigin");

            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swagger, httpReq) =>
                {
                    if (apiKeyEnabled)
                    {
                        swagger.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"{httpReq.Scheme}://{kongHostName}" } };
                    }
                    else
                    {
                        swagger.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"{httpReq.Scheme}://{httpReq.Host.Value}{(pathBase.Length > 1 ? pathBase : string.Empty)}" } };
                    }
                });
            });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint($"v1/swagger.json", "RD RDF Storage-API");

                c.OAuthConfigObject = new OAuthConfigObject
                {
                    AppName = "Research Data Storage API",
                    ClientId = identityProvider.ClientId,
                    ClientSecret = identityProvider.ClientSecret,
                };

                c.OAuthUsePkce();
            });


            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/health/startup", new HealthCheckOptions { Predicate = x => false });
                endpoints.MapHealthChecks("/health/live", new HealthCheckOptions { Predicate = x => false });
                endpoints.MapHealthChecks("/health/ready");
                endpoints.MapControllers();
            });
            app.ConfigureGlobalExceptionHandler(loggerFactory);
        }

        private void ConfigureAuthentication(IServiceCollection services)
        {
            IEnumerable<SecurityKey> issuerSigningKeys = null;
            var getKeysTaks = Task.Run(async () => { issuerSigningKeys = await JWKSSecurityKeysProvider.GetPingFederateJwtSigningKeyAsync(identityProvider.PingFederationHost, identityProvider.Endpoints.JwksExtEndpoint); });
            getKeysTaks.Wait();

            var azureAdTenantId = Configuration["AzureAd:TenantId"];
            var azureAdValidIssuer = $"https://sts.windows.net/{azureAdTenantId}/";

            services.AddAuthentication()
            .AddJwtBearer("PingId", options =>
            {
                //This enables the JwtBearer code to validate the JWT tokens issued by the the GSK ping federate IdP. It does this 
                //by fetching the JWKS file which holds the public certs of the IdP. This saves us a whole bunch of work!.
                options.MetadataAddress = $"{identityProvider.PingFederationHost}/{identityProvider.Endpoints.OpenIDConnectMetadataEndpoint}";

                //The list of valid audiences is an array of client_id's that are allowed to call this API. This is in fact not the
                //correct usage of validateAudience and only works because the PingFederate configuration always sets the aud claim
                //in the payload of the JWT to be the client_id.
                var tokenValidationParameterSettings = identityProvider.TokenValidation;

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    NameClaimType = ClaimTypes.NameIdentifier,
                    RequireSignedTokens = tokenValidationParameterSettings.RequireSignedTokens,
                    ValidateIssuerSigningKey = tokenValidationParameterSettings.ValidateIssuerSigningKey,
                    ValidateIssuer = tokenValidationParameterSettings.ValidateIssuer,
                    ValidIssuer = identityProvider.PingFederationHost,
                    ValidateAudience = tokenValidationParameterSettings.ValidateAudience,
                    ValidAudiences = tokenValidationParameterSettings.ValidAudiences,
                    ValidateLifetime = tokenValidationParameterSettings.ValidateLifetime,
                    ValidateActor = tokenValidationParameterSettings.ValidateActor,
                    ValidateTokenReplay = tokenValidationParameterSettings.ValidateTokenReplay,
                    IssuerSigningKeys = issuerSigningKeys,
                    ClockSkew = TimeSpan.FromSeconds(tokenValidationParameterSettings.ClockSkewSeconds)                    
                };     
                 
            })
            //.AddMicrosoftIdentityWebApi(Configuration, "AzureAd", "AzureAd");
            .AddMicrosoftIdentityWebApi(options =>
            {
                Configuration.Bind("AzureAd", options);
                options.TokenValidationParameters.NameClaimType = "preferred_username";
            },
            options => Configuration.Bind("AzureAd", options), "AzureAd");

            services.AddAuthorization(options =>
            {
                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .AddAuthenticationSchemes("PingId", "AzureAd")
                    .Build();
            });


            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "RD RDF Storage-API",
                    Description = $"RD RDF Storage-API<br /><br /> Version: {FullVersionName}"
                });
                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = @"JWT Authorization header using the Bearer scheme. Example: ""Authorization: Bearer {token}""",
                    Type = SecuritySchemeType.OAuth2,
                    Flows = new OpenApiOAuthFlows
                    {
                        AuthorizationCode = new OpenApiOAuthFlow
                        {
                            AuthorizationUrl = new Uri($"{identityProvider.PingFederationHost}/{identityProvider.Endpoints.OauthAuthorizationEndpoint}"),
                            TokenUrl = new Uri($"{identityProvider.PingFederationHost}/{identityProvider.Endpoints.OauthTokenEndpoint}"),
                            Scopes = new Dictionary<string, string>
                                            {
                                               { "openid", "Access to open id connect." }
                                            }
                        }
                    }

                });
                if (apiKeyEnabled)
                {
                    options.AddSecurityDefinition("apikey", new OpenApiSecurityScheme
                    {
                        Description = "Kong GW api key",
                        Type = SecuritySchemeType.ApiKey,
                        In = ParameterLocation.Header,
                        Name = "apikey"
                    });
                }

                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                      new OpenApiSecurityScheme
                      {
                        Reference = new OpenApiReference
                          {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                          },
                          Scheme = "oauth2",
                          Name = "Bearer",
                          In = ParameterLocation.Header,
                        },
                        new List<string>()
                      }
                    });
                if (apiKeyEnabled)
                {
                    options.AddSecurityRequirement(new OpenApiSecurityRequirement
                    {
                        {
                            new OpenApiSecurityScheme
                            {
                            Reference = new OpenApiReference
                                {
                                Type = ReferenceType.SecurityScheme,
                                Id = "apikey"
                                },
                                Scheme = "apikey",
                                Name = "apikey",
                                In = ParameterLocation.Header,
                            },
                            new List<string>()
                            }
                    });
                }
            });


        }
    }
}
