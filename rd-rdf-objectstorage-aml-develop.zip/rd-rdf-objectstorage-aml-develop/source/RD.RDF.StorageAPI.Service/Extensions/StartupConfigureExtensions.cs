﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StorageAPI.Service.ViewModel;
using System;
using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;

using RD.RDF.StoragePortal.DataAccess.Context;
using RD.RDF.StoragePortal.DataAccess.Repository;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using System.Diagnostics;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.DataAccess.Repositories;
using RD.RDF.StorageAPI.Core.Helpers;
using RD.RDF.StorageAPI.DataAccess.ClientImpl;
using RD.RDF.StorageAPI.DataAccess.Providers;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Core.Services;
using RD.RDF.StorageAPI.Service;
using RD.RDF.StorageAPI.DataAccess.AllianceData;

namespace RD.RDF.StorageAPI.Service.Extensions
{
    public static class StartupConfigureExtensions
    {
        public static IServiceCollection InitConfiguration(this IServiceCollection services, IConfiguration Configuration)
        {
            services.Configure<PingIdConfiguration>(Configuration.GetSection(PingIdConfiguration.PingId));
            services.Configure<AzureAdConfiguration>(Configuration.GetSection(AzureAdConfiguration.AzureAd));
            // Storage containers configuration
            services.Configure<StorageConfiguration>(Configuration.GetSection(StorageConfiguration.Storage));
            services.Configure<AllianceConfiguration>(Configuration.GetSection(AllianceConfiguration.Alliance));
            //register PingIdConfiguration
            services.AddSingleton(s =>
            {
                var confOptions = s.GetRequiredService<IOptions<PingIdConfiguration>>();
                var config = confOptions.Value;
                return new OAuth2Configruation
                {
                    AccessTokenUrl = new Uri($"{config.PingFederationHost}/{config.Endpoints.OauthTokenEndpoint}"),
                    ClientId = config.ClientId,
                    ClientSecret = config.ClientSecret,
                    Scope = config.Scope
                };
            });
            services.AddTransient<IOAuth2TokenProvider, OAuth2ClientCredentialsTokenProvider>();

            services.AddApplicationInsightsTelemetry();
            services.AddApplicationInsightsKubernetesEnricher();

            services.AddTransient<IEventsTracker, ApplicationInsightsTracker>();
            services.AddTransient<IMetricsTracker, ApplicationInsightsTracker>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            return services;
        }

        public static IServiceCollection InitDataAccess(this IServiceCollection services, IConfiguration Configuration)
        {
            services.AddSingleton<IContainerConfigurationProvider, AppConfigContainerConfigurationProvider>();
            services.AddTransient<ISearchProvider, AzureBlobStorageSearchProvider>();
            services.AddTransient<EmptySearchProvider>();
            services.AddTransient<ISearchProviderFactory, SearchProviderFactory>();
            services.AddTransient<IFilesRepository, FilesRepository>();
            services.AddTransient<IFoldersRepository, FoldersRepository>();
            services.AddTransient<IStorageClientFactory, StorageClientFactory>();
            services.AddTransient<IStorageClient, AzureBlobStorageClient>();
            services.AddTransient<IStorageClient, ObjectStorageS3Client>();
            services.AddTransient<IStorageClient, AdlsServiceClient>();
            services.AddSingleton<ObjectStorageS3Client.MyHttpClientFactory>();
            services.AddTransient<IStorageClient, GcpStorageClient>();
            services.AddTransient<IIndexingFactory, IndexingFactory>();
            services.AddSingleton<IIndexingFacade, FileIndexingFacade>();
            services.AddTransient<IDataStorageRepository, DataStorageRepository>();
            services.AddSingleton<IAllianceConfigurationProvider, AllianceConfigurationProvider>();
            services.AddTransient<IIndexingRespository, BlobStorageIndexingRepository>();
            services.AddSingleton<IIndexingRespository, KafkaIndexingRepository>();
            services.AddTransient<OdbcAllianceInformationProvider>();
            services.AddSingleton<IAllianceInformationProvider, CachedAllianceInformationProvider>(s =>
            {
                var provider = s.GetRequiredService<OdbcAllianceInformationProvider>();
                var memCache = s.GetRequiredService<IMemoryCache>();
                var config = s.GetRequiredService<IAllianceConfigurationProvider>();
                return new CachedAllianceInformationProvider(provider, memCache, config);
            });

            services.AddSingleton<DefaultMetadataCollectionValidationProvider>();
            services.AddSingleton<IMetadataCollectionValidationProvider, AzureBlobMetadataCollectionValidationProvider>();
            services.AddSingleton<IMetadataCollectionValidationProvider, S3MetadataCollectionValidationProvider>();
            services.AddSingleton<IMetadataCollectionValidationProviderFactory, MetadataCollectionValidationProviderFactory>();
            services.AddTransient<IOdbcFileIndexSearchService, OdbcFileIndexSearchService>();


            return services;
        }

        public static IServiceCollection InitServices(this IServiceCollection services, IConfiguration Configuration)
        {
            services.AddTransient<IMetadataParsingService, MetadataParsingService>();
            services.AddTransient<IMetadataService, MetadataService>();
            services.AddTransient<IDataStorageService, DataStorageService>();
            services.AddHostedService<VersionEnabledCheckService>();
            services.AddSingleton<IAllianceWriter, AllianceWriter>();
            services.AddSingleton<IAllianceReader, AllianceReader>();
            services.AddTransient<IIndexingService, IndexingService>();
            services.AddTransient<IStorageIndexProvider, DatabricksOdbcFileIndexProvider>();
            services.AddTransient<IAllianceSecurityService, AllianceSecurityService>();
            services.AddTransient<IStorageIndexSearchProvider, DatabricksOdbcFileIndexSearchProvider>();
            services.AddSingleton<ReindexingService>();
            services.AddSingleton<IReindexingService, ReindexingService>(s => s.GetRequiredService<ReindexingService>());
            services.AddHostedService<ReindexingService>(s => s.GetRequiredService<ReindexingService>());
            services.AddSingleton<IBackgroundTaskQueue>(ctx =>
            {
                if (!int.TryParse(Configuration["QueueCapacity"], out var queueCapacity))
                    queueCapacity = 100;
                return new BackgroundTaskQueue(queueCapacity);
            });
            services.AddTransient<IUserRepository, UserRepository>();
            return services;
        }

        public static void ConfigureGlobalExceptionHandler(this IApplicationBuilder app, ILoggerFactory loggerFactory)
        {
            var logger = loggerFactory.CreateLogger<Startup>();
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";
                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    if (contextFeature != null)
                    {
                        logger.LogCritical(contextFeature.Error, $"Global error occurred: {contextFeature.Error.Message}");
                        await context.Response.WriteAsync(JsonSerializer.Serialize(new ErrorResult()
                        {
                            Status = context.Response.StatusCode,
                            Title = "Internal Server Error occurred"
                        }));
                    }
                });
            });
        }

        public static IServiceCollection ConfigureDBContext(this IServiceCollection services, IConfiguration Configuration)
        {
            string connectionString = Configuration.GetConnectionString("PortalDB");
#if DEBUG
            if (Debugger.IsAttached)
            {
                connectionString = Configuration.GetConnectionString("LocalPortalDB");
            }
#endif

            //configure sql server
            services.AddDbContext<StoragePortalDbContext>(options =>
                options.UseSqlServer(connectionString, sqlOptions =>
                {
                    sqlOptions.CommandTimeout(60);
                })
            );
            services.AddScoped<IContainersRepository, StorageContainersRepository>();

            return services;
        }
    }
}
