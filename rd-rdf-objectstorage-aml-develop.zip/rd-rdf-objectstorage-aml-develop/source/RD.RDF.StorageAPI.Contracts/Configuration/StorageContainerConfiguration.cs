﻿using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Configuration
{

    public class StorageContainerConfiguration
    {
        public string Name { get; set; }

        public StorageContainerType Type { get; set; }

        /// <summary>
        /// name of container account
        /// </summary>
        public string ContainerAccountName { get; set; }
        /// <summary>
        /// url to account
        /// </summary>
        public string ContainerAccountUrl { get; set; }

        /// <summary>
        /// name to container (or bucket in case of OBject Storage)
        /// </summary>
        public string ContainerName { get; set; }

        /// <summary>
        /// Connection string to Azure Blob Storage container
        /// </summary>
        [JsonIgnore]
        public string ContainerConnectionString { get; set; }

        /// <summary>
        /// sas key or user secret
        /// </summary>
        [JsonIgnore]
        public string ContainerKey { get; set; }

        /// <summary>
        /// user id 
        /// </summary>
        public string ContainerUserId { get; set; }

        /// <summary>
        /// certificate file path 
        /// </summary>
        [JsonIgnore]
        public string ContainerCertFilePath { get; set; }

        /// <summary>
        /// Check if the container version is enabled or not
        /// </summary>
        public bool IsVersionEnabled { get; set; }

        /// <summary>
        /// True if connection is available
        /// </summary>
        public bool? IsConnectionAvailable { get; set; }


        /// <summary>
        /// if this is set the alliance tag name 
        /// </summary>
        public string AllianceTagName { get; set; }

        /// <summary>
        /// if this is set the users will be validated
        /// </summary>
        public bool ValidateAudience { get; set; }

        /// <summary>
        /// Users to be validated are added to this field
        /// </summary>
        public string[] ValidAudiences { get; set; }

        /// <summary>
        /// if this is set the proxy url 
        /// </summary>
        public string ProxyUrl { get; set; }
        public KafkaConfiguration IndexingConfiguration { get; set; }

    }





}
