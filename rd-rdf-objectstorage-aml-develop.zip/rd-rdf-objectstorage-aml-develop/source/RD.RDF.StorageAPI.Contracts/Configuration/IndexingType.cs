﻿namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public enum IndexingType
    {
        none = -1,
        azureblob = 0,
        kafka = 1,
    }
}
