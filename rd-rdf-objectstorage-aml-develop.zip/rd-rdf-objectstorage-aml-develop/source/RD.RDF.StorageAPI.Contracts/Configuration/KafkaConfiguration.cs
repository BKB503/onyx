﻿using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Configuration
{

    public class KafkaConfiguration
    {
        public string Topic { get; set; }

        public string Type { get; set; }

        /// <summary>
        /// Connection string to Azure Event Hub
        /// </summary>
        [JsonIgnore]
        public string EventHubConnectionString { get; set; }

        /// <summary>
        /// sas key or user secret
        /// </summary>
        [JsonIgnore]
        public string EventHubKey { get; set; }

        // namespace part of the eventhub connection string with port number
        public string KafkaServers { get; set; }

        public string SaslUsername { get; set; }

        /// <summary>
        /// connection string to databricks instace holding the index
        /// </summary>
        [JsonIgnore]
        public string IndexOdbcConnectionString { get; set; }
    }
}
