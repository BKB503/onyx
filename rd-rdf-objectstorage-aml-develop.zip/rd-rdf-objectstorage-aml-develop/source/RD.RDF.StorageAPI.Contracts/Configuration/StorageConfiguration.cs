﻿using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public class StorageConfiguration
    {
        public const string Storage = "Storage";

        /// <summary>
        /// a default container from the list.
        /// If not set - the first will be used
        /// </summary>
        public string DefaultContainer { get; set; }

        /// <summary>
        /// A list of containers available
        /// </summary>
        public List<StorageContainerConfiguration> Containers { get; set; }

        /// <summary>
        /// Kafka topic available
        /// </summary>
        public List<KafkaConfiguration> Indexing { get; set; }

        /// <summary>
        /// caching time in seconds by default 60s
        /// </summary>
        public int CacheTimeSeconds { get; set; } = 60;

    }
}
