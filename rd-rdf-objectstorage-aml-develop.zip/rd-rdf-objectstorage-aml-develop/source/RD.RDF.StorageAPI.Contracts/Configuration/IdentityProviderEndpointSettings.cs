﻿namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public class IdentityProviderEndpointSettings
    {
        public string OpenIDConnectMetadataEndpoint { get; set; } = ".well-known/openid-configuration";
        public string OauthTokenEndpoint { get; set; } = "as/token.oauth2";
        public string OauthTokenRevocationEndpoint { get; set; } = "as/revoke_token.oauth2";
        public string OauthAuthorizationEndpoint { get; set; } = "as/authorization.oauth2";
        public string OauthGrantsEndpoint { get; set; } = "as/oauth_access_grants.ping";
        public string OauthTokenIntrospectionEndpoint { get; set; } = "as/introspect.oauth2";
        public string JwksEndpoint { get; set; } = "pf/JWKS";
        public string JwksExtEndpoint { get; set; } = "ext/oauth/jwks";
    }
}
