﻿using System;

namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public class OAuth2Configruation
    {
        public Uri AccessTokenUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string Scope { get; set; }
    }

}
