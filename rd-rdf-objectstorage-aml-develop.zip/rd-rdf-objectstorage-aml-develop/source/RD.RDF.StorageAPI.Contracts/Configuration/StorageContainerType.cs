﻿namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public enum StorageContainerType
    {
        none = -1,
        objectstorage = 0,
        azureblob = 1,
        azureadls = 2,
        googleblob = 3
    }
}
