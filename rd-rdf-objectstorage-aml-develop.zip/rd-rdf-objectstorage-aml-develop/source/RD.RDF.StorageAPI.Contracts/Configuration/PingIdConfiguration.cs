﻿namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public class PingIdConfiguration
    {
        public const string PingId = "PingId";

        /// <summary>
        /// ping federation host
        /// </summary>
        public string PingFederationHost { get; set; }

        /// <summary>
        /// client id
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// client secret
        /// </summary>
        public string ClientSecret { get; set; }

        /// <summary>
        /// client Scope 
        /// </summary>
        public string Scope { get; set; }

        /// <summary>
        /// endpoints url
        /// </summary>
        public IdentityProviderEndpointSettings Endpoints { get; set; } = new IdentityProviderEndpointSettings();

        /// <summary>
        /// token validation configuration
        /// </summary>
        public TokenValidationParameterSettings TokenValidation { get; set; } = new TokenValidationParameterSettings();
    }

}
