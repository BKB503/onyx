﻿namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public class AllianceConfiguration
    {
        public const string Alliance = "AllianceClient";

        /// <summary>
        /// client id
        /// </summary>
        public string ClientID { get; set; }

        /// <summary>
        /// client secret
        /// </summary>
        public string ClientSecret { get; set; }

        /// <summary>
        /// ping federation host
        /// </summary>
        public string PingFedartationUrl { get; set; }

        /// <summary>
        /// scope
        /// </summary>
        public string Scope { get; set; }
        /// <summary>
        /// Base address to fetch the alliance agreement api
        /// </summary>
        public string BaseAddress { get; set; }

        /// <summary>
        /// Alliance Agreement api URL including version
        /// </summary>
        public string APIUrl { get; set; }

        public KafkaConfiguration AllainceKafkaTopic { get; set; }

        public string FilePathRefreshRun { get; set; }

        /// <summary>
        /// Cache Time Seconds
        /// </summary>
        public int CacheTimeSeconds { get; set; }
    }
}
