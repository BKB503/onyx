﻿namespace RD.RDF.StorageAPI.Contracts.Configuration
{
    public class TokenValidationParameterSettings
    {
        public bool RequireSignedTokens { get; set; } = true;
        public bool ValidateIssuerSigningKey { get; set; } = true;
        public bool ValidateIssuer { get; set; } = true;
        public bool ValidateAudience { get; set; } = true;
        public string[] ValidAudiences { get; set; }
        public bool ValidateLifetime { get; set; } = true;
        public double ClockSkewSeconds { get; set; } = 0;
        public bool ValidateActor { get; set; } = true;
        public bool ValidateTokenReplay { get; set; } = true;
    }
}
