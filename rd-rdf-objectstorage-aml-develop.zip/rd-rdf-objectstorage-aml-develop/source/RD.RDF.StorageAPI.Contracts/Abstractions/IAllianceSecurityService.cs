﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IAllianceSecurityService
    {
        Task<AllianceAccessVerificationResult> CheckUserAccessAsync(string containerName, string userMudId, FileIndexModel fileIndexModel, CancellationToken token);
        Task<ContainerContents> FilterContainerContentsAsync(ContainerContents containerContents, string userMudId, CancellationToken cancellationToken);
    }
}
