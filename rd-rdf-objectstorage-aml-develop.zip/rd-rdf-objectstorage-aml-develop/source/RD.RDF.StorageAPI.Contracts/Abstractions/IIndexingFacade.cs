﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IIndexingFacade
    {
        Task IndexTheFileAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token);
        Task<FileResource> UpdateIndexedFileAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token);
    }
}
