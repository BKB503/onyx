﻿using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IIndexingRespository
    {
        IndexingType indexingType { get; }
        Task WriteFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token = default);
        Task<FileResource> UpdateFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token = default);
    }
}
