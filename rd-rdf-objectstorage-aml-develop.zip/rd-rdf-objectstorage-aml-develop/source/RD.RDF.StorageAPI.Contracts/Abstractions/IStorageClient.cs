﻿using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IStorageClient
    {
        StorageContainerType StorageClientType { get; }

        Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token);
        Task<PagedApiResponse<FolderResource>> GetFullFolderInformationAsync(ContainerResource container, string folderName, PaginationFilter filter, CancellationToken token);
        Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token);
        Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token);

        Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folder, Stream fileData, MetadataCollections dictionary, CancellationToken token);
        Task<bool> GetContainerClientPropertiesAsync(ContainerResource container);
        Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token);
        Task<bool> UpdateTagsAsync(ContainerResource container, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken);

        Task<UploadPartsInitResult> UploadPartsInitAsync(ContainerResource container, string fileName, string folder, CancellationToken cancellationToken);

        Task<UploadPartResult> UploadPartFileAsync(ContainerResource container, UploadPartFileModel fileModel, CancellationToken cancellationToken);

        Task<UploadPartCommitResult> UploadPartsCommitAsync(ContainerResource container, string uploadSessionId, string fileName, string folder, UploadPartCommitCollection parts, MetadataCollections metadata, CancellationToken cancellationToken);



    }

}