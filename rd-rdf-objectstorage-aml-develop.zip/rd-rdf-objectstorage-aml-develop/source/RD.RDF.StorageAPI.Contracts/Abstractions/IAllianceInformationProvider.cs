﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IAllianceInformationProvider
    {
        Task<List<AllianceModel>> GetAllAllianceSecurity(ContainerResource container, CancellationToken cancellationToken);

        Task<AllianceModel> GetAllianceSecurityOfUserAsync(ContainerResource container, string userName, string allianceAgreement, CancellationToken cancellationToken);

        Task<AllianceModel> GetOneAllianceAgreementDetails(ContainerResource container, string allianceAgreement, CancellationToken cancellationToken);
    }
}
