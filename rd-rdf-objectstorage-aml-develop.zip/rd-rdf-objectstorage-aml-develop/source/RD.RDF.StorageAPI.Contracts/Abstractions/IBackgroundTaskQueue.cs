﻿using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IBackgroundTaskQueue
    {
        ValueTask<ReindexingStatusModel> QueueBackgroundWorkItemAsync(Func<string, CancellationToken, ValueTask> workItem);

        ValueTask<ReindexingTaskModel> DequeueAsync(CancellationToken cancellationToken);

        ValueTask<ReindexingStatusModel> GetTaskStatusAsync(string taskId, CancellationToken cancellationToken);

        ValueTask SetTaskStatusAsync(string taskId, ReindexingStatusModel model, CancellationToken cancellationToken);

    }
}
