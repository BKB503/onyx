﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.IO;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IMetadataParsingService
    {
        MetadataModel ReadTheMetadataJsonFile(Stream metadataStream);
        MemoryStream SerializeToStream(MetadataModel metadataModel);
    }
}
