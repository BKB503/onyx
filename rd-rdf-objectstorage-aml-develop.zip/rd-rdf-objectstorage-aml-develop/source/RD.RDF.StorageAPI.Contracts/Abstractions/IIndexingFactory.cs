﻿using RD.RDF.StorageAPI.Contracts.Configuration;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IIndexingFactory
    {
        Dictionary<IndexingType, IIndexingRespository> GetAllIndexingRepositories();
    }
}
