﻿using RD.RDF.StorageAPI.Contracts.Model;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IEventsTracker
    {
        void Track(DiagnosticEvent customEvent);
    }
}
