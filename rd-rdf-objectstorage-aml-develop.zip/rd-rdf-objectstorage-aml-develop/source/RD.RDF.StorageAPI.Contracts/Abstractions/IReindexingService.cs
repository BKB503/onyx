﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IReindexingService
    {
        Task<ReindexingStatusModel> StartReindexingProcessAsync(string containerName, bool useFileVersionsAsGuids, CancellationToken cancellationToken);

        Task<ReindexingStatusModel> GetReindexingStatusAsync(string taskKey, CancellationToken cancellationToken);
        Task ReindexOneFileAsync(string containerName, bool useFileVersionsAsGuids, FileResource file, CancellationToken token);
    }
}
