﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IContainerConfigurationProvider
    {
        Task<IList<ContainerResource>> GetAllContainersAdminAsync(CancellationToken token = default);

        Task<IList<ContainerResource>> GetAllContainersAsync(CancellationToken token = default);

        Task<ContainerResource> GetContainerByNameAsync(string containerName, CancellationToken token = default);

        Task<ContainerResource> GetContainerByNameAdminAsync(string containerName, CancellationToken token = default);
    }


}
