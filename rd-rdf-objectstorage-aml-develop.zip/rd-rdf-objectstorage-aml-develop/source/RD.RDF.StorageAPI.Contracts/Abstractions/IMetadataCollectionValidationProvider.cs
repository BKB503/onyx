﻿using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IMetadataCollectionValidationProvider
    {
        StorageContainerType StorageClientType { get; }

        Dictionary<string, string> GetMetadataFromInputCollection(MetadataCollections metadataCollection);

        Dictionary<string, string> GetIndexingTagsFromInputCollection(MetadataCollections metadataCollection);

        string GetValidKeyName(string key);

        string GetValidKeyValue(string value);

        string GetValidIndexTagName(string key);

        string GetValidIndexTagValue(string value);

    }
}
