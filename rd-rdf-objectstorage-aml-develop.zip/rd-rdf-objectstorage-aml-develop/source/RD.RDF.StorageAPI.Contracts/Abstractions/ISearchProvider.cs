﻿using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface ISearchProvider
    {
        StorageContainerType StorageClientType { get; }

        Task<SearchFilesByTagResults> SearchFilesByTagsAsync(ContainerResource container, string tagSearchQuery, CancellationToken token);
    }


}
