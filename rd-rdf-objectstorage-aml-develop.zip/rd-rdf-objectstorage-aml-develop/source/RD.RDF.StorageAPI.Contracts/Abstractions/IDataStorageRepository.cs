﻿using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IDataStorageRepository
    {
        Task<Stream> GetFileStreamAsync(ContainerResource container, FileResource fileInfo, CancellationToken cancellationToken);
        Task<UploadFileResult> UploadFileToFolderAsync(ContainerResource container, string fileName, string folder, Stream fileData, MetadataCollections dictionary, CancellationToken cancellationToken);

        /// <summary>
        /// Method for upload file in parts initialization of session
        /// </summary>
        /// <param name="container">Container name</param>
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>    
        /// <param name="folder">Optional Sub Folder name</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<UploadPartsInitResult> UploadPartsInitAsync(ContainerResource container,
                                                         string fileName,
                                                         string folder,
                                                         CancellationToken cancellationToken);


        /// <summary>
        /// Action for upload file in part 
        /// </summary> 
        /// <param name="container">Container name</param> 
        /// <param name="uploadSessionId">upload Session id</param>
        /// <param name="filePartStream">Stream that contains the data</param>
        /// <param name="filePartStreamLenght">Lenght of part in bytes</param>
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>     
        /// <param name="folder">Optional Sub folder name</param>
        /// <param name="filePartNumber">File part number</param>
        /// <param name="filePartSize">Maximum file part size - last part in upload session might have less bytes. The parameter has to be constant in the whole upload session</param>
        /// <param name="fileTotalSize">File total bytes</param>
        /// <param name="uploadPart">File part model stream</param>
        /// <param name="cancellationToken"></param>
        Task<UploadPartResult> UploadPartFileAsync(ContainerResource container, 
                                                   UploadPartFileModel fileModel,
                                                   CancellationToken cancellationToken);

        /// <summary>
        /// Action for commiting upload file in parts
        /// </summary> 
        /// <param name="container">Container name</param>        
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>      
        /// <param name="uploadRequest">Upload commit request object</param>
        /// <param name="folder">Optional Sub folder name</param>       
        /// <param name="cancellationToken"></param>
        Task<UploadPartCommitResult> UploadPartsCommitAsync(ContainerResource container,
                                                            string uploadSessionId,
                                                            string fileName,
                                                            string folder,
                                                            UploadPartCommitCollection parts,
                                                            MetadataCollections metadata,
                                                            CancellationToken cancellationToken);
        
    }
}