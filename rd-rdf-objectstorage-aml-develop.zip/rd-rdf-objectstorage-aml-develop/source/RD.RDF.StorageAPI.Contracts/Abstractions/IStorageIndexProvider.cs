﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IStorageIndexProvider
    {
        Task<FileIndexModel> GetFileByGuidAsync(ContainerResource container, string fileGuid, CancellationToken cancellationToken);
        Task<List<FileIndexModel>> GetFolderIndexAsync(ContainerResource container, string folderName, CancellationToken cancellationToken);
    }

}
