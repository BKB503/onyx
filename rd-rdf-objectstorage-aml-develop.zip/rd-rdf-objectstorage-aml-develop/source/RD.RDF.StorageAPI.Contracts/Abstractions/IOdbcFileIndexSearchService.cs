﻿using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IOdbcFileIndexSearchService
    {
        Task<PagedOffsetApiResponse<List<FileIndexModel>>> GetIndexSearchResultAsync(string containerName, string metaDataKey, string metaDataValue, string folderName, OffsetPagPaginationFilter filter, CancellationToken cancellationToken);
        Task<PagedOffsetApiResponse<List<FileIndexModel>>> GetIndexSearchByFolderNameAsync(string container, string folder, string metaDataKey, string metaDataValue, OffsetPagPaginationFilter filter, CancellationToken cancellationToken);
    }
}
