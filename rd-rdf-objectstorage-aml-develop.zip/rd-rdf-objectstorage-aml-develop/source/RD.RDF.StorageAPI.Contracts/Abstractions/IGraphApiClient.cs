﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IGraphApiClient
    {
        Task<AzureGraphUserData> GetUserDataByEmailAsync(string userEmail, CancellationToken cancellationToken);
        Task<AzureGraphUserData> GetUserDataByMudIdAsync(string mudId, CancellationToken cancellationToken);
    }

}