﻿using RD.RDF.StorageAPI.Contracts.Configuration;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IMetadataCollectionValidationProviderFactory
    {
        IMetadataCollectionValidationProvider GetProvider(StorageContainerType storageClientType);

    }
}
