﻿using RD.RDF.StorageAPI.Contracts.Configuration;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IOAuth2TokenProvider
    {
        Task<OAuth2Token> GetTokenAsync(CancellationToken cancellationToken);

        Task<OAuth2Token> GetTokenAsync(OAuth2Configruation configuration, CancellationToken cancellationToken);
    }
}
