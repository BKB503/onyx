﻿using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IDataStorageService
    {
        Task<Stream> GetFileStreamAsync(string containerName, FileResource fileInfo, CancellationToken token);

        Task<FileIndexModel> DownloadFileIndexModelAsync(string containerName, FileResource fileInfo, CancellationToken token);

        Task<UploadFileResult> UploadFileWithMetadataAsync(string containerName, string fileName, string folder, Stream fileData, MetadataCollections keyValues, CancellationToken token);

        /// <summary>
        /// Method for upload file in parts initialization of session
        /// </summary>
        /// <param name="container">Container name</param>
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>    
        /// <param name="folder">Optional Sub Folder name</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task<UploadPartsInitResult> UploadPartsInitAsync(string container,
                                                         string fileName,
                                                         string folder,
                                                         CancellationToken cancellationToken);


        /// <summary>
        /// Action for upload file in part 
        /// </summary> 
        /// <param name="container">Container name</param> 
        /// <param name="uploadSessionId">upload Session id</param>
        /// <param name="filePartStream">Stream that contains the data</param>
        /// <param name="filePartStreamLenght">Lenght of part in bytes</param>
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>     
        /// <param name="folder">Optional Sub folder name</param>
        /// <param name="filePartNumber">File part number</param>
        /// <param name="filePartSize">Maximum file part size - last part in upload session might have less bytes. The parameter has to be constant in the whole upload session</param>
        /// <param name="fileTotalSize">File total bytes</param>
        /// <param name="uploadPart">File part model stream</param>
        /// <param name="cancellationToken"></param>
        Task<UploadPartResult> UploadPartFileAsync(UploadPartFileModel fileModel,
                                                   CancellationToken cancellationToken);

        /// <summary>
        /// Action for commiting upload file in parts
        /// </summary> 
        /// <param name="container">Container name</param>        
        /// <param name="fileName">File name with no folder location. Use <paramref name="folder"/> to specify location of the file </param>      
        /// <param name="uploadRequest">Upload commit request object</param>
        /// <param name="folder">Optional Sub folder name</param>       
        /// <param name="cancellationToken"></param>
        Task<UploadPartCommitResult> UploadPartsCommitAsync(string container,
                                                            string uploadSessionId,
                                                            string fileName,
                                                            string folder,
                                                            UploadPartCommitCollection parts,
                                                            MetadataCollections metadata,
                                                            CancellationToken cancellationToken);
        /// <summary>
        /// Upload file with metadata to storage
        /// </summary>
        /// <param name="container">container name</param>
        /// <param name="folder">folder name</param>
        /// <param name="fileName">file name</param>
        /// <param name="fileSize">file size</param>
        /// <param name="fileStream">file stream</param>
        /// <param name="metadataModel">medatada model</param>
        /// <param name="cancellationToken">cancellation token</param>
        /// 
        /// <returns></returns>
        Task<UploadFileResult> UploadFileToStorageAsync(string container, string folder, string fileName, long fileSize, Stream fileStream, MetadataCollections metadataModel, CancellationToken cancellationToken);
    }
}
