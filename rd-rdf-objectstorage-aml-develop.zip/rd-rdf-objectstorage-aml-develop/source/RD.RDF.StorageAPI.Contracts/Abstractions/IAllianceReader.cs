﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IAllianceReader
    {
        Task<IEnumerable<AgreementPacket>> ReadAllianceInformationAsync(CancellationToken token);
    }
}
