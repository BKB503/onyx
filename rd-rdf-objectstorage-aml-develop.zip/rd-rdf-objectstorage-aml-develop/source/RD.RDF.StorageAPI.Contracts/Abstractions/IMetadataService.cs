﻿using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IMetadataService
    {
        Task<PagedApiResponse<IList<string>>> GetAllContainersAsync(PaginationFilter filter, CancellationToken token);

        Task<ContainerResource> GetContainerByNameAsync(string containerName, CancellationToken token);

        Task<ContainerContents> GetContainerContentsAsync(string containerName, string parentFolder, PaginationFilter filter, CancellationToken token);

        Task<SearchFilesByTagResults> SearchFilesByTagsAsync(string containerName, string tagSearchQuery, CancellationToken token);

        Task<FileResource> GetFileByNameAndVersionAsync(string containerName, string fileName, string folderName, string fileGuid, CancellationToken token);

        string GetVersionIdFromIndexModel(FileIndexModel fileIndexModel, string fileGuid);
        FileResource GetFileResourceFromIndexModel(FileIndexModel fileIndexModel, string fileGuid);

        Task UpdateTagsAsync(string containerName, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken);

        /// <summary>
        /// Filters out system folders from result set -  .index and .metadata
        /// </summary>
        /// <param name="inputData"></param>
        /// <returns></returns>
        ContainerContents FilterSystemData(ContainerContents inputData);
    }

}
