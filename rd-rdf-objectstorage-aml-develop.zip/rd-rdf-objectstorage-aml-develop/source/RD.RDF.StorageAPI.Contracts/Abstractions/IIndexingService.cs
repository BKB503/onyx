﻿using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IIndexingService
    {
        Task<FileIndexModel> WriteFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, string container, CancellationToken token);

        Task<FileResource> UpdateFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, string containerName, CancellationToken token);
    }
}
