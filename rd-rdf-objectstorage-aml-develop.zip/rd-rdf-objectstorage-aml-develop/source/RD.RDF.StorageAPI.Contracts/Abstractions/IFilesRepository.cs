﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Abstractions
{
    public interface IFilesRepository
    {
        Task<FileResource> GetFileByNameAndVersionAsync(ContainerResource container, string fileName, string folderName, string fileGuid, CancellationToken token);

        Task UpdateTagsAsync(ContainerResource container, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken);

    }
}
