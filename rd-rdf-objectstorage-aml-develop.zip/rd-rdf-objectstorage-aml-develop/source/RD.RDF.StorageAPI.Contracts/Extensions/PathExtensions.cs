﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Extensions
{
    public static class PathExtensions
    {

        /// <summary>
        /// replaces backslash from path \ and changes it to  slash /
        /// </summary>
        /// <param name="inputPath"></param>
        /// <returns></returns>
        public static string ReplaceWindowsSeparator(string inputPath)
        {
            if (inputPath == null)
            {
                return null;
            }
            return inputPath.Replace('\\', '/');
        }


        /// <summary>
        /// combines path elements (folder with file name) for blob storage 
        ///  using   / slash separator
        /// </summary>
        /// <param name="pathParts"></param>
        /// <returns></returns>
        public static string CombineBlobPath(params string[] pathParts)
        {
            if (pathParts == null)
            {
                return null;
            }
            StringBuilder pathBuilder = new StringBuilder();
            foreach (var part in pathParts)
            {
                if (pathBuilder.Length > 0 && pathBuilder[pathBuilder.Length - 1] != '/')
                {
                    pathBuilder.Append('/');
                }
                pathBuilder.Append(ReplaceWindowsSeparator(part));
            }
            return pathBuilder.ToString();
        }
    }
}
