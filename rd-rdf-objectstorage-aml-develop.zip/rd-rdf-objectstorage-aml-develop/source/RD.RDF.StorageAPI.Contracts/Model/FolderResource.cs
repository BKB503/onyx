﻿using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class FolderResource
    {
        public FolderResource(string folderName) : this(folderName, false)
        {
            SubFolders = new List<FolderResource>();
            Files = new List<FileResource>();
        }

        private FolderResource(string folderName, bool _)
        {
            FolderName = folderName != null && folderName.EndsWith('/') ? folderName.Substring(0, folderName.Length - 1) : folderName;
        }

        public string FolderName { get; set; }

        public int? FilesCount
        {
            get { return Files?.Count; }
        }

        public int? SubFoldersCount
        {
            get { return SubFolders?.Count; }
        }

        public List<FileResource> Files { get; set; }

        public List<FolderResource> SubFolders { get; set; }

        public static FolderResource CreateEmptyFolder(string folderName)
        {
            return new FolderResource(folderName, true);
        }
    }

}
