﻿using Microsoft.Graph;
using System;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class AgreementPacket
    {

        public int? AgreementContractId { get; set; }
        public Agreement Agreement { get; set; }
        public List<int> Projects { get; set; }
        public List<string> TeamMembers { get; set; }
        public List<string> Approvers { get; set; }
        //public List<string> AgreementParties { get; set; }
        public List<Contacts> Contacts { get; set; }
        public ExperimentRestriction ExperimentRestriction { get; set; }
        public PhysicalCompoundRestriction PhysicalCompoundRestriction { get; set; }
        public bool MultipleRestrictionsFlag { get; set; }
        public string MultipleRestrictonInstructions { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime ModificationDate { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int Version { get; set; }
        public string Status { get; set; }
        public bool IsActive { get; set; }
        public string SecurityGroupName { get; set; }
        public string AgreementType { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Abbreviation { get; set; }
        public string ShortName { get; set; }
        public string LongName { get; set; }

        /// <summary>
        /// a team member extended collection wiht mudid and emails
        /// </summary>
        public List<AgreementPacketTeamMember> TeamMembersExtended { get; set; } = new List<AgreementPacketTeamMember>();
    }
}
