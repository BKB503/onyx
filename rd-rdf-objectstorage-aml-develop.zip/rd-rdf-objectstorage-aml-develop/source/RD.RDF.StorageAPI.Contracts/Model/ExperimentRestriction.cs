﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class ExperimentRestriction
    {
        public string Id { get; set; }
        public string Restriction { get; set; }
        public int Code { get; set; }
        public bool ElnbFlag { get; set; }
        public bool ElnbDataFlag { get; set; }
    }
}
