﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class ReindexingTaskModel
    {
        public string TaskId { get; set; }

        public Func<string, CancellationToken, ValueTask> Task { get; set; }

    }
}
