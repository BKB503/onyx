﻿using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Model.Filters
{
    public class PaginationFilter : BasePaginationFilter
    { 
        /// <summary>
        /// a token to start with 
        /// </summary>
        [JsonPropertyName("continuationToken")]
        public string ContinuationToken { get; set; }
         
        public PaginationFilter(string continuationToken, int limit) : base(limit)
        {
            ContinuationToken = continuationToken;            
        }
        public PaginationFilter() : base() 
        {
        }
    }
}
