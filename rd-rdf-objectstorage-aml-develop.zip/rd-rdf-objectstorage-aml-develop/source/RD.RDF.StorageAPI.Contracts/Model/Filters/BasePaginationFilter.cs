﻿using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Model.Filters
{
    public abstract class BasePaginationFilter
    {
        public const int MinLimit = 1;
        public const int MaxLimit = 1000;

        /// <summary>
        /// limit of objects read from underlying Storage solution = up to 1000 
        /// </summary>
        [JsonPropertyName("limit")]
        public int Limit { get; set; }

        public BasePaginationFilter()
        {
            Limit = MaxLimit;
        }

        public BasePaginationFilter(int limit)
        {
            this.Limit = limit < MinLimit || limit > MaxLimit ? MaxLimit : limit;
        }
    }
}
