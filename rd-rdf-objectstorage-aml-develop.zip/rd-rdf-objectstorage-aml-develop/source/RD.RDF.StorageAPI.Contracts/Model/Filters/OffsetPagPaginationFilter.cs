﻿using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Model.Filters
{
    public class OffsetPagPaginationFilter : BasePaginationFilter
    {
        public const long MinOffset = 0;

        /// <summary>
        /// Pagging offset
        /// </summary>
        [JsonPropertyName("offset")]
        public long Offset { get; set; }

        public OffsetPagPaginationFilter() : base()
        {
            this.Offset = MinOffset;
        }

        public OffsetPagPaginationFilter(long offset, int limit) : base(limit)
        {
            this.Offset = offset < MinOffset ? MinOffset : offset;
        }
    }
}
