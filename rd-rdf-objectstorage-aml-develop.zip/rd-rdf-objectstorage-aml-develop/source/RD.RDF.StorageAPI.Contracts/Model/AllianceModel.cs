﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class AllianceModel
    {
        public int AgreementContractId { get; set; }
        public string Name { get; set; }

        public string LongName { get; set; }
        public int Code { get; set; }

        public bool IsActive { get; set; }

        public bool IsRestricted { get; set; }

        public DateTimeOffset CreationDate { get; set; }

        public DateTimeOffset ModificationDate { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }

        public DateTimeOffset EndDate { get; set; }

        public string TeamMember { get; set; }
    }

}
