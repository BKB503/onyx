﻿using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class SearchFilesByMetaDataResults
    {
        public SearchFilesByMetaDataResults(IList<FileResource> results = default, string message = default)
        {
            Results = results;
            Message = message;
            Success = results != null;
        }

        public IList<FileResource> Results { get; }

        public bool Success { get; }

        public string Message { get; }
    }
}
