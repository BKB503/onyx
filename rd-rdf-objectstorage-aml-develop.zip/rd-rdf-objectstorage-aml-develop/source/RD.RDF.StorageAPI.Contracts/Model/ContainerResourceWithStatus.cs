﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class ContainerResourceWithStatus
    {
        public ContainerResourceWithStatus(ContainerResource container, UploadFileResultStatus status, string message)
        {
            Container = container;
            Status = status;
            Message = message;
        }

        public ContainerResource Container { get; set; }

        public UploadFileResultStatus Status { get; set; }

        public string Message { get; set; }

    }
}
