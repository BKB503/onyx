﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class Agreement
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Abbreviation { get; set; }
        public string ShortName { get; set; }
        public string LongName { get; set; }
    }
}
