﻿using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class MetadataModel
    {
        public MetadataModel()
        {

        }

        public MetadataModel(MetadataCollections metadataCollections)
        {
            MetaDataDictionary = new MetadataDictionary(metadataCollections);
        }


        /// <summary>
        /// set the MetaData dictionary
        /// </summary>
        [JsonPropertyName("metaData")]
        public MetadataDictionary MetaDataDictionary
        {
            get;
            set;
        }

    }
}
