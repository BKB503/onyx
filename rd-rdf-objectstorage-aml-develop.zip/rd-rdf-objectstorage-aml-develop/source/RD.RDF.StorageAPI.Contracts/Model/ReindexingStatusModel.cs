﻿using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class ReindexingStatusModel
    {
        public string TaskKey { get; set; }

        public ReindexingStatusEnum Status { get; set; }

        public string Message { get; set; }

        /// <summary>
        /// progress in percentage - from 0 - 100 in value
        /// </summary>
        public decimal Progress { get; set; }

        /// <summary>
        /// Containers list 
        /// </summary>
        public string ContainerName { get; set; }

        public static ReindexingStatusModel CreateEmpty(string taskKey) =>
            new ReindexingStatusModel { TaskKey = taskKey, Status = ReindexingStatusEnum.NotExists, Message = $"Provided {taskKey} does not exists" };
    }
}
