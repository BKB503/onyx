﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class FileIndexModel
    {
        public string FileName { get; set; }
        public string FolderName { get; set; }
        public string FilePath { get; set; }
        public string Container { get; set; }
        public string FileBlobType { get; set; }
        public string FileContentType { get; set; }

        [Required(ErrorMessage = "FileVersionId cannot be null or empty")]
        public string FileVersionId { get; set; }
        [Required(ErrorMessage = "FileGuid cannot be null or empty")]
        public string FileGuid { get; set; }
        [Required(ErrorMessage = "FileHash cannot be null or empty")]

        public string FileETag { get; set; }

        public string FileHash { get; set; }
        public long? FileSize { get; set; }
        [Required(ErrorMessage = "CreationTime cannot be null or empty")]
        public DateTimeOffset? CreationTime { get; set; }
        public DateTimeOffset? ModificationDate { get; set; }

        public List<MetadataKeyValue> Metadata { get; set; } = new List<MetadataKeyValue>();
        public List<Versions> Versions { get; set; } = new List<Versions>();
    }
}
