﻿using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class DiagnosticEvent
    {
        public DiagnosticEvent(ApiDiagnosticEvents eventType)
        {
            EventName = eventType.ToString();
        }
        public string EventName { get; }

        public Dictionary<string, string> Properties { get; set; } = new Dictionary<string, string>();

        public List<DiagnosticMetric> Metrics { get; set; } = new List<DiagnosticMetric>();
    }
}
