﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class PhysicalCompoundRestriction
    {
        public string Id { get; set; }
        public string Restriction { get; set; }
        public int Code { get; set; }

        public string RestrictionTag { get; set; }
    }
}
