﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    /// <summary>
    /// Full list of custom Event Types
    ///  
    /// </summary>
    public enum ApiDiagnosticEvents
    {
        UploadFile,
        DownloadFile,
        GetContainers,
        GetContainerByName,
        SearchByTag,
        UploadFilePart
    }
}
