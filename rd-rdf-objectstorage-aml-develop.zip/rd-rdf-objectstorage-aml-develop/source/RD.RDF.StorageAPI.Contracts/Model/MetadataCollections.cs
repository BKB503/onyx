﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class MetadataCollections
    {
        //[JsonPropertyName("MetaData")]
        public List<MetadataItem> Items { get; set; } = new List<MetadataItem>();
        public MetadataCollections()
        {

        }

        public MetadataCollections(MetadataDictionary inputDict)
        {
            if (inputDict != null)
            {
                foreach (var item in inputDict)
                {
                    Items.Add(new MetadataItem
                    {
                        Key = item.Key,
                        Value = item.Value,
                        IsIndexed = true
                    });
                }
            }
        }
    }

}

