﻿using System;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class MetadataDictionary : Dictionary<string, string>
    {
        private List<MetadataKeyValue> metadata;

        public MetadataDictionary()
        {

        }

        public MetadataDictionary(IDictionary<string, string> inputDict, bool unescapeCharacters = false)
        {
            if (inputDict != null)
            {
                foreach (var item in inputDict)
                {
                    this[item.Key] = unescapeCharacters ? Uri.UnescapeDataString(item.Value) : item.Value;
                }
            }
        }

        public MetadataDictionary(MetadataCollections inputDict)
        {
            if (inputDict != null)
            {
                foreach (var item in inputDict.Items)
                {
                    this[item.Key] = item.Value;
                }
            }
        }

        public MetadataDictionary(List<MetadataKeyValue> metadata)
        {
            foreach (var item in metadata)
            {
                this[item.Key] = item.Value;
            }
        }
    }
}
