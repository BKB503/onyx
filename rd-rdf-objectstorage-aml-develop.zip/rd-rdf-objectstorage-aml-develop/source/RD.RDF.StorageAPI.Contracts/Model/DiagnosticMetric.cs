﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class DiagnosticMetric
    {
        public DiagnosticMetric(ApiDiagnosticMetrics metric, double value)
        {
            MetricName = metric.ToString();
            Value = value;
        }

        public string MetricName { get; }
        public double Value { get; }
    }
}
