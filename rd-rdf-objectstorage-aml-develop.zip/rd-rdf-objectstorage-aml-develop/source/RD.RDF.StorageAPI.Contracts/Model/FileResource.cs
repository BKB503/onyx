﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json.Serialization;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class FileResource
    {
        public FileResource()
        {

        }

        public FileResource(string fileName)
        {
            FileName = Path.GetFileName(fileName);
            FilePath = fileName;
        }

        public FileResource(string fileName, string folderName) : this(fileName)
        {
            FolderName = folderName != null && folderName.EndsWith('/') ? folderName.Substring(0, folderName.Length - 1) : folderName;
        }

        /// <summary>
        /// file name without a path
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? CreationTime { get; set; }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? ModifiedTime { get; set; }

        /// <summary>
        /// file size
        /// </summary>
        public long? FileSize { get; set; }

        /// <summary>
        /// Full path in storage
        /// </summary>
        public string FilePath { get; set; }

        /// <summary>
        /// File GUID
        /// </summary>
        public string FileGuid { get; set; }

        /// <summary>
        /// File Version Id
        /// </summary>
        public string FileVersionId { get; set; }

        /// <summary>
        /// Folder Name
        /// </summary>
        public string FolderName { get; set; }

        /// <summary>
        /// File GUID
        /// </summary>
        public List<VersionDetails> FileVersions { get; set; }

        /// <summary>
        /// file e-tag
        /// </summary>
        public string FileETag { get; set; }

        /// <summary>
        /// file content hash
        /// </summary>
        public string FileContentHash { get; set; }


        /// <summary>
        /// mime content type
        /// </summary>
        public string FileContentType { get; set; }

        /// <summary>
        /// Storage blob type
        /// </summary>
        public string FileBlobType { get; set; }

        /// <summary>
        /// Creating the index file path for the usage
        /// </summary>
        [JsonIgnore]
        public string IndexFilePath
        {
            get
            {
                string indexFilePath = ".index";
                if (!string.IsNullOrEmpty(FolderName))
                {
                    indexFilePath += "/" + FolderName + "/" + FileName + ".json";
                }
                else
                {
                    indexFilePath += "/" + FileName + ".json";
                }
                return indexFilePath;
            }
        }

        /// <summary>
        /// Creating the index folder name for the usage
        /// </summary>
        [JsonIgnore]
        public string IndexFolder
        {
            get
            {
                string indexedFolder = ".index";
                if (!string.IsNullOrEmpty(FolderName))
                {
                    indexedFolder += "/" + FolderName;
                }
                return indexedFolder;
            }
        }

        /// <summary>
        /// Creating the index FileName for the usage
        /// </summary>
        [JsonIgnore]
        public string IndexFileName
        {
            get
            {
                return FileName + ".json";
            }
        }
        /// <summary>
        /// Metadata dictionary
        /// </summary>
        public MetadataDictionary Metadata { get; set; } = new MetadataDictionary();

        /// <summary>
        /// the file is available for the reader to fetch
        /// </summary>
        public bool? FileAvailable { get; set; }

        /// <summary>
        /// Alliance Access Verification result
        /// </summary>
        public AllianceAccessVerificationEnum? AllianceAccessVerification { get; set; }

        /// <summary>
        /// Agreement Packet Name
        /// </summary>
        public string AgreementPacketName { get; set; }
    }
}
