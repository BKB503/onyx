﻿using System;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class Versions
    {
        public string FileName { get; set; }
        public string FolderName { get; set; }
        public string FilePath { get; set; }
        public string Container { get; set; }
        public string FileBlobType { get; set; }
        public string FileContentType { get; set; }
        public bool? IsLatestVersion { get; set; }
        public int VersionNumber { get; set; }
        public string FileVersionId { get; set; }
        public string FileGuid { get; set; }
        public string FileHash { get; set; }
        public string FileETag { get; set; }

        public long? FileSize { get; set; }
        public DateTimeOffset? CreationTime { get; set; }

        public List<MetadataKeyValue> Metadata { get; set; } = new List<MetadataKeyValue>();
    }
}
