﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public enum ReindexingStatusEnum
    {
        NotExists,
        Created,
        Started,
        InProgress,
        Finished,
        Error
    }
}
