﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class AgreementPacketTeamMember
    {
        public string DisplayName { get; set; }

        public string GivenName { get; set; }

        public string Email { get; set; }

        public string UserPrincipalName { get; set; }

        public string MudId { get; set; }

    }
}
