﻿using System;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    [Serializable]
    public class MetadataKeyValue
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }

}
