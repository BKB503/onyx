﻿using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class ContainerContents : BaseApiResponse, IPagedApiResponse
    {
        public ContainerContents()
        {

        }
        public ContainerContents(string containerName)
        {
            ContainerName = containerName;
        }

        public string ContainerName { get; set; }

        public string ParentFolder { get; set; }

        public IList<FolderResource> Folders { get; set; }

        public IList<FileResource> Files { get; set; }

        public int Limit { get; set; }
        public int RecordsReturned { get; set; }
        public string CurrentContinuationToken { get; set; }
        public string NextContinuationToken { get; set; }
        public bool? MoreDataAvailable { get; set; }

        /// <summary>
        /// if any file was restricted form the response the flag is set
        /// </summary>
        public bool ResponseWasFiltered { get; set; }

    }


}
