﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public enum ApiDiagnosticMetrics
    {
        UploadFileBytesPerSecond,
        DownloadFileBytesPerSecond,
        SearchByTag,
    }
}
