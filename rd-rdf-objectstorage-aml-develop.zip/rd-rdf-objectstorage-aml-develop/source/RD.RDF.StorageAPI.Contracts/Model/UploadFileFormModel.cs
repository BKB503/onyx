﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class UploadFileFormModel
    {
        [Required]
        public IFormFile File { get; set; }
        public MetadataCollections Metadata { get; set; }

    }
}
