﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class Contacts
    {
        public string Id { get; set; }
        public string Role { get; set; }
    }
}
