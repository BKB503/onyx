﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class AgreementPackets
    {
        public AgreementPacket AgreementPacket { get; set; }
    }
}
