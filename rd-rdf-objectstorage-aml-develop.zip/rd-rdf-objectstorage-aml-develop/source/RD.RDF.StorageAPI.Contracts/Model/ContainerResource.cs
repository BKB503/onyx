﻿using RD.RDF.StorageAPI.Contracts.Configuration;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public record ContainerResource(string ContainerName)
    {
        public StorageContainerConfiguration Configuration { get; set; }

        public KafkaConfiguration IndexingConfiguration { get; set; }
    }
}
