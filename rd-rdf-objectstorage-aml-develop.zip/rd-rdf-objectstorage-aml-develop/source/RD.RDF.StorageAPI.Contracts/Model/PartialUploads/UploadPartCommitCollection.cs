﻿using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
{
    public class UploadPartCommitCollection
    {
       // [JsonPropertyName("MetaData")]
        public List<UploadPartCommitItem> Items { get; set; } = new List<UploadPartCommitItem>();

        public UploadPartCommitCollection()
        {

        }

    }
}
