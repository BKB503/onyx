﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
{
    public class UploadPartFormModel
    {
        [Required]
        public IFormFile FilePart { get; set; }

        /// <summary>
        /// upload session id - used in all UploadParts endpoints to control the 
        /// </summary>
        [Required]
        public string UploadSessionId { get; set; }

    }

}
