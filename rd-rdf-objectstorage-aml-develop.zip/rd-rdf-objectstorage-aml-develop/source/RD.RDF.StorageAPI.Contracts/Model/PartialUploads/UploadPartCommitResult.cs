﻿namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
{
    public class UploadPartCommitResult : UploadPartsInitResult
    { 
        public UploadPartCommitResult(UploadFileResultStatus status, string message)
        {
            this.Status = status;
            this.Message = message;
        }

        public UploadPartCommitResult()
        {

        }

        /// <summary>
        /// file information from the storage
        /// </summary>
        public FileResource FileInformation { get; set; }
        
    }
}
