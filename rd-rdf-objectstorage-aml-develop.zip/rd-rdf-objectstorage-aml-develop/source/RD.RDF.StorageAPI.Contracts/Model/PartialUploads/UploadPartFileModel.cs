﻿using System.IO;

namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
{
    public class UploadPartFileModel
    {
        public UploadPartFileModel(string containerName, string uploadSessionId, Stream filePartStream, long filePartStreamLenght, string fileName, string folder, int filePartNumber, long filePartSize, long fileTotalSize)
        {
            ContainerName = containerName;
            UploadSessionId = uploadSessionId;
            FilePartStream = filePartStream;
            FilePartStreamLenght = filePartStreamLenght;
            FileName = fileName;
            Folder = folder;
            FilePartNumber = filePartNumber;
            FilePartSize = filePartSize;
            FileTotalSize = fileTotalSize;
        }

        public string ContainerName { get; set; }

        public string UploadSessionId { get; set; }

        public Stream FilePartStream { get; set; }
        public long FilePartStreamLenght { get; set; }
        public string FileName { get; set; }
        public string Folder { get; set; }
        public int FilePartNumber { get; set; }
        public long FilePartSize { get; set; }
        public long FileTotalSize { get; set; }

    }
}
