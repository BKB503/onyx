﻿using System;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class VersionDetails
    {
        /// <summary>
        /// File GUID
        /// </summary>
        public string FileGuid { get; set; }

        /// <summary>
        /// file version ID
        /// </summary>
        public string FileVersionId { get; set; }

        /// <summary>
        /// file size
        /// </summary>
        public long? FileSize { get; set; }

        /// <summary>
        /// file e-tag
        /// </summary>
        public string FileETag { get; set; }

        /// <summary>
        /// file hash value
        /// </summary>
        public string FileContentHash { get; set; }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? CreationTime { get; set; }

        /// <summary>
        /// True for the Latest version of the file and False otherwise
        /// </summary>
        public bool? IsLatestVersion { get; set; }

    }
}
