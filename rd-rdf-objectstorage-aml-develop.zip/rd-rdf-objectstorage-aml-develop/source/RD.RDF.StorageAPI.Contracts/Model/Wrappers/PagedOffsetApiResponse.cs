﻿namespace RD.RDF.StorageAPI.Contracts.Model.Wrappers
{
    public class PagedOffsetApiResponse<T> : ApiResponse<T>, IPagedOffsetApiResponse
    {
        public long Offset { get; set; }
        public long NextOffset { get; set; }
        public int Limit { get; set; }
        public int RecordsReturned { get; set; }
        public bool? MoreDataAvailable { get; set; }

        public PagedOffsetApiResponse()
        {
        }

        public PagedOffsetApiResponse(T data, int recordsReturned, long offset, long nextOffset, int limit = 1000) : base(data)
        {
            Offset = offset;
            NextOffset = nextOffset;
            Limit = limit;
            RecordsReturned = recordsReturned;
            MoreDataAvailable = nextOffset > 0 && recordsReturned == limit;
        }

        public PagedOffsetApiResponse(string errorMessage, long offset, int limit = 1000) : base(errorMessage)
        {
            Offset = offset;
            Limit = limit;
            RecordsReturned = 0;
            MoreDataAvailable = false;
        }
    }

}
