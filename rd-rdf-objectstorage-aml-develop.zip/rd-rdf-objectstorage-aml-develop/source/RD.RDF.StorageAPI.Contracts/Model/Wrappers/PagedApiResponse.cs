﻿namespace RD.RDF.StorageAPI.Contracts.Model.Wrappers
{
    public class PagedApiResponse<T> : ApiResponse<T>, IPagedApiResponse
    {
        /// <summary>
        /// current continuation token
        /// </summary>
        public string CurrentContinuationToken { get; set; }

        /// <summary>
        /// current limit
        /// </summary>
        public int Limit { get; set; }

        /// <summary>
        /// records returned
        /// </summary>
        public int RecordsReturned { get; set; }

        /// <summary>
        /// Next page continuation token - if Null then there is no more data available
        /// </summary>
        public string NextContinuationToken { get; set; }

        /// <summary>
        /// more data is available
        /// </summary>
        public bool? MoreDataAvailable { get; set; }

        public PagedApiResponse(T data, int recordsReturned, string currentContinuationToken, string nextContinuationToken, int limit = 1000) : base(data)
        {
            RecordsReturned = recordsReturned;
            CurrentContinuationToken = currentContinuationToken;
            NextContinuationToken = nextContinuationToken;
            Limit = limit;
            MoreDataAvailable = !string.IsNullOrEmpty(nextContinuationToken);
        }

        public PagedApiResponse(string errorMessage, string currentContinuationToken, int limit = 1000) : base(errorMessage)
        {
            CurrentContinuationToken = currentContinuationToken;
            Limit = limit;
            RecordsReturned = 0;
        }

        /// <summary>
        /// Ctor for JSON deserializer
        /// </summary>
        public PagedApiResponse()
        {
        }
    }
}
