﻿namespace RD.RDF.StorageAPI.Contracts.Model.Wrappers
{
    public interface IPagedOffsetApiResponse
    {
        /// <summary>
        /// current offset
        /// </summary>
        long Offset { get; set; }

        /// <summary>
        /// next offset
        /// </summary>
        long NextOffset { get; set; }

        /// <summary>
        /// current limit
        /// </summary>
        int Limit { get; set; }

        /// <summary>
        /// records returned
        /// </summary>
        int RecordsReturned { get; set; }

        /// <summary>
        /// more data is available
        /// </summary>
        bool? MoreDataAvailable { get; set; }


        bool Succeeded { get; set; }


        string Message { get; set; }

    }
}
