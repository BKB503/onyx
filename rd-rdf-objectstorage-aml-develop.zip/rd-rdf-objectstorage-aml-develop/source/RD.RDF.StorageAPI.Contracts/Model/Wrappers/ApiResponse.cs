﻿namespace RD.RDF.StorageAPI.Contracts.Model.Wrappers
{
    public class ApiResponse<T> : BaseApiResponse
    {
        public ApiResponse()
        {

        }

        public ApiResponse(T data = default) : base()
        {
            Data = data;
        }

        public ApiResponse(string message) : base()
        {
            Message = message;
            Succeeded = false;
        }


        public T Data { get; set; }
    }
}
