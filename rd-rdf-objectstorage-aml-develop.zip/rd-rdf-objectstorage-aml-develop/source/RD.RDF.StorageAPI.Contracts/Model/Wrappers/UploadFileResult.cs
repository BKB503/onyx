﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Contracts.Model.Wrappers
{
    public class UploadFileResult
    {
        public UploadFileResult()
        {
        }
        public UploadFileResult(FileResource fileResource, UploadFileResultStatus status, string Message = default)
        {
            FileInformation = fileResource;
            Status = status;
            this.Message = Message;
        }
        /// <summary>
        /// Error scenario : Consider as error message
        /// </summary>
        /// <param name="ErrorMessage"></param>
        public UploadFileResult(UploadFileResultStatus status, string Message)
        {
            this.Message = Message;
            FileInformation = null;
            Status = status;
        }
        public UploadFileResultStatus Status { get; set; }
        public FileResource FileInformation { get; set; }
        public string Message { get; set; }
        public int StatusCode
        {
            get
            {
                return (int)Status;
            }
        }
    }
}
