﻿namespace RD.RDF.StorageAPI.Contracts.Model.Wrappers
{
    public interface IPagedApiResponse
    {

        /// <summary>
        /// current continuation token
        /// </summary>
        string CurrentContinuationToken { get; set; }

        /// <summary>
        /// current limit
        /// </summary>
        int Limit { get; set; }

        /// <summary>
        /// records returned
        /// </summary>
        int RecordsReturned { get; set; }

        /// <summary>
        /// Next page continuation token - if Null then there is no more data available
        /// </summary>
        string NextContinuationToken { get; set; }

        /// <summary>
        /// more data is available
        /// </summary>
        bool? MoreDataAvailable { get; set; }


        bool Succeeded { get; set; }


        string Message { get; set; }
    }
}
