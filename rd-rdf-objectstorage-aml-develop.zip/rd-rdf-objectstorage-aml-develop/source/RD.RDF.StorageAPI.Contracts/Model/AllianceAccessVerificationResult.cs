﻿using System;

namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class AllianceAccessVerificationResult
    {
        public AllianceAccessVerificationResult(string allianceName, AllianceAccessVerificationEnum result, AllianceModel alliance = null)
        {
            AllianceName = allianceName;
            Result = result;
            Alliance = alliance;
        }

        public AllianceAccessVerificationEnum Result { get; set; }

        public AllianceModel Alliance { get; set; }

        public string AllianceName { get; set; }

        /// <summary>
        /// in case of not allowed response the reason is put here
        /// </summary>
        public string ResultMessage { get; set; }

    }

}
