﻿namespace RD.RDF.StorageAPI.Contracts.Model
{
    public class AzureGraphUserData
    {
        public string Id { get; set; }
        public string City { get; set; }
        public string DisplayName { get; set; }
        public string GivenName { get; set; }
        public string Mail { get; set; }
        public string UserPrincipalName { get; set; }
        public object OfficeLocation { get; set; }
        public string CompanyName { get; set; }
        public string Country { get; set; }

        public string MudId { get; set; }
    }


    public static class GraphConstants
    {
        // Defines the permission scopes used by the app
        public readonly static string[] Scopes =
        {
            "user.read.all"
        };
    }
}
