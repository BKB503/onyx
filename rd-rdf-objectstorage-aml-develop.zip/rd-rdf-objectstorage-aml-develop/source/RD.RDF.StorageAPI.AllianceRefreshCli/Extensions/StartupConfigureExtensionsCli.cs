﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using Microsoft.Extensions.Caching.Memory;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Core.Helpers;
using RD.RDF.StorageAPI.DataAccess.Providers;
using RD.RDF.StorageAPI.DataAccess.Repositories;
using RD.RDF.StorageAPI.DataAccess.ClientImpl;
using RD.RDF.StorageAPI.Core.Services;
using RD.RDF.StorageAPI.DataAccess.AllianceData;
using Microsoft.Graph;
using Azure.Identity;

namespace RD.RDF.StorageAPI.AllianceRefreshCli.Extensions
{
    public static class StartupConfigureExtensionsCli
    {
        public static IServiceCollection InitConfiguration(this IServiceCollection services, IConfiguration Configuration)
        {
            services.Configure<PingIdConfiguration>(Configuration.GetSection(PingIdConfiguration.PingId));
            services.Configure<AzureAdConfiguration>(Configuration.GetSection(AzureAdConfiguration.AzureAd));
            // Storage containers configuration
            services.Configure<StorageConfiguration>(Configuration.GetSection(StorageConfiguration.Storage));
            services.Configure<AllianceConfiguration>(Configuration.GetSection(AllianceConfiguration.Alliance));
            //register PingIdConfiguration
            services.AddSingleton<OAuth2Configruation>(s =>
            {
                var confOptions = s.GetRequiredService<IOptions<PingIdConfiguration>>();
                var config = confOptions.Value;
                return new OAuth2Configruation
                {
                    AccessTokenUrl = new Uri($"{config.PingFederationHost}/{config.Endpoints.OauthTokenEndpoint}"),
                    ClientId = config.ClientId,
                    ClientSecret = config.ClientSecret,
                    Scope = config.Scope
                };
            });
            services.AddTransient<IOAuth2TokenProvider, OAuth2ClientCredentialsTokenProvider>();

            services.AddApplicationInsightsTelemetryWorkerService();
            services.AddApplicationInsightsKubernetesEnricher();

            services.AddTransient<IEventsTracker, ApplicationInsightsTracker>();
            services.AddTransient<IMetricsTracker, ApplicationInsightsTracker>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            return services;
        }

        public static IServiceCollection InitDataAccess(this IServiceCollection services, IConfiguration Configuration)
        {
            services.AddSingleton<IContainerConfigurationProvider, AppConfigContainerConfigurationProvider>();
            services.AddTransient<ISearchProvider, AzureBlobStorageSearchProvider>();
            services.AddTransient<EmptySearchProvider>();
            services.AddTransient<ISearchProviderFactory, SearchProviderFactory>();
            services.AddTransient<IFilesRepository, FilesRepository>();
            services.AddTransient<IFoldersRepository, FoldersRepository>();
            services.AddTransient<IStorageClientFactory, StorageClientFactory>();
            services.AddTransient<IStorageClient, AzureBlobStorageClient>();
            services.AddTransient<IStorageClient, ObjectStorageS3Client>();
            services.AddSingleton<ObjectStorageS3Client.MyHttpClientFactory>();
            services.AddTransient<IIndexingFactory, IndexingFactory>();
            services.AddSingleton<IIndexingFacade, FileIndexingFacade>();
            services.AddTransient<IDataStorageRepository, DataStorageRepository>();
            services.AddSingleton<IAllianceConfigurationProvider, AllianceConfigurationProvider>();
            services.AddTransient<IIndexingRespository, BlobStorageIndexingRepository>();
            services.AddSingleton<IIndexingRespository, KafkaIndexingRepository>();
            services.AddTransient<OdbcAllianceInformationProvider>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IAllianceInformationProvider, CachedAllianceInformationProvider>(s =>
            {
                var provider = s.GetRequiredService<OdbcAllianceInformationProvider>();
                var memCache = s.GetRequiredService<IMemoryCache>();
                var config = s.GetRequiredService<IAllianceConfigurationProvider>();
                return new CachedAllianceInformationProvider(provider, memCache, config);
            });

            services.AddSingleton<GraphServiceClient>(ctx =>
            {

                var scopes = new[] { "https://graph.microsoft.com/.default" };

                // Multi-tenant apps can use "common",
                // single-tenant apps must use the tenant ID from the Azure portal

                var tenantId = Configuration["AzureAd:TenantId"];

                // Values from app registration
                var clientId = Configuration["AzureAd:ClientId"];
                var clientSecret = Configuration["AzureAd:ClientSecret"];

                // using Azure.Identity;
                var options = new TokenCredentialOptions
                {
                    AuthorityHost = AzureAuthorityHosts.AzurePublicCloud                   
                };

                // https://learn.microsoft.com/dotnet/api/azure.identity.clientsecretcredential
                var clientSecretCredential = new ClientSecretCredential(tenantId, clientId, clientSecret, options);
                var graphClient = new GraphServiceClient(clientSecretCredential, scopes)
                {
                    BaseUrl = Configuration["AzureAd:GraphApiUrl"]
       
                };
                return graphClient;
            });
            services.AddTransient<IGraphApiClient, GraphApiClient>();


            services.AddSingleton<DefaultMetadataCollectionValidationProvider>();
            services.AddSingleton<IMetadataCollectionValidationProvider, AzureBlobMetadataCollectionValidationProvider>();
            services.AddSingleton<IMetadataCollectionValidationProvider, S3MetadataCollectionValidationProvider>();
            services.AddSingleton<IMetadataCollectionValidationProviderFactory, MetadataCollectionValidationProviderFactory>();
            services.AddTransient<IOdbcFileIndexSearchService, OdbcFileIndexSearchService>();

            return services;
        }

        public static IServiceCollection InitServices(this IServiceCollection services, IConfiguration Configuration)
        {
            services.AddTransient<IStorageIndexSearchProvider, DatabricksOdbcFileIndexSearchProvider>();
            services.AddTransient<IMetadataParsingService, MetadataParsingService>();
            services.AddTransient<IMetadataService, MetadataService>();
            services.AddTransient<IDataStorageService, DataStorageService>();
            services.AddSingleton<IAllianceWriter, AllianceWriter>();
            services.AddSingleton<IAllianceReader, AllianceReader>();
            services.AddTransient<IIndexingService, IndexingService>();
            services.AddTransient<IStorageIndexProvider, DatabricksOdbcFileIndexProvider>();
            services.AddTransient<IAllianceSecurityService, AllianceSecurityService>();
            services.AddTransient<IUserRepository, UserRepository>();
            return services;
        }

    }
}
