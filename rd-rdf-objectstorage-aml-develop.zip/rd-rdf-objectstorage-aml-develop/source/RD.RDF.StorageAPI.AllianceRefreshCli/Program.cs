﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RD.RDF.StorageAPI.AllianceRefreshCli.Extensions;
using RD.RDF.StorageAPI.Core.Helpers;
using RD.RDF.StorageAPI.Core.Services;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.AllianceRefreshCli
{
    class Program
    {
        public static async Task Main(string[] args)
        {
            var cts = new CancellationTokenSource();
            var hostBuilder = args.CreateGenericHostBuilder(ConfigureServices, CommandMapHelper.CreateCmdMap());

            var host = hostBuilder.Build();
            await host.RunAsync(cts.Token).ConfigureAwait(false);
        }

        private static void ConfigureServices(HostBuilderContext hostCtx, IServiceCollection services)
        {
            services.AddMemoryCache();
            services.InitConfiguration(hostCtx.Configuration)
                    .InitDataAccess(hostCtx.Configuration)
                    .InitServices(hostCtx.Configuration);
            services.AddHostedService<AllianceService>();
        }
    }
}
