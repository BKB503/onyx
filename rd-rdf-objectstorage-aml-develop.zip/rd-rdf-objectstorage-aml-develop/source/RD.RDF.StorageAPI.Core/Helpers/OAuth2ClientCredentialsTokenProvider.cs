﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Helpers
{
    public class OAuth2ClientCredentialsTokenProvider : IOAuth2TokenProvider
    {
        private readonly JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        private readonly OAuth2Configruation defaultConfig;

        private readonly string ConfigKey;

        private readonly ILogger<OAuth2ClientCredentialsTokenProvider> logger;

        private static ConcurrentDictionary<string, OAuth2Token> CachedTokenDict = new ConcurrentDictionary<string, OAuth2Token>();

        private static ConcurrentDictionary<string, DateTime?> CachedTokenExpirationDict = new ConcurrentDictionary<string, DateTime?>();

        public OAuth2ClientCredentialsTokenProvider(OAuth2Configruation configruation, ILogger<OAuth2ClientCredentialsTokenProvider> logger)
        {
            defaultConfig = configruation ?? throw new ArgumentNullException(nameof(configruation));
            ConfigKey = $"{configruation.AccessTokenUrl}|{configruation.ClientId}|{configruation.ClientSecret}|{configruation.Scope}";
            this.logger = logger;
        }

        public async Task<OAuth2Token> GetTokenAsync(CancellationToken cancellationToken)
        {
            string token1;

            CachedTokenDict.TryGetValue(ConfigKey, out OAuth2Token CachedToken);
            CachedTokenExpirationDict.TryGetValue(ConfigKey, out DateTime? CachedTokenExpiration);
            if (CachedToken != null &&
                CachedTokenExpiration != null &&
                DateTime.UtcNow < CachedTokenExpiration.Value)
            {
                return CachedToken;
            }
            else
            {
                CachedTokenDict.TryRemove(ConfigKey, out OAuth2Token r1);
                CachedTokenExpirationDict.TryRemove(ConfigKey, out DateTime? r2);
            }

            try
            {
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Post, defaultConfig.AccessTokenUrl);
                request.Headers.Add("cache-control", "no-cache");
                request.Headers.Add("content-type", "application/x-www-form-urlencoded");
                var httpCallParameters = new List<KeyValuePair<string, string>>()
                {
                   new KeyValuePair<string, string> ("grant_type","client_credentials"),
                   new KeyValuePair<string, string> ("client_id",defaultConfig.ClientId),
                   new KeyValuePair<string, string> ("client_secret",defaultConfig.ClientSecret)
                };
                if (defaultConfig.Scope != null)
                {
                    httpCallParameters.Add(new KeyValuePair<string, string>("scope", defaultConfig.Scope));
                }
                request.Content = new FormUrlEncodedContent(httpCallParameters);
                var responseToken = await client.SendAsync(request, cancellationToken);
                if (responseToken.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var contentData = await responseToken.Content.ReadAsStringAsync(cancellationToken);
                    CachedToken = JsonSerializer.Deserialize<OAuth2Token>(contentData, jsonSerializerOptions);
                    CachedTokenExpiration = DateTime.UtcNow.AddSeconds(CachedToken.ExpiresIn);
                    CachedTokenDict.TryAdd(ConfigKey, CachedToken);
                    CachedTokenExpirationDict.TryAdd(ConfigKey, CachedTokenExpiration);
                    return CachedToken;
                }
                else
                {
                    logger.LogWarning($"No token was generated. Reason = {responseToken.Content}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"OAuth2ClientCredentialsTokenProvider.GetTokenAsync() {ex.Message}");
                throw;
            }
        }

        public async Task<OAuth2Token> GetTokenAsync(OAuth2Configruation configuration, CancellationToken cancellationToken)
        {
            if (configuration is null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }

            var ConfigKey = $"{configuration.AccessTokenUrl}|{configuration.ClientId}|{configuration.ClientSecret}|{configuration.Scope}";
            CachedTokenDict.TryGetValue(ConfigKey, out OAuth2Token CachedToken);
            CachedTokenExpirationDict.TryGetValue(ConfigKey, out DateTime? CachedTokenExpiration);
            if (CachedToken != null &&
                CachedTokenExpiration != null &&
                DateTime.UtcNow < CachedTokenExpiration.Value)
            {
                return CachedToken;
            }
            else
            {
                CachedTokenDict.TryRemove(ConfigKey, out OAuth2Token r1);
                CachedTokenExpirationDict.TryRemove(ConfigKey, out DateTime? r2);
            }

            try
            {
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Post, configuration.AccessTokenUrl);
                //request.Headers.Add("cache-control", "no-cache");
                //request.Headers.Add("content-type", "application/x-www-form-urlencoded");

                var httpCallParameters = new List<KeyValuePair<string, string>>()
                {
                   new KeyValuePair<string, string> ("grant_type","client_credentials"),
                   new KeyValuePair<string, string> ("client_id",configuration.ClientId),
                   new KeyValuePair<string, string> ("client_secret",configuration.ClientSecret)
                };
                if (configuration.Scope != null)
                {
                    httpCallParameters.Add(new KeyValuePair<string, string>("scope", configuration.Scope));
                }
                request.Content = new FormUrlEncodedContent(httpCallParameters);
                var responseToken = await client.SendAsync(request, cancellationToken);
                if (responseToken.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var contentData = await responseToken.Content.ReadAsStringAsync(cancellationToken);
                    CachedToken = JsonSerializer.Deserialize<OAuth2Token>(contentData, jsonSerializerOptions);
                    CachedTokenExpiration = DateTime.UtcNow.AddSeconds(CachedToken.ExpiresIn);
                    CachedTokenDict.TryAdd(ConfigKey, CachedToken);
                    CachedTokenExpirationDict.TryAdd(ConfigKey, CachedTokenExpiration);
                    return CachedToken;
                }

                else
                {
                    logger.LogWarning($"No token was generated. Reason = {responseToken.Content}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"OAuth2ClientCredentialsTokenProvider.GetTokenAsync() {ex.Message}");
                throw;
            }
        }
    }

}
