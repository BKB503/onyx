﻿using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace RD.RDF.StorageAPI.Core.Helpers
{
    public static class StartupExtensions
    {
        public static IHostBuilder CreateGenericHostBuilder(this string[] args, Action<HostBuilderContext, IServiceCollection> configureDelegate, Dictionary<string, string> argsMap = null)
        {
            return Host.CreateDefaultBuilder(args)
                       .UseContentRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location))
                       .ConfigureAppConfiguration((ctx, builder) =>
                       {
                           if (argsMap == null)
                           {
                               builder.AddCommandLine(args);
                           }
                           else
                           {
                               //command line arguments map provided
                               builder.AddCommandLine(args, argsMap);
                           }

                           var builtConfig = builder.Build();
                           string kv = builtConfig["KeyVaultName"];
                           if (!string.IsNullOrEmpty(kv))
                           {
                               var secretClient = new SecretClient(new Uri($"https://{kv}.vault.azure.net/"), new DefaultAzureCredential());
                               builder.AddAzureKeyVault(secretClient, new KeyVaultSecretManager());
                           }
                       })
                       .ConfigureServices(configureDelegate);
        }

    }
}
