﻿using Microsoft.ApplicationInsights;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Linq;

namespace RD.RDF.StorageAPI.Core.Helpers
{
    public class ApplicationInsightsTracker : IEventsTracker, IMetricsTracker
    {
        private readonly TelemetryClient telemetryClient;

        public ApplicationInsightsTracker(TelemetryClient telemetryClient)
        {
            this.telemetryClient = telemetryClient;
        }

        public void Track(DiagnosticMetric customMetric)
        {
            telemetryClient.TrackMetric(customMetric.MetricName, customMetric.Value);
        }

        public void Track(DiagnosticEvent customEvent)
        {
            telemetryClient.TrackEvent(customEvent.EventName,
                                       customEvent.Properties,
                                       customEvent.Metrics?.ToDictionary(key => key.MetricName, value => value.Value));
        }
    }
}
