﻿using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Core.Helpers
{
    public static class CommandMapHelper
    {
        public static Dictionary<string, string> CreateCmdMap()
        {
            return new Dictionary<string, string>
            {
                { "-a","action" }
            };
        }
    }
}
