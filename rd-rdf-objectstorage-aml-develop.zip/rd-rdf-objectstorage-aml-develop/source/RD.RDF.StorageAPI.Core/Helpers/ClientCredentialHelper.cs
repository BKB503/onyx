﻿using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Text.Json;
using RD.RDF.StorageAPI.Contracts.Configuration;

namespace RD.RDF.StorageAPI.Core.Helpers
{
    public static class ClientCredentialHelper
    {
        /// <summary>
        /// Obtains bearer token form the token access point using client credential flow
        /// </summary>
        /// <param name="TokenEndPoint">token provider url</param>
        /// <param name="ClientId">Client ID</param>
        /// <param name="ClientSecret">Client Secret</param>
        /// <param name="Scope">Requested scope</param>
        /// <returns>an authorization header</returns>
        public static async Task<AuthenticationHeaderValue> GetAuthenticationHeadeUsingClientCredentialFlow(string TokenEndPoint, string ClientId, string ClientSecret, string Scope)
        {
            string token = await GetAccessTokenUsingClientCredentialFlow(TokenEndPoint, ClientId, ClientSecret, Scope);
            return new AuthenticationHeaderValue("Bearer", token);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="TokenEndPoint"></param>
        /// <param name="ClientId">Client ID</param>
        /// <param name="ClientSecret">Client Secret</param>
        /// <param name="Scope">Requested scope</param>
        /// <returns>access token</returns>
        public static async Task<string> GetAccessTokenUsingClientCredentialFlow(string TokenEndPoint, string ClientId, string ClientSecret, string Scope)
        {
            string token;

            //call ping for access code
            using (var httpClient = new HttpClient())
            {
                var request = new HttpRequestMessage(HttpMethod.Post, TokenEndPoint)
                {
                    Content = new FormUrlEncodedContent(new Dictionary<string, string> {
               { "client_id", ClientId },
               { "client_secret", ClientSecret },
               { "grant_type", "client_credentials" },
               { "scope", Scope },
             })
                };
                var response = await httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                // pull out token
                var payload = JsonSerializer.Deserialize<OAuth2Token>(await response.Content.ReadAsStringAsync());

                token = payload.AccessToken;
            }
            return token;
        }
    }
}
