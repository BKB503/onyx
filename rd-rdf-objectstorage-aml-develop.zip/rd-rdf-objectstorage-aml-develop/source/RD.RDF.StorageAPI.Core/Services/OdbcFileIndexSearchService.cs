﻿using Google.Api.Gax.ResourceNames;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class OdbcFileIndexSearchService : IOdbcFileIndexSearchService
    {
        ILogger<OdbcFileIndexSearchService> logger;
        IStorageIndexSearchProvider storageIndexSearchProvider;
        private readonly IContainerConfigurationProvider containerConfigurationProvider;
        public OdbcFileIndexSearchService(IContainerConfigurationProvider containerConfigurationProvider, ILogger<OdbcFileIndexSearchService> logger, 
            IStorageIndexSearchProvider storageIndexSearchProvider)
        {
            this.logger = logger;
            this.containerConfigurationProvider = containerConfigurationProvider;
            this.storageIndexSearchProvider = storageIndexSearchProvider;
        }

        public async Task<PagedOffsetApiResponse<List<FileIndexModel>>> GetIndexSearchResultAsync(string containerName, string metaDataKey, string metaDataValue, string folderName, OffsetPagPaginationFilter filter, CancellationToken cancellationToken)
        {
            var container = await containerConfigurationProvider.GetContainerByNameAsync(containerName, cancellationToken);

            if (container == null)
            {
                logger.LogError($"{nameof(OdbcFileIndexSearchService)} no container found with name {containerName}");
                return null;
            }

            return await storageIndexSearchProvider.GetFolderIndexAsync(container, metaDataKey, metaDataValue, folderName, filter, cancellationToken);
        }

        public async Task<PagedOffsetApiResponse<List<FileIndexModel>>> GetIndexSearchByFolderNameAsync(string containerName, string folderName, string metaDataKey, string metaDataValue, OffsetPagPaginationFilter filter, CancellationToken cancellationToken)
        {
            var container = await containerConfigurationProvider.GetContainerByNameAsync(containerName, cancellationToken);

            if (container == null)
            {
                logger.LogError($"{nameof(OdbcFileIndexSearchService)} no container found with name {containerName}");
                return null;
            }

            return await storageIndexSearchProvider.GetIndexSearchByFolderNameAsync(container, folderName,metaDataKey,metaDataValue, filter, cancellationToken);
        }
    }
}
