﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class VersionEnabledCheckService : BackgroundService
    {

        private readonly IContainerConfigurationProvider containerConfigurationProvider;
        private readonly IStorageClientFactory clientFactory;
        private readonly ILogger<VersionEnabledCheckService> _logger;
        public VersionEnabledCheckService(ILogger<VersionEnabledCheckService> logger, IContainerConfigurationProvider containerConfigurationProvider,
                                  IStorageClientFactory clientFactory)
        {
            _logger = logger;
            this.containerConfigurationProvider = containerConfigurationProvider;
            this.clientFactory = clientFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken cancellationToken)
        {
            try
            {
                IList<ContainerResource> containerList = await containerConfigurationProvider.GetAllContainersAdminAsync(cancellationToken);
                foreach (var container in containerList)
                {
                    var storageClient = clientFactory.GetStorageClient(container);
                    if (storageClient == null)
                    {
                        // log error
                        _logger.LogError("Storage client is null");
                        container.Configuration.IsConnectionAvailable = false;
                    }
                    else
                    {
                        container.Configuration.IsConnectionAvailable = true;
                    }

                    //executingTask
                    var version = await storageClient.GetContainerClientPropertiesAsync(container);
                    container.Configuration.IsVersionEnabled = version;
                    _logger.LogInformation($"For the Container '{container.ContainerName}' versioning flag/status is {version}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
        }
    }
}
