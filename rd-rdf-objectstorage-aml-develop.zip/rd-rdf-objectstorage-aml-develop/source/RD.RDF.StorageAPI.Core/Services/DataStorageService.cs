﻿using IdentityModel.OidcClient;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Extensions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class DataStorageService : IDataStorageService
    {
        public const string MetadataFolderPrefix = ".metadata";

        private readonly IContainerConfigurationProvider containerConfigurationProvider;
        private readonly IDataStorageRepository dataStorageRepository;
        private readonly ILogger<DataStorageService> logger;
        private readonly IMetadataService metadataService;
        private readonly IIndexingService indexingService;

        public DataStorageService(IContainerConfigurationProvider containerConfigurationProvider,
                                  IDataStorageRepository dataStorageRepository,
                                  ILogger<DataStorageService> logger,
                                  IMetadataService metadataService,
                                  IIndexingService indexingService)
        {
            this.containerConfigurationProvider = containerConfigurationProvider;
            this.dataStorageRepository = dataStorageRepository;

            this.logger = logger;
            this.metadataService = metadataService;
            this.indexingService = indexingService;
        }

        public async Task<FileIndexModel> DownloadFileIndexModelAsync(string containerName, FileResource fileInfo, CancellationToken token = default)
        {
            FileIndexModel fileIndexModel = null; // if file does not exists
            try
            {
                // create the index file object
                FileResource file = new FileResource(fileInfo.FileName)
                {
                    FilePath = fileInfo.IndexFilePath,
                };
                Stream fileModel = await GetFileStreamAsync(containerName, file, token);
                if (fileModel != null)
                {
                    fileIndexModel = JsonSerializer.Deserialize<FileIndexModel>(fileModel);
                }
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "DownloadFileIndexModelAsync " + ex.Message);
            }
            return fileIndexModel;
        }

        public async Task<Stream> GetFileStreamAsync(string containerName, FileResource fileInfo, CancellationToken cancellationToken)
        {
            if (fileInfo is null)
            {
                //log error
                return null;
            }

            var container = await containerConfigurationProvider.GetContainerByNameAsync(containerName, cancellationToken);
            if (container == null)
            {
                // log error
                return null;
            }

            var stream = await dataStorageRepository.GetFileStreamAsync(container, fileInfo, cancellationToken);
            return stream;
        }

        public async Task<UploadFileResult> UploadFileToStorageAsync(string container,
                                                                     string folder,
                                                                     string fileName,
                                                                     long totalBytes,
                                                                     Stream fileStream,
                                                                     MetadataCollections metadataModel,
                                                                     CancellationToken cancellationToken)
        {
            try
            {
                // quick and dirty fix for saving data 
                if (!string.IsNullOrEmpty(folder) && folder.EndsWith("/"))
                {
                    folder = folder.Substring(0, folder.Length - 1);
                }

                //long totalBytes = file != null ? file.Length : 0;
                //string fileName = file.FileName;
                string fileGuid = SetFileGuid(metadataModel);
                var result = await this.UploadFileWithMetadataAsync(container, fileName, folder, fileStream, metadataModel, cancellationToken);
                if (result.FileInformation != null)
                {
                    result.FileInformation = await StoreMetadataAsync(container, folder, fileName, metadataModel, fileGuid, result.FileInformation, cancellationToken);
                }
                else
                {
                    string errorMsg = $"File upload failed. Please check container versioning or permission.";
                    logger.LogError(errorMsg);
                    return result;
                }

                return result;
            }
            catch (Exception ex)
            {
                string errorMsg = $"Exception occurred in upload process {ex.Message}";
                logger.LogError(ex, ex.Message);
                return new UploadFileResult(UploadFileResultStatus.Error, errorMsg);
            }
        }

        private async Task<FileResource> StoreMetadataAsync(string container,
                                                            string folder,
                                                            string fileName,
                                                            MetadataCollections metadataModel,
                                                            string fileGuid,
                                                            FileResource fileResource,
                                                            CancellationToken cancellationToken)
        {
            var metadataStream = SerializeMetadataToStream(metadataModel);
            // upload the file index
            fileResource.FileGuid = fileGuid;
            fileResource.Metadata = new MetadataDictionary(metadataModel);

            var fileModel = await this.DownloadFileIndexModelAsync(container, fileResource, cancellationToken);
            var indexedModel = await indexingService.WriteFileIndexAsync(fileResource, fileModel, container, cancellationToken);
            //we return the same model as in the get file contents
            var results = metadataService.GetFileResourceFromIndexModel(indexedModel, fileGuid);
            //path to folder
            string metadataFolder = PathExtensions.CombineBlobPath(MetadataFolderPrefix, folder);
            //upload Metadata file as well
            string metadataFileName = Path.GetFileNameWithoutExtension(fileName) + "-metadata.json";
            await this.UploadFileWithMetadataAsync(container, metadataFileName, metadataFolder, metadataStream, null, cancellationToken);
            return results;
        }

        public async Task<UploadFileResult> UploadFileWithMetadataAsync(string containerName, string fileName, string folder, Stream fileData, MetadataCollections keyValues, CancellationToken cancellationToken)
        {
            var containerWithStatus = await GetContainerAsync(containerName, cancellationToken);
            if (containerWithStatus.Status != UploadFileResultStatus.Success)
            {
                return new UploadFileResult(containerWithStatus.Status, containerWithStatus.Message);
            }
            var uploaded = await dataStorageRepository.UploadFileToFolderAsync(containerWithStatus.Container, fileName, folder, fileData, keyValues, cancellationToken);
            return uploaded;
        }

        public async Task<UploadPartResult> UploadPartFileAsync(UploadPartFileModel fileModel, CancellationToken cancellationToken)
        {
            var containerWithStatus = await GetContainerAsync(fileModel.ContainerName, cancellationToken);
            if (containerWithStatus.Status != UploadFileResultStatus.Success)
            {
                return new UploadPartResult(containerWithStatus.Status, containerWithStatus.Message);
            }
            if (containerWithStatus.Container.Configuration.Type != Contracts.Configuration.StorageContainerType.azureblob &&
               containerWithStatus.Container.Configuration.Type != Contracts.Configuration.StorageContainerType.googleblob)
            {
                return new UploadPartResult(UploadFileResultStatus.NoContainerClientAvailabe, "Partial uploads are available only for Azure Blob Storage and Google Cloud Storage");
            }
            var uploaded = await dataStorageRepository.UploadPartFileAsync(containerWithStatus.Container, fileModel, cancellationToken);
            return uploaded;
        }

        public async Task<UploadPartCommitResult> UploadPartsCommitAsync(string container, string uploadSessionId, string fileName, string folder, UploadPartCommitCollection parts, MetadataCollections metadata, CancellationToken cancellationToken)
        {
            var containerWithStatus = await GetContainerAsync(container, cancellationToken);
            if (containerWithStatus.Status != UploadFileResultStatus.Success)
            {
                return new UploadPartCommitResult(containerWithStatus.Status, containerWithStatus.Message);
            }
            if (containerWithStatus.Container.Configuration.Type != Contracts.Configuration.StorageContainerType.azureblob &&
               containerWithStatus.Container.Configuration.Type != Contracts.Configuration.StorageContainerType.googleblob)
            {
                return new UploadPartCommitResult(UploadFileResultStatus.NoContainerClientAvailabe, "Partial uploads are available only for Azure Blob Storage and Google Cloud Storage");
            }

            var fileGuid = SetFileGuid(metadata);
            var uploaded = await dataStorageRepository.UploadPartsCommitAsync(containerWithStatus.Container, uploadSessionId, fileName, folder, parts, metadata, cancellationToken);
            if (uploaded != null && uploaded.Status == UploadFileResultStatus.Success)
            {
                uploaded.FileInformation = await StoreMetadataAsync(container, folder, fileName, metadata, fileGuid, uploaded.FileInformation, cancellationToken);
            }
            return uploaded;
        }

        public async Task<UploadPartsInitResult> UploadPartsInitAsync(string container, string fileName, string folder, CancellationToken cancellationToken)
        {
            var containerWithStatus = await GetContainerAsync(container, cancellationToken);
            if (containerWithStatus.Status != UploadFileResultStatus.Success)
            {
                return new UploadPartsInitResult(containerWithStatus.Status, containerWithStatus.Message);
            }
            if (containerWithStatus.Container.Configuration.Type != Contracts.Configuration.StorageContainerType.azureblob &&
               containerWithStatus.Container.Configuration.Type != Contracts.Configuration.StorageContainerType.googleblob)
            {
                return new UploadPartsInitResult(UploadFileResultStatus.NoContainerClientAvailabe, "Partial uploads are available only for Azure Blob Storage and Google Cloud Storage");
            }

            var uploaded = await dataStorageRepository.UploadPartsInitAsync(containerWithStatus.Container, fileName, folder, cancellationToken);
            return uploaded;
        }

        private async Task<ContainerResourceWithStatus> GetContainerAsync(string containerName, CancellationToken cancellationToken)
        {
            UploadFileResultStatus status = UploadFileResultStatus.Success;
            string message = null;
            ContainerResource container = await containerConfigurationProvider.GetContainerByNameAsync(containerName, cancellationToken);
            if (container == null)
            {
                status = UploadFileResultStatus.ContainerNotAvailabe;
                message = "Container unavailable";
            }
            else if (container.Configuration.IsConnectionAvailable != true)
            {
                status = UploadFileResultStatus.ConnectionNotActive;
                message = "Connection is not active";
            }
            else if (!container.Configuration.IsVersionEnabled)
            {
                status = UploadFileResultStatus.VersioningNotEnabled;
                message = "Container version is not enabled";
            }
            return new ContainerResourceWithStatus(container, status, message);
        }

        private static string SetFileGuid(MetadataCollections metadataCollection)
        {
            Guid guid = Guid.NewGuid();
            string fileGuid = guid.ToString();
            var guidIndex = metadataCollection.Items.FindIndex(item => item.Key == Common.FileGuid);
            if (guidIndex >= 0)
            {
                metadataCollection.Items[guidIndex].Value = fileGuid;
                metadataCollection.Items[guidIndex].IsIndexed = true;
            }
            else
            {
                metadataCollection.Items.Add(new MetadataItem { Key = Common.FileGuid, Value = fileGuid, IsIndexed = true });
            }

            return fileGuid;
        }


        public Stream SerializeMetadataToStream(MetadataCollections metadataCollection)
        {
            var metadataModel = new MetadataModel(metadataCollection);
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                WriteIndented = true
            };
            string json = JsonSerializer.Serialize(metadataModel, options);
            var buffer = Encoding.UTF8.GetBytes(json);
            return new MemoryStream(buffer);

        }
    }
}
