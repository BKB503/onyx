﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace RD.RDF.StorageAPI.Core.Services
{
    public class AllianceService : BackgroundService
    {
        ILogger<AllianceService> logger;
        private readonly IGraphApiClient graphApiClient;
        IAllianceReader allianceReader;
        IAllianceWriter allianceWriter;
        IAllianceConfigurationProvider allianceConfigurationProvider;
        private readonly AllianceConfiguration allianceConfiguration;

        public AllianceService(IAllianceConfigurationProvider allianceConfigurationProvider,
                               IAllianceReader allianceReader,
                               IAllianceWriter allianceWriter,
                               ILogger<AllianceService> logger,
                               IGraphApiClient graphApiClient)
        {
            this.logger = logger;
            this.graphApiClient = graphApiClient;
            this.allianceReader = allianceReader;
            this.allianceWriter = allianceWriter;
            this.allianceConfigurationProvider = allianceConfigurationProvider;
            allianceConfiguration = this.allianceConfigurationProvider.GetAllianceConfiguration();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            DateTime lastRunTime = DateTime.MinValue;
            DateTime startRunTime = DateTime.UtcNow;

            try
            {
                var lastRunFile = new FileInfo(allianceConfiguration.FilePathRefreshRun);
                if (lastRunFile.Exists)
                {
                    try
                    {
                        string lastFileData = File.ReadAllText(lastRunFile.FullName);
                        lastRunTime = DateTime.ParseExact(lastFileData, "u", CultureInfo.InvariantCulture);
                    }
                    catch (Exception ex)
                    {
                        logger.LogError(ex, ex.Message);
                        lastRunTime = DateTime.MinValue;
                    }
                }

                logger.LogInformation($"AllianceService is starting. Start date : {startRunTime:u} Last Run : {lastRunTime:u} from file {lastRunFile.FullName}");
                var allianceAgreement = await allianceReader.ReadAllianceInformationAsync(stoppingToken);
                if (allianceAgreement == null)
                {
                    logger.LogWarning($"Alliances read didn't return any result");
                    Environment.Exit(1);
                }
                else
                {
                    logger.LogInformation($"Alliances read : {allianceAgreement.Count()}");
                    allianceAgreement = allianceAgreement.Where(ap => ap.ModificationDate >= lastRunTime).ToList();
                    logger.LogInformation($"Alliances filtered : {allianceAgreement.Count()}");
                    //await EnrichTeamMembersAsync(allianceAgreement, stoppingToken);
                    await allianceWriter.WriteAllianceInfromationAsync(allianceAgreement, stoppingToken);
                    logger.LogInformation($"Alliances update finished");
                    File.WriteAllText(lastRunFile.FullName, startRunTime.ToString("u", CultureInfo.InvariantCulture));
                    logger.LogInformation($"Last Run Date updated");
                }
                // that's a bit rough but the process didn't end properly
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                Environment.Exit(1);
            }
        }
        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            logger.LogInformation($"AllianceService is stopping");
        }

        private async Task EnrichTeamMembersAsync(IEnumerable<AgreementPacket> agreementPackets, CancellationToken token)
        {
            try
            { 
                Dictionary<string, AgreementPacketTeamMember> usersCache = new Dictionary<string, AgreementPacketTeamMember>();
                foreach (var ap in agreementPackets)
                {
                    foreach (var teamMemberMudId in ap.TeamMembers)
                    {
                        AgreementPacketTeamMember aptm;
                        if (!usersCache.TryGetValue(teamMemberMudId, out aptm))
                        {
                            var user = await graphApiClient.GetUserDataByMudIdAsync(teamMemberMudId, token);
                            aptm = new AgreementPacketTeamMember
                            {
                                DisplayName = user.DisplayName,
                                Email = user.Mail,
                                GivenName = user.GivenName,
                                MudId = user.MudId,
                                UserPrincipalName = user.UserPrincipalName
                            };
                            usersCache.Add(teamMemberMudId, aptm);
                        }
                        ap.TeamMembersExtended.Add(aptm);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"EnrichTeamMembersAsync error {ex.Message}");
                throw;
            }
        }
    }
}
