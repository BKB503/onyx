﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class AllianceSecurityService : IAllianceSecurityService
    {
        public const string GSKProprietary = "GSK Proprietary";

        ILogger<AllianceSecurityService> logger;
        IAllianceInformationProvider allianceInformationProvider;
        private readonly IContainerConfigurationProvider containerConfigurationProvider;
        public AllianceSecurityService(IAllianceInformationProvider allianceInformationProvider, IContainerConfigurationProvider containerConfigurationProvider, ILogger<AllianceSecurityService> logger)
        {
            this.allianceInformationProvider = allianceInformationProvider;
            this.logger = logger;
            this.containerConfigurationProvider = containerConfigurationProvider;
        }

        public async Task<AllianceAccessVerificationResult> CheckUserAccessAsync(string containerName, string userMudId, FileIndexModel fileIndexModel, CancellationToken token)
        {
            AllianceAccessVerificationResult result;
            var container = await containerConfigurationProvider.GetContainerByNameAsync(containerName, token);
            if (container == null)
            {
                logger.LogError($"{nameof(AllianceSecurityService)} no container found with name {containerName}");
                return null;
            }
            var allianceName = GetAllianceAgreementFromIndexModel(container, fileIndexModel);
            result = await VerifyAllianceAndReturnResultAsync(userMudId, container, allianceName, token);
            return result;
        }

        public async Task<ContainerContents> FilterContainerContentsAsync(ContainerContents containerContents, string userMudId, CancellationToken token)
        {
            if (containerContents == null || containerContents.Files == null || containerContents.Files.Count == 0)
                return containerContents;

            string containerName = containerContents.ContainerName;
            var container = await containerConfigurationProvider.GetContainerByNameAsync(containerName, token);
            if (container == null)
            {
                logger.LogError($"{nameof(AllianceSecurityService)} no container found with name {containerName}");
                return null;
            }
            for (int i = containerContents.Files.Count - 1; i >= 0; i--)
            {
                var file = containerContents.Files[i];
                var allianceName = GetAllianceAgreementFromFileResourceModel(container, file);
                var verification = await VerifyAllianceAndReturnResultAsync(userMudId, container, allianceName, token);
                if (verification?.Result == AllianceAccessVerificationEnum.NotAllowed)
                {
                    containerContents.Files.RemoveAt(i);
                    containerContents.RecordsReturned--;
                    containerContents.ResponseWasFiltered = true;
                }
                else
                {
                    containerContents.Files[i].AgreementPacketName = allianceName;
                    containerContents.Files[i].AllianceAccessVerification = verification?.Result;
                }
            }
            return containerContents;
        }

        public string GetAllianceAgreementFromIndexModel(ContainerResource container, FileIndexModel fileIndexModel)
        {
            var mt = fileIndexModel?.Metadata.FirstOrDefault(k => k.Key == container.Configuration.AllianceTagName);
            return mt?.Value;
        }

        public string GetAllianceAgreementFromFileResourceModel(ContainerResource container, FileResource fileResource)
        {
            var mt = fileResource?.Metadata.FirstOrDefault(k => k.Key == container.Configuration.AllianceTagName);
            return mt?.Value;
        }

        private async Task<AllianceAccessVerificationResult> VerifyAllianceAndReturnResultAsync(string userMudId, ContainerResource container, string allianceName, CancellationToken token)
        {
            AllianceAccessVerificationResult result = null;
            if (allianceName == null)
            {
                result = new AllianceAccessVerificationResult(allianceName, AllianceAccessVerificationEnum.AllowedNoAlliance);
            }
            else if (allianceName == GSKProprietary)
            {
                result = new AllianceAccessVerificationResult(allianceName, AllianceAccessVerificationEnum.AllowedGSKProprietary);
            }
            else
            {
                var allianceModel = await allianceInformationProvider.GetAllianceSecurityOfUserAsync(container, userMudId, allianceName, token);
                if (allianceModel == null)
                {
                    allianceModel = await allianceInformationProvider.GetOneAllianceAgreementDetails(container, allianceName, token);
                    if (allianceModel == null)
                    {
                        result = new AllianceAccessVerificationResult(allianceName, AllianceAccessVerificationEnum.AllowedNoAllianceFoundInDatabase);
                    }
                    else if (allianceModel.IsRestricted)
                    {
                        //restricted alliance - and user is not in that alliance
                        result = new AllianceAccessVerificationResult(allianceName, AllianceAccessVerificationEnum.NotAllowed, allianceModel)
                        {
                            ResultMessage = $"Alliance: {allianceName} is restricted and User: {userMudId} is not in that Alliance"
                        };
                    }
                    else
                    {
                        //not-restricted alliance 
                        result = new AllianceAccessVerificationResult(allianceName, AllianceAccessVerificationEnum.AllowedNotRestrictedAlliance, allianceModel);
                    }
                }
                else
                {
                    //user alliance
                    result = new AllianceAccessVerificationResult(allianceName, AllianceAccessVerificationEnum.AllowedUserAlliance, allianceModel);
                }
            }

            return result;
        }


    }

}
