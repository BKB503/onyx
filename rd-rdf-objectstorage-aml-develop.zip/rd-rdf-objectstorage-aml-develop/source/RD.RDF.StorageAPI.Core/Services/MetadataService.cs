﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class MetadataService : IMetadataService
    {
        private readonly string[] SystemDirectories = new[] { ".index", ".metadata" };
        private readonly IContainerConfigurationProvider containerConfigurationProvider;
        private readonly IFilesRepository filesRepository;
        private readonly IFoldersRepository foldersRepository;
        private readonly ISearchProviderFactory searchProviderFactory;
        private readonly ILogger<MetadataService> logger;

        public MetadataService(IContainerConfigurationProvider containerConfigurationProvider,
            IFilesRepository filesRepository,
            IFoldersRepository foldersRepository,
            ISearchProviderFactory searchProviderFactory,
            ILogger<MetadataService> logger)
        {
            this.containerConfigurationProvider = containerConfigurationProvider;
            this.filesRepository = filesRepository;
            this.foldersRepository = foldersRepository;
            this.searchProviderFactory = searchProviderFactory;
            this.logger = logger;
        }

        public async Task<PagedApiResponse<IList<string>>> GetAllContainersAsync(PaginationFilter filter, CancellationToken token)
        {
            var result = await containerConfigurationProvider.GetAllContainersAsync(token);
            if (result != null)
            {
                int.TryParse(filter.ContinuationToken, out int skip);
                var list = result.Select(el => el.ContainerName).Skip(skip).Take(filter.Limit).ToList();
                string nextToken = result.Count - (skip + filter.Limit) < 0 ? null : (skip + filter.Limit).ToString();
                return new PagedApiResponse<IList<string>>(list, list.Count, filter.ContinuationToken, nextToken, filter.Limit);
            }
            else
            {
                return new PagedApiResponse<IList<string>>("No data available", filter.ContinuationToken, filter.Limit);
            }
        }

        public Task<ContainerResource> GetContainerByNameAsync(string containerName, CancellationToken token)
        {
            return containerConfigurationProvider.GetContainerByNameAsync(containerName, token);
        }

        public async Task<ContainerContents> GetContainerContentsAsync(string containerName, string folderPath, PaginationFilter filter, CancellationToken token)
        {
            var container = await GetContainerByNameAsync(containerName, token);
            if (container == null)
            {
                return null;
            }
            var pagedData = await foldersRepository.GetAllFoldersAsync(container, folderPath, filter, token);
            if (pagedData.Succeeded)
            {
                var folderData = pagedData.Data;
                var results = new ContainerContents(containerName)
                {
                    Files = folderData.Files,
                    Folders = folderData.SubFolders,
                    ParentFolder = folderPath,
                    CurrentContinuationToken = filter.ContinuationToken,
                    Limit = filter.Limit,
                    RecordsReturned = pagedData.RecordsReturned,
                    MoreDataAvailable = pagedData.MoreDataAvailable,
                    NextContinuationToken = pagedData.NextContinuationToken,
                    Succeeded = pagedData.Succeeded,
                    Errors = pagedData.Errors,
                    Message = pagedData.Message
                };
                return FilterSystemData(results);
            }
            else
            {
                return new ContainerContents(containerName)
                {
                    CurrentContinuationToken = filter.ContinuationToken,
                    NextContinuationToken = pagedData.NextContinuationToken,
                    Limit = filter.Limit,
                    RecordsReturned = pagedData.RecordsReturned,
                    MoreDataAvailable = pagedData.MoreDataAvailable,
                    Succeeded = pagedData.Succeeded,
                    Errors = pagedData.Errors,
                    Message = pagedData.Message
                };
            }
        }

        public async Task<SearchFilesByTagResults> SearchFilesByTagsAsync(string containerName, string tagSearchQuery, CancellationToken token)
        {
            var container = await GetContainerByNameAsync(containerName, token);
            if (container is null)
            {
                return null;
            }
            var searchProvider = searchProviderFactory.GetSearchProvider(container);
            return await searchProvider.SearchFilesByTagsAsync(container, tagSearchQuery, token);
        }

        public async Task<FileResource> GetFileByNameAndVersionAsync(string containerName, string fileName, string folderName, string VersionId, CancellationToken token)
        {
            var container = await GetContainerByNameAsync(containerName, token);
            return await filesRepository.GetFileByNameAndVersionAsync(container, fileName, folderName, VersionId, token);
        }

        public string GetVersionIdFromIndexModel(FileIndexModel fileIndexModel, string fileGuid)
        {
            if (fileIndexModel is null)
            {
                return null;
            }

            if (string.IsNullOrEmpty(fileGuid))
            {
                return null;
            }

            string versionID = null;
            if (fileIndexModel.FileGuid == fileGuid)
            {
                versionID = fileIndexModel.FileVersionId;
            }
            else
            {
                foreach (var version in fileIndexModel.Versions)
                {
                    if (version.FileGuid.Equals(fileGuid))
                    {
                        versionID = version.FileVersionId;
                    }
                }
            }

            return versionID;
        }

        public FileResource GetFileResourceFromIndexModel(FileIndexModel fileIndexModel, string fileGuid)
        {
            if (fileIndexModel is null)
            {
                return null;
            }

            FileResource fileResource = new FileResource(fileIndexModel.FileName)
            {
                FileName = fileIndexModel.FileName,
                FilePath = fileIndexModel.FilePath,
                FileBlobType = fileIndexModel.FileBlobType,
                FolderName = fileIndexModel.FolderName,
                FileContentType = fileIndexModel.FileContentType,

                FileGuid = fileIndexModel.FileGuid,
                FileSize = fileIndexModel.FileSize,
                FileETag = fileIndexModel.FileETag,
                FileContentHash = fileIndexModel.FileHash,
                FileVersionId = fileIndexModel.FileVersionId,
                Metadata = new MetadataDictionary(fileIndexModel.Metadata),
                CreationTime = fileIndexModel.CreationTime,
                ModifiedTime = fileIndexModel.ModificationDate,


                FileVersions = fileIndexModel.Versions?.Select(item => new VersionDetails
                {
                    CreationTime = item.CreationTime,
                    FileETag = item.FileETag,
                    FileGuid = item.FileGuid,
                    FileSize = item.FileSize,
                    IsLatestVersion = item.IsLatestVersion,
                    FileVersionId = item.FileVersionId,
                    FileContentHash = item.FileHash
                }).ToList()

            };
            var versionSelected = fileIndexModel?.Versions.FirstOrDefault(ver => ver.FileGuid == fileGuid);
            if (versionSelected != null)
            {
                //we need to replace the root object with Version information
                fileResource.FileGuid = versionSelected.FileGuid;
                fileResource.FileSize = versionSelected.FileSize;
                fileResource.FileETag = versionSelected.FileETag;
                fileResource.FileContentHash = versionSelected.FileHash;
                fileResource.FileVersionId = versionSelected.FileVersionId;
                fileResource.Metadata = new MetadataDictionary(versionSelected.Metadata);
                fileResource.CreationTime = versionSelected.CreationTime;
                fileResource.ModifiedTime = versionSelected.CreationTime;
            }
            return fileResource;
        }

        public async Task UpdateTagsAsync(string containerName, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken)
        {
            var container = await containerConfigurationProvider.GetContainerByNameAsync(containerName, cancellationToken);
            if (container == null)
            {
                // log error
                return;
            }
            await filesRepository.UpdateTagsAsync(container, file, tags, cancellationToken);
        }

        public ContainerContents FilterSystemData(ContainerContents inputData)
        {
            if (inputData != null)
            {
                inputData.Folders = inputData?.Folders.Where(folder => !SystemDirectories.Any(el => folder.FolderName.StartsWith(el))).ToList();
                inputData.Files = inputData?.Files.Where(file => !SystemDirectories.Any(el => file.FolderName != null && file.FolderName.StartsWith(el))).ToList();
                inputData.RecordsReturned = inputData.Folders.Count + inputData.Files.Count;
            }
            return inputData;
        }

        
    }
}
