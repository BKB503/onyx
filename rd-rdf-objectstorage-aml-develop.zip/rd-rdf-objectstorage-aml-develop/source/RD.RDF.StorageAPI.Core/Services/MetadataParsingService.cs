﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.IO;
using System.Text;
using System.Text.Json;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class MetadataParsingService : IMetadataParsingService
    {
        private readonly JsonSerializerOptions options;
        ILogger<MetadataParsingService> logger;
        public MetadataParsingService(ILogger<MetadataParsingService> logger)
        {
            this.logger = logger;
            options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                WriteIndented = true
            };
        }

        public MetadataModel ReadTheMetadataJsonFile(Stream metadataStream)
        {
            MetadataModel result = null;
            try
            {
                result = JsonSerializer.Deserialize<MetadataModel>(metadataStream, options);
                if (result.MetaDataDictionary == null)
                {
                    metadataStream.Seek(0, SeekOrigin.Begin);
                    result.MetaDataDictionary = JsonSerializer.Deserialize<MetadataDictionary>(metadataStream, options);
                }
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Error occurred while deserializing metadata file");
            }
            return result;
        }

        public MemoryStream SerializeToStream(MetadataModel metadataModel)
        {
            string json = JsonSerializer.Serialize(metadataModel, options);
            var buffer = Encoding.UTF8.GetBytes(json);
            MemoryStream stream = new MemoryStream(buffer);
            return stream;
        }
    }
}
