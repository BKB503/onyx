﻿using Microsoft.AspNetCore.Http;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class UserRepository : IUserRepository
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserRepository(IHttpContextAccessor httpContextAccessor) =>
            _httpContextAccessor = httpContextAccessor;

        public string GetCurrentUserClientId()
        {
            string clientID = null;
            if (_httpContextAccessor.HttpContext != null)
            {
                clientID = _httpContextAccessor.HttpContext.User.FindFirst(c => c.Type == "aud")?.Value;
            }

            return clientID;
        }
    }
}
