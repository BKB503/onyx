﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class IndexingService : IIndexingService
    {
        private readonly IMetadataService metadataService;
        private readonly IFilesRepository filesRepository;
        private readonly IFoldersRepository foldersRepository;
        private readonly ISearchProviderFactory searchProviderFactory;
        private IIndexingFacade fileIndexingFacade;

        public IndexingService(IMetadataService metadataService, IIndexingFacade fileIndexingFacade)
        {
            this.metadataService = metadataService;
            this.fileIndexingFacade = fileIndexingFacade;
        }
        public async Task<FileIndexModel> WriteFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, string containerName, CancellationToken token)
        {
            if (fileResource is null)
            {
                throw new ArgumentNullException(nameof(fileResource));
            }
            // if the file exists - read file /modify and pass it along
            // if file does not exists - create the model
            if (fileIndexModel == null)
            {
                fileIndexModel = CreateFileIndexModel(fileResource, containerName);
            }
            else
            {
                fileIndexModel = AddNewVersion(fileResource, fileIndexModel, containerName);
            }
            var container = await metadataService.GetContainerByNameAsync(containerName, token);
            await fileIndexingFacade.IndexTheFileAsync(fileResource, fileIndexModel, container, token);
            return fileIndexModel;
        }



        public async Task<FileResource> UpdateFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, string containerName, CancellationToken token)
        {
            if (fileResource is null)
            {
                throw new ArgumentNullException(nameof(fileResource));
            }

            if (fileIndexModel is null)
            {
                throw new ArgumentNullException(nameof(fileIndexModel));
            }

            var container = await metadataService.GetContainerByNameAsync(containerName, token);

            // updating file metadata with new value
            if (fileIndexModel.FileGuid == fileResource.FileGuid)
            {
                fileIndexModel.Metadata = fileResource.Metadata.Select(el => new MetadataKeyValue() { Key = el.Key, Value = el.Value }).ToList();
            }
            var metadata = fileResource.Metadata.Select(el => new MetadataKeyValue() { Key = el.Key, Value = el.Value }).ToList();
            fileIndexModel.Versions.Where(ver => ver.FileGuid == fileResource.FileGuid).ToList().ForEach(item => item.Metadata = metadata);

            var result = await fileIndexingFacade.UpdateIndexedFileAsync(fileResource, fileIndexModel, container, token);
            return result;
        }

        private FileIndexModel CreateFileIndexModel(FileResource fileResource, string containerName)
        {
            FileIndexModel fileIndexModel = new FileIndexModel
            {
                FileName = fileResource.FileName,
                FolderName = fileResource.FolderName,
                FilePath = fileResource.FilePath,
                Container = containerName,
                FileBlobType = fileResource.FileBlobType,
                FileContentType = fileResource.FileContentType,
                FileVersionId = fileResource.FileVersionId,
                FileGuid = fileResource.FileGuid,
                FileHash = fileResource.FileContentHash,
                FileETag = fileResource.FileETag,
                FileSize = fileResource.FileSize,
                CreationTime = fileResource.CreationTime,
                ModificationDate = fileResource.ModifiedTime,
                Metadata = fileResource.Metadata.Select(el => new MetadataKeyValue() { Key = el.Key, Value = el.Value }).ToList(),
            };

            List<Versions> versions = new List<Versions>();
            int count = 0;
            foreach (var item in fileResource.FileVersions)
            {
                var versionModel = new Versions
                {
                    FileName = fileResource.FileName,
                    FolderName = fileResource.FolderName,
                    FilePath = fileResource.FilePath,
                    Container = containerName,
                    FileBlobType = fileResource.FileBlobType,
                    FileContentType = fileResource.FileContentType,
                    FileVersionId = item.FileVersionId,
                    FileGuid = item.FileGuid,
                    FileHash = item.FileContentHash,
                    FileSize = item.FileSize,
                    FileETag = item.FileETag,
                    CreationTime = item.CreationTime,
                    IsLatestVersion = item.IsLatestVersion,
                    VersionNumber = count,
                    Metadata = fileResource.Metadata.Select(el => new MetadataKeyValue() { Key = el.Key, Value = el.Value }).ToList()
                };
                count++;
                versions.Add(versionModel);
            }

            fileIndexModel.Versions = versions;
            foreach (var item in versions.Where(x => x.IsLatestVersion == true))
            {
                item.FileGuid = fileResource.FileGuid;
            }

            return fileIndexModel;
        }
        private FileIndexModel AddNewVersion(FileResource fileResource, FileIndexModel fileIndexModel, string containerName)
        {
            var metadata = fileResource.Metadata.Select(el => new MetadataKeyValue() { Key = el.Key, Value = el.Value }).ToList();
            fileIndexModel.Versions.ForEach(item => item.IsLatestVersion = false);

            var version = new Versions
            {
                FileName = fileResource.FileName,
                FolderName = fileResource.FolderName,
                FilePath = fileResource.FilePath,
                Container = containerName,
                FileBlobType = fileResource.FileBlobType,
                FileContentType = fileResource.FileContentType,
                FileVersionId = fileResource.FileVersionId,
                FileGuid = fileResource.FileGuid,
                FileHash = fileResource.FileContentHash,
                FileETag = fileResource.FileETag,
                FileSize = fileResource.FileSize,
                CreationTime = fileResource.CreationTime,
                IsLatestVersion = true,
                VersionNumber = fileIndexModel.Versions.Count,
                Metadata = metadata
            };

            fileIndexModel.FileVersionId = fileResource.FileVersionId;
            fileIndexModel.FileGuid = fileResource.FileGuid;
            fileIndexModel.FileHash = fileResource.FileContentHash;
            fileIndexModel.FileETag = fileResource.FileETag;
            fileIndexModel.ModificationDate = fileResource.ModifiedTime;
            fileIndexModel.CreationTime = fileResource.CreationTime;
            fileIndexModel.Metadata = metadata;
            fileIndexModel.Versions.Add(version);
            return fileIndexModel;
        }
    }
}
