﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class ReindexingService : BackgroundService, IReindexingService
    {
        private readonly IContainerConfigurationProvider containerConfigurationProvider;
        private readonly IDataStorageRepository dataStorageRepository;
        private readonly IFoldersRepository foldersRepository;
        private readonly IIndexingService indexingService;
        private readonly IBackgroundTaskQueue taskQueue;
        private readonly IMetadataService metadataService;
        private readonly ILogger<ReindexingService> logger;


        public ReindexingService(IContainerConfigurationProvider containerConfigurationProvider,
                                 IDataStorageRepository dataStorageRepository,
                                 IFoldersRepository foldersRepository,
                                 IIndexingService indexingService,
                                 IBackgroundTaskQueue taskQueue,
                                 IMetadataService metadataService,
                                 ILogger<ReindexingService> logger)
        {
            this.containerConfigurationProvider = containerConfigurationProvider;
            this.dataStorageRepository = dataStorageRepository;
            this.foldersRepository = foldersRepository;
            this.indexingService = indexingService;
            this.taskQueue = taskQueue;
            this.metadataService = metadataService;
            this.logger = logger;
        }

        public async Task<ReindexingStatusModel> GetReindexingStatusAsync(string taskId, CancellationToken cancellationToken)
        {
            return await taskQueue.GetTaskStatusAsync(taskId, cancellationToken);
        }

        public async Task<ReindexingStatusModel> StartReindexingProcessAsync(string containerName, bool useFileVersionsAsGuids, CancellationToken cancellationToken)
        {
            return await taskQueue.QueueBackgroundWorkItemAsync((taskId, cancellationToken) => ReindexContainerAsync(taskId, containerName, useFileVersionsAsGuids, cancellationToken));
        }

        private async ValueTask ReindexContainerAsync(string taskId, string containerName, bool useFileVersionsAsGuids, CancellationToken token)
        {
            try
            {
                var container = await containerConfigurationProvider.GetContainerByNameAdminAsync(containerName, token);
                if (container == null)
                {
                    var errorStatus = await GetReindexingStatusAsync(taskId, token);
                    errorStatus.Status = ReindexingStatusEnum.Error;
                    errorStatus.Message = $"Container={containerName} does not exists";
                    await SetReindexingStatusAsync(taskId, errorStatus, token);
                }
                var statusModel = await GetReindexingStatusAsync(taskId, token);
                statusModel.ContainerName = container.ContainerName;
                statusModel.Status = ReindexingStatusEnum.Started;
                statusModel.Message = $"Started container={container.ContainerName} reindexing";
                await SetReindexingStatusAsync(taskId, statusModel, token);
                var data = await ReadAllDataFromContainer(container, token);
                statusModel.Status = ReindexingStatusEnum.InProgress;
                statusModel.Message = $"Read all files from container={container.ContainerName} files count={data.Files.Count}";
                await SetReindexingStatusAsync(taskId, statusModel, token);
                await ReindexData(taskId, data, useFileVersionsAsGuids, token);
                statusModel.Status = ReindexingStatusEnum.Finished;
                statusModel.Message = $"Reindexing from container={container.ContainerName} finished";
                await SetReindexingStatusAsync(taskId, statusModel, token);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Error in ReindexContainerAsync(containerName={containerName})");
                var errorStatus = await GetReindexingStatusAsync(taskId, token);
                errorStatus.Status = ReindexingStatusEnum.Error;
                errorStatus.Message = $"Reindexing from container={containerName} error {ex.ToString()}";
                await SetReindexingStatusAsync(taskId, errorStatus, token);
            }
        }

        private async Task ReindexData(string taskId, ContainerData containerData, bool useFileVersionsAsGuids, CancellationToken token)
        {
            var fileToIndex = containerData.Files.Where(file => containerData.IndexFiles.ContainsKey(file.Value.FilePath.ToLower() + ".json") == false).Select(kv => kv.Value).ToList();
            var statusModel = await GetReindexingStatusAsync(taskId, token);
            statusModel.Status = ReindexingStatusEnum.InProgress;
            statusModel.Message = $"Reindexing the container={containerData.ContainerName}. Files to index {fileToIndex.Count}";
            await SetReindexingStatusAsync(taskId, statusModel, token);
            int i = 0;
            foreach (var file in fileToIndex)
            {
                if (token.IsCancellationRequested)
                    return;
                // no index present
                await ReindexOneFileAsync(containerData.ContainerName, useFileVersionsAsGuids, file, token);
                statusModel.Progress = i++ / (decimal)fileToIndex.Count * 100m;
                await SetReindexingStatusAsync(taskId, statusModel, token);
            }
        }

        public async Task ReindexOneFileAsync(string containerName, bool useFileVersionsAsGuids, FileResource file, CancellationToken token)
        {
            var fileInfo = await metadataService.GetFileByNameAndVersionAsync(containerName, file.FileName, file.FolderName, null, token);
            if (useFileVersionsAsGuids)
            {
                fileInfo.FileGuid = file.FileVersionId;
                foreach (var version in fileInfo.FileVersions)
                {
                    version.FileGuid = version.FileVersionId;
                }
            }
            else
            {
                fileInfo.FileGuid = Guid.NewGuid().ToString();
                foreach (var version in fileInfo.FileVersions)
                {
                    if (version.FileVersionId == fileInfo.FileVersionId)
                    {
                        version.FileGuid = fileInfo.FileGuid;
                    }
                    else
                    {
                        version.FileGuid = Guid.NewGuid().ToString();
                    }
                }
            }

            await indexingService.WriteFileIndexAsync(fileInfo, null, containerName, token);
            await metadataService.UpdateTagsAsync(containerName, fileInfo, new Dictionary<string, string> { { Common.FileGuid, fileInfo.FileGuid } }, token);
        }

        private async Task<ContainerData> ReadAllDataFromContainer(ContainerResource container,
                                                                                 CancellationToken cancellationToken)
        {
            var result = await GetFolderData(container, null, cancellationToken);
            return result;
        }

        private async Task<ContainerData> GetFolderData(ContainerResource container, string folder, CancellationToken cancellationToken)
        {
            var result = new ContainerData() { ContainerName = container.ContainerName };
            PagedApiResponse<FolderResource> pageResponse;
            var filter = new PaginationFilter();
            do
            {
                pageResponse = await foldersRepository.GetAllFoldersAsync(container, folder, filter, cancellationToken);
                foreach (var file in pageResponse.Data.Files)
                {
                    if (file.FilePath.StartsWith(".index/", StringComparison.CurrentCultureIgnoreCase))
                    {
                        result.IndexFiles.Add(file.FilePath.Substring(7).ToLower(), file);
                    }
                    else if (file.FilePath.StartsWith(".metadata/", StringComparison.CurrentCultureIgnoreCase))
                    {
                        result.MetadataFiles.Add(file.FilePath.Substring(10).ToLower(), file);
                    }
                    else
                    {
                        result.Files.Add(file.FilePath.ToLower(), file);
                    }
                }
                //directory browse
                foreach (var subFolder in pageResponse.Data.SubFolders)
                {
                    // call it recursively
                    var subFolderResult = await GetFolderData(container, subFolder.FolderName, cancellationToken);
                    if (subFolderResult != null)
                    {
                        result.Merge(subFolderResult);
                    }
                }
                filter.ContinuationToken = pageResponse.NextContinuationToken;
            }
            while (pageResponse.MoreDataAvailable.GetValueOrDefault());
            return result;
        }


        private async ValueTask SetReindexingStatusAsync(string taskKey, ReindexingStatusModel model, CancellationToken cancellationToken)
        {
            await taskQueue.SetTaskStatusAsync(taskKey, model, cancellationToken);
        }


        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            logger.LogInformation($"ReindexingService started");
            await RunBackgroundProcessingAsync(stoppingToken);
        }

        private async Task RunBackgroundProcessingAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var workItem = await taskQueue.DequeueAsync(stoppingToken);
                try
                {
                    logger.LogInformation($"ReindexingService Task {workItem.TaskId} started");
                    await workItem.Task(workItem.TaskId, stoppingToken);
                    logger.LogInformation($"ReindexingService Task {workItem.TaskId} finished");
                }
                catch (Exception ex)
                {
                    logger.LogError(ex, $"Error occurred executing Task {workItem.TaskId}");
                }
            }
        }
        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            logger.LogInformation($"ReindexingService is stopping");
            await base.StopAsync(stoppingToken);
        }

        protected class ContainerData
        {
            public string ContainerName { get; set; }

            public Dictionary<string, FileResource> Files { get; } = new Dictionary<string, FileResource>();

            public Dictionary<string, FileResource> IndexFiles { get; } = new Dictionary<string, FileResource>();

            public Dictionary<string, FileResource> MetadataFiles { get; } = new Dictionary<string, FileResource>();

            public void Merge(ContainerData inputData)
            {
                Files.MergeDictionary(inputData.Files);
                IndexFiles.MergeDictionary(inputData.IndexFiles);
                MetadataFiles.MergeDictionary(inputData.MetadataFiles);
            }
        }





    }
    public static class DictionaryExtensionsClass
    {
        public static void MergeDictionary<TK, TV>(this Dictionary<TK, TV> destDict, Dictionary<TK, TV> inputDict)
        {
            if (destDict == null || inputDict == null)
                return;

            foreach (var kv in inputDict)
            {
                destDict.TryAdd(kv.Key, kv.Value);
            }
        }
    }

}
