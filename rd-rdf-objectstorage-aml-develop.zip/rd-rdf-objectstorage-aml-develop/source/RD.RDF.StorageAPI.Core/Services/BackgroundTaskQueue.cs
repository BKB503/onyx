﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Core.Services
{
    public class BackgroundTaskQueue : IBackgroundTaskQueue
    {
        private readonly Channel<ReindexingTaskModel> _queue;

        private readonly ConcurrentDictionary<string, ReindexingStatusModel> dictionary = new ConcurrentDictionary<string, ReindexingStatusModel>();

        public BackgroundTaskQueue(int capacity)
        {

            // Capacity should be set based on the expected application load and
            // number of concurrent threads accessing the queue.            
            // BoundedChannelFullMode.Wait will cause calls to WriteAsync() to return a task,
            // which completes only when space became available. This leads to backpressure,
            // in case too many publishers/calls start accumulating.
            var options = new BoundedChannelOptions(capacity)
            {
                FullMode = BoundedChannelFullMode.Wait
            };
            _queue = Channel.CreateBounded<ReindexingTaskModel>(options);
        }

        public async ValueTask<ReindexingStatusModel> QueueBackgroundWorkItemAsync(Func<string, CancellationToken, ValueTask> workItem)
        {
            if (workItem == null)
            {
                throw new ArgumentNullException(nameof(workItem));
            }


            var sm = new ReindexingStatusModel
            {
                TaskKey = Guid.NewGuid().ToString(),
                Status = ReindexingStatusEnum.Created
            };
            dictionary.TryAdd(sm.TaskKey, sm);
            await _queue.Writer.WriteAsync(new ReindexingTaskModel { Task = workItem, TaskId = sm.TaskKey });
            return sm;
        }

        public async ValueTask<ReindexingTaskModel> DequeueAsync(CancellationToken cancellationToken)
        {
            var workItem = await _queue.Reader.ReadAsync(cancellationToken);
            dictionary.TryGetValue(workItem.TaskId, out ReindexingStatusModel model);
            model.Status = ReindexingStatusEnum.Started;
            dictionary.TryUpdate(workItem.TaskId, model, model);
            return workItem;
        }


        public async ValueTask<ReindexingStatusModel> GetTaskStatusAsync(string taskKey, CancellationToken cancellationToken)
        {
            if (!dictionary.TryGetValue(taskKey, out ReindexingStatusModel model))
            {
                return ReindexingStatusModel.CreateEmpty(taskKey);
            }
            return model;
        }

        public ValueTask SetTaskStatusAsync(string taskId, ReindexingStatusModel model, CancellationToken cancellationToken)
        {
            if (!dictionary.TryGetValue(taskId, out ReindexingStatusModel oldmodel))
            {
                dictionary.TryUpdate(taskId, model, oldmodel);
            }
            else
            {
                dictionary.TryAdd(taskId, model);
            }
            return ValueTask.CompletedTask;
        }
    }

}
