﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class IndexingFactory : IIndexingFactory
    {
        public static Dictionary<IndexingType, IIndexingRespository> indexingMethods = new Dictionary<IndexingType, IIndexingRespository>();

        public IndexingFactory(IEnumerable<IIndexingRespository> indexingRespositories)
        {

            foreach (var repo in indexingRespositories)
            {
                indexingMethods.Add(repo.indexingType, repo);
            }
        }

        public Dictionary<IndexingType, IIndexingRespository> GetAllIndexingRepositories()
        {
            return indexingMethods;
        }
    }
}
