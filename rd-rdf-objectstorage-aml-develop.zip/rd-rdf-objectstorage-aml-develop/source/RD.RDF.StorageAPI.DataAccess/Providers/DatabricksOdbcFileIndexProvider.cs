﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class DatabricksOdbcFileIndexProvider : OdbcConnectionHelper, IStorageIndexProvider
    {
        private readonly ILogger<DatabricksOdbcFileIndexProvider> logger;
        private string DatabaseName = "suplementarydata";
        private string DataLakeName = "silverlake";

        public DatabricksOdbcFileIndexProvider(ILogger<DatabricksOdbcFileIndexProvider> logger) : base(logger)
        {
            this.logger = logger;
        }


        public async Task<FileIndexModel> GetFileByGuidAsync(ContainerResource container, string fileGuid, CancellationToken cancellationToken)
        {
            FileIndexModel model = null;
            string sql = $"select * from {DatabaseName}.{DataLakeName} where Container = '{container.ContainerName}' and FileGuid = '{fileGuid}' order by CreationTime desc limit 1";
            using OdbcConnection connection = CreateOpenedConnection(container);
            if (connection != null)
            {
                using var cmd = CreateCommand(connection, sql);
                using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
                await reader.ReadAsync(cancellationToken);
                if (reader.HasRows)
                {
                    model = (FileIndexModel)ReadOneRow(reader);
                }
            }
            return model;
        }

        public async Task<List<FileIndexModel>> GetFolderIndexAsync(ContainerResource container, string folderName, CancellationToken cancellationToken)
        {
            List<FileIndexModel> results = new List<FileIndexModel>();
            string sql = string.Empty;
            if (string.IsNullOrEmpty(folderName))
            {
                sql = $"select * from {DatabaseName}.{DataLakeName} where Container = '{container.ContainerName}' and (FolderName is null or FolderName like '')";
            }
            else
            {
                sql = $"select * from {DatabaseName}.{DataLakeName} where Container = '{container.ContainerName}' and FolderName like '{folderName}'";
            }
            using OdbcConnection connection = CreateOpenedConnection(container);
            if (connection != null)
            {
                using var cmd = CreateCommand(connection, sql);
                using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync())
                {
                    var row = (FileIndexModel)ReadOneRow(reader);
                    results.Add(row);
                }
            }
            return results;
        }

        private OdbcConnection CreateOpenedConnection(ContainerResource container)
        {
            OdbcConnection conn = null;
            try
            {
                conn = new OdbcConnection(container.Configuration.IndexingConfiguration.IndexOdbcConnectionString);
                conn.Open();
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message, ex);
                conn = null;
            }
            return conn;
        }

        private OdbcCommand CreateCommand(OdbcConnection conn, string sql)
        {
            return new OdbcCommand(sql, conn);

        }

        public FileIndexModel ReadOneRow(DbDataReader reader)
        {
            string metadata = ReadColumn(reader, "Metadata");
            string ct = ReadColumn(reader, "CreationTime");
            DateTimeOffset.TryParse(ct, out DateTimeOffset creationTime);
            var fim = new FileIndexModel
            {
                Metadata = JsonSerializer.Deserialize<List<MetadataKeyValue>>(metadata),
                Container = ReadColumn(reader, "Container"),
                FileBlobType = ReadColumn(reader, "FileBlobType"),
                FileContentType = ReadColumn(reader, "FileContentType"),
                FileGuid = ReadColumn(reader, "FileGuid"),
                FileHash = ReadColumn(reader, "FileHash"),
                FileName = ReadColumn(reader, "FileName"),
                FilePath = ReadColumn(reader, "FilePath"),
                FileVersionId = ReadColumn(reader, "FileVersionId"),
                FolderName = ReadColumn(reader, "FolderName"),
                CreationTime = creationTime
            };
            return fim;
        }
    }
}
