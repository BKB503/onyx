﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class FileIndexingFacade : IIndexingFacade
    {
        ILogger<FileIndexingFacade> logger;
        IIndexingFactory indexingFactory;
        IIndexingRespository respository;
        private Dictionary<IndexingType, IIndexingRespository> indexingRepos;
        public FileIndexingFacade(ILogger<FileIndexingFacade> logger, IIndexingFactory indexingFactory)
        {
            this.logger = logger;
            this.indexingFactory = indexingFactory;
            indexingRepos = this.indexingFactory.GetAllIndexingRepositories();
        }

        /// <summary>
        /// Function to upload the index file and also to send the indexing details to Kafka topic
        /// </summary>
        /// <param name="fileResource"></param>
        /// <param name="fileIndexModel"></param>
        /// <param name="container"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task IndexTheFileAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token)
        {
            foreach (var repo in indexingRepos)
            {
                //logger.LogInformation($"Executing the indexing on {repo.Key}");
                await repo.Value.WriteFileIndexAsync(fileResource, fileIndexModel, container);
            }
        }

        /// <summary>
        /// Function to update the metadata details in the index file and also to send the updated indexing details to Kafka topic
        /// </summary>
        /// <param name="fileResource"></param>
        /// <param name="fileIndexModel"></param>
        /// <param name="container"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task<FileResource> UpdateIndexedFileAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token)
        {
            FileResource result = null;

            foreach (var repo in indexingRepos)
            {
                // logger.LogInformation($"Executing the indexing on {repo.Key}");
                result = await respository.UpdateFileIndexAsync(fileResource, fileIndexModel, container, token);
            }

            return result;
        }
    }
}
