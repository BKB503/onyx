﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using System.Collections.Generic;
using System.Linq;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class MetadataCollectionValidationProviderFactory : IMetadataCollectionValidationProviderFactory
    {
        private readonly Dictionary<StorageContainerType, IMetadataCollectionValidationProvider> ProvidersDictionary;
        private readonly DefaultMetadataCollectionValidationProvider defaultProvider;

        public MetadataCollectionValidationProviderFactory(IEnumerable<IMetadataCollectionValidationProvider> providers, DefaultMetadataCollectionValidationProvider defaultProvider)
        {
            this.defaultProvider = defaultProvider;
            ProvidersDictionary = providers == null
                ? new Dictionary<StorageContainerType, IMetadataCollectionValidationProvider>()
                : providers.ToDictionary(key => key.StorageClientType);
        }

        public IMetadataCollectionValidationProvider GetProvider(StorageContainerType storageContainerType)
        {
            if (ProvidersDictionary.TryGetValue(storageContainerType, out IMetadataCollectionValidationProvider provider))
            {
                return provider;
            }
            return defaultProvider;
        }
    }

}
