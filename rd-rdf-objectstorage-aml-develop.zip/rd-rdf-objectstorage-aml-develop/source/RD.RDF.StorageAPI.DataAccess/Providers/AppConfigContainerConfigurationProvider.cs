﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class AppConfigContainerConfigurationProvider : IContainerConfigurationProvider
    {
        private readonly StorageConfiguration Config;
        private readonly IUserRepository userRepository;
        private readonly ILogger<ContainerConfigurationProvider> logger;
        private readonly KafkaConfiguration indexingConfig;

        public AppConfigContainerConfigurationProvider(IOptions<StorageConfiguration> options, IConfiguration configuration,
            IUserRepository userRepository, ILogger<ContainerConfigurationProvider> logger)
        {
            this.userRepository = userRepository;
            this.logger = logger;
            this.Config = options.Value;

            foreach (var item in this.Config.Indexing)
            {
                item.EventHubKey = configuration["RDFKafkaKey"];
                item.EventHubConnectionString = configuration["RDFKafkaConnectionString"];
                item.Topic = configuration["RDFKafkaTopicFiles"];
                item.KafkaServers = configuration["RDFKafkaServers"];
                item.IndexOdbcConnectionString = configuration["IndexOdbcConnectionString"];
                item.SaslUsername = configuration["RDFKafkaUserName"];
                indexingConfig = item;
                break;
            }
            foreach (var item in this.Config.Containers)
            {
                item.ContainerKey = configuration[$"{item.Name}-ContainerKey"];
                item.ContainerConnectionString = configuration[$"{item.Name}-ContainerConnectionString"];
                item.IndexingConfiguration = indexingConfig;
            }
        }

        public Task<IList<ContainerResource>> GetAllContainersAdminAsync(CancellationToken token = default)
        {

            if (Config.Containers == null)
                return Task.FromResult<IList<ContainerResource>>(null);        
            var allContainerResources = Config.Containers.Select(Convert).ToList();         
            return Task.FromResult<IList<ContainerResource>>(allContainerResources);
        }

        public async Task<IList<ContainerResource>> GetAllContainersAsync(CancellationToken token = default)
        {
            var allContainerResources = await GetAllContainersAdminAsync(token);

            string clientId = userRepository.GetCurrentUserClientId();
            IList<ContainerResource> allowedContainers = new List<ContainerResource>();
            foreach (var container in allContainerResources)
            {
                if (container.Configuration.ValidateAudience)
                {
                    if (container.Configuration.ValidAudiences == null)
                    {
                        logger.LogError($"ValidAudiences collection for container : {container.ContainerName} is empty");
                    }
                    else
                    {
                        if (container.Configuration.ValidAudiences.Contains(clientId))
                        {
                            allowedContainers.Add(container);
                        }
                        else
                        {
                            logger.LogWarning($"ClientID {clientId} don't have access to container :{container.ContainerName}");
                        }
                    }
                }
                else
                {
                    allowedContainers.Add(container);
                }
            }

            return allowedContainers;
        }

        public async Task<ContainerResource> GetContainerByNameAsync(string containerName, CancellationToken token = default)
        {
            var container = await GetContainerByNameAdminAsync(containerName, token);
            string clientId = userRepository.GetCurrentUserClientId();
            if (container.Configuration.ValidateAudience && !container.Configuration.ValidAudiences.Contains(clientId))
            {
                logger.LogWarning($"ClientID {clientId} don't have access to container :{container.ContainerName}");
                return null;
            }

            return container;
        }
        public Task<ContainerResource> GetContainerByNameAdminAsync(string containerName, CancellationToken token = default)
        {
            if (Config.Containers == null)
                return Task.FromResult<ContainerResource>(null);
            var item = this.Config.Containers.FirstOrDefault(el => el.Name == containerName);
            if (item == null)
                return Task.FromResult<ContainerResource>(null);           
            var container = Convert(item);            
            return Task.FromResult(container);
        }

        private ContainerResource Convert(StorageContainerConfiguration item)
        {
            return new ContainerResource(item.Name) { Configuration = item , IndexingConfiguration = indexingConfig};
        }
    }
}

