﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StoragePortal.Contracts.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class ContainerConfigurationProvider : IContainerConfigurationProvider
    {
        private readonly IMemoryCache cache;
        private readonly IServiceScopeFactory scopeFactory;


        private readonly StorageConfiguration Config;
   
        private readonly IUserRepository userRepository;
        private readonly ILogger<ContainerConfigurationProvider> logger;
        private List<ContainerResource> allContainerResources;
        private const string ContainerResourcesCacheKey = "containerResources";

        public ContainerConfigurationProvider
            (
                IOptions<StorageConfiguration> options,
                IUserRepository userRepository,
                ILogger<ContainerConfigurationProvider> logger,
                IServiceScopeFactory scopeFactory, IMemoryCache cache
            )
        {
            this.scopeFactory = scopeFactory;         
            this.userRepository = userRepository;
            this.logger = logger;
            Config = options.Value;
            this.cache = cache;
        }

        public async Task<IList<ContainerResource>> GetAllContainersAdminAsync(CancellationToken token = default)
        {
            if (!cache.TryGetValue(ContainerResourcesCacheKey, out allContainerResources))
            {
                var indexList = new List<KafkaConfiguration>();
                var containerList = new List<StorageContainerConfiguration>();
                using (var scope = scopeFactory.CreateScope())
                {
                    var repository = scope.ServiceProvider.GetRequiredService<IContainersRepository>();
                    var containers = await repository.GetAllStorageContainersAsync(token);
                    if (containers != null)
                    {
                        foreach (var item in containers)
                        {
                            var container = new StorageContainerConfiguration
                            {
                                Name = item.Name,
                                Type = (StorageContainerType)(int)item.ContainerType,
                                ContainerAccountName = item.ContainerAccountName,
                                ContainerAccountUrl = item.ContainerAccountUrl,
                                ContainerName = item.ContainerName,
                                ContainerConnectionString = item.ContainerConnectionString,
                                ContainerKey = item.ContainerKey,
                                AllianceTagName = item.AllianceTagName,
                                ValidateAudience = item.ValidateAudience,
                                ProxyUrl = item.ProxyUrl,
                                ContainerUserId = item.ContainerUserId,
                                ValidAudiences = item?.ValidAudiences?.Select(va => va.ValidAudience)?.ToArray(),
                            };
                            if (item.Indexing != null)
                            {
                                var index = new KafkaConfiguration
                                {
                                    Topic = item.Indexing.RDFKafkaTopic,
                                    Type = item.Indexing.Type,
                                    EventHubConnectionString = item.Indexing.RDFKafkaConnectionString,
                                    EventHubKey = item.Indexing.RDFKafkaKey,
                                    KafkaServers = item.Indexing.KafkaServers,
                                    SaslUsername = item.Indexing.SaslUsername,
                                    IndexOdbcConnectionString = item.Indexing.IndexOdbcConnectionString,

                                };

                                container.IndexingConfiguration = index;
                            }

                            containerList.Add(container);
                        }
                    }
                    else
                    {
                        return null;
                    }
                }

                allContainerResources = containerList.Select(Convert).ToList();
                cache.Set(ContainerResourcesCacheKey, allContainerResources, new MemoryCacheEntryOptions() { AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(Config.CacheTimeSeconds) });
            }

            return allContainerResources;
        }

        public async Task<IList<ContainerResource>> GetAllContainersAsync(CancellationToken token = default)
        {
            var allContainerResources = await GetAllContainersAdminAsync(token);
            string clientId = userRepository.GetCurrentUserClientId();
            IList<ContainerResource> allowedContainers = new List<ContainerResource>();
            foreach (var container in allContainerResources)
            {
                if (container.Configuration.ValidateAudience)
                {
                    if (container.Configuration.ValidAudiences == null)
                    {
                        logger.LogError($"ValidAudiences collection for container : {container.ContainerName} is empty");
                    }
                    else
                    {
                        if (container.Configuration.ValidAudiences.Contains(clientId))
                        {
                            allowedContainers.Add(container);
                        }
                        else
                        {
                            logger.LogWarning($"ClientID {clientId} don't have access to container :{container.ContainerName}");
                        }
                    }
                }
                else
                {
                    allowedContainers.Add(container);
                }
            }

            return allowedContainers;
        }

        public async Task<ContainerResource> GetContainerByNameAsync(string containerName, CancellationToken token = default)
        {
            var container = await GetContainerByNameAdminAsync(containerName, token);
            string clientId = userRepository.GetCurrentUserClientId();
            if (container.Configuration.ValidateAudience && !container.Configuration.ValidAudiences.Contains(clientId))
            {
                logger.LogWarning($"ClientID {clientId} don't have access to container :{container.ContainerName}");
                return null;
            }

            return container;
        }
        public async Task<ContainerResource> GetContainerByNameAdminAsync(string containerName, CancellationToken token = default)
        {
            if (allContainerResources == null)
            {
                allContainerResources = (List<ContainerResource>)await GetAllContainersAdminAsync(token);
            }

            var item = allContainerResources.FirstOrDefault(x => x.Configuration.Name == containerName);

            if (item == null)
                return null;

            return item;
        }

        private static ContainerResource Convert(StorageContainerConfiguration item)
        {
            return new ContainerResource(item.Name)
            {
                Configuration = item

            };
        }

        //private static ContainerResource Convert(StorageContainerConfiguration item)
        //{
        //    return new ContainerResource(item.Name)
        //    {
        //        Configuration = item

        //    };
        //}
    }
}
