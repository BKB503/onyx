﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public abstract class OdbcConnectionHelper
    {
        ILogger<OdbcConnectionHelper> logger;

        public OdbcConnectionHelper(ILogger<OdbcConnectionHelper> logger)
        {
            this.logger = logger;
        }


        public OdbcConnection CreateOpenedConnection(ContainerResource container)
        {
            OdbcConnection conn = null;
            try
            {
                conn = new OdbcConnection(container.Configuration.IndexingConfiguration.IndexOdbcConnectionString);
                conn.Open();
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message, ex);
                conn = null;
            }
            return conn;
        }

        public OdbcCommand CreateCommand(OdbcConnection conn, string sql)
        {
            return new OdbcCommand(sql, conn);

        }
        public string ReadColumn(DbDataReader reader, string column)
        {
            try
            {
                return reader[column]?.ToString();
            }
            catch
            {
                return null;
            }
        }

        public long? ReadLongColumn(DbDataReader reader, string column)
        {
            try
            {
                return reader.GetInt64(reader.GetOrdinal(column));
            }
            catch
            {
                return null;
            }
        }
        public DateTime? ReadDateTimeColumn(DbDataReader reader, string column)
        {
            try
            {
                return reader.GetDateTime(reader.GetOrdinal(column));
            }
            catch
            {
                return null;
            }
        }

        public DateTimeOffset? ReadDateTimeOffsetColumn(DbDataReader reader, string column)
        {
            try
            {
                var dt = reader.GetDateTime(reader.GetOrdinal(column));
                return new DateTimeOffset(dt);
            }
            catch
            {
                return null;
            }
        }


        public T ReadObjectColumn<T>(DbDataReader reader, string column) where T : class
        {
            try
            {
                string strJsonValue = reader[column]?.ToString();
                return JsonSerializer.Deserialize<T>(strJsonValue);
            }
            catch(Exception ex) 
            {
                logger.LogDebug(ex.Message, ex);
                return default(T);
            }
        }
    }
}
