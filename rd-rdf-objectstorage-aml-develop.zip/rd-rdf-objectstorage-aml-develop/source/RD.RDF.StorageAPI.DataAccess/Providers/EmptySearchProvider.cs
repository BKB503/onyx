﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class EmptySearchProvider : ISearchProvider
    {
        public StorageContainerType StorageClientType => StorageContainerType.none;

        public Task<SearchFilesByTagResults> SearchFilesByTagsAsync(ContainerResource container, string tagSearchQuery, CancellationToken token = default)
        {
            return Task.FromResult(new SearchFilesByTagResults(message: $"No search provider available for container type: {container.Configuration.Type}"));
        }
    }


}
