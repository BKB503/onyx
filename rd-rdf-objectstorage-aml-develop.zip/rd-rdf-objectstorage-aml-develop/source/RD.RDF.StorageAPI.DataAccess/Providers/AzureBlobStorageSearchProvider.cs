﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class AzureBlobStorageSearchProvider : ISearchProvider
    {
        private readonly ILogger<AzureBlobStorageSearchProvider> logger;
        private readonly IMetadataCollectionValidationProvider validationProvider;

        public StorageContainerType StorageClientType => StorageContainerType.azureblob;

        public AzureBlobStorageSearchProvider(ILogger<AzureBlobStorageSearchProvider> logger, IMetadataCollectionValidationProviderFactory validationProviderFactory)
        {
            this.logger = logger;
            validationProvider = validationProviderFactory.GetProvider(StorageClientType);
        }

        public async Task<SearchFilesByTagResults> SearchFilesByTagsAsync(ContainerResource container, string tagSearchQuery, CancellationToken token = default)
        {
            SearchFilesByTagResults results;
            var fileResults = new List<FileResource>();
            try
            {
                var containerClient = GetBlobContainerClient(container);
                string newQuery = tagSearchQuery;
                var parsedResult = ParseSearchQuery(tagSearchQuery);
                if (parsedResult != null && parsedResult.Any())
                {
                    newQuery = string.Join(" AND ", parsedResult);
                }
                await foreach (var item in containerClient.FindBlobsByTagsAsync(newQuery, token))
                {
                    var fr = new FileResource(item.BlobName)
                    {
                        Metadata = new MetadataDictionary(item.Tags, true)
                    };
                    fileResults.Add(fr);
                }
                results = new SearchFilesByTagResults(fileResults);
            }
            catch (Exception ex)
            {
                results = new SearchFilesByTagResults(message: ex.Message);
            }
            return results;
        }
        private BlobServiceClient GetServiceClient(ContainerResource container)
        {
            var serviceClient = new BlobServiceClient(container.Configuration.ContainerConnectionString);
            return serviceClient;
        }

        private BlobContainerClient GetBlobContainerClient(ContainerResource container)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetBlobContainerClient(container.Configuration.ContainerName);
            return containerClient;
        }


        private static Regex searchTokenizerRegex = new Regex(@"""([a-zA-Z0-9\-\s.:=_\/\+]+)""\s+(=|<|>|=>|<=)\s+'(\w*)'");

        private List<SearchTagWithValue> ParseSearchQuery(string searchQuery)
        {
            var resultsList = new List<SearchTagWithValue>();
            var result = searchTokenizerRegex.Match(searchQuery);
            do
            {
                if (result.Success)
                {
                    string key = result.Groups[1].Value;
                    string op = result.Groups[2].Value;
                    string value = result.Groups[3].Value;
                    resultsList.Add(new SearchTagWithValue(validationProvider.GetValidIndexTagName(key),
                                                           op,
                                                           validationProvider.GetValidIndexTagValue(value)));
                    result = result.NextMatch();
                }
            } while (result.Success);
            return resultsList;
        }

        public class SearchTagWithValue
        {
            public SearchTagWithValue(string tag, string op, string value)
            {
                Tag = tag;
                Value = value;
                Operator = op;
            }

            public string Tag { get; set; }
            public string Value { get; set; }

            public string Operator { get; set; }

            public override string ToString()
            {
                return $"\"{Tag}\" {Operator} '{Value}'";
            }

        }
    }
}