﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class AllianceConfigurationProvider : IAllianceConfigurationProvider
    {
        public readonly AllianceConfiguration allianceConfiguration;
        ILogger<AllianceConfigurationProvider> logger;

        public AllianceConfigurationProvider(IOptions<AllianceConfiguration> allianceConfig, IConfiguration configuration, ILogger<AllianceConfigurationProvider> logger)
        {
            allianceConfiguration = allianceConfig.Value;
            // setting kafka publisher config from custom keys from key vault
            allianceConfiguration.AllainceKafkaTopic.EventHubKey = configuration["RDFKafkaKey"];
            allianceConfiguration.AllainceKafkaTopic.EventHubConnectionString = configuration["RDFKafkaConnectionString"];
            allianceConfiguration.AllainceKafkaTopic.Topic = configuration["RDFKafkaTopicAlliance"];
            allianceConfiguration.AllainceKafkaTopic.KafkaServers = configuration["RDFKafkaServers"];
            allianceConfiguration.AllainceKafkaTopic.SaslUsername = configuration["RDFKafkaUserName"];
            allianceConfiguration.FilePathRefreshRun = configuration["FilePathLastRefreshRun"];

        }

        public AllianceConfiguration GetAllianceConfiguration()
        {
            return allianceConfiguration;
        }
    }
}
