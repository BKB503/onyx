﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class OdbcAllianceInformationProvider : OdbcConnectionHelper, IAllianceInformationProvider
    {

        public string DatabaseName = "alliancedata";
        public string DataLakeName = "v_agreementPackets_teamMembers";
        ILogger<OdbcAllianceInformationProvider> logger;

        public OdbcAllianceInformationProvider(ILogger<OdbcAllianceInformationProvider> logger) : base(logger)
        {
            this.logger = logger;
        }
        public async Task<AllianceModel> GetAllianceSecurityOfUserAsync(ContainerResource container, string userName, string allianceAgreement, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(userName))
            {
                logger.LogError($"'{nameof(userName)}' cannot be null or empty.", nameof(userName));
                return null;
            }
            if (string.IsNullOrEmpty(allianceAgreement))
            {
                logger.LogError($"'{nameof(allianceAgreement)}' cannot be null or empty.", nameof(allianceAgreement));
                return null;
            }

            AllianceModel model = null;
            try
            {
                string sql = $"select * from {DatabaseName}.{DataLakeName} where teamMember='{userName}' and name='{allianceAgreement}' limit 1";
                using OdbcConnection connection = CreateOpenedConnection(container);
                if (connection != null)
                {
                    using var cmd = CreateCommand(connection, sql);
                    using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
                    await reader.ReadAsync(cancellationToken);
                    if (reader.HasRows)
                    {
                        model = ReadOneRow(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return model;
        }

        public async Task<AllianceModel> GetOneAllianceAgreementDetails(ContainerResource container, string allianceAgreement, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(allianceAgreement))
            {
                logger.LogError($"'{nameof(allianceAgreement)}' cannot be null or empty.", nameof(allianceAgreement));
                return null;
            }

            AllianceModel model = null;
            try
            {
                string sql = $"select * from {DatabaseName}.{DataLakeName} where name='{allianceAgreement}' limit 1";
                using OdbcConnection connection = CreateOpenedConnection(container);
                if (connection != null)
                {
                    using var cmd = CreateCommand(connection, sql);
                    using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
                    await reader.ReadAsync(cancellationToken);
                    if (reader.HasRows)
                    {
                        model = ReadOneRow(reader);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return model;
        }

        public async Task<List<AllianceModel>> GetAllAllianceSecurity(ContainerResource container, CancellationToken cancellationToken)
        {
            List<AllianceModel> model = new List<AllianceModel>();
            string sql = $"select * from {DatabaseName}.{DataLakeName}";
            using OdbcConnection connection = CreateOpenedConnection(container);
            if (connection != null)
            {
                using var cmd = CreateCommand(connection, sql);
                using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    if (reader.HasRows)
                    {
                        var row = (AllianceModel)ReadOneRow(reader);
                        model.Add(row);
                    }
                }
            }
            return model;
        }

        public AllianceModel ReadOneRow(DbDataReader reader)
        {
            DateTimeOffset.TryParse(ReadColumn(reader, "creationDate"), out DateTimeOffset creationTime);
            DateTimeOffset.TryParse(ReadColumn(reader, "modificationDate"), out DateTimeOffset modificationDate);
            DateTimeOffset.TryParse(ReadColumn(reader, "effectiveDate"), out DateTimeOffset effectiveDate);
            DateTimeOffset.TryParse(ReadColumn(reader, "endDate"), out DateTimeOffset endDate);
            var fim = new AllianceModel
            {
                AgreementContractId = Convert.ToInt32(ReadColumn(reader, "agreementContractId")),
                Name = ReadColumn(reader, "name"),
                LongName = ReadColumn(reader, "longName"),
                Code = Convert.ToInt32(ReadColumn(reader, "code")),
                IsActive = Convert.ToBoolean(ReadColumn(reader, "isActive")),
                IsRestricted = Convert.ToBoolean(ReadColumn(reader, "isRestricted")),
                CreationDate = creationTime,
                ModificationDate = modificationDate,
                EffectiveDate = effectiveDate,
                EndDate = endDate,
                TeamMember = ReadColumn(reader, "teamMember")
            };
            return fim;
        }

    }
}
