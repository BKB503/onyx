﻿using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public abstract class BaseMetadataCollectionValidationProvider
    {
        public virtual string GetValidIndexTagName(string key)
        {
            return key;
        }

        public virtual string GetValidIndexTagValue(string value)
        {
            return value;
        }

        protected virtual Dictionary<string, string> GetTagsDictionary(MetadataCollections valuePairs, int maxTags)
        {
            var correctedMetadataDic = new Dictionary<string, string>();
            //Index Tag limit is 10
            foreach (var item in valuePairs.Items.Where(x => x.IsIndexed == true).Take(maxTags))
            {
                correctedMetadataDic.Add(GetValidIndexTagName(item.Key), GetValidIndexTagValue(item.Value));
            }

            // if there is no GUID in indexed keys let's try to add it
            // that should not happen
            if (!correctedMetadataDic.ContainsKey(Common.FileGuid))
            {
                string fileGuid = valuePairs.Items.FirstOrDefault(k => k.Key == Common.FileGuid)?.Value ?? string.Empty;
                if (string.IsNullOrEmpty(fileGuid))
                {
                    //logger.LogError("No FileGuid found in the metadata list");
                }
                // we should have only maxTags items in dictionary 
                if (correctedMetadataDic.Count == maxTags)
                {
                    //we choose last key and remove it
                    var lastKey = correctedMetadataDic.Keys.Last();
                    correctedMetadataDic.Remove(lastKey);
                }
                correctedMetadataDic.Add(Common.FileGuid, fileGuid);
            }

            return correctedMetadataDic;
        }
        protected virtual string ValidateInputString(string inputStr, Regex validPattern, string charReplacement, int maxLen)
        {
            string modifiedValue = inputStr ?? string.Empty;
            if (modifiedValue.Length > maxLen)
            {
                //allows only 256 characters
                modifiedValue = modifiedValue.Substring(0, maxLen);
            }
            if (validPattern != null && validPattern.IsMatch(modifiedValue))
            {
                modifiedValue = validPattern.Replace(modifiedValue, charReplacement);
            }
            return modifiedValue?.TrimEnd();
        }
    }
}
