﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class AzureBlobMetadataCollectionValidationProvider : BaseMetadataCollectionValidationProvider, IMetadataCollectionValidationProvider
    {
        private static Regex allowedKeyPattern = new Regex("[^a-zA-Z0-9_]");
        private static int maxValueLength = 8000;
        private static int maxKeyLength = 128;

        private static Regex allowedTagValuePattern = new Regex("[^a-zA-Z0-9\\ +./:=_-]");
        private static Regex allowedTagKeyPattern = new Regex("[^a-zA-Z0-9 +-.:=_/]");
        private static int maxTagValueLength = 256;
        private static int maxTagKeyLength = 128;
        private static int maxTagsCount = 10;
        private static string valueTagCharReplacement = ":";
        private static string keyCharReplacement = "_";

        private readonly ILogger<AzureBlobMetadataCollectionValidationProvider> logger;

        public AzureBlobMetadataCollectionValidationProvider(ILogger<AzureBlobMetadataCollectionValidationProvider> logger)
        {
            this.logger = logger;
        }

        public StorageContainerType StorageClientType => StorageContainerType.azureblob;

        public Dictionary<string, string> GetIndexingTagsFromInputCollection(MetadataCollections metadataCollection)
        {
            if (metadataCollection == null)
            {
                return new Dictionary<string, string>();
            }
            return GetTagsDictionary(metadataCollection, maxTagsCount);
        }

        public Dictionary<string, string> GetMetadataFromInputCollection(MetadataCollections metadataCollection)
        {
            if (metadataCollection == null)
            {
                return new Dictionary<string, string>();
            }
            return metadataCollection.Items.ToDictionary(k => GetValidKeyName(k.Key), val => GetValidKeyValue(val.Value));
        }

        public override string GetValidIndexTagName(string key)
        {
            return ValidateInputString(key, allowedTagKeyPattern, keyCharReplacement, maxTagKeyLength);
        }

        public override string GetValidIndexTagValue(string value)
        {
            return ValidateInputString(value, allowedTagValuePattern, valueTagCharReplacement, maxTagValueLength);
        }

        public string GetValidKeyName(string key)
        {
            return ValidateInputString(key, allowedKeyPattern, keyCharReplacement, maxKeyLength);
        }

        public string GetValidKeyValue(string value)
        {
            return Uri.EscapeDataString(ValidateInputString(value, null, null, maxValueLength));
        }
    }
}
