﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Odbc;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class DatabricksOdbcFileIndexSearchProvider : OdbcConnectionHelper, IStorageIndexSearchProvider
    {
        private readonly ILogger<DatabricksOdbcFileIndexSearchProvider> logger;
        private readonly string DatabaseName = "suplementarydata";
        private readonly string MetadataTableName = "v_filesinfo_metadata";
        private readonly string FilesinfoTableName = "filesinfo";

        public DatabricksOdbcFileIndexSearchProvider(ILogger<DatabricksOdbcFileIndexSearchProvider> logger) : base(logger)
        {
            this.logger = logger;
        }

        public async Task<PagedOffsetApiResponse<List<FileIndexModel>>> GetFolderIndexAsync(ContainerResource container, string metaDataKey, string metaDataValue, string folderName, OffsetPagPaginationFilter filter, CancellationToken cancellationToken)
        {
            List<FileIndexModel> results = new List<FileIndexModel>();            
            long nextToken = filter.Offset + filter.Limit;
            try
            {
                string sql;
                if (string.IsNullOrEmpty(folderName))
                {
                    sql = $"select distinct F.* from {DatabaseName}.{FilesinfoTableName} F " +
                        $"INNER JOIN {DatabaseName}.{MetadataTableName} I ON (F.Container = I.Container and F.FileName = I.FileName AND F.FilePath = I.filepath) " +
                        $"Where  (I.Key='{metaDataKey}' AND I.Value='{metaDataValue}') " +
                        $"AND (F.Container='{container.ContainerName}') " +
                        $"order by F.CreationTime desc LIMIT {filter.Limit} OFFSET {filter.Offset}";
                }
                else
                {
                    sql = $"select distinct F.* from {DatabaseName}.{FilesinfoTableName} F INNER JOIN {DatabaseName}.{MetadataTableName} I ON (F.Container=I.Container and F.FileName = I.FileName AND F.FilePath = I.filepath) " +                    
                    $"Where  (I.Key='{metaDataKey}' AND I.Value='{metaDataValue}') " +
                    $"AND (F.FolderName='{folderName}' AND F.Container='{container.ContainerName}') order by F.CreationTime desc LIMIT {filter.Limit} OFFSET {filter.Offset}";
                }

                using OdbcConnection connection = CreateOpenedConnection(container);
                if (connection != null)
                {
                    using var cmd = CreateCommand(connection, sql);
                    using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

                    while (await reader.ReadAsync(cancellationToken))
                    {
                        if (reader.HasRows)
                        {
                            var row = ReadOneRow(reader);
                            results.Add(row);
                        }
                    }
                }

                return new PagedOffsetApiResponse<List<FileIndexModel>>(results, results.Count, filter.Offset, results.Count > 0 ? nextToken : 0, filter.Limit);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedOffsetApiResponse<List<FileIndexModel>>(ex.Message, filter.Offset, filter.Limit);
            }


        }

        public async Task<PagedOffsetApiResponse<List<FileIndexModel>>> GetIndexSearchByFolderNameAsync(ContainerResource container, string folderName, string metaDataKey, string metaDataValue, OffsetPagPaginationFilter filter, CancellationToken cancellationToken)
        {
            List<FileIndexModel> results = new List<FileIndexModel>();                    
            string searchFolderName = Uri.UnescapeDataString(folderName)?.Replace("*", "%").Replace("%%", "%");                        
            long nextToken = filter.Offset + filter.Limit;
            try
            {
                string sql;                
                if (!string.IsNullOrEmpty(metaDataKey) && !string.IsNullOrEmpty(metaDataValue))
                {
                    sql = $"select distinct F.* from {DatabaseName}.{FilesinfoTableName} F " +
                      $"INNER JOIN {DatabaseName}.{MetadataTableName} I ON (F.Container=I.Container AND F.FileName = I.FileName AND F.FilePath = I.FilePath) " +                      
                      $"Where  (I.Key='{metaDataKey}' AND I.Value='{metaDataValue}') " +
                      $"AND (F.FolderName like '{searchFolderName}' AND F.Container='{container.ContainerName}') order by F.CreationTime desc LIMIT {filter.Limit} OFFSET {filter.Offset}";
                }

                else
                {
                    sql = $"select distinct F.* from {DatabaseName}.{FilesinfoTableName} F " +                    
                    $"Where F.FolderName like '{searchFolderName}' AND F.Container='{container.ContainerName}' " +
                    $"order by F.CreationTime desc LIMIT {filter.Limit} OFFSET {filter.Offset}";
                }

                using OdbcConnection connection = CreateOpenedConnection(container);
                if (connection != null)
                {
                    using var cmd = CreateCommand(connection, sql);
                    using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

                    while (await reader.ReadAsync(cancellationToken))
                    {
                        if (reader.HasRows)
                        {
                            var row = ReadOneRow(reader);
                            results.Add(row);
                        }
                    }
                }

                return new PagedOffsetApiResponse<List<FileIndexModel>>(results, results.Count, filter.Offset, results.Count > 0 ? nextToken : 0, filter.Limit);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedOffsetApiResponse<List<FileIndexModel>>(ex.Message, filter.Offset, filter.Limit);
            }
        }

        private OdbcConnection CreateOpenedConnection(ContainerResource container)
        {
            OdbcConnection conn = null;
            try
            {
                conn = new OdbcConnection(container.Configuration.IndexingConfiguration.IndexOdbcConnectionString);
                conn.Open();
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message, ex);
                conn = null;
            }
            return conn;
        }

        private OdbcCommand CreateCommand(OdbcConnection conn, string sql)
        {
            return new OdbcCommand(sql, conn);

        }

        public FileIndexModel ReadOneRow(DbDataReader reader)
        { 
            var fim = new FileIndexModel
            {
                FileName = ReadColumn(reader, "FileName"),
                FilePath = ReadColumn(reader, "FilePath"),
                FolderName = ReadColumn(reader, "FolderName"),
                Container = ReadColumn(reader, "Container"),                
                FileBlobType = ReadColumn(reader, "FileBlobType"),
                FileContentType = ReadColumn(reader, "FileContentType"),
                FileGuid = ReadColumn(reader, "FileGuid"),
                FileVersionId = ReadColumn(reader, "FileVersionId"),
                FileHash = ReadColumn(reader, "FileHash"),                
                FileSize = ReadLongColumn(reader,"FileSize"),
                FileETag = ReadColumn(reader, "FileETag"),
                ModificationDate = ReadDateTimeColumn(reader, "ModificationDate"),
                CreationTime = ReadDateTimeOffsetColumn(reader, "CreationTime"),
                Versions = ReadObjectColumn<List<Versions>>(reader, "Versions"),
                Metadata = ReadObjectColumn<List<MetadataKeyValue>>(reader, "Metadata")
            };
            return fim;
        }


    }
}
