﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Linq;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class DefaultMetadataCollectionValidationProvider : IMetadataCollectionValidationProvider
    {
        public StorageContainerType StorageClientType => StorageContainerType.none;

        public Dictionary<string, string> GetIndexingTagsFromInputCollection(MetadataCollections metadataCollection)
        {
            return GetMetadataFromInputCollection(metadataCollection);
        }

        public Dictionary<string, string> GetMetadataFromInputCollection(MetadataCollections metadataCollection)
        {
            return metadataCollection.Items.ToDictionary(k => k.Key, val => val.Value);
        }

        public string GetValidIndexTagName(string key)
        {
            return key;
        }

        public string GetValidIndexTagValue(string value)
        {
            return value;
        }

        public string GetValidKeyName(string key)
        {
            return key;
        }

        public string GetValidKeyValue(string value)
        {
            return value;
        }
    }

}
