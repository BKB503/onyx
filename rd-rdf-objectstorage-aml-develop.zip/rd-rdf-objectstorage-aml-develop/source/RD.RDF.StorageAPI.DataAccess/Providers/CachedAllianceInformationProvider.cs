﻿using Microsoft.Extensions.Caching.Memory;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class CachedAllianceInformationProvider : IAllianceInformationProvider
    {
        private readonly IMemoryCache cache;
        private readonly IAllianceConfigurationProvider cacheconfiguration;
        private readonly AllianceConfiguration allianceConfiguration;
        private readonly IAllianceInformationProvider allianceInformationProvider;

        private ConcurrentDictionary<string, List<AllianceModel>> UserAlliancesDictionary = new ConcurrentDictionary<string, List<AllianceModel>>();

        private ConcurrentDictionary<string, AllianceModel> AlliancesDictionary = new ConcurrentDictionary<string, AllianceModel>();
        private List<AllianceModel> allAlliances;

        public CachedAllianceInformationProvider(IAllianceInformationProvider allianceInformationProvider, IMemoryCache cache, IAllianceConfigurationProvider cacheconfiguration)
        {
            this.allianceInformationProvider = allianceInformationProvider;
            this.cache = cache;
            this.cacheconfiguration = cacheconfiguration;
            allianceConfiguration = this.cacheconfiguration.GetAllianceConfiguration();
        }

        public async Task<List<AllianceModel>> GetAllAllianceSecurity(ContainerResource container, CancellationToken cancellationToken)
        {
            if (!cache.TryGetValue("allAlliances", out allAlliances))
            {
                allAlliances = await allianceInformationProvider.GetAllAllianceSecurity(container, cancellationToken);
                UserAlliancesDictionary.Clear();
                AlliancesDictionary.Clear();
                allAlliances.ForEach(alliance =>
                {
                    if (cancellationToken.IsCancellationRequested)
                        return;

                    AlliancesDictionary.TryAdd(alliance.Name?.ToLower(), alliance);
                    if (!UserAlliancesDictionary.TryGetValue(alliance.TeamMember?.ToLower(), out List<AllianceModel> userAlliances))
                    {
                        userAlliances = new List<AllianceModel>();
                        UserAlliancesDictionary.TryAdd(alliance.TeamMember?.ToLower(), userAlliances);


                    }
                    userAlliances.Add(alliance);
                });
                cache.Set("allAlliances", allAlliances, new MemoryCacheEntryOptions() { AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(allianceConfiguration.CacheTimeSeconds) });

            }


            return allAlliances;
        }



        public async Task<AllianceModel> GetAllianceSecurityOfUserAsync(ContainerResource container, string userName, string allianceAgreement, CancellationToken cancellationToken)
        {
            if (allAlliances == null)
            {
                await GetAllAllianceSecurity(container, cancellationToken);
            }

            if (UserAlliancesDictionary.TryGetValue(userName?.ToLower(), out List<AllianceModel> userAlliances))
            {
                return userAlliances.FirstOrDefault(an => an.Name == allianceAgreement);
            }
            return null;
        }

        public async Task<AllianceModel> GetOneAllianceAgreementDetails(ContainerResource container, string allianceAgreement, CancellationToken cancellationToken)
        {
            if (allAlliances == null)
            {
                await GetAllAllianceSecurity(container, cancellationToken);
            }

            if (AlliancesDictionary.TryGetValue(allianceAgreement?.ToLower(), out AllianceModel allianceModel))
            {
                return allianceModel;
            }
            return null;
        }
    }
}
