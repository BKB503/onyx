﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Linq;

namespace RD.RDF.StorageAPI.DataAccess.Providers
{
    public class SearchProviderFactory : ISearchProviderFactory
    {
        private readonly Dictionary<StorageContainerType, ISearchProvider> ProvidersDictionary;
        private readonly EmptySearchProvider emptySearchProvider;

        public SearchProviderFactory(IEnumerable<ISearchProvider> providers, EmptySearchProvider emptySearchProvider)
        {
            this.emptySearchProvider = emptySearchProvider;
            ProvidersDictionary = providers == null
                ? new Dictionary<StorageContainerType, ISearchProvider>()
                : providers.ToDictionary(key => key.StorageClientType);
        }

        public ISearchProvider GetSearchProvider(ContainerResource container)
        {
            if (!ProvidersDictionary.TryGetValue(container.Configuration.Type, out ISearchProvider provider))
            {
                provider = emptySearchProvider;
            }
            return provider;
        }
    }
}
