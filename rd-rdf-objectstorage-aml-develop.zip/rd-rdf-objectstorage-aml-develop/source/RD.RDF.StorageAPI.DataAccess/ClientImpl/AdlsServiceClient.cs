﻿using System;
using System.Collections.Generic;
using Azure;
using Azure.Storage.Files.DataLake;
using Azure.Storage.Files.DataLake.Models;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using Microsoft.Azure.DataLake.Store;
using Microsoft.Extensions.Logging;
using System.Text.RegularExpressions;
using System.Linq;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;

namespace RD.RDF.StorageAPI.DataAccess.ClientImpl
{
    public class AdlsServiceClient : IStorageClient
    {
        private readonly ConcurrentDictionary<string, DataLakeServiceClient> Services = new ConcurrentDictionary<string, DataLakeServiceClient>();
        private readonly ILogger<AdlsServiceClient> logger;

        public StorageContainerType StorageClientType => StorageContainerType.azureadls;

        public AdlsServiceClient(ILogger<AdlsServiceClient> logger)
        {
            this.logger = logger;
        }

        private DataLakeServiceClient GetServiceClient(ContainerResource container)
        {
            if (!Services.TryGetValue(container.ContainerName, out DataLakeServiceClient serviceClient))
            {
                serviceClient = new DataLakeServiceClient(container?.Configuration?.ContainerConnectionString);
                Services.TryAdd(container.ContainerName, serviceClient);
            }
            return serviceClient;
        }
        private DataLakeFileSystemClient GetFileSystemClient(ContainerResource container)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetFileSystemClient(container.Configuration.ContainerName);
            return containerClient;
        }

        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            var adlsClient = GetFileClient(container, file);
            var downloadStream = await adlsClient.ReadAsync(cancellationToken: token);
            return downloadStream.Value.Content;


        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            List<FileResource> fr = new List<FileResource>();
            var containerClient = GetFileSystemClient(container);
            try
            {
                var resultSegment = containerClient.GetPathsAsync();

                await foreach (PathItem pathItem in resultSegment)
                {


                    fr.Add(new FileResource(pathItem.Name)
                    {
                        ModifiedTime = pathItem.LastModified,
                        CreationTime = pathItem.CreatedOn,
                        FileBlobType = pathItem.GetType().ToString(),
                        FileGuid = pathItem.CreatedOn.ToString(),
                        FilePath = pathItem.Name,
                        FolderName = pathItem.Name.Contains('/') ? pathItem.Name.Substring(0, pathItem.Name.LastIndexOf('/', 0)) : string.Empty,
                        FileETag = pathItem.ETag.ToString(),
                        FileSize = pathItem.ContentLength
                    });

                }
                return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, null);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<List<FileResource>>(ex.Message, filter.ContinuationToken, filter.Limit);
            }


        }

        public Task<bool> GetContainerClientPropertiesAsync(ContainerResource container)
        {

            return Task.FromResult(true);

        }
        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }
        private static string GetContentHash(byte[] contentHash)
        {
            return contentHash != null ? Convert.ToBase64String(contentHash) : null;
        }


        public async Task<PagedApiResponse<FolderResource>> GetFullFolderInformationAsync(ContainerResource container, string folderName, PaginationFilter filter, CancellationToken token)
        {
            var containerClient = GetFileSystemClient(container);
            var storageFolder = HandleFolderName(folderName);
            var fr = new FolderResource(folderName);
            try
            {
                var resultSegment = containerClient.GetPathsAsync(folderName);
                string nextToken = null;

                await foreach (PathItem pathItem in resultSegment)
                {
                    if ((bool)pathItem.IsDirectory)
                    {
                        fr.SubFolders.Add(FolderResource.CreateEmptyFolder(pathItem.Name));


                    }
                    else
                    {

                        fr.Files.Add(new FileResource(pathItem.Name)
                        {

                            ModifiedTime = pathItem.LastModified,
                            CreationTime = pathItem.CreatedOn,
                            FileBlobType = pathItem.GetType().ToString(),
                            FileGuid = pathItem.CreatedOn.ToString(),
                            FileVersionId = pathItem.CreatedOn.ToString(),
                            FileVersions = new List<VersionDetails>
                            {
                                new VersionDetails
                                {
                                    CreationTime = pathItem.CreatedOn,
                                    FileETag = pathItem.ETag.ToString("G"),
                                    FileSize = pathItem.ContentLength,
                                    FileVersionId = pathItem.CreatedOn.ToString(),
                                    FileGuid = pathItem.CreatedOn.ToString()
                                }
                            },
                            FileETag = pathItem.ETag.ToString("G"),
                            FilePath = pathItem.Name,
                            FileSize = pathItem.ContentLength,
                            FolderName = fr.FolderName

                        });
                    }
                }

                return new PagedApiResponse<FolderResource>(fr, fr.FilesCount.GetValueOrDefault() + fr.SubFoldersCount.GetValueOrDefault(), filter.ContinuationToken, nextToken, filter.Limit);
            }

            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<FolderResource>(ex.Message, filter.ContinuationToken, filter.Limit);
            }
        }

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            // passing null version id to fetch the latest version (default)
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);

        }


        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = string.IsNullOrEmpty(parentFolder.FolderName) ? fileName : $"{parentFolder.FolderName}{Path.AltDirectorySeparatorChar}{fileName}";
            var containerClient = GetFileSystemClient(container);
            var adlsClient = containerClient.GetFileClient(blobName);
            try
            {
                var props = await adlsClient.GetPropertiesAsync(default, cancellationToken: token);
                props.Value.Metadata.TryGetValue("FileGuid", out string fileGuid);
                return new FileResource(fileName)
                {
                    FileSize = props.Value.ContentLength,
                    ModifiedTime = props.Value.LastModified,
                    CreationTime = props.Value.CreatedOn,
                    FileContentType = props.Value.ContentType,
                    FileETag = props.Value.ETag.ToString("G"),
                    FileVersionId = props.Value.CreatedOn.ToString(),
                    FileVersions = new List<VersionDetails>
                    {
                        new VersionDetails
                    {
                      FileSize = props.Value.ContentLength,
                      CreationTime = props.Value.CreatedOn,
                      FileETag = props.Value.ETag.ToString("G"),
                      FileVersionId = props.Value.CreatedOn.ToString(),
                      FileGuid = props.Value.CreatedOn.ToString()
                    }
                    },
                    FileGuid = props.Value.CreatedOn.ToString(),
                    FilePath = blobName,
                    FolderName = folderName,
                    Metadata = new MetadataDictionary(props.Value.Metadata, true)
                };
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return null;
            }
        }

        public Task<bool> UpdateTagsAsync(ContainerResource container, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken)
        {
            return Task.FromResult(true);
        }

        private DataLakeFileClient GetFileClient(ContainerResource container, FileResource fileInfo)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetFileSystemClient(container.Configuration.ContainerName);
            return containerClient.GetFileClient(fileInfo.FilePath);
        }
        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folderName, Stream fileData, MetadataCollections dictionary, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = string.IsNullOrEmpty(parentFolder.FolderName) ? fileName : $"{parentFolder.FolderName}{Path.AltDirectorySeparatorChar}{fileName}";

            var fileInfo = new FileResource(fileName) { FilePath = blobName };
            var adlsClient = GetFileClient(container, fileInfo);

            DataLakeFileUploadOptions dataLakeFileUploadOptions = new DataLakeFileUploadOptions();
            if (dictionary != null)
            {
                dataLakeFileUploadOptions.Metadata = new MetadataDictionary(dictionary);
            }
            await adlsClient.UploadAsync(fileData, dataLakeFileUploadOptions, token);

            var returnFileInfo = await GetOneFileInformationAsync(container, fileName, folderName, token);
            return returnFileInfo;

        }

        private static FolderResource GetParentFolder(ContainerResource container, string folderName)
        {
            FolderResource parentFolder = new FolderResource(string.Empty);
            if (!string.IsNullOrEmpty(folderName))
            {
                parentFolder = FolderResource.CreateEmptyFolder(HandleFolderName(folderName));
            }

            return parentFolder;
        }

        public Task<UploadPartsInitResult> UploadPartsInitAsync(ContainerResource container, string fileName, string folder, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<UploadPartResult> UploadPartFileAsync(ContainerResource container, UploadPartFileModel fileModel, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<UploadPartCommitResult> UploadPartsCommitAsync(ContainerResource container, string uploadSessionId, string fileName, string folder, UploadPartCommitCollection parts, MetadataCollections metadata, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
