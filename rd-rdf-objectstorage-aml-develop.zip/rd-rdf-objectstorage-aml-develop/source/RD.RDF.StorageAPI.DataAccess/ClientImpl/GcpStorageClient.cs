﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Http;
using Google.Cloud.Storage.V1;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Extensions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.ClientImpl
{
    public class GcpStorageClient : IStorageClient
    {
        private readonly ConcurrentDictionary<string, StorageClient> Services = new ConcurrentDictionary<string, StorageClient>();
        private readonly ILogger<GcpStorageClient> logger;

        public StorageContainerType StorageClientType => StorageContainerType.googleblob;

        public GcpStorageClient(ILogger<GcpStorageClient> logger)
        {
            this.logger = logger;
        }

        #region IStorageClient interface Implementation Section

        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            var containerClient = GetServiceClient(container);
            Stream stream = new MemoryStream();
            long.TryParse(file?.FileVersionId, out long versionId);
            var options = new DownloadObjectOptions
            {
                Generation = versionId
            };
            await containerClient.DownloadObjectAsync(container.Configuration.ContainerName, file.FilePath, stream, options, token);
            stream.Seek(0, SeekOrigin.Begin);

            return stream;
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            string folderName = string.Empty;
            List<FileResource> fr = new List<FileResource>();
            var storageFolder = HandleFolderName(folderName);
            var containerClient = GetServiceClient(container);
            var listOptions = new ListObjectsOptions
            {
                UserProject = container.Configuration.ContainerAccountName,
                Versions = true,
                Delimiter = "/",
                IncludeTrailingDelimiter = true,
                PageToken = filter.ContinuationToken,
            };

            try
            {
                var resultSegment = containerClient.ListObjectsAsync(container.Configuration.ContainerName, storageFolder, listOptions);//.GetAsyncEnumerator(token);

                await foreach (var resource in resultSegment)
                {
                    string fileGuid = null;
                    if (resource.Metadata != null)
                    {
                        resource.Metadata.TryGetValue("FileGuid", out fileGuid);
                    }
                    fr.Add(new FileResource(resource.Name)
                    {
                        ModifiedTime = resource.Updated,
                        CreationTime = resource.TimeCreated,
                        FileContentHash = resource.Md5Hash,
                        FileBlobType = resource.ContentType,
                        FileContentType = resource.ContentType,
                        FileETag = resource.ETag,
                        FileVersionId = Convert.ToString(resource.Generation),
                        FileGuid = fileGuid,
                        FilePath = resource.Name,
                        FileSize = (long)resource.Size,
                        FolderName = resource.Name.Contains('/') ? resource.Name.Substring(0, resource.Name.LastIndexOf('/', 0)) : string.Empty,
                        Metadata = new MetadataDictionary(resource.Metadata, false)
                    });
                }

                //read one page and break

                return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, null);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<List<FileResource>>(ex.Message, filter.ContinuationToken, filter.Limit);
            }
        }

        public Task<bool> GetContainerClientPropertiesAsync(ContainerResource container)
        {
            return Task.FromResult(true);
        }

        public async Task<PagedApiResponse<FolderResource>> GetFullFolderInformationAsync(ContainerResource container, string folderName, PaginationFilter filter, CancellationToken token)
        {
            bool isLatestVersion = false;
            var fr = new FolderResource(folderName);
            FileResource currentFileResource = null;
            var storageFolder = HandleFolderName(folderName);
            var containerClient = GetServiceClient(container);
            var listOptions = new ListObjectsOptions
            {
                UserProject = container.Configuration.ContainerAccountName,
                Versions = true,
                Delimiter = "/",
                IncludeTrailingDelimiter = true,
                PageToken = filter.ContinuationToken,
            };

            string nextToken = null;
            try
            {
                var resultSegment = containerClient.ListObjectsAsync(container.Configuration.ContainerName, storageFolder, listOptions);
                var pageResult = await resultSegment.ReadPageAsync(filter.Limit, token);

                await foreach (var resource in resultSegment)
                {
                    if (currentFileResource == null)
                    {
                        currentFileResource = CreateFileResource(resource);
                    }
                    if (resource.Size == 0)
                    {
                        fr.SubFolders.Add(FolderResource.CreateEmptyFolder(resource.Name));
                    }
                    else
                    {
                        if (currentFileResource.FilePath == resource.Name)
                        {
                            //same file key - add version to the FR object
                            AddVersinToFileResource(currentFileResource, resource);
                        }
                        else
                        {
                            //different key - put this fr object in files collection
                            fr.Files.Add(currentFileResource);
                            //create new FileResource object
                            currentFileResource = CreateFileResource(resource);
                            AddVersinToFileResource(currentFileResource, resource);
                        }
                    }

                }

                nextToken = pageResult.NextPageToken;
                //read one page and break

                return new PagedApiResponse<FolderResource>(fr, fr.FilesCount.GetValueOrDefault() + fr.SubFoldersCount.GetValueOrDefault(), filter.ContinuationToken, nextToken, filter.Limit);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<FolderResource>(ex.Message, filter.ContinuationToken, filter.Limit);
            }
        }

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            // passing null version id to fetch the latest version (default)
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);
        }

        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token)
        {
            var parentFolder = GetParentFolder(container, folderName);
            var objectName = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var containerClient = GetServiceClient(container);
            var props = await containerClient.GetObjectAsync(container.Configuration.ContainerName, objectName, null, token);

            string fileGuid = null;
            if (props.Metadata != null)
            {
                props.Metadata.TryGetValue("FileGuid", out fileGuid);
            }

            var fileResource = new FileResource(fileName)
            {
                FileSize = (long)props.Size,
                ModifiedTime = props.Updated == null ? null : new DateTimeOffset(props.Updated.Value),
                CreationTime = props.TimeCreated,
                FileContentHash = props.Md5Hash,
                FileBlobType = props.ContentType,
                FileContentType = props.ContentType,
                FileETag = props.ETag,
                FileVersionId = Convert.ToString(props.Generation),
                FileVersions = await GetFileVersionsAsync(container, containerClient, objectName, token),
                FileGuid = fileGuid,
                FilePath = objectName,
                FolderName = folderName,
                Metadata = new MetadataDictionary(props.Metadata, false)

            };

            return fileResource;
        }

        public Task<bool> UpdateTagsAsync(ContainerResource container, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken)
        {
            return Task.FromResult(true);
        }

        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folderName, Stream fileData, MetadataCollections dictionary, CancellationToken token)
        {
            int maxLength = 256;
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var filePath = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var storageClient = GetServiceClient(container);

            var uploadRequest = new Google.Apis.Storage.v1.Data.Object()
            {
                Bucket = container.Configuration.ContainerName,
                Name = filePath,
                Metadata = new Dictionary<string, string>()
            };

            if (dictionary != null)
            {
                //setting the metadata on the file
                foreach (var item in dictionary.Items)
                {
                    uploadRequest.Metadata.Add(item.Key, item.Value.Length < maxLength ? item.Value : item.Value.Substring(0, maxLength));
                }
            }
            string fileGuid = uploadRequest.Metadata.Where(x => x.Key == Common.FileGuid).Any() ? uploadRequest.Metadata.Where(x => x.Key == Common.FileGuid).Select(x => x.Value).FirstOrDefault() : "";
            if (string.IsNullOrEmpty(fileGuid))
            {
                logger.LogError("No FileGuid found in the metadata list");
            }
            uploadRequest.Metadata[Common.FileGuid] = fileGuid;
            UploadObjectOptions uploadObjectOptions = new UploadObjectOptions();

            var uploadResponse = await storageClient.UploadObjectAsync(uploadRequest, fileData, uploadObjectOptions, token);
            return await GetOneFileInformationAsync(container, fileName, folderName, token);
        }

        public MetadataDictionary SetTags(MetadataCollections valuePairs)
        {
            MetadataDictionary correctedMetadataDic = new MetadataDictionary();
            if (valuePairs is null)
            {
                return correctedMetadataDic;
            }

            int maxLength = 256;

            Regex allowedPattern = new Regex("[^a-zA-Z0-9\\ +./:=_$]");

            //Allowed tags are 10. SetTagsAsync takes only first 10 values by default
            foreach (var item in valuePairs.Items.Where(x => x.IsIndexed == true).Take(9))
            {
                //allows only 256 characater
                string modifiedValue = item.Value.Length < maxLength ? item.Value : item.Value.Substring(0, maxLength);
                if (allowedPattern.IsMatch(modifiedValue))
                {
                    modifiedValue = allowedPattern.Replace(modifiedValue, ":");
                    correctedMetadataDic.Add(item.Key, modifiedValue);
                }
                else { correctedMetadataDic.Add(item.Key, modifiedValue); }
            }
            string fileGuid = valuePairs.Items.Where(x => x.Key == Common.FileGuid).Any() ? valuePairs.Items.Where(x => x.Key == Common.FileGuid).Select(x => x.Value).FirstOrDefault() : "";
            if (string.IsNullOrEmpty(fileGuid))
            {
                logger.LogError("No FileGuid found in the metadata list");
            }
            correctedMetadataDic[Common.FileGuid] = fileGuid;

            return correctedMetadataDic;
        }

        public async Task<UploadPartsInitResult> UploadPartsInitAsync(ContainerResource container, string fileName, string folder, CancellationToken cancellationToken)
        {
            var filePath = PathExtensions.CombineBlobPath(folder, fileName);
            string signedUrl = string.Empty;
            try
            {
                string token = await GetOauthTokenFromCredentials(container, cancellationToken);
                using var initHttpClient = new HttpClient();
                string blobName = container.Configuration.ContainerName;
                string uri = $"https://storage.googleapis.com/upload/storage/v1/b/{blobName}/o?uploadType=resumable&name={filePath}";
                var data = new StringContent("", Encoding.UTF8, "application/json");
                initHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var initHttpResponse = await initHttpClient.PostAsync(uri, data);
                if (initHttpResponse.IsSuccessStatusCode)
                {
                    signedUrl = initHttpResponse.Headers?.Location?.ToString();
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new UploadPartsInitResult(UploadFileResultStatus.Error, ex.Message);
            }

            return new UploadPartsInitResult
            {
                UploadSessionId = Base64Encode(signedUrl),
                Container = container.ContainerName,
                FileName = fileName,
                FolderName = folder,
                FilePath = filePath,
                Status = UploadFileResultStatus.Success
            };
        }

        public async Task<UploadPartResult> UploadPartFileAsync(ContainerResource container, UploadPartFileModel fileModel, CancellationToken cancellationToken)
        {
            HttpStatusCode statusCode;
            string url = Base64Decode(fileModel.UploadSessionId);
            long fileTotalSize = fileModel.FileTotalSize;
            long firstByte = (fileModel.FilePartNumber - 1) * fileModel.FilePartSize;
            long lastByte = (firstByte + fileModel.FilePartStreamLenght) - 1;
            //Byte ranges are inclusive; that is, bytes 0-999 represent the first 1000 bytes in a file or object 
            //https://cloud.google.com/storage/docs/json_api/v1/parameters#contentrange 
            string partGuid;
            StreamContent content = new StreamContent(fileModel.FilePartStream)
            {
                Headers = {
                    ContentType = new MediaTypeHeaderValue("application/octet-stream"),
                    ContentLength = fileModel.FilePartStreamLenght
                }
            };
            content.Headers.Add("Content-Range", $"bytes {firstByte}-{lastByte}/{fileTotalSize}");
            try
            {
                if (!string.IsNullOrEmpty(container.Configuration.ProxyUrl))
                {
                    IWebProxy webProxy = new WebProxy(container.Configuration.ProxyUrl);
                    HttpClient.DefaultProxy = webProxy;
                }
                var httpClient = new HttpClient();
                var response = await httpClient.PutAsync(url, content, cancellationToken);
                partGuid = Convert.ToBase64String(BitConverter.GetBytes(fileModel.FilePartNumber));
                statusCode = response.StatusCode;

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    statusCode = HttpStatusCode.OK;
                }
                else if (response.StatusCode == HttpStatusCode.Created)
                {
                    statusCode = HttpStatusCode.OK;
                }
                else if (response.StatusCode == HttpStatusCode.PermanentRedirect)

                {
                    statusCode = HttpStatusCode.OK;
                }
                else
                {
                    statusCode = response.StatusCode;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new UploadPartResult(UploadFileResultStatus.Error, ex.Message);
            }

            return new UploadPartResult
            {
                PartGuid = partGuid,
                BytesSend = fileModel.FilePartStreamLenght,
                BytesWritten = fileModel.FilePartStreamLenght,
                FileName = fileModel.FileName,
                FolderName = fileModel.Folder,
                FilePartSize = fileModel.FilePartSize,
                FileTotalSize = fileModel.FileTotalSize,
                FilePartNumber = fileModel.FilePartNumber,
                Status = (UploadFileResultStatus)statusCode,
                Container = container.ContainerName,
                FilePath = PathExtensions.CombineBlobPath(fileModel.Folder, fileModel.FileName),
                UploadSessionId = fileModel.UploadSessionId
            };


        }

        public async Task<UploadPartCommitResult> UploadPartsCommitAsync(ContainerResource container, string uploadSessionId, string fileName, string folder, UploadPartCommitCollection parts, MetadataCollections metadata, CancellationToken cancellationToken)
        {
            var parentFolder = GetParentFolder(container, folder);
            var objectName = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var containerClient = GetServiceClient(container);
            var objectInfo = await containerClient.GetObjectAsync(container.Configuration.ContainerName, objectName, null, cancellationToken);
            try
            {
                objectInfo.Metadata = metadata.Items.ToDictionary(k => k.Key, v => v.Value);
                var commitResult = await containerClient.UpdateObjectAsync(objectInfo);
                var fileInfo = await this.GetOneFileInformationAsync(container, fileName, folder, cancellationToken);
                if (fileInfo != null)
                {
                    return new UploadPartCommitResult
                    {
                        FileInformation = fileInfo,
                        Status = UploadFileResultStatus.Success,
                        FileName = fileName,
                        FolderName = folder,
                        Container = container.ContainerName,
                        FilePath = PathExtensions.CombineBlobPath(folder, fileName),
                        UploadSessionId = uploadSessionId
                    };
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new UploadPartCommitResult(UploadFileResultStatus.Error, ex.Message);
            }
            return new UploadPartCommitResult(UploadFileResultStatus.Error, "UploadPartsCommit was not successfull")
            {
                FileName = fileName,
                FolderName = folder,
                Container = container.ContainerName,
                FilePath = PathExtensions.CombineBlobPath(folder, fileName),
                UploadSessionId = uploadSessionId
            };
        }

        #endregion

        #region Private Methods Section

        private static void AddVersinToFileResource(FileResource file, Google.Apis.Storage.v1.Data.Object ObjectVersion)
        {
            string fileGuid = null;
            if (ObjectVersion.Metadata != null)
            {
                ObjectVersion.Metadata.TryGetValue("FileGuid", out fileGuid);
            }

            file.FileVersions.Add(new VersionDetails
            {
                FileGuid = fileGuid,
                FileVersionId = Convert.ToString(ObjectVersion.Generation),
                FileETag = ObjectVersion.ETag,
                FileContentHash = ObjectVersion.Md5Hash,
                CreationTime = ObjectVersion.Updated,
                FileSize = (long)ObjectVersion.Size,

                //IsLatestVersion = isLatest,
            });

        }

        private StorageClient GetServiceClient(ContainerResource container)
        {
            if (!Services.TryGetValue(container.ContainerName, out StorageClient serviceClient))
            {
                GoogleCredential credential = GetCredentials(container);
                serviceClient = StorageClient.Create(credential);
                Services.TryAdd(container.ContainerName, serviceClient);
            }
            return serviceClient;
        }

        private static GoogleCredential GetCredentials(ContainerResource container)
        {
            var credential = GoogleCredential.FromJson(container?.Configuration?.ContainerConnectionString);
            if (!string.IsNullOrEmpty(container.Configuration.ProxyUrl))
            {
                IWebProxy webProxy = new WebProxy(container.Configuration.ProxyUrl);
                var factory = HttpClientFactory.ForProxy(webProxy);
                credential = credential.CreateWithHttpClientFactory(factory);
            }

            return credential;
        }

        private static async Task<string> GetOauthTokenFromCredentials(ContainerResource container, CancellationToken cancellationToken)
        {
            var gcpCredentials = GetCredentials(container);
            return await gcpCredentials
                            .CreateScoped("https://www.googleapis.com/auth/devstorage.read_write")
                            .UnderlyingCredential
                            .GetAccessTokenForRequestAsync(cancellationToken: cancellationToken);
        }

        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }

        private static async Task<List<VersionDetails>> GetFileVersionsAsync(ContainerResource container, StorageClient containerClient,
                                         string blobName, CancellationToken token)
        {

            List<VersionDetails> versions = new List<VersionDetails>();
            var listOptions = new ListObjectsOptions
            {
                UserProject = container.Configuration.ContainerAccountName,
                Versions = true,
                Delimiter = "/",
                IncludeTrailingDelimiter = true,

            };

            bool isLatestVersion = false;
            string nextToken = null;
            var resultSegment = containerClient.ListObjectsAsync(container.Configuration.ContainerName, blobName, listOptions);
            var pageResult = await resultSegment.ReadPageAsync(100, token);
            var latestObjectInfo = pageResult.OrderBy(x => x.Id).LastOrDefault();


            foreach (var version in pageResult)
            {
                if (version.Id == latestObjectInfo.Id)
                {
                    isLatestVersion = true;
                }
                versions.Add(new VersionDetails
                {
                    FileVersionId = Convert.ToString(version.Generation),
                    FileETag = version.ETag,
                    FileSize = (long)version.Size,
                    FileContentHash = version.Md5Hash,
                    CreationTime = version.TimeCreated,
                    IsLatestVersion = isLatestVersion

                });
            }

            return versions;
        }

        private static FolderResource GetParentFolder(ContainerResource container, string folderName)
        {
            FolderResource parentFolder = new FolderResource(string.Empty);
            if (!string.IsNullOrEmpty(folderName))
            {
                parentFolder = FolderResource.CreateEmptyFolder(HandleFolderName(folderName));
            }

            return parentFolder;
        }

        private static FileResource CreateFileResource(Google.Apis.Storage.v1.Data.Object gcpObject)
        {
            string fileGuid = null;
            if (gcpObject.Metadata != null)
            {
                gcpObject.Metadata.TryGetValue("FileGuid", out fileGuid);
            }

            var fr = new FileResource(GetFileNameFromKey(gcpObject.Name))
            {
                ModifiedTime = gcpObject.Updated,
                CreationTime = gcpObject.TimeCreated,
                FileContentHash = gcpObject.Md5Hash,
                FileBlobType = gcpObject.ContentType,
                FileContentType = gcpObject.ContentType,
                FileETag = gcpObject.ETag,
                FileVersionId = Convert.ToString(gcpObject.Generation),
                FileVersions = new List<VersionDetails>(),
                FileGuid = fileGuid,
                FilePath = gcpObject.Name,
                FileSize = (long)gcpObject.Size,
                Metadata = new MetadataDictionary(),
                FolderName = GetFolderFromKey(gcpObject.Name)
            };

            return fr;
        }

        private static string GetFileNameFromKey(string key)
        {
            return Path.GetFileName(key);
        }

        private static string GetFolderFromKey(string key)
        {
            return Path.GetDirectoryName(key);
        }

        private static string Base64Encode(string toEncode)
        {
            var toEncodeAsBytes = Encoding.UTF8.GetBytes(toEncode);
            return toEncodeAsBytes != null ? Convert.ToBase64String(toEncodeAsBytes) : null;
        }

        private static string Base64Decode(string toDecode)
        {
            var valueBytes = System.Convert.FromBase64String(toDecode);
            return Encoding.UTF8.GetString(valueBytes);
        }

        #endregion
    }
}
