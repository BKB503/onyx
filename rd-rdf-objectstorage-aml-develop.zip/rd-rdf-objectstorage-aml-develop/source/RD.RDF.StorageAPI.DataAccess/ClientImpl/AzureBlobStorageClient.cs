﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs.Specialized;
using Google.Api.Gax.ResourceNames;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Microsoft.Graph;
using Newtonsoft.Json.Linq;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Extensions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using static Google.Apis.Storage.v1.Data.Bucket.LifecycleData;

namespace RD.RDF.StorageAPI.DataAccess.ClientImpl
{
    public class AzureBlobStorageClient : IStorageClient
    {
        private readonly ConcurrentDictionary<string, BlobServiceClient> Services = new ConcurrentDictionary<string, BlobServiceClient>();
        private readonly ILogger<AzureBlobStorageClient> logger;
        private readonly IMetadataCollectionValidationProvider validationProvider;

        public StorageContainerType StorageClientType => StorageContainerType.azureblob;

        public AzureBlobStorageClient(ILogger<AzureBlobStorageClient> logger, IMetadataCollectionValidationProviderFactory validationProviderFactory)
        {
            this.logger = logger;
            this.validationProvider = validationProviderFactory.GetProvider(StorageClientType);
        }

        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            var blobClient = GetBlobClientWithVersion(container, file);
            var blobExists = await blobClient.ExistsAsync(token);
            if (blobExists.Value)
            {
                var downloadStream = await blobClient.DownloadStreamingAsync(cancellationToken: token);
                return downloadStream.Value.Content;
            }
            else
            {
                return null;
            }
        }

        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folderName, Stream fileData, MetadataCollections dictionary, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var fileInfo = new FileResource(fileName) { FilePath = blobName };
            var blobClient = GetBlobClient(container, fileInfo);
            BlobUploadOptions blobUploadOptions = new BlobUploadOptions();
            if (dictionary != null)
            {
                blobUploadOptions.Metadata = validationProvider.GetMetadataFromInputCollection(dictionary);
                blobUploadOptions.Tags = validationProvider.GetIndexingTagsFromInputCollection(dictionary);
            }
            var uploadResult = await blobClient.UploadAsync(fileData, blobUploadOptions, token);
            if (uploadResult?.Value?.VersionId != null)
            {
                return await GetOneFileInformationAsync(container, fileName, folderName, token);
            }
            else
            {
                return null;
            }
        }  

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            // passing null version id to fetch the latest version (default)
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);

        }
        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string VersionId, CancellationToken token)
        {
            FolderResource parentFolder = GetParentFolder(container, folderName);
            var blobName = PathExtensions.CombineBlobPath(parentFolder.FolderName, fileName);
            var containerClient = GetBlobContainerClient(container);
            var blobClient = containerClient.GetBlobClient(blobName).WithVersion(VersionId);
            try
            {
                var props = await blobClient.GetPropertiesAsync(cancellationToken: token);
                props.Value.Metadata.TryGetValue("FileGuid", out string fileGuid);
                if (fileGuid == null && props.Value.TagCount > 0)
                {
                    var tags = await blobClient.GetTagsAsync(cancellationToken: token);
                    tags.Value.Tags.TryGetValue("FileGuid", out fileGuid);
                }
                return new FileResource(fileName)
                {
                    FileSize = props.Value.ContentLength,
                    ModifiedTime = props.Value.LastModified,
                    CreationTime = props.Value.CreatedOn,
                    FileContentHash = GetContentHash(props.Value.ContentHash),
                    FileBlobType = props.Value.BlobType.ToString(),
                    FileContentType = props.Value.ContentType,
                    FileETag = props.Value.ETag.ToString("G"),
                    FileVersionId = props.Value.VersionId,
                    FileVersions = await GetFileVersionsAsync(containerClient, blobClient.Name, token),
                    FileGuid = fileGuid,
                    FilePath = blobName,
                    FolderName = folderName,
                    Metadata = new MetadataDictionary(props.Value.Metadata, true)
                };
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return null;
            }
        }

        public async Task<PagedApiResponse<FolderResource>> GetFullFolderInformationAsync(ContainerResource container, string folderName, PaginationFilter filter, CancellationToken token)
        {
            var containerClient = GetBlobContainerClient(container);
            var storageFolder = HandleFolderName(folderName);
            var fr = new FolderResource(folderName);
            try
            {
                var resultSegment = containerClient.GetBlobsByHierarchyAsync(BlobTraits.Metadata | BlobTraits.Tags, prefix: storageFolder, delimiter: "/", cancellationToken: token)
                                                   .AsPages(filter.ContinuationToken, filter.Limit);
                string nextToken = null;
                await foreach (Page<BlobHierarchyItem> blobPage in resultSegment)
                {
                    foreach (BlobHierarchyItem item in blobPage.Values)
                    {
                        if (item.IsPrefix)
                        {
                            fr.SubFolders.Add(FolderResource.CreateEmptyFolder(item.Prefix));
                        }
                        else
                        {
                            var props = item.Blob.Properties;
                            string fileGuid = null;
                            item.Blob.Metadata.TryGetValue("FileGuid", out fileGuid);
                            if (fileGuid == null && item.Blob.Tags != null)
                            {
                                item.Blob.Tags.TryGetValue("FileGuid", out fileGuid);
                            }
                            fr.Files.Add(new FileResource(item.Blob.Name)
                            {
                                ModifiedTime = props.LastModified,
                                CreationTime = props.CreatedOn,
                                FileContentHash = GetContentHash(props.ContentHash),
                                FileBlobType = props.BlobType.ToString(),
                                FileContentType = props.ContentType,
                                FileETag = props.ETag?.ToString("G"),
                                FileVersionId = item.Blob.VersionId,
                                FileGuid = fileGuid,
                                FilePath = item.Blob.Name,
                                FileSize = item.Blob.Properties.ContentLength,
                                FolderName = fr.FolderName,
                                Metadata = new MetadataDictionary(item.Blob.Metadata, true)
                            });
                        }
                    }
                    nextToken = blobPage.ContinuationToken;
                    //read one page and break
                    break;
                }
                return new PagedApiResponse<FolderResource>(fr, fr.FilesCount.GetValueOrDefault() + fr.SubFoldersCount.GetValueOrDefault(), filter.ContinuationToken, nextToken, filter.Limit);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<FolderResource>(ex.Message, filter.ContinuationToken, filter.Limit);
            }
        }



        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            List<FileResource> fr = new List<FileResource>();
            var containerClient = GetBlobContainerClient(container);
            try
            {
                var resultSegment = containerClient.GetBlobsAsync(BlobTraits.Metadata | BlobTraits.Tags, cancellationToken: token)
                                                   .AsPages(filter.ContinuationToken, filter.Limit);
                await foreach (Page<BlobItem> blobPage in resultSegment)
                {
                    foreach (var item in blobPage.Values)
                    {
                        var props = item.Properties;
                        string fileGuid = null;
                        item.Metadata.TryGetValue("FileGuid", out fileGuid);
                        if (fileGuid == null && item.Tags != null)
                        {
                            item.Tags.TryGetValue("FileGuid", out fileGuid);
                        }
                        fr.Add(new FileResource(item.Name)
                        {
                            ModifiedTime = props.LastModified,
                            CreationTime = props.CreatedOn,
                            FileContentHash = GetContentHash(props.ContentHash),
                            FileBlobType = props.BlobType.ToString(),
                            FileContentType = props.ContentType,
                            FileETag = props.ETag?.ToString("G"),
                            FileVersionId = item.VersionId,
                            FileGuid = fileGuid,
                            FilePath = item.Name,
                            FileSize = item.Properties.ContentLength,
                            FolderName = item.Name.Contains('/') ? item.Name.Substring(0, item.Name.LastIndexOf('/', 0)) : string.Empty,
                            Metadata = new MetadataDictionary(item.Metadata, true)
                        });
                    }
                }
                return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, null);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                return new PagedApiResponse<List<FileResource>>(ex.Message, filter.ContinuationToken, filter.Limit);
            }

        }

        private static async Task<List<VersionDetails>> GetFileVersionsAsync(BlobContainerClient blobContainerClient,
                                           string blobName, CancellationToken token)
        {
            List<VersionDetails> versions = new List<VersionDetails>();
            var blobVersions = blobContainerClient.GetBlobsAsync(BlobTraits.None, BlobStates.Version, blobName, token);
            await foreach (var version in blobVersions)
            {
                versions.Add(new VersionDetails
                {
                    FileVersionId = version.VersionId,
                    FileETag = version.Properties.ETag?.ToString("G"),
                    FileSize = version.Properties.ContentLength,
                    FileContentHash = GetContentHash(version.Properties.ContentHash),
                    CreationTime = version.Properties.CreatedOn,
                    IsLatestVersion = version.IsLatestVersion ?? false
                });
            }
            return versions;
        }
        private BlobServiceClient GetServiceClient(ContainerResource container)
        {
            if (!Services.TryGetValue(container.ContainerName, out BlobServiceClient serviceClient))
            {
                serviceClient = new BlobServiceClient(container?.Configuration?.ContainerConnectionString);
                Services.TryAdd(container.ContainerName, serviceClient);
            }
            return serviceClient;
        }

        private BlobClient GetBlobClient(ContainerResource container, FileResource fileInfo)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetBlobContainerClient(container.Configuration.ContainerName);
            return containerClient.GetBlobClient(fileInfo.FilePath);
        }

        private BlobClient GetBlobClientWithVersion(ContainerResource container, FileResource fileInfo)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetBlobContainerClient(container.Configuration.ContainerName);

            return containerClient.GetBlobClient(fileInfo.FilePath).WithVersion(fileInfo.FileVersionId);
        }

        public async Task<bool> GetContainerClientPropertiesAsync(ContainerResource container)
        {
            bool versioningEnabled = true;
            try
            { 
                var containerClient = GetBlobContainerClient(container);
                var anyFile = containerClient.GetBlobs().AsPages(pageSizeHint: 1).Take(1);
                if (anyFile.First().Values.Count > 0)
                {
                    versioningEnabled = !string.IsNullOrEmpty(anyFile.First().Values.First().VersionId);
                }
                return versioningEnabled;
            }
            catch (Exception exc)
            {

                throw;
            }
        }

        private BlobContainerClient GetBlobContainerClient(ContainerResource container)
        {
            var serviceClient = GetServiceClient(container);
            var containerClient = serviceClient.GetBlobContainerClient(container.Configuration.ContainerName);
            return containerClient;
        }

        private static FolderResource GetParentFolder(ContainerResource container, string folderName)
        {
            FolderResource parentFolder = new FolderResource(string.Empty);
            if (!string.IsNullOrEmpty(folderName))
            {
                parentFolder = FolderResource.CreateEmptyFolder(HandleFolderName(folderName));
            }

            return parentFolder;
        }

        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }

        private static string GetContentHash(byte[] contentHash)
        {
            return contentHash != null ? Convert.ToBase64String(contentHash) : null;
        }

        public async Task<bool> UpdateTagsAsync(ContainerResource container, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken)
        {
            var blobClient = GetBlobClient(container, file);
            var currentTags = await blobClient.GetTagsAsync(cancellationToken: cancellationToken);
            var existingTagsDict = currentTags?.Value?.Tags;
            if (existingTagsDict == null)
                existingTagsDict = new Dictionary<string, string>();
            existingTagsDict[Common.FileGuid] = tags[Common.FileGuid];
            if (existingTagsDict.Count > 10)
            {
                existingTagsDict.Remove("Format");
            }
            var response = await blobClient.SetTagsAsync(existingTagsDict, cancellationToken: cancellationToken);
            return response.IsError == false;
        }


        public async Task<UploadPartResult> UploadPartFileAsync(ContainerResource container, UploadPartFileModel fileModel, CancellationToken cancellationToken)
        {
            var blobServiceClient = GetServiceClient(container);
            var containerClient = blobServiceClient.GetBlobContainerClient(container.ContainerName);
            var blobName = PathExtensions.CombineBlobPath(fileModel.Folder, fileModel.FileName);
            var blobClient = containerClient.GetBlockBlobClient(blobName);
            string blockId = Convert.ToBase64String(BitConverter.GetBytes(fileModel.FilePartNumber));
            var stageBlockResults = await blobClient.StageBlockAsync(blockId, fileModel.FilePartStream);
            var rawResult = stageBlockResults.GetRawResponse();
            if(rawResult.IsError)
            {  
                return new UploadPartResult(UploadFileResultStatus.Error, $"Error in UploadPartFile. Message: {rawResult.ToString()}");
            }            
            return new UploadPartResult
            {
                PartGuid = blockId,
                BytesSend = fileModel.FilePartStreamLenght,
                BytesWritten = fileModel.FilePartStreamLenght,
                FileName = fileModel.FileName,
                FolderName = fileModel.Folder,
                FilePartSize = fileModel.FilePartSize,
                FileTotalSize = fileModel.FileTotalSize,
                FilePartNumber = fileModel.FilePartNumber,
                Status = UploadFileResultStatus.Success,
                Container = container.ContainerName,
                FilePath = PathExtensions.CombineBlobPath(fileModel.Folder, fileModel.FileName),
                UploadSessionId = fileModel.UploadSessionId                
            };

        }


        public async Task<UploadPartCommitResult> UploadPartsCommitAsync(ContainerResource container, string uploadSessionId, string fileName, string folder, UploadPartCommitCollection parts, MetadataCollections metadata, CancellationToken cancellationToken)
        {
            var blobServiceClient = GetServiceClient(container);
            var containerClient = blobServiceClient.GetBlobContainerClient(container.ContainerName);
            var blobName = PathExtensions.CombineBlobPath(folder, fileName);
            var blobClient = containerClient.GetBlockBlobClient(blobName);

            // commit the block list to construct the whole blob
            var opts = new CommitBlockListOptions();
            if (metadata != null)
            {
                opts.Metadata = validationProvider.GetMetadataFromInputCollection(metadata);
                opts.Tags = validationProvider.GetIndexingTagsFromInputCollection(metadata);
            }
            var partIds = parts.Items.Select(p => p.PartGuid).ToArray();
            var commitResult = await blobClient.CommitBlockListAsync(partIds, opts);
            if (!string.IsNullOrEmpty(commitResult?.Value?.VersionId))
            {
                var fileInfo = await this.GetOneFileInformationAsync(container, fileName, folder, cancellationToken);
                return new UploadPartCommitResult
                {
                    FileInformation = fileInfo,
                    Status = UploadFileResultStatus.Success,
                    FileName = fileName,
                    FolderName = folder,
                    Container = container.ContainerName,
                    FilePath = PathExtensions.CombineBlobPath(folder, fileName),
                    UploadSessionId = uploadSessionId
                };
            }
            else
            {
                return new UploadPartCommitResult(UploadFileResultStatus.Error, "UploadPartsCommit was not successfull")
                {
                    FileName = fileName,
                    FolderName = folder,
                    Container = container.ContainerName,
                    FilePath = PathExtensions.CombineBlobPath(folder, fileName),
                    UploadSessionId = uploadSessionId
                };
            } 
        }

        public Task<UploadPartsInitResult> UploadPartsInitAsync(ContainerResource container, string fileName, string folder, CancellationToken cancellationToken)
        {
            var uploadpartcommitresult = new UploadPartsInitResult()
            {
                Status = UploadFileResultStatus.Success,
                FileName = fileName,
                FolderName = folder,
                Container = container.ContainerName,
                FilePath = PathExtensions.CombineBlobPath(folder, fileName),
                UploadSessionId = Guid.NewGuid().ToString()
            };
            return Task.FromResult(uploadpartcommitresult);
        }
    }
}
