﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Linq;

namespace RD.RDF.StorageAPI.DataAccess.ClientImpl
{
    public class StorageClientFactory : IStorageClientFactory
    {
        private readonly Dictionary<StorageContainerType, IStorageClient> ClientsDictionary;

        public StorageClientFactory(IEnumerable<IStorageClient> clients)
        {
            ClientsDictionary = clients.ToDictionary(item => item.StorageClientType);
        }

        public IStorageClient GetStorageClient(ContainerResource container)
        {
            ClientsDictionary.TryGetValue(container.Configuration.Type, out IStorageClient client);
            return client;
        }
    }
}
