﻿using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.ClientImpl
{
    public class ObjectStorageS3Client : IStorageClient
    {
        private readonly ILogger<ObjectStorageS3Client> logger;
        private readonly MyHttpClientFactory clientFactory;
        private readonly IMetadataCollectionValidationProvider validationProvider;

        public StorageContainerType StorageClientType => StorageContainerType.objectstorage;

        public ObjectStorageS3Client(ILogger<ObjectStorageS3Client> logger, MyHttpClientFactory clientFactory, IMetadataCollectionValidationProviderFactory validationProviderFactory)
        {
            this.logger = logger;
            this.clientFactory = clientFactory;
            this.validationProvider = validationProviderFactory.GetProvider(StorageClientType);
        }

        public async Task<Stream> DownloadObjectAsync(ContainerResource container, FileResource file, CancellationToken token)
        {
            Stream responseStream = null;
            var s3Clinet = CreateS3Client(container);
            try
            {
                var request = new GetObjectRequest()
                {
                    BucketName = container.Configuration.ContainerName,
                    Key = file.FilePath,
                    VersionId = file.FileVersionId,
                };
                GetObjectResponse response = await s3Clinet.GetObjectAsync(request);
                responseStream = response.ResponseStream;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return responseStream;
        }

        public async Task<PagedApiResponse<FolderResource>> GetFullFolderInformationAsync(ContainerResource container, string folderName, PaginationFilter filter, CancellationToken token)
        {
            AmazonS3Client s3Clinet = CreateS3Client(container);
            var storageFolder = HandleFolderName(folderName);
            var listRequest = new ListVersionsRequest()
            {
                BucketName = container.Configuration.ContainerName,
                Delimiter = "/",
                Prefix = storageFolder,
                MaxKeys = filter.Limit
            };
            ListVersionsResponse listResponse;
            var results = new FolderResource(folderName);
            FileResource currentFileResource = null;
            int objectsSkipped = 0;
            int objectsRead = 0;
            var currentToken = DecodeToken(filter.ContinuationToken);
            if (currentToken.Value != null)
            {
                listRequest.KeyMarker = currentToken.Value.Item1;
                listRequest.VersionIdMarker = currentToken.Value.Item2;
            }
            string nextToken = null;
            try
            {
                listResponse = await s3Clinet.ListVersionsAsync(listRequest);
                if (listResponse.HttpStatusCode != HttpStatusCode.OK)
                {
                    string errMsg = $"ListVersions returned {listResponse.HttpStatusCode} code.";
                    logger.LogError(errMsg);
                    return new PagedApiResponse<FolderResource>(errMsg, filter.ContinuationToken, filter.Limit);
                }
                foreach (string folder in listResponse.CommonPrefixes)
                {
                    results.SubFolders.Add(FolderResource.CreateEmptyFolder(folder));
                }
                foreach (var s3Object in listResponse.Versions)
                {
                    if (currentFileResource == null)
                    {
                        currentFileResource = CreateFileResource(s3Object);
                    }
                    if (currentFileResource.FilePath == s3Object.Key)
                    {
                        //same file key - add version to the FR object
                        AddVersinToFileResource(currentFileResource, s3Object);
                    }
                    else
                    {
                        //different key - put this fr object in files collection
                        results.Files.Add(currentFileResource);
                        //create new FileResource object
                        currentFileResource = CreateFileResource(s3Object);
                        AddVersinToFileResource(currentFileResource, s3Object);
                    }

                }
                if (listResponse.NextKeyMarker != null)
                {
                    nextToken = EncodeToken(listResponse.NextKeyMarker, listResponse.NextVersionIdMarker);
                }
                results.Files.Add(currentFileResource);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return new PagedApiResponse<FolderResource>(results, results.FilesCount.GetValueOrDefault() + results.SubFoldersCount.GetValueOrDefault(), filter.ContinuationToken, nextToken, filter.Limit);
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            string folderName = string.Empty;
            List<FileResource> fr = new List<FileResource>();
            AmazonS3Client s3Clinet = CreateS3Client(container);
            FileResource currentFileResource = null;
            
            var request = new ListObjectsV2Request
            {
                BucketName = container.Configuration.ContainerName,
                ContinuationToken = filter.ContinuationToken,
                MaxKeys = filter.Limit,
            };

            string nextToken = null;
            try
            {

                var listObjects = await s3Clinet.ListObjectsV2Async(request, token);

                foreach (var s3Object in listObjects.S3Objects)
                {
                    currentFileResource = CreateFileInfo(s3Object);
                    fr.Add(currentFileResource);
                }

                nextToken = listObjects.NextContinuationToken;

            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }

            return new PagedApiResponse<List<FileResource>>(fr, fr.Count, filter.ContinuationToken, nextToken, filter.Limit);
        }

        public async Task<FileResource> GetOneFileInformationAsync(ContainerResource container, string fileName, string folderName, CancellationToken token)
        {
            return await GetOneFileInformationWithVersionAsync(container, fileName, folderName, null, token);
        }

        public async Task<FileResource> GetOneFileInformationWithVersionAsync(ContainerResource container, string fileName, string folderName, string versionId, CancellationToken token)
        {
            AmazonS3Client s3Client = CreateS3Client(container);
            var storageFolder = HandleFolderName(folderName);
            var listRequest = new ListVersionsRequest()
            {
                BucketName = container.Configuration.ContainerName,
                Delimiter = "/",
                Prefix = storageFolder + fileName
            };
            ListVersionsResponse listResponse;
            FileResource currentFileResource = null;
            try
            {
                do
                {
                    listResponse = await s3Client.ListVersionsAsync(listRequest);

                    if (listResponse.HttpStatusCode != HttpStatusCode.OK)
                    {
                        logger.LogError($"ListVersions for OneFile returned {listResponse.HttpStatusCode} code.");
                        break;
                    }
                    foreach (var s3Object in listResponse.Versions)
                    {
                        if (versionId == null)
                        {
                            if (currentFileResource == null)
                            {
                                currentFileResource = CreateFileResource(s3Object);
                            }
                            AddVersinToFileResource(currentFileResource, s3Object);
                        }
                        else if (versionId == s3Object.VersionId)
                        {
                            //one version will be returned
                            currentFileResource = CreateFileResource(s3Object);
                            AddVersinToFileResource(currentFileResource, s3Object);
                        }
                    }
                    listRequest.KeyMarker = listResponse.NextKeyMarker;
                    listRequest.VersionIdMarker = listResponse.NextVersionIdMarker;
                } while (listResponse.IsTruncated);

                var metadataCollection = await GetMetadataObjectAsync(s3Client, container, fileName, folderName);
                currentFileResource.FileGuid = GetFilGuidFromMeatadata(metadataCollection);
                currentFileResource.Metadata = GetMetadataDictionaryObject(metadataCollection);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return currentFileResource;
        }

        public async Task<FileResource> UploadObjectAsync(ContainerResource container, string fileName, string folder, Stream fileData, MetadataCollections keyValues, CancellationToken token)
        {
            FileResource newFileInfo = null;
            int maxLength = 256;
            try
            {
                var s3 = CreateS3Client(container);
                var fileTransferUtility = new TransferUtility(s3);
                string key = HandleFolderName(folder) + fileName;
                var uploadRequest = new TransferUtilityUploadRequest()
                {
                    BucketName = container.Configuration.ContainerName,
                    InputStream = fileData,
                    AutoResetStreamPosition = true,
                    AutoCloseStream = true,
                    StorageClass = S3StorageClass.Standard,
                    PartSize = 1024 * 1024 * 2, // 2MB
                    Key = key,
                };
                if (keyValues != null)
                {
                    var validMetadata = validationProvider.GetMetadataFromInputCollection(keyValues);
                    //setting the metadata on the file
                    foreach (var item in validMetadata)
                    {
                        uploadRequest.Metadata.Add(item.Key, item.Value);
                    }
                    string fileGuid = keyValues.Items.Where(x => x.Key == "FileGuid") != null ? keyValues.Items.Where(x => x.Key == "FileGuid").Select(x => x.Value).ToString() : "";
                    uploadRequest.Metadata.Add("FileGuid", fileGuid);
                }

                await fileTransferUtility.UploadAsync(uploadRequest);

                newFileInfo = await GetOneFileInformationWithVersionAsync(container, fileName, folder, null, token);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
            return newFileInfo;
        }

        public async Task<bool> GetContainerClientPropertiesAsync(ContainerResource container)
        {
            var s3Clinet = CreateS3Client(container);
            var BucketVersionRequest = new GetBucketVersioningRequest
            {
                BucketName = container.Configuration.ContainerName
            };
            var res = await s3Clinet.GetBucketVersioningAsync(BucketVersionRequest);

            if (res.VersioningConfig.Status == "Enabled")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static string HandleFolderName(string inputFolderName)
        {
            string storageFolder = inputFolderName;
            if (!string.IsNullOrEmpty(storageFolder))
            {
                if (!storageFolder.EndsWith("/"))
                {
                    storageFolder += "/";
                }
            }
            return storageFolder;
        }

        //Amazon S3 client configuration
        public AmazonS3Client CreateS3Client(ContainerResource container)
        {
            var config = new AmazonS3Config()
            {
                ForcePathStyle = true,
                SignatureVersion = "2",
                ServiceURL = container.Configuration.ContainerAccountUrl,
                SignatureMethod = SigningAlgorithm.HmacSHA1,
                UseHttp = false,
                HttpClientFactory = clientFactory
            };
            var credentials = new BasicAWSCredentials(container.Configuration.ContainerUserId, container.Configuration.ContainerKey);
            return new AmazonS3Client(credentials, config);
        }

        private static FileResource CreateFileResource(S3ObjectVersion s3Object)
        {
            var fr = new FileResource(GetFileNameFromKey(s3Object.Key))
            {
                ModifiedTime = s3Object.LastModified,
                CreationTime = s3Object.LastModified,
                FileContentHash = s3Object.ETag,
                FileBlobType = s3Object.StorageClass.Value,
                // FileContentType = s3Object.,
                FileETag = s3Object.ETag,
                FileVersionId = s3Object.VersionId,
                FileVersions = new List<VersionDetails>(),
                //FileGuid = s3Object.VersionId,
                FilePath = s3Object.Key,
                FileSize = s3Object.Size,
                Metadata = new MetadataDictionary(),
                FolderName = GetFolderFromKey(s3Object.Key)
            };

            return fr;
        }

        private static FileResource CreateFileInfo(S3Object s3Object)
        {
            var fr = new FileResource(GetFileNameFromKey(s3Object.Key))
            {
                ModifiedTime = s3Object.LastModified,
                CreationTime = s3Object.LastModified,
                FileContentHash = s3Object.ETag,
                FileBlobType = s3Object.StorageClass.Value,
                // FileContentType = s3Object.,
                FileETag = s3Object.ETag,
                //FileVersionId = s3Object.VersionId,
                FileVersions = new List<VersionDetails>(),
                //FileGuid = s3Object.VersionId,
                FilePath = s3Object.Key,
                FileSize = s3Object.Size,
                Metadata = new MetadataDictionary(),
                FolderName = GetFolderFromKey(s3Object.Key)
            };

            return fr;
        }

        private static void AddVersinToFileResource(FileResource file, S3ObjectVersion s3ObjectVersion)
        {
            file.FileVersions.Add(new VersionDetails
            {
                //FileGuid = s3ObjectVersion.VersionId,
                FileVersionId = s3ObjectVersion.VersionId,
                FileETag = s3ObjectVersion.ETag,
                FileContentHash = s3ObjectVersion.ETag,
                CreationTime = s3ObjectVersion.LastModified,
                FileSize = s3ObjectVersion.Size,
                IsLatestVersion = s3ObjectVersion.IsLatest
            });

        }

        private static string GetFilGuidFromMeatadata(MetadataCollection metadataObject)
        {
            string fileGuid = null;

            if (metadataObject != null)
            {
                fileGuid = metadataObject["x-amz-meta-fileguid"];
            }
            return fileGuid;
        }

        private static MetadataDictionary GetMetadataDictionaryObject(MetadataCollection metadataObject)
        {
            MetadataDictionary keyValuePairs = new MetadataDictionary();
            if (metadataObject is null)
            {
                return keyValuePairs;
            }
            foreach (var metadata in metadataObject.Keys)
            {
                string key = metadata.Replace("x-amz-meta-", "");
                keyValuePairs.Add(key, metadataObject[metadata]);
            }

            return keyValuePairs;
        }

        private async Task<MetadataCollection> GetMetadataObjectAsync(AmazonS3Client s3Clinet, ContainerResource container, string fileName, string folderName)
        {
            var storageFolder = HandleFolderName(folderName);
            var metadataObject = await s3Clinet.GetObjectMetadataAsync(
                        new GetObjectMetadataRequest() { BucketName = container.Configuration.ContainerName, Key = storageFolder + fileName });
            return metadataObject.Metadata;
        }

        private static string GetFileNameFromKey(string key)
        {
            return Path.GetFileName(key);
        }
        private static string GetFolderFromKey(string key)
        {
            return Path.GetDirectoryName(key);
        }

        private static IOptions<Tuple<string, string>> DecodeToken(string inputToken)
        {
            try
            {
                byte[] data = Convert.FromBase64String(inputToken);
                string decodedString = Encoding.UTF8.GetString(data);
                string[] split = decodedString.Split('|', StringSplitOptions.RemoveEmptyEntries);
                return Options.Create(new Tuple<string, string>(split[0], split[1]));
            }
            catch
            {
                return Options.Create<Tuple<string, string>>(null);
            }
        }
        private static string EncodeToken(string tokenPart1, string tokenPart2)
        {
            string token = $"{tokenPart1}|{tokenPart2}";
            byte[] data = Encoding.UTF8.GetBytes(token);
            return Convert.ToBase64String(data);
        }

        public async Task<bool> UpdateTagsAsync(ContainerResource container, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken)
        {
            var s3Clinet = CreateS3Client(container);
            var por = new PutObjectTaggingRequest
            {
                BucketName = container.Configuration.ContainerName,
                Tagging = new Tagging
                {
                    TagSet = tags.Select(el => new Tag { Key = el.Key, Value = el.Value }).ToList()
                },
                Key = file.FilePath,
                VersionId = file.FileVersionId
            };
            var result = await s3Clinet.PutObjectTaggingAsync(por, cancellationToken);
            return result.HttpStatusCode == HttpStatusCode.OK;
        }

        public Task<UploadPartsInitResult> UploadPartsInitAsync(ContainerResource container, string fileName, string folder, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<UploadPartResult> UploadPartFileAsync(ContainerResource container, UploadPartFileModel fileModel, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task<UploadPartCommitResult> UploadPartsCommitAsync(ContainerResource container, string uploadSessionId, string fileName, string folder, UploadPartCommitCollection parts, MetadataCollections metadata, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public class MyHttpClientFactory : HttpClientFactory
        {
            private readonly ILogger<MyHttpClientFactory> logger;

            public MyHttpClientFactory(ILogger<MyHttpClientFactory> logger)
            {
                this.logger = logger;
            }

            public override HttpClient CreateHttpClient(IClientConfig clientConfig)
            {
                var httpMessageHandler = new HttpClientHandler();
                //we don't validate the cert of server
                httpMessageHandler.ServerCertificateCustomValidationCallback = (_, _, _, _) => true;
                if (clientConfig.MaxConnectionsPerServer != null)
                {
                    httpMessageHandler.MaxConnectionsPerServer = clientConfig.MaxConnectionsPerServer.Value;
                }
                try
                {
                    // If HttpClientHandler.AllowAutoRedirect is set to true (default value),
                    // redirects for GET requests are automatically followed and redirects for POST
                    // requests are thrown back as exceptions.
                    // If HttpClientHandler.AllowAutoRedirect is set to false (e.g. S3),
                    // redirects are returned as responses.
                    httpMessageHandler.AllowAutoRedirect = clientConfig.AllowAutoRedirect;

                    // Disable automatic decompression when Content-Encoding header is present
                    httpMessageHandler.AutomaticDecompression = DecompressionMethods.None;
                }
                catch (PlatformNotSupportedException pns)
                {
                    logger.LogDebug(pns, $"The current runtime does not support modifying the configuration of HttpClient.");
                }
                try
                {
                    var proxy = clientConfig.GetWebProxy();
                    if (proxy != null)
                    {
                        httpMessageHandler.Proxy = proxy;
                    }

                    if (httpMessageHandler.Proxy != null && clientConfig.ProxyCredentials != null)
                    {
                        httpMessageHandler.Proxy.Credentials = clientConfig.ProxyCredentials;
                    }
                }
                catch (PlatformNotSupportedException pns)
                {
                    logger.LogDebug(pns, $"The current runtime does not support modifying proxy settings of HttpClient.");
                }

                var httpClient = new HttpClient(httpMessageHandler);

                if (clientConfig.Timeout != null)
                {
                    // Timeout value is set to ClientConfig.MaxTimeout for S3 and Glacier.
                    // Use default value (100 seconds) for other services.
                    httpClient.Timeout = clientConfig.Timeout.Value;
                }

                return httpClient;
            }
        }


    }
}
