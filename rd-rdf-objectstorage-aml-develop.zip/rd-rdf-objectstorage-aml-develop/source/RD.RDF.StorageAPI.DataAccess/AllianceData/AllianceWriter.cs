﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.AllianceData
{
    public class AllianceWriter : IAllianceWriter
    {
        public readonly string allianceTopic;
        public readonly ProducerConfig producerConfig;
        ILogger<AllianceWriter> logger;
        public AllianceWriter(IAllianceConfigurationProvider allianceConfig, ILogger<AllianceWriter> logger)
        {
            var allianceConfiguration = allianceConfig.GetAllianceConfiguration();
            producerConfig = new ProducerConfig
            {
                SaslPassword = allianceConfiguration.AllainceKafkaTopic.EventHubConnectionString,
                BootstrapServers = allianceConfiguration.AllainceKafkaTopic.KafkaServers,
                SaslMechanism = SaslMechanism.Plain,
                SaslUsername = allianceConfiguration.AllainceKafkaTopic.SaslUsername,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                Debug = "security,broker,protocol"
                //MessageMaxBytes= 1024 * 1024 * 10
            };

            allianceTopic = allianceConfiguration.AllainceKafkaTopic.Topic;
            this.logger = logger;
        }
        public async Task WriteAllianceInfromationAsync(IEnumerable<AgreementPacket> agreementPackets, CancellationToken token)
        {
            if (agreementPackets == null)
            {
                logger.LogWarning("No agreement packets to save");
                return;
            }
            try
            {
                JsonSerializerOptions options = new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                };
                logger.LogInformation("Creating the AllianceWriter client and sending messages..");
                using (var producerClient = new ProducerBuilder<Null, string>(producerConfig).Build())
                {
                    foreach (var item in agreementPackets)
                    {
                        if (token.IsCancellationRequested)
                            break;

                        var json = JsonSerializer.Serialize(item, options);
                        var msg = new Message<Null, string> { Value = json };
                        producerClient.Produce(allianceTopic, msg, onDeliveryHandler);
                        //var deliveryReport = await producerClient.ProduceAsync(allianceTopic, msg, token);                        
                    }
                    producerClient.Flush(token);
                }
                logger.LogInformation("AllianceWriter action completed.");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
            }
        }

        private void onDeliveryHandler(DeliveryReport<Null, string> obj)
        {
            logger.LogDebug($"onDeliveryHandler, Message {obj.Offset.Value} was delivered with status {obj.Error}");
        }
    }
}
