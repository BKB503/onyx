﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Graph;
using System.Linq;

namespace RD.RDF.StorageAPI.DataAccess.AllianceData
{
    public class GraphApiClient : IGraphApiClient
    {
        private const string DefaultSelectFields = "id,city,displayName,givenName,mail,userPrincipalName,officeLocation,companyName,country,mailNickname";

        private readonly ILogger<GraphApiClient> logger;
        private readonly GraphServiceClient graphClient;

        public GraphApiClient(GraphServiceClient graphClient, ILogger<GraphApiClient> logger)
        {
            this.graphClient = graphClient;
            this.logger = logger;
        }

        public async Task<AzureGraphUserData> GetUserDataByEmailAsync(string userEmail, CancellationToken cancellationToken)
        {
            if (userEmail is null)
            {
                return null;
            }
            try
            {                
                var filterString = $"startswith(mail, '{userEmail}')";
                return await RunGraphApiCallAsync(filterString, DefaultSelectFields, cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"GetUserDataAsync({userEmail}) error : {ex.Message}");
            }
            return null;
        }

        public async Task<AzureGraphUserData> GetUserDataByMudIdAsync(string mudId, CancellationToken cancellationToken)
        {
            if (mudId is null)
            {
                return null;
            }
            try
            {               
                var filterString = $"startswith(mailNickname, '{mudId}')";
                return await RunGraphApiCallAsync(filterString, DefaultSelectFields, cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"GetUserDataByMudIdAsync({mudId}) error : {ex.Message}");
            }
            return null;
        }
        private async Task<AzureGraphUserData> RunGraphApiCallAsync(string filterString, string selectFields, CancellationToken cancellationToken)
        {
            var result = await graphClient.Users
                                        .Request()
                                        .Filter(filterString)
                                        .Select(selectFields)
                                        .GetAsync(cancellationToken);
            var adUser = result.FirstOrDefault();
            if (adUser != null)
            {
                return new AzureGraphUserData
                {
                    Id = adUser.Id,
                    City = adUser.City,
                    CompanyName = adUser.CompanyName,
                    Country = adUser.Country,
                    DisplayName = adUser.DisplayName,
                    GivenName = adUser.GivenName,
                    Mail = adUser.Mail,
                    OfficeLocation = adUser.OfficeLocation,
                    UserPrincipalName = adUser.UserPrincipalName,
                    MudId = adUser.MailNickname
                };
            }
            return null;
        }
    }
}
