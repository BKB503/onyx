﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.DataAccess.Providers;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.AllianceData
{
    public class AllianceReader : IAllianceReader
    {
        public readonly IAllianceConfigurationProvider allianceConfigurationProvider;
        IOAuth2TokenProvider oAuth2TokenProvider;
        ILogger<AllianceReader> logger;

        public AllianceReader(IAllianceConfigurationProvider options, IOAuth2TokenProvider oAuth2TokenProvider, ILogger<AllianceReader> logger)
        {
            allianceConfigurationProvider = options;
            this.oAuth2TokenProvider = oAuth2TokenProvider;
            this.logger = logger;
        }
        public async Task<IEnumerable<AgreementPacket>> ReadAllianceInformationAsync(CancellationToken cancellationToken)
        {
            logger.LogInformation($"Alliance reader call started");
            AllianceConfiguration allianceConfiguration = allianceConfigurationProvider.GetAllianceConfiguration();
            var config = new OAuth2Configruation
            {
                ClientId = allianceConfiguration.ClientID,
                ClientSecret = allianceConfiguration.ClientSecret,
                AccessTokenUrl = new Uri(allianceConfiguration.PingFedartationUrl),
                Scope = allianceConfiguration.Scope
            };

            OAuth2Token token = await oAuth2TokenProvider.GetTokenAsync(config, cancellationToken);

            if (token == null)
            {
                logger.LogError($"No token for AllianceReader provisioned. Client Id : {config.ClientId} Client Secret (5 first letters) :{config.ClientSecret?.Substring(0, 5)}");
                return null;
            }


            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(allianceConfiguration.BaseAddress);
            try
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, allianceConfiguration.APIUrl))
                {
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                    logger.LogInformation($"Alliance Agreement packets api call");
                    var response = await client.SendAsync(request, cancellationToken);

                    response.EnsureSuccessStatusCode();

                    var result = await response.Content.ReadAsStringAsync(cancellationToken);
                    JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true,
                        WriteIndented = true
                    };
                    jsonSerializerOptions.Converters.Add(new JsonDateTimeConverter());

                    var dataSet = JsonSerializer.Deserialize<IEnumerable<AgreementPacket>>(result, jsonSerializerOptions);
                    logger.LogInformation($"Alliance Agreement packets received");
                    return dataSet;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message, ex.StackTrace);
                return null;
            }
        }
    }
}
