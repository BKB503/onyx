﻿using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Repositories
{
    public class FilesRepository : IFilesRepository
    {
        private readonly IStorageClientFactory clientFactory;
        private readonly IStorageIndexProvider storageIndexProvider;

        public FilesRepository(IStorageClientFactory clientFactory,
                               IStorageIndexProvider fileIndexProvider)
        {
            this.clientFactory = clientFactory;
            storageIndexProvider = fileIndexProvider;
        }

        public async Task<FileResource> GetFileByNameAndVersionAsync(ContainerResource container, string fileName, string folderName, string versionId, CancellationToken token)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                // log error
                return null;
            }
            return await storageClient.GetOneFileInformationWithVersionAsync(container, fileName, folderName, versionId, token);
        }

        public async Task UpdateTagsAsync(ContainerResource container, FileResource file, Dictionary<string, string> tags, CancellationToken cancellationToken)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                // log error
                return;
            }
            await storageClient.UpdateTagsAsync(container, file, tags, cancellationToken);
        }
    }
}
