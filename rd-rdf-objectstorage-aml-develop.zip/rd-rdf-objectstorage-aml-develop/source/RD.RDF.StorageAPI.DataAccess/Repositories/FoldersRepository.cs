﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.Filters;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Repositories
{
    public class FoldersRepository : IFoldersRepository
    {
        private readonly IStorageClientFactory clientFactory;
        private readonly ILogger<FoldersRepository> logger;

        public FoldersRepository(IStorageClientFactory clientFactory, ILogger<FoldersRepository> logger)
        {
            this.clientFactory = clientFactory;
            this.logger = logger;
        }

        public async Task<PagedApiResponse<List<FileResource>>> GetAllDataFromStorageAsync(ContainerResource container, PaginationFilter filter, CancellationToken token)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                logger.LogError($"No storageClient for container: {container.ContainerName} of type {container.Configuration.Type}");
                return null;
            }
            var result = await storageClient.GetAllDataFromStorageAsync(container, filter, token);
            return result;
        }

        public async Task<PagedApiResponse<FolderResource>> GetAllFoldersAsync(ContainerResource container, string parentFolder, PaginationFilter filter, CancellationToken token)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                logger.LogError($"No storageClient for container: {container.ContainerName} of type {container.Configuration.Type}");
                return null;
            }
            var result = await storageClient.GetFullFolderInformationAsync(container, parentFolder, filter, token);
            return result;
        }
    }

}
