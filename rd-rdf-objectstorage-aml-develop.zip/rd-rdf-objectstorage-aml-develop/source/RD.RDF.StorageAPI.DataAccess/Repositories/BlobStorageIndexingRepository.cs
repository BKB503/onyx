﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Repositories
{
    public class BlobStorageIndexingRepository : IIndexingRespository
    {
        private readonly IStorageClientFactory clientFactory;
        private static readonly JsonSerializerOptions options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = false,
            WriteIndented = true
        };

        public IndexingType indexingType { get => IndexingType.azureblob; }
        ILogger<BlobStorageIndexingRepository> logger;

        public BlobStorageIndexingRepository(IStorageClientFactory clientFactory, ILogger<BlobStorageIndexingRepository> logger)
        {
            this.clientFactory = clientFactory;
            this.logger = logger;
        }
        public async Task WriteFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token = default)
        {
            logger.LogInformation("Writing index file to .index folder of the storage");
            var storageClient = clientFactory.GetStorageClient(container);
            string json = JsonSerializer.Serialize(fileIndexModel, options);
            var buffer = Encoding.ASCII.GetBytes(json);
            using MemoryStream stream = new MemoryStream(buffer);
            logger.LogInformation("Uploading the index file to storage");
            await storageClient.UploadObjectAsync(container, fileResource.IndexFileName, fileResource.IndexFolder, stream, null, token);

        }


        public async Task<FileResource> UpdateFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token = default)
        {
            logger.LogInformation("Updating metadata information in the index file");
            var storageClient = clientFactory.GetStorageClient(container);

            string json = JsonSerializer.Serialize(fileIndexModel, options);
            var buffer = Encoding.ASCII.GetBytes(json);
            MemoryStream stream = new MemoryStream(buffer);

            // uploading it back to blob
            logger.LogInformation("Upploading file back to storage");

            return await storageClient.UploadObjectAsync(container, fileResource.FileName, fileResource.FolderName, stream, null, token);
        }

    }
}
