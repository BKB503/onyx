﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Configuration;
using RD.RDF.StorageAPI.Contracts.Model;
using System;
using System.Collections.Concurrent;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Repositories
{
    public class KafkaIndexingRepository : IIndexingRespository
    {
        private readonly ILogger<KafkaIndexingRepository> logger;
        private readonly JsonSerializerOptions jsonOptions;
        private readonly ConcurrentDictionary<string, IProducer<Null, string>> kafkaProducers = new ConcurrentDictionary<string, IProducer<Null, string>>();

        public KafkaIndexingRepository(ILogger<KafkaIndexingRepository> logger)
        {
            this.logger = logger;
            jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = false,
                WriteIndented = true
            };
        }
        public IndexingType indexingType { get => IndexingType.kafka; }

        public async Task<FileResource> UpdateFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token = default)
        {
            await WriteFileIndexAsync(fileResource, fileIndexModel, container, token);
            return null;
        }

        public async Task WriteFileIndexAsync(FileResource fileResource, FileIndexModel fileIndexModel, ContainerResource container, CancellationToken token)
        {
            logger.LogInformation($"Writing the index file {fileResource.FilePath} to Kafka Started");
            try
            {
                var producerClient = GetKafkaProducer(container);
                string json = JsonSerializer.Serialize(fileIndexModel, jsonOptions);
                var msg = new Message<Null, string> { Value = json };
                var deliveryReport = await producerClient.ProduceAsync(container.Configuration.IndexingConfiguration.Topic, msg, token);
                logger.LogInformation($"Writing the index file {fileResource.FilePath} to Kafka Completed");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Writing the index file {fileResource.FilePath} to Kafka Error: {ex.Message}");
            }
        }

        private IProducer<Null, string> GetKafkaProducer(ContainerResource container)
        {
            if (!kafkaProducers.TryGetValue(container.ContainerName, out IProducer<Null, string> producer))
            {
                var config = new ProducerConfig
                {
                    SaslPassword = container.Configuration.IndexingConfiguration.EventHubConnectionString,
                    BootstrapServers = container.Configuration.IndexingConfiguration.KafkaServers,
                    SaslMechanism = SaslMechanism.Plain,
                    SaslUsername = container.Configuration.IndexingConfiguration.SaslUsername,
                    SecurityProtocol = SecurityProtocol.SaslSsl,
                    // SslCaLocation = container.indexingConfiguration.SslCaLocation,
                    Debug = "security,broker,protocol"
                };
                producer = new ProducerBuilder<Null, string>(config).SetKeySerializer(Serializers.Null).SetValueSerializer(Serializers.Utf8).Build();
                kafkaProducers.TryAdd(container.ContainerName, producer);
            }
            return producer;
        }

    }
}
