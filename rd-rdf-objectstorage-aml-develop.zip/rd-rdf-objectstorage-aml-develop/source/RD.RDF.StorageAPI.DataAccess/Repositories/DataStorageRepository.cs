﻿using Confluent.Kafka;
using Microsoft.Graph;
using RD.RDF.StorageAPI.Contracts.Abstractions;
using RD.RDF.StorageAPI.Contracts.Model;
using RD.RDF.StorageAPI.Contracts.Model.PartialUploads;
using RD.RDF.StorageAPI.Contracts.Model.Wrappers;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.DataAccess.Repositories
{
    public class DataStorageRepository : IDataStorageRepository
    {
        private readonly IStorageClientFactory clientFactory;

        public DataStorageRepository(IStorageClientFactory clientFactory)
        {
            this.clientFactory = clientFactory;
        }

        public async Task<Stream> GetFileStreamAsync(ContainerResource container, FileResource fileInfo, CancellationToken token = default)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                // log error
                return null;
            }
            var stream = await storageClient.DownloadObjectAsync(container, fileInfo, token);
            return stream;
        }

        public async Task<UploadFileResult> UploadFileToFolderAsync(ContainerResource container, string fileName, string folder, Stream fileData, MetadataCollections dictionary, CancellationToken token = default)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                return new UploadFileResult(UploadFileResultStatus.Error, "Storage client not available");
            }
            fileData.Position = 0;// to avoid file content position error.
            var uploaded = await storageClient.UploadObjectAsync(container, fileName, folder, fileData, dictionary, token);

            return new UploadFileResult(uploaded,
                                        uploaded != null ? UploadFileResultStatus.Success : UploadFileResultStatus.Error,
                                        uploaded != null ? "Upload Successfull" : "Upload Failed");
        }

        public async Task<UploadPartResult> UploadPartFileAsync(ContainerResource container, UploadPartFileModel fileModel, CancellationToken cancellationToken)
        {
            var storageClient = clientFactory.GetStorageClient(container);

            if (storageClient == null)
            {
                return new UploadPartResult(UploadFileResultStatus.Error, "Storage client not available");
            }

            fileModel.FilePartStream.Position = 0;// to avoid file content position error.
            return await storageClient.UploadPartFileAsync(container, fileModel, cancellationToken);
        }

        public async Task<UploadPartCommitResult> UploadPartsCommitAsync(ContainerResource container, string uploadSessionId, string fileName, string folder, UploadPartCommitCollection parts, MetadataCollections metadata, CancellationToken cancellationToken)
        {
            var storageClient = clientFactory.GetStorageClient(container);
            if (storageClient == null)
            {
                return new UploadPartCommitResult(UploadFileResultStatus.Error, "Storage client not available");
            }
            return await storageClient.UploadPartsCommitAsync(container, uploadSessionId, fileName, folder, parts, metadata, cancellationToken);
        }

        public async Task<UploadPartsInitResult> UploadPartsInitAsync(ContainerResource container, string fileName, string folder, CancellationToken cancellationToken)
        {
            var storageClient = clientFactory.GetStorageClient(container);

            if (storageClient == null)
            {
                return new UploadPartsInitResult(UploadFileResultStatus.Error, "Storage client not available");
            }
            return await storageClient.UploadPartsInitAsync(container, fileName, folder, cancellationToken);
        }
    }
}
