# RDF Storage-API\databricks

Folder contains Databricks code for Alliance db and Indexing db
