# Databricks notebook source
# MAGIC %run ./InitMountContainer

# COMMAND ----------

#create bronze data lake
bronzeDataLake = mountPoint + "/db/bronze/lake"
bronzeDataLakeCheckpoints = mountPoint + "/db/bronze/lake_checkpoints"
bronzeDataLakeCheckpoints1 = mountPoint + "/db/bronze/kafka_checkpoints"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark import Row
from delta.tables import *
from pyspark.sql import functions as F

spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")
#uncomment that for clean start
#dbutils.fs.rm(bronzeDataLake, True)
#dbutils.fs.rm(bronzeDataLakeCheckpoints, True)
#dbutils.fs.rm(bronzeDataLakeCheckpoints1, True)


schemaFolder = mountPoint + "/schema"
dataSourceModel = schemaFolder + "/schema.json"
schemaDF = spark.read.option("multiline","true").json(dataSourceModel)

# Load your Streaming DataFrame
sdf = (spark.readStream 
            .format("cloudFiles") 
            .option("cloudFiles.format", "json") 
            .option("cloudFiles.schemaEvolutionMode", "rescue") 
            .option("rescuedDataColumn", "_rescuedData") 
            .option("cloudFiles.inferColumnTypes", "false") 
            .option("cloudFiles.allowOverwrites", "true") 
            .option("cloudFiles.includeExistingFiles", "true") 
            .option("cloudFiles.useNotifications","false") 
            .option("multiline","true") 
            .schema(schemaDF.schema) 
            .option("latestFirst", "false") 
            .load(schemaFolder)  
            .withColumn("ModificationDate",F.to_timestamp(F.col("ModificationDate")))
            .withColumn("CreationTime",F.to_timestamp(F.col("CreationTime")))
            .withColumn("InputFileName", F.input_file_name()) 
            .withColumn("InputFileLoadDate", F.current_timestamp())
            .withColumn("YearCreated", F.date_format(F.col("CreationTime"), "yyyy"))
            .withColumn("MonthCreated", F.date_format(F.col("CreationTime"), "MM")))


# Perform transformations and then write… once trigger
# .trigger(once=True)
#  
ws = (sdf.writeStream 
         .option("checkpointLocation", bronzeDataLakeCheckpoints) 
         .format("delta") 
         .outputMode("append") 
         .trigger(once=True) 
         .option("mergeSchema", "true") 
         .partitionBy("Container", "YearCreated", "MonthCreated")
         .start(bronzeDataLake))

ws.awaitTermination()

# COMMAND ----------

dbName = "suplementarydata"
tableName = "bronzeLake"
spark.sql(f"drop database if exists {dbName} cascade;")
spark.sql(f"CREATE DATABASE IF NOT EXISTS {dbName};")
spark.sql(f"CREATE TABLE IF NOT EXISTS {dbName}.{tableName} USING DELTA LOCATION '{bronzeDataLake}';")

# COMMAND ----------

# MAGIC %sql
# MAGIC use suplementarydata;
# MAGIC 
# MAGIC CREATE OR REPLACE VIEW v_bronzeLake  as
# MAGIC  SELECT r.FileName,
# MAGIC         r.FolderName,
# MAGIC         r.FilePath,
# MAGIC         r.Container,
# MAGIC         r.FileBlobType,
# MAGIC         r.FileContentType,
# MAGIC         r.FileGuid,
# MAGIC         r.FileVersionId,
# MAGIC         r.FileHash,
# MAGIC         r.CreationTime,
# MAGIC         r.FileSize,
# MAGIC         r.InputFileName,
# MAGIC         r.InputFileLoadDate,
# MAGIC         r.ModificationDate
# MAGIC  FROM bronzeLake r ;
# MAGIC 
# MAGIC 
# MAGIC CREATE OR REPLACE VIEW v_bronzeLake_metadata  as
# MAGIC  SELECT r.FileName,
# MAGIC         r.FolderName,
# MAGIC         r.FilePath,
# MAGIC         r.Container,
# MAGIC         r_meta.Key,
# MAGIC         r_meta.Value
# MAGIC  FROM bronzeLake r 
# MAGIC   LATERAL VIEW OUTER explode(r.Metadata) AS r_meta;
# MAGIC    
# MAGIC   
# MAGIC  CREATE OR REPLACE VIEW v_bronzeLake_versions  as
# MAGIC  SELECT  r.FileName,r.FolderName, r.FilePath,  r.Container ,
# MAGIC r_version.IsLatestVersion,
# MAGIC r_version.VersionNumber,
# MAGIC r_version.FileVersionId,
# MAGIC r_version.FileGuid,
# MAGIC r_version.FileHash,
# MAGIC r_version.FileSize,
# MAGIC r_version.CreationTime
# MAGIC  FROM bronzeLake r 
# MAGIC   LATERAL VIEW OUTER explode(r.Versions) AS r_version;
# MAGIC   
# MAGIC   
# MAGIC   CREATE OR REPLACE VIEW v_bronzeLake_versionsMetadata  as
# MAGIC  SELECT  r.FileName,r.FolderName, r.FilePath,  r.Container ,
# MAGIC r_version.IsLatestVersion,
# MAGIC r_version.VersionNumber,
# MAGIC r_version.FileVersionId,
# MAGIC r_version.FileGuid,
# MAGIC r_version.FileHash,
# MAGIC r_version.FileSize,
# MAGIC r_version.CreationTime,
# MAGIC   r_versionMeta.Key,
# MAGIC         r_versionMeta.Value
# MAGIC  FROM bronzeLake r 
# MAGIC   LATERAL VIEW OUTER explode(r.Versions) AS r_version
# MAGIC    LATERAL VIEW OUTER explode(r_version.Metadata) AS r_versionMeta;
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC use suplementarydata;
# MAGIC --select * from v_bronzeLake_versionsMetadata
# MAGIC --select * from v_bronzeLake;
# MAGIC --select * from v_bronzeLake_metadata;
# MAGIC delete from bronzeLake where FileGuid = "9e810f82-b582-4f8e-b219-4708ee2b9532";

# COMMAND ----------

from pyspark.sql.functions import expr
from pyspark.sql.types import *

#silver data lake - delete
silverDataLake = mountPoint + "/db/silver/lake"
silverDataLakeCheckpoints = mountPoint + "/db/silver/lake_checkpoints"
silverDataLakeCheckpoints1 = mountPoint + "/db/silver/_initlake_checkpoints"

dbutils.fs.rm(silverDataLake, True)
dbutils.fs.rm(silverDataLakeCheckpoints, True)
dbutils.fs.rm(silverDataLakeCheckpoints1, True)

# COMMAND ----------

#files data lake
filesLakeDataLake = mountPoint + "/db/files/lake"
filesDataLakeCheckpoints = mountPoint + "/db/files/lake_checkpoints"
filesDataLakeCheckpoints1 = mountPoint + "/db/files/_initlake_checkpoints"

#dbutils.fs.rm(filesLakeDataLake, True)
#dbutils.fs.rm(filesDataLakeCheckpoints, True)
#dbutils.fs.rm(filesDataLakeCheckpoints1, True)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark import Row
from delta.tables import *
from pyspark.sql import functions as F

dataIn = [{"FileGuid": 'A'}]
dtBronze = DeltaTable.forPath(spark, path=bronzeDataLake)
dtBronzeDF = dtBronze.toDF() 
schemaSilver = dtBronzeDF.schema

silverIn = spark.createDataFrame(dataIn, schemaSilver)

silverOut = (silverIn.withColumn("CreationTime",F.to_timestamp(F.col("CreationTime")))
                     .withColumn("InputFileLoadDate", F.current_timestamp())
                     .withColumn("YearCreated", F.date_format(F.col("CreationTime"), "yyyy"))
                     .withColumn("MonthCreated", F.date_format(F.col("CreationTime"), "MM"))
                     .withColumn("InputFileName", F.input_file_name()) )
spark.sql(f"drop TABLE IF EXISTS {dbName}.streamSilverIn")
silverOut.write.format("delta").mode("overwrite").saveAsTable(f"{dbName}.streamSilverIn")
streamSilverIn = spark.readStream.table(f"{dbName}.streamSilverIn")

writeSilver = (streamSilverIn.writeStream
                        .option("checkpointLocation", filesDataLakeCheckpoints1) 
                        .format("delta") 
                        .partitionBy("Container", "YearCreated", "MonthCreated")
                        .trigger(once=True)
                        .start(filesLakeDataLake))

writeSilver.awaitTermination()
spark.sql(f"drop TABLE IF EXISTS {dbName}.streamSilverIn")

dbName = "suplementarydata"
tableNameFiles = "filesInfo"
spark.sql(f"CREATE DATABASE IF NOT EXISTS {dbName};")
spark.sql(f"CREATE TABLE IF NOT EXISTS {dbName}.{tableNameFiles} USING DELTA LOCATION '{filesLakeDataLake}';")
spark.sql(f"ALTER TABLE {dbName}.{tableNameFiles} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")
#writeSilver.awaitTermination()

# COMMAND ----------

# MAGIC %sql
# MAGIC use suplementarydata;
# MAGIC 
# MAGIC   
# MAGIC  CREATE OR REPLACE VIEW v_filesInfo  as
# MAGIC  SELECT r.FileName,
# MAGIC         r.FolderName,
# MAGIC         r.FilePath,
# MAGIC         r.Container,
# MAGIC         r.FileBlobType,
# MAGIC         r.FileContentType,
# MAGIC         r.FileGuid,
# MAGIC         r.FileVersionId,
# MAGIC         r.FileHash,
# MAGIC         r.CreationTime,
# MAGIC         r.FileSize,
# MAGIC         r.InputFileName,
# MAGIC         r.InputFileLoadDate,
# MAGIC         r.ModificationDate
# MAGIC  FROM filesInfo r ;
# MAGIC 
# MAGIC 
# MAGIC CREATE OR REPLACE VIEW v_filesInfo_metadata  as
# MAGIC  SELECT r.FileName,
# MAGIC         r.FolderName,
# MAGIC         r.FilePath,
# MAGIC         r.Container,
# MAGIC         r_meta.Key,
# MAGIC         r_meta.Value
# MAGIC  FROM filesInfo r 
# MAGIC   LATERAL VIEW OUTER explode(r.Metadata) AS r_meta;
# MAGIC    
# MAGIC   
# MAGIC  CREATE OR REPLACE VIEW v_filesInfo_versions  as
# MAGIC  SELECT  r.FileName,r.FolderName, r.FilePath,  r.Container ,
# MAGIC r_version.IsLatestVersion,
# MAGIC r_version.VersionNumber,
# MAGIC r_version.FileVersionId,
# MAGIC r_version.FileGuid,
# MAGIC r_version.FileHash,
# MAGIC r_version.FileSize,
# MAGIC r_version.CreationTime
# MAGIC  FROM filesInfo r 
# MAGIC   LATERAL VIEW OUTER explode(r.Versions) AS r_version;
# MAGIC   
# MAGIC   
# MAGIC   CREATE OR REPLACE VIEW v_filesInfo_versionsMetadata  as
# MAGIC  SELECT  r.FileName,r.FolderName, r.FilePath,  r.Container ,
# MAGIC r_version.IsLatestVersion,
# MAGIC r_version.VersionNumber,
# MAGIC r_version.FileVersionId,
# MAGIC r_version.FileGuid,
# MAGIC r_version.FileHash,
# MAGIC r_version.FileSize,
# MAGIC r_version.CreationTime,
# MAGIC   r_versionMeta.Key,
# MAGIC         r_versionMeta.Value
# MAGIC  FROM filesInfo r 
# MAGIC   LATERAL VIEW OUTER explode(r.Versions) AS r_version
# MAGIC    LATERAL VIEW OUTER explode(r_version.Metadata) AS r_versionMeta;
# MAGIC   
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC use suplementarydata;
# MAGIC --select * from v_silverLake;
# MAGIC --select * from v_bronzeLake_metadata;
# MAGIC delete from filesInfo where FileGuid = "A";
