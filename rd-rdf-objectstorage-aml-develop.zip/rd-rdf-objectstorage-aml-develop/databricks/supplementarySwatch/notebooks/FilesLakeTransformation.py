# Databricks notebook source
keyVaultName = "keyVaultStorage"
#read container name from second KeyVault - Idbs
adlsContainerName= dbutils.secrets.get(scope=keyVaultName, key="adlsContainerName")
 
mountPoint = "/mnt/" + adlsContainerName

 
#create bronze data lake
bronzeDataLake = mountPoint + "/db/bronze/lake"
bronzeDataLakeCheckpoints = mountPoint + "/db/bronze/lake_checkpoints"
bronzeDataLakeCheckpoints1 = mountPoint + "/db/bronze/kafka_checkpoints"

#files data lake
filesLakeDataLake = mountPoint + "/db/files/lake"
filesDataLakeCheckpoints = mountPoint + "/db/files/lake_checkpoints"

 
# Make some configurations small-scale friendly
sql("set spark.sql.shuffle.partitions = 1")
sql("set spark.databricks.delta.snapshotPartitions = 1")
    

# COMMAND ----------

from pyspark.sql.types import *
from pyspark import Row
from delta.tables import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window

filesTable = DeltaTable.forPath(spark, filesLakeDataLake)
 
def upsertToDelta(microDF, batchId) :
    #print(f"upsertToDelta forEachRow for batchId:{batchId}. Rows in passed DataFrame: {microDF.count()}")
    #get the latest update in  microBatch
    microDF = (microDF.withColumn("ContainerFilePath", F.concat_ws("|", F.col("Container"),F.col("FilePath")))
                      .withColumn("rn", F.row_number()
                      .over(Window.partitionBy("ContainerFilePath")
                                  .orderBy(F.col("ModificationDate").desc()))
                            )
                      .filter(F.col("rn") == 1)
                      .drop("rn")
                      .drop("ContainerFilePath")
                      )    
    mergeRes = (filesTable.alias("t")
                           .merge(microDF.alias("s"), "s.Container = t.Container AND s.FilePath = t.FilePath")
                           .whenMatchedUpdateAll("s.ModificationDate >= t.ModificationDate")
                           .whenNotMatchedInsertAll()
                           .execute())

bronzeLakeIn = (spark.readStream
                     .format("delta")                    
                     .load(bronzeDataLake)
                     .withColumn("VersionCount", F.size(F.col("Versions")))
                     .withColumn("MetadataCount", F.size(F.col("Metadata")))
               )

ws = (bronzeLakeIn.writeStream
                  .option("checkpointLocation", filesDataLakeCheckpoints)
                  .format("delta")
                  .outputMode("append")
                  .option("mergeSchema", "true")
                  .foreachBatch(upsertToDelta)
                  .start(filesLakeDataLake))

# COMMAND ----------

# %sql
# select * from suplementarydata.filesInfo
