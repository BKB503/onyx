# Databricks notebook source
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import Row

meta = spark.sql("select * from suplementarydata.v_filesinfo_metadata")
filesinfo = spark.sql("select * from suplementarydata.filesinfo")
users_alliance = spark.sql("select * from alliancedata.v_agreementpackets_teammembers")
alliance_data = spark.sql("select * from alliancedata.agrementpackets")


containers=filesinfo.select(f"Container").distinct()
container_list = [x.Container for x in containers.collect()]

#Define the required parameters to run the script.
dbutils.widgets.dropdown("container_name", container_list[0],container_list)
dbutils.widgets.text("full_path","")
dbutils.widgets.text("mudid","")
container_name = dbutils.widgets.get("container_name")
full_path = dbutils.widgets.get("full_path")
mudid = dbutils.widgets.get("mudid")

file_exists = True if len(filesinfo.filter(f"FilePath==\"{full_path}\" AND Container == \"{container_name}\"").collect())>0 else False
alliance_exists = False
is_gsk_prop = False
user_acc = False
is_restricted = False

if file_exists==True:
    alliance=meta.filter(f"FilePath==\"{full_path}\" and Key ==\"AgreementPacket\"")
    alliance_exists=True if len(alliance.collect())>0 else False
    if alliance_exists:
        alliance_tag=alliance.collect()[0]['Value']
        is_restricted = alliance_data.filter(f"abbreviation==\"{alliance_tag}\" ").collect()[0]["isRestricted"]
        is_gsk_prop=True if alliance_tag=="GSK Proprietary" else False
        if not is_gsk_prop:
            user_alliance = users_alliance.filter(f"teamMember==\"{mudid}\"")
            user_acc = True if len(user_alliance.filter(f"name==\"{alliance_tag}\"").collect())>0 and not is_restricted else False


data = [{"File exists": file_exists, "Allieance exists": alliance_exists, "Alliance restricted": is_restricted, "GSK Proprietary": is_gsk_prop, "User access": user_acc}]
df = spark.createDataFrame(data)
display(df)
