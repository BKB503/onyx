# Databricks notebook source
from pyspark.sql.types import *
from pyspark import Row
from delta.tables import *
from pyspark.sql import functions as F

spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

keyVaultName = "keyVaultStorage"

# Define the variables used for creating connection strings 
adlsAccountName = dbutils.secrets.get(scope=keyVaultName, key="adlsAccountName")
# Application (Client) ID
applicationId = dbutils.secrets.get(scope=keyVaultName, key="adlsClientid")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope=keyVaultName, key="adlsClientSecret")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope=keyVaultName, key="adlsTenantId")
#read container name from second KeyVault - Idbs
adlsContainerName= dbutils.secrets.get(scope=keyVaultName, key="adlsContainerNameAlliance")

# Kafka (event hubs) topic
kafkaServers = dbutils.secrets.get(scope=keyVaultName,key="RDFKafkaServers")
# Kafka (event hubs) connection string
kafkaConnectionString = dbutils.secrets.get(scope=keyVaultName, key="RDFKafkaConnectionString")
# Kafka (event hubs) topic
kafkaTopic = dbutils.secrets.get(scope=keyVaultName, key="RDFKafkaTopicAlliance")
# Kafka (event hubs) group id
kafkaUsername = dbutils.secrets.get(scope=keyVaultName, key="RDFKafkaUserName")
kafkaGroupId = "DatabricksIngestion"
kafkaSASL = f'org.apache.kafka.common.security.plain.PlainLoginModule required username="{kafkaUsername}" password="{kafkaConnectionString}";'

mountPoint = "/mnt/" + adlsContainerName
#bronze data lake
bronzeDataLake = mountPoint + "/db/bronze/lake"
bronzeDataLakeCheckpoints = mountPoint + "/db/bronze/kafka_checkpoints"


schemaFolder = mountPoint + "/schema"
dataSourceModel = schemaFolder + "/schema.json"
schemaDF = spark.read.option("multiline","true").json(dataSourceModel)
 
#Read from your Kafka topic 
df = (spark.readStream
    .format("kafka")
    .option("subscribe", kafkaTopic)
    .option("kafka.bootstrap.servers", kafkaServers)
    .option("kafka.sasl.mechanism", "PLAIN")
    .option("kafka.security.protocol", "SASL_SSL")
    .option("kafka.sasl.jaas.config", kafkaSASL)
    .option("kafka.request.timeout.ms", "60000")
    .option("kafka.session.timeout.ms", "30000")
    .option("kafka.group.id", kafkaGroupId)
    .option("failOnDataLoss", "true")
    .option("startingOffsets", "earliest") 
    .load()
    .select(F.from_json(F.col("value").cast("string"),schemaDF.schema).alias("jsonObj"),
            F.concat_ws("_",F.col("topic"),F.col("partition"),F.col("offset"),F.col("timestamp")).alias("InputFileName"),
            F.col("value").cast("string").alias("rawJsonData"))
    .select("jsonObj.*","InputFileName", "rawJsonData")
    .withColumn("ingestionTimestamp", F.current_timestamp())
    .withColumn("isActive",  F.col("isActive").cast('boolean'))
    .withColumn("creationDate",F.to_timestamp(F.col("creationDate")))
    .withColumn("modificationDate",F.to_timestamp(F.col("modificationDate")))
    .withColumn("effectiveDate",F.to_timestamp(F.col("effectiveDate")))
    .withColumn("endDate",F.to_timestamp(F.col("endDate")))
    .withColumn("isRestricted",F.when(F.col("experimentRestriction.code") == 101, False)
                               .when(F.col("experimentRestriction.code") == 105, False)
                               .otherwise(True))
     )
   
    

df_write = (df.writeStream
              .option("checkpointLocation", bronzeDataLakeCheckpoints) 
              .format("delta") 
              .outputMode("append")               
              .start(bronzeDataLake))


# COMMAND ----------

# test the streaming job
# dbName = "suplementarydata"
# tmpView = "bronzeLakeView"

# spark.readStream \
#   .format("delta") \
#   .load(bronzeDataLake) \
#   .createOrReplaceTempView(tmpView)

# spark.sql(f"SELECT * FROM {tmpView} limit 100").display()

# COMMAND ----------

# %sql

# select abbreviation , count(abbreviation)
# from alliancedata.agrementpacketsraw
# group by abbreviation
# order by 1 desc
