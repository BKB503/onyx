# Databricks notebook source
# define keyVault connection first in DataBrics ui
#Go to https://<DATABRICKS-INSTANCE>#secrets/createScope and replace <DATABRICKS-INSTANCE> with your actual Databricks instance URL. Create a Secret Scope, as shown below.
# full instruction here -> https://towardsdatascience.com/mounting-accessing-adls-gen2-in-azure-databricks-using-service-principal-and-secret-scopes-96e5c3d6008b
 
keyVaultName = "keyVaultStorage"

# Define the variables used for creating connection strings 
adlsAccountName = dbutils.secrets.get(scope=keyVaultName, key="adlsAccountName")
# Application (Client) ID
applicationId = dbutils.secrets.get(scope=keyVaultName, key="adlsClientid")
# Application (Client) Secret Key
authenticationKey = dbutils.secrets.get(scope=keyVaultName, key="adlsClientSecret")
# Directory (Tenant) ID
tenandId = dbutils.secrets.get(scope=keyVaultName, key="adlsTenantId")

#read container name from second KeyVault
adlsContainerName= dbutils.secrets.get(scope=keyVaultName, key="adlsContainerNameAlliance")
 
mountPoint = "/mnt/" + adlsContainerName

endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/"

# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# Mounting ADLS Storage to DBFS
# Mount only if the directory is not already mounted
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
  dbutils.fs.mount(
    source = source,
    mount_point = mountPoint,
    extra_configs = configs)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark import Row
from delta.tables import *
from pyspark.sql import functions as F

spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")
spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

#create bronze data lake
bronzeDataLake = mountPoint + "/db/bronze/lake"
bronzeDataLakeCheckpoints = mountPoint + "/db/bronze/lake_checkpoints"
bronzeDataLakeCheckpoints1 = mountPoint + "/db/bronze/kafka_checkpoints"

#uncomment that for clean start
# dbutils.fs.rm(bronzeDataLake, True)
# dbutils.fs.rm(bronzeDataLakeCheckpoints, True)
# dbutils.fs.rm(bronzeDataLakeCheckpoints1, True)

sampleFile = mountPoint + "/initData/AllianceAgreements.json"
schemaFolder = mountPoint + "/schema"
dataSourceModel = schemaFolder + "/schema.json"
schemaDF = spark.read.option("multiline","true").json(dataSourceModel)
sampleData = (spark.read.option("multiline","true")
                .schema(schemaDF.schema)
                .json(sampleFile))

sampleData = (sampleData
               .withColumn("isActive",  F.col("isActive").cast('boolean'))
               .withColumn("creationDate",F.to_timestamp(F.col("creationDate")))
               .withColumn("modificationDate",F.to_timestamp(F.col("modificationDate")))
               .withColumn("effectiveDate",F.to_timestamp(F.col("effectiveDate")))
               .withColumn("endDate",F.to_timestamp(F.col("endDate")))
               .withColumn("isRestricted",F.when(F.col("experimentRestriction.code") == 101, False)
                                           .when(F.col("experimentRestriction.code") == 105, False)
                                           .otherwise(True))
             )
 
ws = (sampleData.write          
         .format("delta")
         .mode("overwrite")
         .save(bronzeDataLake))


dbName = "allianceData"
tableName = "agrementPacketsRaw"
spark.sql(f"drop database if exists {dbName} cascade;")
spark.sql(f"CREATE DATABASE IF NOT EXISTS {dbName};")
spark.sql(f"CREATE TABLE IF NOT EXISTS {dbName}.{tableName} USING DELTA LOCATION '{bronzeDataLake}';")


# COMMAND ----------

from pyspark.sql.types import *
from pyspark import Row
from delta.tables import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window

#initialize gold layer 

#gold data lake
goldDataLake = mountPoint + "/db/gold/lake"
goldDataLakeCheckpoints = mountPoint + "/db/gold/lake_checkpoints"
#uncomment that for clean start
dbutils.fs.rm(goldDataLake, True)
dbutils.fs.rm(goldDataLakeCheckpoints, True)


bronzeLakeIn = (spark.readStream
                     .format("delta")                     
                     .load(bronzeDataLake)
                     .where("agreementContractId is not null"))

ws = (bronzeLakeIn.writeStream
                  .option("checkpointLocation", goldDataLakeCheckpoints)
                  .format("delta")
                  .outputMode("append")
                  .option("mergeSchema", "true")
                  .trigger(once=True)
                  #.foreachBatch(upsertToDelta)
                  .start(goldDataLake))


# COMMAND ----------

tableNameGold = "agrementPackets"
spark.sql(f"CREATE TABLE IF NOT EXISTS {dbName}.{tableNameGold} USING DELTA LOCATION '{goldDataLake}';")


# COMMAND ----------

# MAGIC %sql
# MAGIC use allianceData;
# MAGIC   
# MAGIC CREATE OR REPLACE VIEW v_agreementPackets_teamMembers  as
# MAGIC  SELECT raw.agreementContractId,
# MAGIC         raw.name,
# MAGIC         raw.longName,
# MAGIC         raw.experimentRestriction.code as `code`,
# MAGIC         raw.isActive , 
# MAGIC         raw.isRestricted, 
# MAGIC         raw.creationDate,
# MAGIC         raw.modificationDate,
# MAGIC         raw.effectiveDate,
# MAGIC         raw.endDate,
# MAGIC        r_team as `teamMember`
# MAGIC  FROM agrementPackets raw
# MAGIC   LATERAL VIEW OUTER explode(raw.teamMembers) AS r_team;
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC use allianceData;
# MAGIC --select * from v_agreementPacketsRaw_teamMembers;
# MAGIC select * 
# MAGIC from v_agreementPackets_teamMembers;
# MAGIC 
# MAGIC -- GRANT SELECT ON TABLE allianceData.agrementPacketsRaw TO devs;
