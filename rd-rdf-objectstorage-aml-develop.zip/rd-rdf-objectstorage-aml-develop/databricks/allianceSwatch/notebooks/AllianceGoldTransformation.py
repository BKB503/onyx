# Databricks notebook source
keyVaultName = "keyVaultStorage"
#read container name from second KeyVault - Idbs
adlsContainerName= dbutils.secrets.get(scope=keyVaultName, key="adlsContainerNameAlliance")
 
mountPoint = "/mnt/" + adlsContainerName

#bronze data lake
bronzeDataLake = mountPoint + "/db/bronze/lake"
bronzeDataLakeCheckpoints = mountPoint + "/db/bronze/lake_checkpoints"
bronzeDataLakeCheckpoints1 = mountPoint + "/db/bronze/kafka_checkpoints"


#gold data lake
goldDataLake = mountPoint + "/db/gold/lake"
goldDataLakeCheckpoints = mountPoint + "/db/gold/lake_checkpoints"
 
# Make some configurations small-scale friendly
sql("set spark.sql.shuffle.partitions = 1")
sql("set spark.databricks.delta.snapshotPartitions = 1")
    

# COMMAND ----------

from pyspark.sql.types import *
from pyspark import Row
from delta.tables import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window

goldTable = DeltaTable.forPath(spark, goldDataLake)

def upsertToDelta(microDF, batchId) :
    #print(f"upsertToDelta forEachRow for batchId:{batchId}. Rows in passed DataFrame: {microDF.count()}")
    #get the latest update in  microBatch
    microDF = (microDF.withColumn("rn", F.row_number()
                      .over(Window.partitionBy("agreementContractId")
                                  .orderBy(F.col("modificationDate").desc()))
                            )
                      .filter(F.col("rn") == 1)                      
                      .drop("rn"))    
    mergeRes = (goldTable.alias("t")
                           .merge(microDF.alias("s"), "s.agreementContractId = t.agreementContractId")
                           .whenMatchedUpdateAll("s.modificationDate >= t.modificationDate")
                           .whenNotMatchedInsertAll()
                           .execute())



bronzeLakeIn = (spark.readStream
                     .format("delta")
                     .option("ignoreDeletes", "true")
                     .load(bronzeDataLake)
                     .withColumn("updateTimestamp", F.current_timestamp())
                     .where("agreementContractId is not null"))

ws = (bronzeLakeIn.writeStream
                  .option("checkpointLocation", goldDataLakeCheckpoints)
                  .format("delta")
                  .outputMode("append")
                  .option("mergeSchema", "true")
                  .foreachBatch(upsertToDelta)
                  .start(goldDataLake))
