# RDF Storage-API\hosting

API should have it's own internal DNS GSK name.
Environments

|Env|GSK Host Name|Corpnet name|Internal IP|
|:--|:-|:-|:-|
|Dev    |rdstorage-dev.gsk.com  |rdstorage-dev.corpnet1.com   |10.44.6.166|
|Uat    |rdstorage-uat.gsk.com  |rdstorage-uat.corpnet1.com   |10.44.11.102|
|Prod   |rdstorage.gsk.com      |rdstorage.corpnet1.com       |10.44.3.167|
 

SSL CNF request file [GSK file](rdstorage.gsk.com.csr)

SSL CNF request file [Coprnet1 file](rdstorage.corpnet1.com.cnf)

**OpenSSL commands**

openssl req -out rdstorage.gsk.com.csr -newkey rsa:2048 -keyout rdstorage.gsk.com.private.key -config rdstorage.gsk.com.cnf

openssl req -out rdstorage.corpnet1.com.csr -newkey rsa:2048 -keyout rdstorage.corpnet1.com.private.key -config rdstorage.corpnet1.com.cnf



Kubernetes SSL installation:

kubectl create secret tls rdstorage-tls --key rdstorage.gsk.com.private.key.open --cert rdstorage.gsk.com.crt
kubectl create secret tls rdstorage1-tls --key rdstorage.corpnet1.com.private.key.open --cert rdstorage.corpnet1.com.crt


**Swagger redirect urls for [Air Portal](https://air.gsk.com/air)**

https://{URL}/storage-api/swagger/oauth2-redirect.html
