# RDF Storage-API\docker

Folder contains Dockerfile-s for all solutions that are deployed
