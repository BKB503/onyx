# RDF Storage-API

Scientific Data Storage Access Management Layer (or in short **RDF Storage-API**) it is a solution (API and indexing mechanism) that will mitigate the risks connected with current storage solution not being ALCOA+ compliant

---
## Folder structure

### [ado](ado)

Folder contains Azure DevOps pipeline code
### [client](client)

Folder contains .Net Core 6.0 Storage-API Client library 

Solution name : [client/RD.RDF.StorageAPIClient.sln](client/RD.RDF.StorageAPIClient.sln)

### [databricks](databricks)

Folder contains Databricks code for Alliance db and Indexing db

### [docker](docker)

Folder contains Dockerfile-s for all solutions that are deployed

### [hosting](hosting)

Folder contains hosting information as well as SSL request files

### [portal](portal)

Folder contains Asp.Net Core 6.0 StorageAPI Portal Web application as well as Migration Tool Worker services

Solution name : [portal/RD.RDF.StoragePortal.sln](portal/RD.RDF.StoragePortal.sln)

### [source](source)

Folder contains Asp.Net Core 6.0 Storage-API solution and AllianceRefreshCli tool

Solution name : [source/RD.RDF.StorageAPI.sln](source/RD.RDF.StorageAPI.sln)

### [tools](tools)

Folder contains .Net Core 6.0 Storage-API CLI and FileWatcher tools that communicate to Storage-API

Solution name : [tools/RD.RDF.StorageAPITools.sln](tools/RD.RDF.StorageAPITools.sln)