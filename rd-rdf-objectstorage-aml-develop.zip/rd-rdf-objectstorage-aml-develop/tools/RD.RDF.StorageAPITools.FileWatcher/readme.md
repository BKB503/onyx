﻿Installation instruction:

Installation command 
sc create FileWatcherService BinPath=C:\full\path\to\publish\dir\FileWatcherService.exe

Start:
sc start FileWatcherService

Stop:
sc stop FileWatcherService

Delete the service: 
sc delete FileWatcherService