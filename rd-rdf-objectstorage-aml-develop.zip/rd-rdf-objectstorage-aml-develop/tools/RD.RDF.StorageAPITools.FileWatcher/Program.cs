using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RD.RDF.StorageAPITools.ToolsCore.Helpers;
using RD.RDF.StorageAPITools.ToolsCore.Services;
using System;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPITools.FileWatcher
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            string appDir = System.AppContext.BaseDirectory; // Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var cts = new CancellationTokenSource();
            var hostBuilder = args.CreateGenericHostBuilder(appDir, ConfigureServices);
            if (OperatingSystem.IsWindows())
            {
                hostBuilder.UseWindowsService();
            }
            else if (OperatingSystem.IsLinux())
            {
                hostBuilder.UseSystemd();
            }
            var host = hostBuilder.Build();
            await host.RunAsync(cts.Token).ConfigureAwait(false);
        }
        private static void ConfigureServices(HostBuilderContext hostCtx, IServiceCollection services)
        {
            //configure services here
            services.AddHostedService<FileWatcherWorker>();
        }
    }
}
