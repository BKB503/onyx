﻿namespace RD.RDF.StorageAPITools.ToolsCore.Configurations
{
    public class ApiCLIClientConnection
    {
        public const string Section = "ApiConnection";

        public string Name { get; set; }
        public string ApiUrl { get; set; }
        public string ContainerName { get; set; }
        public string KongApiKey { get; set; }
    }
}
