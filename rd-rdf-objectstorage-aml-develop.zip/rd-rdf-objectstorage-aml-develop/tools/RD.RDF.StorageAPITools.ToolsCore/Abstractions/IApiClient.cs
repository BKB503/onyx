﻿using RD.RDF.StorageAPI.Client.Model;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPITools.ToolsCore.Abstractions
{
    public interface IApiClient
    {
        Task<Stream> DownloadFileAsync(string containerName, string fileName, string folderName, string fileGuid, CancellationToken cancellationToken);
        Task<ContainerContents> GetContainerContentsAsync(string containerName, string folder, string continuationToken, int limit = 1000, CancellationToken cancellationToken = default);
        
        Task<ContainersResponse> GetContainersAsync(long offset, int limit, CancellationToken cancellationToken);

        Task<ContainerContents> GetContainerContentsAsync(Verbs.ListVerbOptions arg, CancellationToken ct);
         
        Task<ApiClientUploadFileResult> UploadFileAsync(string containerName, string inputFilePath, string fileName, string folderName, MetadataCollections metadata, CancellationToken cancellationToken);
    }
}
