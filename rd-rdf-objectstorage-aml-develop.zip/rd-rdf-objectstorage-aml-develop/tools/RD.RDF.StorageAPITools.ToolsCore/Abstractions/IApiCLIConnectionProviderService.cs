﻿using RD.RDF.StorageAPITools.ToolsCore.Configurations;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPITools.ToolsCore.Abstractions
{
    public interface IApiCLIConnectionProviderService
    {
        /// <summary>
        /// Get Client connection based on config
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        Task<ApiCLIClientConnection> GetClientConnectionAsync(CancellationToken token);


    }
}
