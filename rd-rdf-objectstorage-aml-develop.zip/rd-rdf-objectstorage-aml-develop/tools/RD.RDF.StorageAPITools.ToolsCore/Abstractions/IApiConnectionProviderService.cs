﻿using Microsoft.Extensions.Options;
using RD.RDF.StorageAPITools.ToolsCore.Configurations;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPITools.ToolsCore.Abstractions
{
    public interface IApiConnectionProviderService
    {
        /// <summary>
        /// Get Configuration By name - when no name is provided the default connection will be retrieved
        /// </summary>
        /// <param name="name">name of connection</param>
        /// <returns>null if connection of that name was not found</returns>
        Task<IOptions<ApiConnectionItemConfiguration>> GetConfigByNameAsync(string name = null);


        /// <summary>
        /// Get user secret for given connection. Overrides the password provided by command line parameter
        /// </summary>
        /// <param name="name">name of connection</param>
        /// <returns>null if connection of that name was not found</returns>
        Task<IOptions<string>> GetUserSecretForConfigAsync(string name = null);
    }
}
