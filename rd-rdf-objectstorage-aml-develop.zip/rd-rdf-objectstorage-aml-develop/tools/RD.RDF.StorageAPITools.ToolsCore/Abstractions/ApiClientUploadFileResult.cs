﻿using RD.RDF.StorageAPI.Client.Model;

namespace RD.RDF.StorageAPITools.ToolsCore.Abstractions
{
    public class ApiClientUploadFileResult
    {
        public ApiClientUploadFileResult(UploadFileResultStatus status, string message)
        {
            Status = status;
            Message = message;
        }

        public ApiClientUploadFileResult(UploadFileResultStatus status, FileResource fileInformation, string message = null)
        {
            Status = status;
            FileInformation = fileInformation;
            Message = message;
        }

        public UploadFileResultStatus Status { get; set; }
        public FileResource FileInformation { get; set; }
        public string Message { get; set; }

    }
}
