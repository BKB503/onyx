﻿using RD.RDF.StorageAPI.Client.Model;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPITools.ToolsCore.Abstractions
{
    public interface ICLIMetadataService
    {
        /// <summary>
        /// parses out cmd line args 
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        MetadataDictionary ParseCommandLineArgs(string[] args);

        /// <summary>
        /// prepares metadata collection based on Metadata File JSON and command line arguments that ovveride 
        /// </summary>
        /// <param name="metadataJsonTemplate"></param>
        /// <param name="cmdLineOverrides">Key value list of parameters that ovveride </param>
        /// <returns></returns>
        MetadataCollections PrepareMetadata(string metadataJsonTemplate, MetadataDictionary cmdLineOverrides);

        /// <summary>
        /// gets metadata json template contentst pased on path 
        /// if file is not provided or found the default file will be used
        /// if that's not working null string will be returned
        /// </summary>
        /// <param name="metadataJsonTemplatePath">path to  metadat json file</param>
        /// <returns>contentes of the file</returns>
        Task<string> GetMetadataJsonTemplateContentsAsync(string metadataJsonTemplatePath, System.Threading.CancellationToken cancellationToken);

    }
}
