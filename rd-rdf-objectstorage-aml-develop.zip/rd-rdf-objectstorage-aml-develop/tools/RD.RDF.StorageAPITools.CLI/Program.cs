﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.Identity.Client.Extensions.Msal;
using RD.RDF.StorageAPI.Client;
using RD.RDF.StorageAPITools.CLI.Helpers;
using RD.RDF.StorageAPITools.ToolsCore.Abstractions;
using RD.RDF.StorageAPITools.ToolsCore.Configurations;
using RD.RDF.StorageAPITools.ToolsCore.DataAccess;
using RD.RDF.StorageAPITools.ToolsCore.Helpers;
using RD.RDF.StorageAPITools.ToolsCore.Providers;
using RD.RDF.StorageAPITools.ToolsCore.Services;
using Serilog;
using Serilog.Extensions.Logging;
using System;
using System.IO;
using System.Net.Http.Headers;
using System.Reflection;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPITools.CLI
{
    public class Program
    {
        private static async Task Main(string[] args)
        {
            string appDir = System.AppContext.BaseDirectory;
            var host = args.CreateGenericHostBuilder(appDir, ConfigureServices);
            await host.RunConsoleAsync();
        }

        private static void ConfigureServices(HostBuilderContext hostCtx, IServiceCollection services)
        {
            string logPath = Path.Combine(System.AppContext.BaseDirectory, "logs", "storageCli.log");
            string outputTemplate = "{Timestamp:HH:mm:ss.fff zzz} [{Level:w3}] {Message:lj}{NewLine}{Exception}";
            Log.Logger = new LoggerConfiguration()
                         // .ReadFrom.Configuration(hostCtx.Configuration)
                          .Enrich.FromLogContext()
                          .MinimumLevel.Debug()
                          .WriteTo.Console(outputTemplate: outputTemplate)
                          .WriteTo.File(logPath, outputTemplate:outputTemplate, rollingInterval: RollingInterval.Day)
                          .CreateLogger();

            services.AddLogging(config =>
            {
                config.ClearProviders();
                config.AddProvider(new SerilogLoggerProvider(Log.Logger));
                //var minimumLevel = hostCtx.Configuration.GetSection("Serilog:MinimumLevel")?.Value;
                //if (!string.IsNullOrEmpty(minimumLevel))
                //{
                //    config.SetMinimumLevel(Enum.Parse<Microsoft.Extensions.Logging.LogLevel>(minimumLevel));
                //}
            });


            //default host service
            services.AddHostedService<ConsoleHostedService>();
            //add all the rest of configure services here
            services.Configure<ApiCLIClientConnection>(hostCtx.Configuration.GetSection(ApiCLIClientConnection.Section));
            services.Configure<AzureAdConfiguration>(hostCtx.Configuration.GetSection(AzureAdConfiguration.AzureAd));
            services.AddSingleton<SecureStorageConfig>();
            services.AddSingleton<AzureAuthenticationConfiguration>();

            services.AddSingleton<IApiCLIConnectionProviderService, ApiCLIConnectionProviderService>();

            services.AddTransient<IStorageAPIClientConfigurationProvider, ConsoleStorageAPIClientConfigurationProvider>();
            services.AddTransient<IOAuth2TokenProvider, AzureDeviceCodeOAuth2TokenProvider>();
            services.AddTransient<IStorageAPIClient, StorageAPIHttpClient>();
            services.AddTransient<IApiClient, ApiClient>();
            services.AddTransient<ICLIMetadataService, CLIMetadataService>();

            services.AddSingleton<IPublicClientApplication>(ctx =>
            {

                var configStorage = ctx.GetRequiredService<SecureStorageConfig>();
                var appConfig = ctx.GetRequiredService<AzureAuthenticationConfiguration>();
                var storageProperties =
                    new StorageCreationPropertiesBuilder(configStorage.CacheFileName, configStorage.CacheDir)
                    .WithLinuxKeyring(
                        configStorage.LinuxKeyRingSchema,
                        configStorage.LinuxKeyRingCollection,
                        configStorage.LinuxKeyRingLabel,
                        configStorage.LinuxKeyRingAttr1,
                        configStorage.LinuxKeyRingAttr2)
                    .WithMacKeyChain(
                        configStorage.KeyChainServiceName,
                        configStorage.KeyChainAccountName)
                    .WithCacheChangedEvent(appConfig.PublicClientApplicationOptions.ClientId, appConfig.Authority)
                    .Build();

                var app = PublicClientApplicationBuilder.CreateWithApplicationOptions(appConfig.PublicClientApplicationOptions)
                                                        .Build();
                var cht = Task.Run<MsalCacheHelper>(async () => await MsalCacheHelper.CreateAsync(storageProperties));
                cht.Wait();
                var cacheHelper = cht.Result;

                //cacheHelper.CacheChanged += (object sender, CacheChangedEventArgs args) =>
                //{
                //    Console.WriteLine($"Cache Changed, Added: {args.AccountsAdded.Count()} Removed: {args.AccountsRemoved.Count()}");
                //};

                cacheHelper.RegisterCache(app.UserTokenCache);

                return app;
            });

        }



    }
}
