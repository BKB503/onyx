﻿Command line parameters handling : 

	1. Connection to API. You can either use connection from a collection list in App.config - or provide all parameters by cmd line
	Parameters:
		--connectionName={name of connection from app.config}
		if app.config is missing user or password you need to provide it by command line parameter
		--userId={userId}
		--userSecret={userSecret}
		
		the other option of providing userId or userSecret is to set proper env variable before runnig the cmd line tool
		
		The env variable name rules -
		- For userId we are expecting this environment variable to be set - AML_{connectionName}_USERID
		- For userSecret we are expecting this environment variable to be set - AML_{connectionName}_USERSECRET
		
		UserId and UserSecret -s are maitained in PingId by AIR system (https://air.gsk.com/air/)
		
	If you don't provide connection name then you need to provide all connection parameters
		--apiUrl={urltoapi}
		--apiContainerName={api container name}
		
		+ userId and userSecret as specified above.
		
		--uploadProcessLogic={optional name for upload process logic} 
		
	2. Selecting an action. This client can upload or download the data from API
	
	--action=upload|download|list
	
	Parameters for upload action:
		You can select a single file to upload
		--uploadFile={path to a file.png}
		--uploadFileMetadata={path to json file with metadata}
			
		Then you need to select a destination folder (optional) 
		--containerFolder={path to destination folder -- optional} 
	
	Parameters for download action:
		--downloadFile={path or name to a file in blob container}		
		--downloadFolder={if not provided then the file will be downloaded to current working directory}
		--containerFolder={path to destination folder -- optional} 
	
	Parameters for list action:
		--containerFolder={path to destination folder -- optional} 
		
		--limit={number of elements in response - 2000 if omitted}
		--offset={page offset - 0 if omitted}
		or you can download all data from api
		--all 
		
		Saving the result to a file. Normaly it will be outputed to console
		--saveResult={json fole path.json}