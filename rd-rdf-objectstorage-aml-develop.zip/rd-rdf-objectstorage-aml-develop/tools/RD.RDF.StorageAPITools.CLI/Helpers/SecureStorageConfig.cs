﻿using Microsoft.Identity.Client.Extensions.Msal;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPITools.CLI.Helpers
{
    public  class SecureStorageConfig
    {
        //// App settings
        //public static readonly string[] Scopes = new[] { "user.read" };

        //// Use "common" if you want to allow any "enterprise" (work or school) account AND any user account (live.com, outlook, hotmail) to log in.
        //// Use an actual tenant ID to allow only your enterprise to log in.
        //// Use "organizations" to allow only enterprise log-in, this is required for the Username / Password flow
        //public const string Authority = "https://login.microsoftonline.com/organizations";

        //// DO NOT USE THIS CLIENT ID IN YOUR APP. WE REGULARLY DELETE THEM. CREATE YOUR OWN!
        //public const string ClientId = "1d18b3b0-251b-4714-a02a-9956cec86c2d";

        // Cache settings
        public string CacheFileName { get; set; } = "storageCLI_msal_cache.txt";
        public string CacheDir { get; set; } = MsalCacheHelper.UserRootDirectory + Path.DirectorySeparatorChar + "storageCLI";

        public string KeyChainServiceName { get; set; } = "storageCLI_msal_service";
        public string KeyChainAccountName { get; set; } = "storageCLI_msal_account";

        public string LinuxKeyRingSchema { get; set; } = "com.gsk.rd.storageCLI";
        public string LinuxKeyRingCollection { get; set; } = MsalCacheHelper.LinuxKeyRingDefaultCollection;
        public string LinuxKeyRingLabel { get; set; } = "MSAL token cache for all Contoso dev tool apps.";
        public KeyValuePair<string, string> LinuxKeyRingAttr1 { get; set; } = new KeyValuePair<string, string>("Version", "1");

        public KeyValuePair<string, string> LinuxKeyRingAttr2 { get; set; } = new KeyValuePair<string, string>("GSKRD", "storageCLI");


    }
}
