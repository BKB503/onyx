docker build -f docker/api/Dockerfile -t rd-rdf-storage-api .
docker build -f docker/portal/Dockerfile -t rd-rdf-storage-portal .