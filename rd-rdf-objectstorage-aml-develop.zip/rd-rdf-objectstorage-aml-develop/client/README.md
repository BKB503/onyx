# RDF Storage-API\client

Folder contains .Net Core 6.0 Storage-API Client library 

Solution name : [RD.RDF.StorageAPIClient.sln](RD.RDF.StorageAPIClient.sln)
