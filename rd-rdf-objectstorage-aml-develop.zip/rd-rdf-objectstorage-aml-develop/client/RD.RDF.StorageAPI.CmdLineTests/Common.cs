﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.CmdLineTests
{
    public static class Common
    {
        public static string GetHashCodeOfFileStream(MemoryStream memoryStream)
        {
            byte[] myBynary = memoryStream.ToArray();
            string hash = string.Empty;
            using (var md5Hash = MD5.Create())
            {
                // Generate hash value(Byte Array) for input data
                var hashBytes = md5Hash.ComputeHash(myBynary);

                // Convert hash byte array to string
                hash = BitConverter.ToString(hashBytes).Replace("-", string.Empty);
            }

            return hash;
        }

        
    }
}
