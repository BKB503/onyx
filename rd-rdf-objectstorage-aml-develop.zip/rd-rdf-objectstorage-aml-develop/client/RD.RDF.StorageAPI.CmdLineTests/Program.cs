﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Client;
using RD.RDF.StorageAPI.Client.Model;
using RD.RDF.StorageAPI.Client.Model.PartialUploads;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.CmdLineTests
{
    public class Program
    {
        public static IStorageAPIClient amlRestHttpClient;
        public static ILogger<StorageAPIHttpClient> logger;
        static async Task Main(string[] args)
        {
            Console.WriteLine("**********************************************");
            Console.WriteLine("Starting testing of Scientific Data AML API's !");
            Console.WriteLine("**********************************************");

            var config = new OAuth2Configuration
            {
                AccessTokenUrl = new Uri("https://federation-qa.gsk.com/as/token.oauth2"),
                ClientId = "ce85d31f462a4fdf917e94cbee2ef392",
                ClientSecret = args[0],
                Scope = "openid"
            };

            string baseApiUrl = "https://dev.api.gsk.com/storage-api"; //"https://localhost:7104";// "http://10.44.11.102/aml";
            //string baseApiUrl = "https://localhost:7104";// "http://10.44.11.102/aml";
            string apiKey = "YTg0OTNiNTQtNTUwOC00YTVmLWJhNDctNGY3NTU2MWE0MTQ5sOQqJ3XjIXrkaNBCtHKeWIrnB6q5SeRiC9T60y199cUe";


            logger = new LoggerFactory().CreateLogger<StorageAPIHttpClient>();
            var logger2 = new LoggerFactory().CreateLogger<OAuth2ClientCredentialsTokenProvider>();
            var tokenProvider = new OAuth2ClientCredentialsTokenProvider(config, logger2);
            amlRestHttpClient = new StorageAPIHttpClient(baseApiUrl, apiKey, tokenProvider, logger);

            string containerName = "storage-api-dev";
            FileUploadRequest fileUploadDeatils = new FileUploadRequest
            {
                ContainerName = "storage-api-dev",
                FileName = "TestImage.png",
                FolderName = "IntegrationTests"
            };

            //string fileGuid = null;

            Console.WriteLine("--------------Task 1 : Get containers --------------");
            await amlRestHttpClient.GetContainersAsync(null, 1000, default);
            Console.WriteLine("--------------End Task 1");
            Console.WriteLine();

            Console.WriteLine("--------------Task 2 : Get container by name--------------");
            await amlRestHttpClient.GetContainerByNameAsync(containerName, default);
            Console.WriteLine("--------------End Task 2");
            Console.WriteLine();

            Console.WriteLine("--------------Task 3 : Get container contents --------------");
            string folder = "logo";
            await amlRestHttpClient.GetContainerContentsAsync(containerName, folder, null, 1000, default);
            Console.WriteLine("--------------End Task 3");
            Console.WriteLine();

            fileUploadDeatils.FileStream = new FileStream(fileUploadDeatils.FileName, FileMode.Open);
            fileUploadDeatils.MetadataFileStream = new FileStream("TestImage.json", FileMode.Open);

            Console.WriteLine("--------------Task 4 : Upload File event --------------");
            var uploadResult = await amlRestHttpClient.UploadFileAsync(fileUploadDeatils, default);
            Console.WriteLine("--------------End Task 4");
            Console.WriteLine();


            var fileUploadObjectDeatils = new FileUploadObjectRequest
            {
                ContainerName = "storage-api-dev",
                FileName = "TestImage.png",
                FolderName = "IntegrationTests"
            };
             

            List<MetadataItem> metadataItems = new List<MetadataItem>();
            for (int i = 0; i < 10; i++)
            {
                MetadataItem metadataItem = new MetadataItem
                { Key = $"TestKey{i}", Value = $"TestValue{i}", IsIndexed = i % 2 == 0 ? true : false };
                metadataItems.Add(metadataItem);
            }
            fileUploadObjectDeatils.MetadataCollections = new MetadataCollections { Items = metadataItems };

            Console.WriteLine("--------------Task 5 : Upload File event --------------");
            var uploadFileObjResult = await amlRestHttpClient.UploadFileObjectAsync(fileUploadObjectDeatils, default);
            Console.WriteLine("--------------End Task 5");
            Console.WriteLine();

            Console.WriteLine("--------------Task 6 : Get one file information --------------");
            var fileInfo = await amlRestHttpClient.GetOneFileInformationAsync(containerName, fileUploadDeatils.FileName, fileUploadDeatils.FolderName, uploadResult.FileInformation.FileGuid, default);
            Console.WriteLine("--------------End Task 6");
            Console.WriteLine();

            Console.WriteLine("-------------- Task 7 : Download File event --------------");
            var fileDownloadStream = await amlRestHttpClient.DownlaodFileAsync(containerName, fileUploadDeatils.FileName, fileUploadDeatils.FolderName, fileInfo.FileGuid, default);
            Console.WriteLine("--------------End Task 7");
            Console.WriteLine();

            MemoryStream m = new MemoryStream();
            string uploadHash;
            string downloadHash;
            using (var fileStream = new FileStream(fileUploadDeatils.FileName, FileMode.Open))
            {
                fileStream.CopyTo(m);
                uploadHash = Common.GetHashCodeOfFileStream(m);

                // Output the MD5 hash
                logger.LogInformation("The MD5 hash of upload is: " + uploadHash);
            }

            var memoryStream = new MemoryStream();
            fileDownloadStream.CopyTo(memoryStream);

            downloadHash = Common.GetHashCodeOfFileStream(memoryStream);
            // Output the MD5 hash
            logger.LogInformation("The MD5 hash of Download is: " + downloadHash);
            Console.WriteLine("The MD5 hash of Download is: " + downloadHash);

            if (!uploadHash.Equals(downloadHash))
            {
                Console.WriteLine("The upload file hash and download file hash are not same.");

            }
            else
            {
                Console.WriteLine("The upload file hash and download file hash are same. Files are identical.");
            }

            Console.WriteLine("-------------- Task 8 : Download File event of Uplaod with metadata object --------------");
            var fileDownloadStream2 = await amlRestHttpClient.DownlaodFileAsync(containerName, fileUploadDeatils.FileName, fileUploadDeatils.FolderName, uploadFileObjResult.FileInformation.FileGuid, default);
            Console.WriteLine("--------------End Task 8");
            Console.WriteLine();

            var memoryStream2 = new MemoryStream();
            fileDownloadStream2.CopyTo(memoryStream2);
            downloadHash = Common.GetHashCodeOfFileStream(memoryStream2);
            // Output the MD5 hash
            logger.LogInformation("The MD5 hash of Download is: " + downloadHash);
            Console.WriteLine("The MD5 hash of Download is: " + downloadHash);

            if (!uploadHash.Equals(downloadHash))
            {
                Console.WriteLine("The upload file hash and download file hash of object upload are not same.");

            }
            else
            {
                Console.WriteLine("The upload file hash and download file hash of object upload are same. Files are identical.");
            }

            Console.WriteLine("-------------- Task 9 : Serch for File GUID--------------");
            var resutls = await amlRestHttpClient.SearchFilesAsync(containerName, @"""FileGuid""='" + fileInfo.FileGuid + "'", default);
            Console.WriteLine("--------------End Task 9");
            Console.WriteLine();

            string filePath = "testUpload.zip";
            string metadataPath = "Testlargeupload.json";
            var fileInfoPart = new FileInfo(filePath);

            FilePartUploadRequest filepartUploadDetails = new FilePartUploadRequest
            {
                ContainerName = "storage-api-dev",
                FileName = "testUpload.zip",
                Folder = "IntegrationTests",
                FilePartSize = 1024 * 1024,
                FileTotalSize = fileInfoPart.Length,
            };
            int chunks = (int)Math.Ceiling((decimal)filepartUploadDetails.FileTotalSize / (decimal)filepartUploadDetails.FilePartSize);

            Console.WriteLine("-------------- Task 10 : Get Upload SessionId--------------");
            var uploadPartInit = await amlRestHttpClient.UploadPartsInitAsync(filepartUploadDetails, default);
            Console.WriteLine("--------------End Task 10");
            Console.WriteLine();
            var uploadSessionId = uploadPartInit.UploadSessionId;

            List<UploadPartResult> uploadPartResult = new List<UploadPartResult>();
            using var fs = fileInfoPart.OpenRead();
            for (int filePartNumber = 0; filePartNumber < chunks; filePartNumber++)
            {
                long remainingBytes = filepartUploadDetails.FileTotalSize - (filePartNumber * filepartUploadDetails.FilePartSize);
                int blockSize = (int)Math.Min(remainingBytes, filepartUploadDetails.FilePartSize);
                byte[] block = new byte[blockSize];
                int bytesRead = fs.Read(block, 0, blockSize);
                using var partStream = new MemoryStream(block);
                partStream.Seek(0, SeekOrigin.Begin);

                Console.WriteLine("-------------- Task 11 : Part Upload--------------");
                var uploadPart = await amlRestHttpClient.UploadPartFileAsync(filepartUploadDetails, partStream, filePartNumber + 1, uploadSessionId, default);
                Console.WriteLine("--------------End Task 11");
                Console.WriteLine();
                uploadPartResult.Add(uploadPart);

            }
            FilePartUploadRequest fileCommitUpload = new FilePartUploadRequest
            {
                ContainerName = "storage-api-dev",
                FileName = "testUpload.zip",
                Folder = "IntegrationTests"

            };
            var partsList = new UploadPartCommitCollection();
            for (int i = 0; i < uploadPartResult.Count; i++)
            {
                partsList.Items.Add(new UploadPartCommitItem(i + 1, uploadPartResult[i].PartGuid));
            }
            // metadata collection
            var fiMetadata = new FileInfo(metadataPath);
            using var metadataStream = fiMetadata.OpenRead();
            var metadataDict = JsonSerializer.Deserialize<MetadataDictionary>(metadataStream);
            var metadataCollection = new MetadataCollections(metadataDict);

            Console.WriteLine("-------------- Task 12 : Part Upload--------------");
            var commitUpload = await amlRestHttpClient.UploadPartsCommitAsync(fileCommitUpload, uploadPartInit.UploadSessionId, partsList, metadataCollection, default);
            Console.WriteLine("--------------End Task 12");
            Console.WriteLine();

        }

    }
}
