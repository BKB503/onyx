using Microsoft.Extensions.Logging;
using Moq;
using RD.RDF.StorageAPI.Client;
using RD.RDF.StorageAPI.Client.Model;
using RichardSzalay.MockHttp;
using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace RD.RDF.StorageAPI.ClientTests
{
    public class StorageAPIHttpClientTests
    {

        private Mock<IOAuth2TokenProvider> tokenProvider;
        private Mock<ILogger<StorageAPIHttpClient>> Ilogger;
        //private readonly string baseAPIUrl = "https://localhost:7104/";
        private Mock<IStorageAPIClientConfigurationProvider> configProviderMock;

        private JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };


        public StorageAPIHttpClientTests()
        {
            tokenProvider = new Mock<IOAuth2TokenProvider>();
            tokenProvider.Setup(method => method.GetTokenAsync(It.IsAny<CancellationToken>()))
                         .ReturnsAsync(new OAuth2Token { AccessToken = "token123", ExpiresIn = 3600, TokenType = "Bearer" });

            Ilogger = new Mock<ILogger<StorageAPIHttpClient>>();
            configProviderMock = new Mock<IStorageAPIClientConfigurationProvider>();
        }

        [Fact]
        public void Constructor1Tests()
        {
            //test the constructor 1 test
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(null, null, null));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(configProviderMock.Object, null, null));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(configProviderMock.Object, tokenProvider.Object, null));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(configProviderMock.Object, tokenProvider.Object, null));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(null, tokenProvider.Object, Ilogger.Object));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(configProviderMock.Object, null, Ilogger.Object));
            Assert.Throws<NullReferenceException>(() => new StorageAPIHttpClient(configProviderMock.Object, tokenProvider.Object, Ilogger.Object));
        }

        [Fact]
        public void Constructor2Tests()
        {
            string baseUrl = "https://api.gsk.com/storage-api";
            //test the constructor 1 test
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(null, null, null, null));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(baseUrl, null, null, null));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(baseUrl, "key", tokenProvider.Object, null));
            Assert.Throws<ArgumentNullException>(() => new StorageAPIHttpClient(baseUrl, "key", null, Ilogger.Object));
            Assert.Throws<ArgumentException>(() => new StorageAPIHttpClient("invalidUrl", "key", tokenProvider.Object, Ilogger.Object));
        }

        [Fact]
        public void TestGetTheRestApiClientObject1_Valid_BaseURL()
        {
            string baseUrl = "https://api.gsk.com/storage-api";
            //setup some valid config
            configProviderMock.Setup(c => c.GetConfiguration()).Returns(new StorageAPIClientConfiguration { BaseApiUrl = new Uri(baseUrl) });

            StorageAPIHttpClient amlRestHttpClient = new StorageAPIHttpClient(configProviderMock.Object, tokenProvider.Object, Ilogger.Object);
            Assert.NotNull(amlRestHttpClient);
        }

        [Fact]
        public void TestGetTheRestApiClientObject2_Valid_BaseURL()
        {
            string baseUrl = "https://api.gsk.com/storage-api";
            StorageAPIHttpClient amlRestHttpClient = new StorageAPIHttpClient(baseUrl, null, tokenProvider.Object, Ilogger.Object);
            Assert.NotNull(amlRestHttpClient);
        }

        [Fact]
        public   void TestGetTheRestApiClientObject1_Invalid_BaseURL()
        {
            var baseAPIUrl = "https:localhost:7104";
            string apiKey = null;
            Assert.Throws<ArgumentException>(() => new StorageAPIHttpClient(baseAPIUrl, apiKey, tokenProvider.Object, Ilogger.Object));
        }


        [Fact]
        public async Task GetContainersTest()
        {
            string baseUrl = "https://api.gsk.com/storage-api";
            var client = new StorageAPIHttpClient(baseUrl, null, tokenProvider.Object, Ilogger.Object);
            var mockedHttpProvider = new MockHttpClientProvider();
            client.HttpClientProvider = mockedHttpProvider;

            var expectedResult = new ContainersResponse()
            {
                Data = (new List<string> { "storage-api-dev", "storage-api-dev2" }).ToArray(),
                Limit = 1000,
                RecordsReturned = 1,
                Succeeded = true,
                MoreDataAvailable = false
            };
            string expectedResultJson = JsonSerializer.Serialize(expectedResult, jsonSerializerOptions);
            mockedHttpProvider.MockedHttpRequest.When(System.Net.Http.HttpMethod.Get, $"{baseUrl}/api/v1/containers")
                                                //.WithQueryString("Limit", "1000")
                                                .Respond("application/json", expectedResultJson);


            var result = await client.GetContainersAsync(null, 1000, CancellationToken.None);
            Assert.True(result.Succeeded);
            Assert.Equal(expectedResult.Data, result.Data);
        }


    }
}
