﻿using RD.RDF.StorageAPI.Client;
using RichardSzalay.MockHttp;
using System.Net.Http;

namespace RD.RDF.StorageAPI.ClientTests
{
    public class MockHttpClientProvider : IHttpClientProvider
    { 
        public MockHttpMessageHandler MockedHttpRequest { get; set; } = new MockHttpMessageHandler();
        public HttpClient GetHttpClient()
        { 
            return MockedHttpRequest.ToHttpClient();
        }
    }
}
