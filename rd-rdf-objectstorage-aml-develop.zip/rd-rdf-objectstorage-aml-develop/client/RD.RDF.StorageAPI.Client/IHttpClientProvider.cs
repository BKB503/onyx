﻿using System.Net.Http;

namespace RD.RDF.StorageAPI.Client
{
    public interface IHttpClientProvider
    {
        HttpClient GetHttpClient();

    }
}
