﻿using Microsoft.Extensions.Logging;
using RD.RDF.StorageAPI.Client.Model;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Client
{
    public class OAuth2ClientCredentialsTokenProvider : IOAuth2TokenProvider
    {
        private readonly JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        private readonly ILogger<OAuth2ClientCredentialsTokenProvider> logger;
        private readonly OAuth2Configuration configuration;
        private readonly string configKey;
        private static ConcurrentDictionary<string, OAuth2Token> CachedTokenDict = new ConcurrentDictionary<string, OAuth2Token>();

        private static ConcurrentDictionary<string, DateTime?> CachedTokenExpirationDict = new ConcurrentDictionary<string, DateTime?>();

        public OAuth2ClientCredentialsTokenProvider(IStorageAPIClientConfigurationProvider configurationProvider, ILogger<OAuth2ClientCredentialsTokenProvider> logger)
        {
            if (configurationProvider == null)
            {
                throw new ArgumentNullException(nameof(configurationProvider));
            }
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            var config = configurationProvider.GetConfiguration();
            configuration = config.AccessConfiguration;
            configKey = $"{configuration.AccessTokenUrl}|{configuration.ClientId}|{configuration.ClientSecret}|{configuration.Scope}";
        }

        public OAuth2ClientCredentialsTokenProvider(OAuth2Configuration configuration, ILogger<OAuth2ClientCredentialsTokenProvider> logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            configKey = $"{configuration.AccessTokenUrl}|{configuration.ClientId}|{configuration.ClientSecret}|{configuration.Scope}";
        }


        public async Task<OAuth2Token> GetTokenAsync(CancellationToken cancellationToken)
        {
            CachedTokenDict.TryGetValue(configKey, out OAuth2Token CachedToken);
            CachedTokenExpirationDict.TryGetValue(configKey, out DateTime? CachedTokenExpiration);
            if (CachedToken != null &&
                CachedTokenExpiration != null &&
                DateTime.UtcNow < CachedTokenExpiration.Value)
            {
                return CachedToken;
            }
            else
            {
                CachedTokenDict.TryRemove(configKey, out OAuth2Token r1);
                CachedTokenExpirationDict.TryRemove(configKey, out DateTime? r2);
            }

            try
            {
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Post, configuration.AccessTokenUrl);
                request.Headers.Add("cache-control", "no-cache");                
                var callParameters = new List<KeyValuePair<string, string>>()
                {
                   new KeyValuePair<string, string> ("grant_type",configuration.GrantType.ToString()),
                   new KeyValuePair<string, string> ("client_id",configuration.ClientId),
                   new KeyValuePair<string, string> ("client_secret",configuration.ClientSecret)
                };
                if (configuration.Scope != null)
                {
                    callParameters.Add(new KeyValuePair<string, string>("scope", configuration.Scope));
                }
                request.Content = new FormUrlEncodedContent(callParameters);
                var responseToken = await client.SendAsync(request, cancellationToken);
                if (responseToken.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var contentData = await responseToken.Content.ReadAsStringAsync(cancellationToken);
                    CachedToken = JsonSerializer.Deserialize<OAuth2Token>(contentData, jsonSerializerOptions);
                    CachedTokenExpiration = DateTime.UtcNow.AddSeconds(CachedToken.ExpiresIn);
                    CachedTokenDict.TryAdd(configKey, CachedToken);
                    CachedTokenExpirationDict.TryAdd(configKey, CachedTokenExpiration);
                    return CachedToken;
                }
                else
                {
                    logger.LogWarning($"No token was generated. Reason = {responseToken.Content}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"OAuth2ClientCredentialsTokenProvider.GetTokenAsync() {ex.Message}");
                throw;
            }
        }

    }
}
