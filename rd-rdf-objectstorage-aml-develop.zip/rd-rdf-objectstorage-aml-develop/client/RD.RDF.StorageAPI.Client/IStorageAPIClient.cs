﻿using RD.RDF.StorageAPI.Client.Model;
using RD.RDF.StorageAPI.Client.Model.PartialUploads;
using RD.RDF.StorageAPI.Client.Model.Wrapper;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Client
{
    public interface IStorageAPIClient
    {
        /// <summary>
        /// reading timeout - 60s by default
        /// </summary>
        int ClientReadTimeout { get; set; }

        /// <summary>
        /// upload timeout - 3600s by default
        /// </summary>
        int ClientUploadTimeout { get; set; }

        /// <summary>
        /// upload timeout - 3600s by default
        /// </summary>
        int ClientDownloadTimeout { get; set; }

        /// <summary>
        /// HttpClient provider - in case of Asp.net core the interface can use IHttpClientFactory to provide an HttpClient object
        /// </summary>
        IHttpClientProvider HttpClientProvider { get; set; }

        Task<ContainersResponse> GetContainersAsync(string continuationToken, int limit, CancellationToken cancellationToken);

        Task<ApiResponse<ContainerResource>> GetContainerByNameAsync(string containerName, CancellationToken cancellationToken);

        Task<ContainerContents> GetContainerContentsAsync(string containerName, string folder, string continuationToken, int limit, CancellationToken cancellationToken);

        Task<FileResource> GetOneFileInformationAsync(string containerName, string fileName, string folder, string fileGuid, CancellationToken cancellationToken);

        Task<UploadFileResult> UploadFileAsync(FileUploadRequest fileDetails, CancellationToken cancellationToken);

        Task<UploadFileResult> UploadFileObjectAsync(FileUploadObjectRequest fileDetails, CancellationToken cancellationToken);

        Task<Stream> DownlaodFileAsync(string containerName, string fileName, string folder, string fileGuid, CancellationToken cancellationToken);

        /// <summary>
        /// Search files by tags using ANSI like query
        /// See 
        /// </summary>
        /// <param name="container">Container name</param>
        /// <param name="tagSearchQuery"> Tag search query  <br/>
        /// The following operators are supported: =, >, >=, <, <=, AND. Example expression: "tagKey"='tagValue'. <br />
        /// @container operator is not supported - as it will search in configured container <br />
        /// Example : <br />
        /// "ExperimentId" > 'ELN1234' AND "AllianceId" = 'GSK' <br/>
        /// <b>URI parameter must be properly URI encoded</b>
        /// </param>    
        /// <param name="cancellationToken"></param>
        /// <returns>Search result or empty result set</returns>
        Task<ApiResponse<IList<FileResource>>> SearchFilesAsync(string container, string tagSearchQuery, CancellationToken cancellationToken);

        Task<UploadPartsInitResult> UploadPartsInitAsync(FilePartUploadRequest fileDetails, CancellationToken cancellationToken);

        Task<UploadPartResult> UploadPartFileAsync(FilePartUploadRequest fileDetails, Stream PartStream, int filePartNumber, string uploadSessionId, CancellationToken cancellationToken );

        Task<UploadPartCommitResult> UploadPartsCommitAsync(FilePartUploadRequest fileDetails, string uploadSessionId, UploadPartCommitCollection parts,
                                                                          MetadataCollections metadata, CancellationToken cancellationToken);


    }
}
