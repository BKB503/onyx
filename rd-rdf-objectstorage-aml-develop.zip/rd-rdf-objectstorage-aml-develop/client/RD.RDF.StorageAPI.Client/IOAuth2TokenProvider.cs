﻿using RD.RDF.StorageAPI.Client.Model;
using System.Threading;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Client
{
    public interface IOAuth2TokenProvider
    {
        Task<OAuth2Token> GetTokenAsync(CancellationToken cancellationToken);
    }
}
