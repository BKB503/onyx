﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using RD.RDF.StorageAPI.Client.Model;
using RD.RDF.StorageAPI.Client.Model.Wrapper;
using RD.RDF.StorageAPI.Client.Model.PartialUploads;

namespace RD.RDF.StorageAPI.Client
{
    public class StorageAPIHttpClient : IStorageAPIClient
    {
        private readonly IOAuth2TokenProvider tokenProvider;

        private readonly ILogger<StorageAPIHttpClient> logger;

        private readonly Uri BaseApiUrl;

        private readonly string ApiKey;

        /// <summary>
        /// reading timeout - 60s by default
        /// </summary>
        public int ClientReadTimeout { get; set; } = 60;

        /// <summary>
        /// upload timeout - 3600s by default
        /// </summary>
        public int ClientUploadTimeout { get; set; } = 3600;

        /// <summary>
        /// upload timeout - 3600s by default
        /// </summary>
        public int ClientDownloadTimeout { get; set; } = 3600;


        /// <summary>
        /// HttpClient provider - in case of Asp.net core the interface can use IHttpClientFactory to provide an HttpClient object
        /// </summary>
        public IHttpClientProvider HttpClientProvider { get; set; } = new DefaultHttpClientProvider();

        private JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        public StorageAPIHttpClient(string baseApiUrl, string apiKey, IOAuth2TokenProvider tokenProvider, ILogger<StorageAPIHttpClient> logger)
        {
            if (baseApiUrl is null)
            {
                throw new ArgumentNullException(nameof(baseApiUrl));
            }

            if (!CheckURLValid(baseApiUrl))
            {
                throw new ArgumentException($"'{nameof(baseApiUrl)}' is not in the correct format. Please provide a valid URL", nameof(baseApiUrl));
            }
            if (!baseApiUrl.EndsWith('/'))
            {
                baseApiUrl += "/";
            }
            BaseApiUrl = new Uri(baseApiUrl);
            ApiKey = apiKey;
            this.tokenProvider = tokenProvider ?? throw new ArgumentNullException(nameof(tokenProvider));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        }

        public StorageAPIHttpClient(IStorageAPIClientConfigurationProvider configurationProvider, IOAuth2TokenProvider tokenProvider, ILogger<StorageAPIHttpClient> logger)
        {
            if (configurationProvider == null)
            {
                throw new ArgumentNullException(nameof(configurationProvider));
            }
            this.tokenProvider = tokenProvider ?? throw new ArgumentNullException(nameof(tokenProvider));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            var config = configurationProvider.GetConfiguration();
            string baseApiUrl = config.BaseApiUrl.AbsoluteUri;
            if (!baseApiUrl.EndsWith('/'))
            {
                baseApiUrl += "/";
            }
            BaseApiUrl = new Uri(baseApiUrl);
            if (!CheckURLValid(baseApiUrl))
            {
                throw new ArgumentException($"'{nameof(baseApiUrl)}' is not in the correct format. Please provide a valid URL", nameof(baseApiUrl));
            }
            ApiKey = config.ApiKey;
            ClientReadTimeout = config.ClientReadTimeout;
            ClientDownloadTimeout = config.ClientDownloadTimeout;
            ClientUploadTimeout = config.ClientUploadTimeout;
            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        }

        /// <summary>
        /// A function to test the Get Container contents API.
        /// </summary>
        /// <param name="token"></param>
        /// <param name="baseApiUrl"></param>
        /// <param name="containerName"></param>
        /// <param name="folder"></param>
        /// <returns></returns>
        public async Task<ContainerContents> GetContainerContentsAsync(string containerName, string folder, string continuationToken, int limit, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(containerName))
            {
                throw new ArgumentException($"'{nameof(containerName)}' cannot be null or empty.", nameof(containerName));
            }
            using var client = HttpClientProvider.GetHttpClient();
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientReadTimeout);
            OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
            ContainerContents responses = null;

            //get container contents
            string queryString = AddQueryStringParameters(folder, continuationToken, limit);
            string getContainerContents = $"api/v1/container/{containerName}/contents{queryString}";

            using (var request = new HttpRequestMessage(HttpMethod.Get, getContainerContents))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<ContainerContents>(result, jsonSerializerOptions);
                logger.LogDebug($"ContainerName : {responses.ContainerName}. Files of container count: {responses.Files.Count} Folder of container: {responses.Folders.Count} Get container contents completed.");
            }
            return responses;
        }

       

        public async Task<FileResource> GetOneFileInformationAsync(string containerName, string fileName, string folder, string fileGuid, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(containerName))
            {
                throw new ArgumentException($"'{nameof(containerName)}' cannot be null or empty.", nameof(containerName));
            }

            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentException($"'{nameof(fileName)}' cannot be null or empty.", nameof(fileName));
            }

            var client = HttpClientProvider.GetHttpClient();
            FileResource responses = null;
            OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);

            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientReadTimeout);
            //get container contents            
            string queryString = null;
            if (!string.IsNullOrEmpty(folder))
            {
                queryString = $"?folder={folder}";
            }
            if (!string.IsNullOrEmpty(fileGuid))
            {
                queryString = $"{queryString}{(queryString == null ? "?" : "&")}fileGuid={fileGuid}";
            }
            string getfileInfo = $"api/v1/container/{containerName}/contents/{fileName}{queryString}";
            using (var request = new HttpRequestMessage(HttpMethod.Get, getfileInfo))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<FileResource>(result, jsonSerializerOptions);
            }
            return responses;
        }

        /// <summary>
        /// A function to test the Get Container By Name API.
        /// </summary>
        /// <param name="token"></param>
        /// <param name="baseApiUrl"></param>
        /// <param name="containerName"></param>
        /// <returns></returns>
        public async Task<ApiResponse<ContainerResource>> GetContainerByNameAsync(string containerName, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(containerName))
            {
                throw new ArgumentException($"'{nameof(containerName)}' cannot be null or empty.", nameof(containerName));
            }

            using var client = HttpClientProvider.GetHttpClient();
            ApiResponse<ContainerResource> responses = null;

            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientReadTimeout);
            //get container by name
            string getContainerContents = $"api/v1/container/{containerName}";
            using (var request = new HttpRequestMessage(HttpMethod.Get, getContainerContents))
            {
                OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);

                response.EnsureSuccessStatusCode();

                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<ApiResponse<ContainerResource>>(result, jsonSerializerOptions);


                logger.LogDebug($"ContainerName of container: {responses.Data.Configuration.ContainerName} Name of container: {responses.Data.Configuration.Name} " +
                    $"Type of container: {responses.Data.Configuration.Type} ContainerAccountUrl of container: {responses.Data.Configuration.ContainerAccountUrl}" +
                    $"ContainerAccountName of container: {responses.Data.Configuration.ContainerAccountName}");
            }
            return responses;
        }

        /// <summary>
        /// A function to test the Get Container API.
        /// </summary>
        /// <param name="token"></param>
        /// <param name="baseApiUrl"></param>
        /// <returns></returns>
        public async Task<ContainersResponse> GetContainersAsync(string continuationToken, int limit, CancellationToken cancellationToken)
        {
            using var client = HttpClientProvider.GetHttpClient();
            ContainersResponse responses = null;
            string queryString = AddQueryStringParameters(null, continuationToken, limit);
            string apiURL = $"api/v1/containers{queryString}";
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientReadTimeout);
            var token = await tokenProvider.GetTokenAsync(cancellationToken);
            //get containers
            using (var request = new HttpRequestMessage(HttpMethod.Get, apiURL))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);

                response.EnsureSuccessStatusCode();

                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<ContainersResponse>(result, jsonSerializerOptions);

                logger.LogDebug($"Get containers completed");
            }
            return responses;
        }

        /// <summary>
        /// A function to test the Upload file with folder name API.
        /// </summary>
        /// <param name="token"></param>
        /// <param name="baseApiUrl"></param>
        /// <param name="containerName"></param>
        /// <param name="fileDetails"></param>
        /// <returns></returns>
        public async Task<UploadFileResult> UploadFileAsync(FileUploadRequest fileDetails, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(fileDetails.ContainerName))
            {
                throw new ArgumentException($"'{nameof(fileDetails.ContainerName)}' cannot be null or empty.", nameof(fileDetails.ContainerName));
            }

            try
            {
                using var client = HttpClientProvider.GetHttpClient();
                client.BaseAddress = BaseApiUrl;
                client.Timeout = TimeSpan.FromSeconds(ClientUploadTimeout);
                OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
                UploadFileResult responses = null;

                //send a file to service 
                string uploadFile = $"api/v1/upload/{fileDetails.ContainerName}/file";
                if (!string.IsNullOrEmpty(fileDetails.FolderName))
                {
                    uploadFile += $"?folder={fileDetails.FolderName}";
                }
                using (var content = new MultipartFormDataContent())
                {
                    var fileContent = new StreamContent(fileDetails.FileStream);
                    var fileContentMetadata = new StreamContent(fileDetails.MetadataFileStream);
                    content.Add(fileContent, "file", fileDetails.FileName);
                    content.Add(fileContentMetadata, "metadata", fileDetails.FileName + "-metadata.json");
                    var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile)
                    {
                        Content = content
                    };

                    requestUpload.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                    if (!string.IsNullOrEmpty(ApiKey))
                    {
                        requestUpload.Headers.Add("apikey", ApiKey);
                    }

                    requestUpload.Headers.Add("accept", "application/json");
                    var response = await client.SendAsync(requestUpload, cancellationToken);
                    response.EnsureSuccessStatusCode();
                    var result = await response.Content.ReadAsStringAsync(cancellationToken);
                    responses = JsonSerializer.Deserialize<UploadFileResult>(result, jsonSerializerOptions);
                    logger.LogDebug(result);
                }
                return responses;
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                return null;
            }
        }

        /// <summary>
        /// A function to test the Upload file with folder name API.
        /// </summary>
        /// <param name="token"></param>
        /// <param name="baseApiUrl"></param>
        /// <param name="containerName"></param>
        /// <param name="fileDetails"></param>
        /// <returns></returns>
        public async Task<UploadFileResult> UploadFileObjectAsync(FileUploadObjectRequest fileDetails, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(fileDetails.ContainerName))
            {
                throw new ArgumentException($"'{nameof(fileDetails.ContainerName)}' cannot be null or empty.", nameof(fileDetails.ContainerName));
            }

            try
            {
                using var client = HttpClientProvider.GetHttpClient();
                client.BaseAddress = BaseApiUrl;
                client.Timeout = TimeSpan.FromSeconds(ClientUploadTimeout);
                OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
                UploadFileResult responses = null;

                //send a file to service 
                string uploadFile = $"api/v1/upload/{fileDetails.ContainerName}/fileObj";
                if (!string.IsNullOrEmpty(fileDetails.FolderName))
                {
                    uploadFile += $"?folder={fileDetails.FolderName}";
                }
                using (var content = new MultipartFormDataContent())
                {
                    var fileContent = new StreamContent(fileDetails.FileStream);
                    var collection = fileDetails.MetadataCollections;

                    content.Add(fileContent, "File", fileDetails.FileName);
                    foreach (var item in collection.Items)
                    {
                        // JSON Format eg: "{\"key\": \"string\",\"value\": \"string\", \"isIndexed\": true}";
                        content.Add(new StringContent(JsonSerializer.Serialize(item)), $"Metadata.Items");
                    }
                    var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile)
                    {
                        Content = content
                    };

                    requestUpload.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                    if (!string.IsNullOrEmpty(ApiKey))
                    {
                        requestUpload.Headers.Add("apikey", ApiKey);
                    }

                    requestUpload.Headers.Add("accept", "application/json");
                    var response = await client.SendAsync(requestUpload, cancellationToken);
                    response.EnsureSuccessStatusCode();
                    var result = await response.Content.ReadAsStringAsync(cancellationToken);
                    responses = JsonSerializer.Deserialize<UploadFileResult>(result, jsonSerializerOptions);
                    logger.LogDebug(result);
                }
                return responses;
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                return null;
            }
        }

        /// <summary>
        /// A function to test the Download File API.
        /// </summary>
        /// <param name="token"></param>
        /// <param name="baseApiUrl"></param>
        /// <param name="containerName"></param>
        /// <param name="fileDetails"></param>
        /// <returns></returns>
        public async Task<Stream> DownlaodFileAsync(string containerName, string fileName, string folder, string fileGuid, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(containerName))
            {
                throw new ArgumentException($"'{nameof(containerName)}' cannot be null or empty.", nameof(containerName));
            }

            try
            {
                using var client = HttpClientProvider.GetHttpClient();
                client.BaseAddress = BaseApiUrl;
                client.Timeout = TimeSpan.FromSeconds(ClientDownloadTimeout);
                OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);

                //send a file to service 
                StringBuilder downloadFile = new StringBuilder();

                downloadFile.Append($"api/v1/download/{containerName}/file");

                downloadFile.Append($"?fileName={fileName}&folder={folder}&fileGuid={fileGuid}");
                Stream fileContentMetadata = null;
                using (var request = new HttpRequestMessage(HttpMethod.Get, downloadFile.ToString()))
                {
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                    if (!string.IsNullOrEmpty(ApiKey))
                    {
                        request.Headers.Add("apikey", ApiKey);
                    }
                    var responses = await client.SendAsync(request, cancellationToken);
                    fileContentMetadata = await responses.Content.ReadAsStreamAsync(cancellationToken);

                    responses.EnsureSuccessStatusCode();

                    var result = await responses.Content.ReadAsStringAsync(cancellationToken);
                    responses.EnsureSuccessStatusCode();
                    logger.LogDebug($"Downloaded File Details " +
                                          $"File Content Disposition: {responses.Content.Headers.ContentDisposition} " +
                                          $"File Content Type: {responses.Content.Headers.ContentType} " +
                                          $"File Content Length: {responses.Content.Headers.ContentLength} ");
                }
                return fileContentMetadata;
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                return null;
            }
        }

        /// <summary>
        /// Search files by tags using ANSI like query
        /// See 
        /// </summary>
        /// <param name="container">Container name</param>
        /// <param name="tagSearchQuery"> Tag search query  <br/>
        /// The following operators are supported: =, >, >=, <, <=, AND. Example expression: "tagKey"='tagValue'. <br />
        /// @container operator is not supported - as it will search in configured container <br />
        /// Example : <br />
        /// "ExperimentId" > 'ELN1234' AND "AllianceId" = 'GSK' <br/>
        /// <b>URI parameter must be properly URI encoded</b>
        /// </param>    
        /// <param name="cancellationToken"></param>
        /// <returns>Search result or empty result set</returns>
        public async Task<ApiResponse<IList<FileResource>>> SearchFilesAsync(string containerName, string tagSearchQuery, CancellationToken cancellationToken)
        {
            if (string.IsNullOrEmpty(containerName))
            {
                throw new ArgumentException($"'{nameof(containerName)}' cannot be null or empty.", nameof(containerName));
            }

            if (string.IsNullOrEmpty(tagSearchQuery))
            {
                throw new ArgumentException($"'{nameof(tagSearchQuery)}' cannot be null or empty.", nameof(tagSearchQuery));
            }

            using var client = HttpClientProvider.GetHttpClient();
            ApiResponse<IList<FileResource>> responses = null;

            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientReadTimeout);
            //get container by name
            string getContainerContents = $"api/v1/search/{containerName}/files/byTags/{tagSearchQuery}";
            using (var request = new HttpRequestMessage(HttpMethod.Get, getContainerContents))
            {
                OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);

                response.EnsureSuccessStatusCode();

                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<ApiResponse<IList<FileResource>>>(result, jsonSerializerOptions);
                logger.LogDebug($"SearchFilesAsync returned {(responses.Succeeded ? $"success Result count: {responses.Data.Count}" : $"error {responses.Message}")}");
            }
            return responses;

        }

        public static bool CheckURLValid(string source) => Uri.TryCreate(source, UriKind.Absolute, out Uri uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

        public async Task<UploadPartsInitResult> UploadPartsInitAsync(FilePartUploadRequest fileDetails, CancellationToken cancellationToken)
        {
            using var client = HttpClientProvider.GetHttpClient();
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientReadTimeout);
            OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
            UploadPartsInitResult responses = null;

            string uploadFile = $"api/v1/uploadPartsInit/{fileDetails.ContainerName}/file/{fileDetails.FileName}";
            using (var request = new HttpRequestMessage(HttpMethod.Get, uploadFile))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<UploadPartsInitResult>(result, jsonSerializerOptions);
                logger.LogDebug($"ContainerName : {responses.Container}. FileName Of Container: {responses.FileName}. File Session ID: {responses.UploadSessionId}.");
            }

            return responses;
        }

        public async Task<UploadPartResult> UploadPartFileAsync(FilePartUploadRequest fileDetails, Stream PartStream, int filePartNumber, string uploadSessionId, CancellationToken cancellationToken)
        {
            using var client = HttpClientProvider.GetHttpClient();
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientUploadTimeout);
            OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
            UploadPartResult responses = null;

            //send a file to service 
            string uploadFile = $"api/v1/uploadPart/{fileDetails.ContainerName}/file/{fileDetails.FileName}/ts/{fileDetails.FileTotalSize}/ps/{fileDetails.FileTotalSize}/pn/{filePartNumber}";
            if (!string.IsNullOrEmpty(fileDetails.Folder))
            {
                uploadFile += $"?folder={fileDetails.Folder}";
            }
            using (var content = new MultipartFormDataContent())
            {
                var partContent = new StreamContent(PartStream);
                content.Add(partContent, "FilePart", fileDetails.FileName);
                content.Add(new StringContent(uploadSessionId), "UploadSessionId");
                var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile)
                {
                    Content = content
                };
                requestUpload.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    requestUpload.Headers.Add("apikey", ApiKey);
                }
                requestUpload.Headers.Add("accept", "application/json");

                var response = await client.SendAsync(requestUpload, cancellationToken);
                response.EnsureSuccessStatusCode();
                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<UploadPartResult>(result, jsonSerializerOptions);
                logger.LogDebug(result);
            }
            return responses;

        }

        public async Task<UploadPartCommitResult> UploadPartsCommitAsync(FilePartUploadRequest fileDetails, string uploadSessionId, UploadPartCommitCollection parts,
                                                                          MetadataCollections metadata, CancellationToken cancellationToken)
        {
            using var client = HttpClientProvider.GetHttpClient();
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientUploadTimeout);
            OAuth2Token token = await tokenProvider.GetTokenAsync(cancellationToken);
            UploadPartCommitResult responses = null;

            string uploadFile = $"api/v1/uploadPartsCommit/{fileDetails.ContainerName}/file/{fileDetails.FileName}";
            if (!string.IsNullOrEmpty(fileDetails.Folder))
            {
                uploadFile += $"?folder={fileDetails.Folder}";
            }

            var uploadCommitRequest = new UploadPartCommitRequest
            {
                UploadSessionId = uploadSessionId,
                Metadata = metadata,
                Parts = parts
            };
            var json = JsonSerializer.Serialize(uploadCommitRequest);
            var data = new StringContent(json, Encoding.UTF8, "application/json");

            var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile);
            requestUpload.Content = data;
            requestUpload.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.AccessToken);
            if (!string.IsNullOrEmpty(ApiKey))
            {
                requestUpload.Headers.Add("apikey", ApiKey);
            }
            requestUpload.Headers.Add("accept", "application/json");

            var response = await client.SendAsync(requestUpload, cancellationToken);

            response.EnsureSuccessStatusCode();
            var result = await response.Content.ReadAsStringAsync(cancellationToken);
            responses = JsonSerializer.Deserialize<UploadPartCommitResult>(result, jsonSerializerOptions);
            logger.LogDebug(result);
            return responses;

        }

        private static string AddQueryStringParameters(string folder, string continuationToken, int limit)
        {
            string queryString = null;
            if (!string.IsNullOrEmpty(folder))
            {
                queryString = $"?folder={folder}";
            }
            if (!string.IsNullOrEmpty(continuationToken))
            {
                queryString = $"{queryString}{(queryString == null ? "?" : "&")}continuationToken={continuationToken}";
            }
            if (limit > 0 && limit < 1000)
            {
                queryString = $"{queryString}{(queryString == null ? "?" : "&")}Limit={limit}";
            }

            return queryString;
        }
    }
}