﻿using RD.RDF.StorageAPI.Client.Model;

namespace RD.RDF.StorageAPI.Client
{
    public interface IStorageAPIClientConfigurationProvider
    {
        StorageAPIClientConfiguration GetConfiguration();

    }
}
