﻿namespace RD.RDF.StorageAPI.Client.Model
{
    public class FileUploadObjectRequest : FileUploadRequestBase
    {
        public MetadataCollections MetadataCollections { get; set; }

    }
}
