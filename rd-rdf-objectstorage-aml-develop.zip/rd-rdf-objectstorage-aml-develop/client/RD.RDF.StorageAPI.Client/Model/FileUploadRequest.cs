﻿using System.IO;

namespace RD.RDF.StorageAPI.Client.Model
{
    public class FileUploadRequest : FileUploadRequestBase
    {
        public Stream MetadataFileStream { get; set; }
    }
}
