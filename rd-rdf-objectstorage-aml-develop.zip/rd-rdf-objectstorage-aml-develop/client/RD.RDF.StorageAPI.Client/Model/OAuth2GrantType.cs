﻿namespace RD.RDF.StorageAPI.Client.Model
{
    public enum OAuth2GrantType
    {
        /// <summary>
        /// Client	Credentials grant type
        /// </summary>
        client_credentials,
        /// <summary>
        /// Resource	Owner	Password	Credentials	(ROPC) grant type
        /// </summary>
        password
    }
}
