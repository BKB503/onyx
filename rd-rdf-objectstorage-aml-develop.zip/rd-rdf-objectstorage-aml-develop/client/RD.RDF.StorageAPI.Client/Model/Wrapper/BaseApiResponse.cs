﻿namespace RD.RDF.StorageAPI.Client.Model.Wrapper
{
    public abstract class BaseApiResponse
    {
        public BaseApiResponse()
        {
            Succeeded = true;
            Message = null;
            Errors = null;
        }

        public bool Succeeded { get; set; }

        public string[] Errors { get; set; }
        public string Message { get; set; }
    }
}