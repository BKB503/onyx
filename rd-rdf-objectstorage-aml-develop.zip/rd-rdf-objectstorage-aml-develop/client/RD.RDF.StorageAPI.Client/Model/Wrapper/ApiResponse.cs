﻿namespace RD.RDF.StorageAPI.Client.Model.Wrapper
{
    public class ApiResponse<T> : BaseApiResponse
    {
        public ApiResponse(T data = default) : base()
        {
            Data = data;
        }

        public T Data { get; set; }
    }
}
