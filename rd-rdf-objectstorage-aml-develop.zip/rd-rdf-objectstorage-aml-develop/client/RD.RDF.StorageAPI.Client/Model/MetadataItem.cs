﻿namespace RD.RDF.StorageAPI.Client.Model
{
    public class MetadataItem
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public bool IsIndexed { get; set; }
    }
}

