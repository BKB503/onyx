﻿using System;

namespace RD.RDF.StorageAPI.Client.Model
{
    public class OAuth2Configuration
    {
        public Uri AccessTokenUrl { get; set; }

        public string ClientId { get; set; }

        public string ClientSecret { get; set; }

        public string Scope { get; set; }

        public OAuth2GrantType GrantType { get; set; } = OAuth2GrantType.client_credentials;
    }
}
