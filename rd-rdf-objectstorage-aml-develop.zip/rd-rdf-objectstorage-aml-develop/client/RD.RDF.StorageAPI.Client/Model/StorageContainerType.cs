﻿namespace RD.RDF.StorageAPI.Client.Model
{
    public enum StorageContainerType
    {
        objectstorage = 0,
        azureblob = 1,
        azureadls = 2,
        googleblob = 3
    }
}
