﻿//namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
namespace RD.RDF.StorageAPI.Client.Model.PartialUploads

{
    public abstract class UploadPartsBaseModel
    {
        /// <summary>
        /// upload session id - used in all UploadParts endpoints to control the 
        /// upload process
        /// </summary>
        public string UploadSessionId { get; set; }

        /// <summary>
        /// container name
        /// </summary>
        public string Container { get; set; }

        /// <summary>
        /// file name with no folder
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// folder name 
        /// </summary>
        public string FolderName { get; set; }

        /// <summary>
        /// file path - file name with folder location
        /// </summary>
        public string FilePath { get; set; }
    }
}