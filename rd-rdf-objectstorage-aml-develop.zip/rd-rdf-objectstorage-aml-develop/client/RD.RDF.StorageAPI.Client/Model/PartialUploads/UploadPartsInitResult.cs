﻿//namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
namespace RD.RDF.StorageAPI.Client.Model.PartialUploads

{
    public class UploadPartsInitResult : UploadPartsBaseModel
    {
         

        public UploadPartsInitResult(UploadFileResultStatus status, string message)
        {
            this.Status = status;
            this.Message = message;
        }

        public UploadPartsInitResult()
        {

        }

        /// <summary>
        /// Result status
        /// </summary>
        public UploadFileResultStatus Status { get; set; }

        /// <summary>
        /// in case of error the message will be provided here
        /// </summary>
        public string Message { get; set; }
    }
}
