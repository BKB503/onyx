﻿//namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
namespace RD.RDF.StorageAPI.Client.Model.PartialUploads

{
    public class UploadPartResult : UploadPartsInitResult
    {  
        public UploadPartResult(UploadFileResultStatus status, string message)
        {
            this.Status = status;
            this.Message = message;
        }
        public UploadPartResult()
        {

        }

        /// <summary>
        /// part number
        /// </summary>
        public int FilePartNumber { get; set; }

        /// <summary>
        /// file part max size
        /// </summary>
        public long FilePartSize { get; set; }

        /// <summary>
        /// file total size
        /// </summary>
        public long FileTotalSize { get; set; }

        /// <summary>
        /// bytes send to the API
        /// </summary>
        public long BytesSend { get; set; }

        /// <summary>
        /// bytes saved in the storage
        /// </summary>
        public long BytesWritten { get; set; }

        /// <summary>
        /// part identification - depending on storage it can be ETag or MD5 hash or other identification string
        /// that value has to be provided in Commit message item <seealso cref="UploadPartCommitItem"/>
        /// </summary>
        public string PartGuid { get; set; }
    }
}
