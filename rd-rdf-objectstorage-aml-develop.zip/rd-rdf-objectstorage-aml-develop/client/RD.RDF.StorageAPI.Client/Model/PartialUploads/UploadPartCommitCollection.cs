﻿using System.Collections.Generic;

    namespace RD.RDF.StorageAPI.Client.Model.PartialUploads

{
    public class UploadPartCommitCollection
    {
        public List<UploadPartCommitItem> Items { get; set; } = new List<UploadPartCommitItem>();

        public UploadPartCommitCollection()
        {

        }

    }
}
