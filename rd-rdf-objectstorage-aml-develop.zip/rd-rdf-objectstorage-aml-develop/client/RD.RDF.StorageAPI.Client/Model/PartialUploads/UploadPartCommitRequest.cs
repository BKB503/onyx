﻿using System.Collections.Generic;

//namespace RD.RDF.StorageAPI.Contracts.Model.PartialUploads
namespace RD.RDF.StorageAPI.Client.Model.PartialUploads

{
    /// <summary>
    /// Commit request object
    /// </summary>
    public class UploadPartCommitRequest
    {
        /// <summary>
        /// upload session id - used in all UploadParts endpoints to control the 
        /// upload process
        /// </summary>
        public string UploadSessionId { get; set; }

        /// <summary>
        /// metadata list that will be saved with file
        /// </summary>
        public MetadataCollections Metadata { get; set; }

        /// <summary>
        /// upload parts list - ordered list
        /// </summary>
        public UploadPartCommitCollection Parts { get; set; }

    }
}
