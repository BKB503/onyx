﻿namespace RD.RDF.StorageAPI.Client.Model.PartialUploads

{
    /// <summary>
    /// upload part item
    /// </summary>
    public class UploadPartCommitItem
    {
        public UploadPartCommitItem(int filePartNumber, string partGuid)
        {
            FilePartNumber = filePartNumber;
            PartGuid = partGuid;
        }

        /// <summary>
        /// part number
        /// </summary>
        public int FilePartNumber { get; set; }

        /// <summary>
        /// part identification - depending on storage it can be ETag or MD5 hash or other identification string
        /// </summary>
        public string PartGuid { get; set; }
    }
}
