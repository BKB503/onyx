﻿using System;

namespace RD.RDF.StorageAPI.Client.Model
{
    public class StorageAPIClientConfiguration
    {
        /// <summary>
        /// Oauth2 Access Configuration
        /// </summary>
        public OAuth2Configuration AccessConfiguration { get; set; }

        /// <summary>
        /// in case of KONG based hosting api key is required
        /// </summary>
        public string ApiKey { get; set; }

        /// <summary>
        /// base api url  : For example  https://dev.api.gsk.com/storage-api 
        /// </summary>
        public Uri BaseApiUrl { get; set; }

        /// <summary>
        /// Configuration Name
        /// </summary>
        public string Name { get; set; }
  
        /// <summary>
        /// reading timeout - 60s by default
        /// </summary>
        public int ClientReadTimeout { get; set; } = 60;

        /// <summary>
        /// upload timeout - 3600s by default
        /// </summary>
        public int ClientUploadTimeout { get; set; } = 3600;

        /// <summary>
        /// upload timeout - 3600s by default
        /// </summary>
        public int ClientDownloadTimeout { get; set; } = 3600;
    }
}
