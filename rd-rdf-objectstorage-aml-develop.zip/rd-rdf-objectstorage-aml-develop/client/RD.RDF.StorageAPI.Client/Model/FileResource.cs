﻿using System;
using System.Collections.Generic;

namespace RD.RDF.StorageAPI.Client.Model
{
    public record FileResource(string FileName)
    {
        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? CreationTime { get; set; }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? ModifiedTime { get; set; }

        /// <summary>
        /// file size
        /// </summary>
        public long? FileSize { get; set; }

        /// <summary>
        /// Full path in storage
        /// </summary>
        public string FilePath { get; set; }

        /// <summary>
        /// File GUID
        /// </summary>
        public string FileGuid { get; set; }

        /// <summary>
        /// File Version Id
        /// </summary>
        public string FileVersionId { get; set; }

        /// <summary>
        /// Folder Name
        /// </summary>
        public string FolderName { get; set; }

        /// <summary>
        /// File GUID
        /// </summary>
        public List<VersionDetails> FileVersions { get; set; }

        /// <summary>
        /// file e-tag
        /// </summary>
        public string FileETag { get; set; }

        /// <summary>
        /// file content hash
        /// </summary>
        public string FileContentHash { get; set; }


        /// <summary>
        /// mime content type
        /// </summary>
        public string FileContentType { get; set; }

        /// <summary>
        /// Storage blob type
        /// </summary>
        public string FileBlobType { get; set; }


        /// <summary>
        /// Metadata dictionary
        /// </summary>
        public MetadataDictionary Metadata { get; set; } = new MetadataDictionary();
    }
}
