﻿namespace RD.RDF.StorageAPI.Client.Model
{
    public class StorageContainerConfiguration
    {
        public string Name { get; set; }
        public StorageContainerType Type { get; set; }
        public string ContainerAccountName { get; set; }
        public string ContainerAccountUrl { get; set; }
        public string ContainerName { get; set; }
        public string ContainerUserId { get; set; }
        public bool IsVersionEnabled { get; set; }
        public bool IsConnectionAvailable { get; set; }
    }


}
