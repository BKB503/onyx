﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RD.RDF.StorageAPI.Client.Model
{
    public class MetadataCollections
    {
        //[JsonPropertyName("MetaData")]
        public List<MetadataItem> Items { get; set; }
        public MetadataCollections()
        {

        }

        public MetadataCollections(IDictionary<string, string> inputDict)
        {
            FillCollection(inputDict);
        }


        public MetadataCollections(MetadataDictionary inputDict)
        {
            FillCollection(inputDict);
        }

        private void FillCollection(IDictionary<string, string> inputDict)
        {
            List<MetadataItem> metadata = new List<MetadataItem>();
            foreach (var item in inputDict)
            {
                MetadataItem metadataItem = new MetadataItem
                {
                    Key = item.Key,
                    Value = item.Value,
                    IsIndexed = true
                };
                metadata.Add(metadataItem);
            }
            Items = metadata;
        }
    }

}

