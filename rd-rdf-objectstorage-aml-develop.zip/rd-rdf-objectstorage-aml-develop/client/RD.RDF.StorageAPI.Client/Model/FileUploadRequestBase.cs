﻿using System.IO;

namespace RD.RDF.StorageAPI.Client.Model
{
    public abstract class FileUploadRequestBase
    {
        public string ContainerName { get; set; }
        public string FileName { get; set; }
        public Stream FileStream { get; set; }
        public string FolderName { get; set; } 
       
    }
}
