﻿using System.IO;

namespace RD.RDF.StorageAPI.Client.Model
{
    public class FilePartUploadRequest
    {
        public string ContainerName { get; set; }
        public string FileName { get; set; }
        public string Folder { get; set; }
        public long FilePartSize { get; set; }
        public long FileTotalSize { get; set; }
        public int Chunks { get; set; }


    }
}
