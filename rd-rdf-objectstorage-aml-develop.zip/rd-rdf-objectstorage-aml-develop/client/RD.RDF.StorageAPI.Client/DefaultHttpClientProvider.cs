﻿using System.Net.Http;

namespace RD.RDF.StorageAPI.Client
{
    public class DefaultHttpClientProvider : IHttpClientProvider
    {
        public HttpClient GetHttpClient() => new HttpClient();
        
    }
}
