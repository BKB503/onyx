Write-Host "SonarQubeAnalysis  $Env:AGENT_NAME."
#pwd
#dotnet sonarscanner begin /d:sonar.verbose=true /k:"gsk-tech_rd-rdf-objectstorage-aml" /d:sonar.login="49422b963241714573d12bcd6e42599f924f10c5" /d:sonar.host.url="https://sonarqube.gsk.com/"  /d:sonar.cs.opencover.reportsPaths=**/coverage.opencover.xml

dotnet build .\client\RD.RDF.StorageAPIClient.sln
dotnet test .\client\RD.RDF.StorageAPIClient.sln /p:CollectCoverage=true /p:CoverletOutputFormat=opencover

dotnet build .\portal\RD.RDF.StoragePortal.sln
dotnet test .\portal\RD.RDF.StoragePortal.sln /p:CollectCoverage=true /p:CoverletOutputFormat=opencover

dotnet build .\source\RD.RDF.StorageAPI.sln
dotnet test .\source\RD.RDF.StorageAPI.sln /p:CollectCoverage=true /p:CoverletOutputFormat=opencover --filter FullyQualifiedName!~IntegrationTest

dotnet build .\tools\RD.RDF.StorageAPITools.sln
dotnet test .\tools\RD.RDF.StorageAPITools.sln /p:CollectCoverage=true /p:CoverletOutputFormat=opencover
 
#dotnet sonarscanner end /d:sonar.login="49422b963241714573d12bcd6e42599f924f10c5"

