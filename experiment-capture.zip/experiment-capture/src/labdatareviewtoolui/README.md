# Getting Started with React App

npm install 

## Update all the configuration 


## Start the application locally 

npm start listen on local host port 3000

## Build 

npm run build

### Docker

start dev docker install docker to local 
Build and Run from docker compose Dev : docker-compose -f docker-compose-dev.yml up  --build
BUILD and Run Docker prod : docker-compose -f docker-compose-prod.yml up -d  --build
Delete or Remove Docker : docker-compose -f docker-compose-dev.yml down
