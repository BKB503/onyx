const path = require('path');


module.exports = {
  context: path.resolve(__dirname, '../'),
  entry: './src/index.js',
  output: {
    path: path.join(__dirname, '../build'),
    filename: 'static/js/[name].[contenthash:8].js',
    publicPath: '/',
  },
  resolve: {
    extensions: ['.js', '.less'],
  },
  performance: {
    maxAssetSize: 650 * 1024,
    maxEntrypointSize: 650 * 1024,
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /nodeModules/,
        use: {
          loader: 'babel-loader',
        },
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
        use: [
          {
            loader: 'babel-loader',
          },
          {
            loader: '@svgr/webpack',
            options: {
              babel: false,
              icon: true,
            },
          },
        ],
      }
    ],
  },
};
