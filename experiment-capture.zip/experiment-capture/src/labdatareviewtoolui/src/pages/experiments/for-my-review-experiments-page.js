import { ForMyReviewContainer } from "../../components/experiments/for-my-review/for-my-review.container"

export const ForMyReviewExperimentsPage = () =>{
    return (<ForMyReviewContainer></ForMyReviewContainer>)
}