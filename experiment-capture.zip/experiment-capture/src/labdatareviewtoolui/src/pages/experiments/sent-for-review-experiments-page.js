import { SentForReviewContainer } from "../../components/experiments/sent-for-review/sent-for-review.container";


export const SentForReviewExperimentsPage = () =>{
    return (<SentForReviewContainer />)
}