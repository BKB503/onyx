import { ExperimentDashboard } from "../../components/experiments/experiment-dashboard/experiment-dashboard.component"
import { ExperimentsProvider } from "../../components/experiments/experiments.provider"

export const ExperimentsDashboardPage = () => {

    return <ExperimentsProvider>
        <ExperimentDashboard></ExperimentDashboard>
    </ExperimentsProvider>
}