
import { MyExperimentsContainer } from "../../components/experiments/my-experiments/my-experiments.container";

export const MyExperimentsPage = () =>{
    
    return (<MyExperimentsContainer></MyExperimentsContainer>)
}