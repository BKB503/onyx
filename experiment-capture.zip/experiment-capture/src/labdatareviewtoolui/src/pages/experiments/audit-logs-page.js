import { AuditLogs } from "../../components/experiments/audit-logs/audit-logs.component"
import { ExperimentsProvider } from "../../components/experiments/experiments.provider"

export const AuditLogsPage = () => {

    return <ExperimentsProvider>
        <AuditLogs></AuditLogs>
    </ExperimentsProvider>
}