export const ConstantsHelper  ={ 
    DateFormat : "YYYY-MM-DD HH:mm:ss", 
    DisplayDateFormat: "MMM DD, YYYY"
};

export const ExperimentType ={
    Task : "task",
    Experiment:"experiment",
    Workflow:"workflow"
}