import React, { useContext } from 'react'
import { SideBar } from '../sidebar/sidebar.component';
import { Header } from '../header/header.component';
import { Layout } from 'antd';
import { Route, Routes } from 'react-router-dom';
import { MyExperimentsPage } from '../../../pages/experiments/my-experiments-page';
import { ForMyReviewExperimentsPage } from '../../../pages/experiments/for-my-review-experiments-page';
import { SentForReviewExperimentsPage } from '../../../pages/experiments/sent-for-review-experiments-page';
import { Button } from 'antd';
import { AuthContext } from "react-oauth2-code-pkce";
import { ExperimentsDashboardPage } from '../../../pages/experiments/experiment-dashboard-page';
import { NotFoundPage } from '../../../pages/error-pages/not-found-page';
import { AuditLogsPage } from '../../../pages/experiments/audit-logs-page';
const { Content } = Layout;

export const MainLayout = () => {
  
    const { 
        token, 
        login, 
        error, 
        loginInProgress 
      } = useContext(AuthContext);
   
    if (token) {
        return (<div>
            <Layout
                style={{
                    minHeight: '100vh',
                }}
            > <SideBar></SideBar>
                <Layout className="site-layout">
                    <Header />
                    <Content
                        style={{
                            margin: '0 16px',
                        }}
                    >
                        <Routes>
                            <Route exact path="/" element={<MyExperimentsPage />}></Route>
                            <Route path="myexperiments" element={<MyExperimentsPage />}></Route>
                            <Route path="formyreview" element={<ForMyReviewExperimentsPage />}></Route>
                            <Route path="sentforreview" element={<SentForReviewExperimentsPage />}></Route>
                            <Route path="experimentdashboard/:type/:experimentId/:entityId" element={<ExperimentsDashboardPage />}></Route>
                            <Route path="experimentdashboard/:type/:experimentId/:entityId/:workflowId" element={<ExperimentsDashboardPage />}></Route>
                            <Route path="experimentdashboard/:type/:experimentId/:entityId/:workflowId/:taskId" element={<ExperimentsDashboardPage />}></Route>
                            <Route path="auditlogs/:entityId" element={<AuditLogsPage />}></Route>
                            <Route path="*" element={<NotFoundPage />}></Route>
                        </Routes>
                    </Content>
                </Layout>
            </Layout>
        </div>)
    } else if (error) {
        return <span>An error occurred during login! {error}</span>
    } else {
        return <span>Only unauthenticated users can see me. Please click Sign in button
            <Button
                key="signin"
                type="primary"
                onClick={() => login()}
                size="medium"
            >
                Sign in
            </Button>
        </span>
    }
}