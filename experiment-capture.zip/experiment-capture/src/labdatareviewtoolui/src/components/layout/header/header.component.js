import { LogoutOutlined, UserOutlined } from '@ant-design/icons';
import { React, useContext, useState, useEffect } from 'react';
import { AuthContext } from "react-oauth2-code-pkce";
import { PageHeader, Divider } from 'antd';
import './header.less';

export const Header = () => {

  const {
    tokenData,
    logOut
  } = useContext(AuthContext);
  const [headerState, setHeaderState] = useState({
    username: "",

  });

  useEffect(() => {
    if (tokenData) {
      setHeaderState({
        ...headerState,
        username: `${tokenData.given_name} ${tokenData.family_name}`
      });
    }
  }, [tokenData]);

  return (<PageHeader key="top-header"
    ghost={false}
    title=""
    subTitle=""
    extra={[
      <label key="1"><UserOutlined /> {headerState.username}</label>,
      <Divider type="vertical" key="2" />,
      <a key="3" onClick={() => logOut()}> <LogoutOutlined /> Logout</a>,

    ]}
  ></PageHeader>)
}