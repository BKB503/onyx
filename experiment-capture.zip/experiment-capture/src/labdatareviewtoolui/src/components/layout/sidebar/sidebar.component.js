import React, { useState } from 'react';
import { Layout, Menu } from 'antd';
import { Link, useLocation } from 'react-router-dom';
const { Sider } = Layout;


export const SideBar = () => {
  const { pathname } = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  function getItem(label, key, icon, children, type) {
    return {
      key,
      icon,
      children,
      label,
      type
    };
  }

  function getRoutedLink(title, routeTo) {
    return <Link to={routeTo}>
      <span className="nav-text">{title} </span>
    </Link>
  }

  const items = [
    getItem("Experiments", "experiments", "", [
      getItem(getRoutedLink("My Experiments","/myexperiments"),"/myexperiments"),
      getItem(getRoutedLink("For My Review","/formyreview"), "/formyreview"),
      getItem(getRoutedLink("Sent For Review","/sentforreview"), "/sentforreview"),
    ])
  ];

  return (
    <Sider collapsible collapsed={collapsed} onCollapse={(value) => setCollapsed(value)}>
      <Link to="/myexperiments">
        <div className="logo">
          <b>
            {!collapsed && (<span>Lab Data Review Tool</span>)}
            {collapsed && (<span>LDRT</span>)}
          </b>
        </div>
      </Link>

      <Menu
        selectedKeys={[pathname]}
        defaultOpenKeys={["experiments"]}
        mode="inline"
        theme="dark"
        items={items}
      />
    </Sider>
  )

}

