import * as types from './action-types';

export const reducer = (state, action) => {
    switch (action.type) {
        case types.SET_LOADING:
            return { ...state, loading: action.payload };
        case types.GET_EXPERIMENTS:
            return { ...state, ...action.payload };
        case types.GET_EXPERIMENTS_FOR_MY_REVIEW:
            return { ...state, ...action.payload };
        case types.GET_EXPERIMENTS_SENT_FOR_REVIEW:
            return { ...state, ...action.payload };
        case types.GET_COMMENTS:
            return { ...state, ...action.payload };
        case types.GET_DOCUMENTS_INFO:
            return { ...state, ...action.payload };
        case types.DOWNLOAD_DOCUMENT:
            return { ...state, ...action.payload };
        case types.EXPERIMENT_EXPORTTOPDF:
            return {... state, ...action.payload};
        case types.SET_SPOTFIRE_DOC:
            return { ...state, ...action.payload };
        case types.CANCEL_TASK:
            return { ...state, ...action.payload };
        case types.COMPLETE_TASK:
            return { ...state, ...action.payload };
        case types.GET_LOGS:
            return { ...state, ...action.payload };
        case types.REJECT_RESPONSE:
            return { ...state, ...action.payload };
        default:
            return state;
    }
};