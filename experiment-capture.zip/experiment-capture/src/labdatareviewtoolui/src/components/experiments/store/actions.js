import { getLogs } from '../api/auditlogs.api';
import {
    getExperiments, getExperimentsForMyReview,
    getExperimentsSentForReview, getDocumentsByEntityId,
    downloadDocument, downloadExperimentPDF
} from '../api/experiments.api';
import { taskCancel, getComments, taskComplete } from '../api/tasks.api';
import * as types from './action-types';

export const getExperimentsDispatch = async (dispatch, dateRange) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await getExperiments(dateRange);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const experiments = response.data;
            dispatch({
                type: types.GET_EXPERIMENTS,
                payload: { experiments, loading: false, error: null }
            });
        }
    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const getExperimentsForMyReviewDispatch = async (dispatch, dateRange) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await getExperimentsForMyReview(dateRange);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const experimentsForMyReview = response.data;
            dispatch({
                type: types.GET_EXPERIMENTS_FOR_MY_REVIEW,
                payload: { experimentsForMyReview, loading: false, error: null }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const getExperimentsSentForReviewDispatch = async (dispatch, dateRange) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await getExperimentsSentForReview(dateRange);

        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const experimentsSentForReview = response.data;
            dispatch({
                type: types.GET_EXPERIMENTS_SENT_FOR_REVIEW,
                payload: { experimentsSentForReview, loading: false, error: null }
            });
        }
    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const getTaskComments = async (dispatch, taskId) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await getComments(taskId);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const taskComments = response.data;
            dispatch({
                type: types.GET_COMMENTS,
                payload: { taskComments, loading: false, error: null }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const taskCancelDispatch = async (dispatch, taskId) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await taskCancel(taskId);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            dispatch({
                type: types.CANCEL_TASK,
                payload: { successMessage: response.data.message, loading: false, error: null }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const taskCompleteDispatch = async (dispatch, taskId, entityId) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await taskComplete(taskId, entityId);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            dispatch({
                type: types.COMPLETE_TASK,
                payload: { successMessage: response.data.message, loading: false, error: null }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const getDocumentsByEntityIdDispatch = async (dispatch, entityId) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await getDocumentsByEntityId(entityId);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const documentsInfo = response.data;
            dispatch({
                type: types.GET_DOCUMENTS_INFO,
                payload: { documentsInfo, loading: false, error: null }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const downloadDocumentAction = async (dispatch, entityId, versionId, filename) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await downloadDocument(entityId, versionId, filename);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const blobDocument = response.data;
            dispatch({
                type: types.DOWNLOAD_DOCUMENT,
                payload: { blobDocument, loading: false, error: null, filename: filename }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}

export const downloadExperimentPDFAction = async (dispatch, entityId, filename) => {
    dispatch({ type: types.SET_LOADING, payload: true });

    try {
        const response = await downloadExperimentPDF(entityId);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const blobDocument = response.data;
            dispatch({
                type: types.EXPERIMENT_EXPORTTOPDF,
                payload: { blobDocument, loading: false, error: null, filename: filename }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}


export const getAuditLogsDispatch = async (dispatch, entityId) => {
    dispatch({ type: types.SET_LOADING, payload: true });
    const filterArray = ["ENTITY_VERSION_CREATED",
        "ENTITY_LOCKED",
        "ENTITY_UNLOCKED",
        "ENTITY_VERSION_SIGNED",
        "ENTITY_VERSION_SIGNOFF_REVOKED",
        "ENTITY_UNLOCKED_AGAINST_EDITING",
        "ENTITY_LOCKED_AGAINST_EDITING"
    ];
    try {
        const response = await getLogs(entityId);
        if (response && response.status != 200) {
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { loading: false, error: response.data.Message }
            });
        } else {
            const auditLogs = response.data;
            var auditLogsOverview = [];
            if (auditLogs.length > 0) {
                auditLogsOverview = auditLogs.filter(a => filterArray.some(f => f === a.type));
            }
            dispatch({
                type: types.GET_LOGS,
                payload: { auditLogs, auditLogsOverview, loading: false, error: null }
            });
        }

    } catch (error) {
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error.message, loading: false }
        });
    }
}