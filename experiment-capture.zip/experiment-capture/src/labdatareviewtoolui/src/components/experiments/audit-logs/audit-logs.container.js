import { ExperimentsProvider } from "../experiments.provider"
import { AuditLogs } from "./audit-logs.component";

export const AuitLogsContainer = (props) => {
    return <ExperimentsProvider>
                <AuditLogs {...props}/>
           </ExperimentsProvider>
}