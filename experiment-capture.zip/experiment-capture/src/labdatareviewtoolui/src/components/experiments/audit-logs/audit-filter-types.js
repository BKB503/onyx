export const FilterTypes = [{
    value: 'ENTITY_VERSION_CREATED',
    label: 'ENTITY_VERSION_CREATED'
},
{
    value: 'ENTITY_VERSION_UPDATED',
    label: 'ENTITY_VERSION_UPDATED'
},
{
    value: 'ENTITY_LOCKED',
    label: 'ENTITY_LOCKED'
},
{
    value: 'ENTITY_LOCKED_AGAINST_EDITING',
    label: 'ENTITY_LOCKED_AGAINST_EDITING'
},
{
    value: 'ENTITY_UNLOCKED_AGAINST_EDITING',
    label: 'ENTITY_UNLOCKED_AGAINST_EDITING'
},
{
    value: 'ENTITY_UNLOCKED',
    label: 'ENTITY_UNLOCKED'
},
{
    value: 'Data Added',
    label: 'Data Added'
},
{
    value: 'Items Added',
    label: 'Items Added'
},
{
    value: 'ENTITY_VERSION_SIGNED',
    label: 'ENTITY_VERSION_SIGNED'
},
{
    value: 'SmartFill Data Refreshed',
    label: 'SmartFill Data Refreshed'
},
{
    value: 'Data Exchange',
    label: 'Data Exchange'
},
{
    value: 'Data Removed',
    label: 'Data Removed'
},{
    value:'Items Removed',
    label:'Items Removed'
},
{
    value: 'Data Changed',
    label: 'Data Changed'
},
{
    value: 'Items Changed',
    label: 'Items Changed'
},
];

export const FilterTypesForOverView = ["ENTITY_VERSION_CREATED",
"ENTITY_LOCKED",
"ENTITY_UNLOCKED",
"ENTITY_VERSION_SIGNED",
"ENTITY_VERSION_SIGNOFF_REVOKED",
"ENTITY_UNLOCKED_AGAINST_EDITING",
"ENTITY_LOCKED_AGAINST_EDITING"
];