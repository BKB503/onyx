import { useEffect, useState } from "react";
import { useExperimentsContext } from "../experiments.provider";
import { getAuditLogsDispatch } from "../store/actions";
import { Breadcrumb, Layout, Alert, Timeline, Col, Row, Button, Space, Select } from 'antd';
import ExchangeSvg from './svgs/exchange.svg';
import {
    CloseCircleOutlined, EditOutlined, HighlightTwoTone, InteractionTwoTone, LockTwoTone,
    PlusCircleOutlined, PlusSquareTwoTone, SearchOutlined, SwapOutlined, SyncOutlined, UnlockTwoTone, CloseSquareOutlined
} from '@ant-design/icons';
import moment from 'moment';
import { Link, useNavigate } from "react-router-dom";
import { ConstantsHelper } from '../../constants';
import { LoadingSpinner } from "../../shared/loading.component";
import { useParams } from 'react-router-dom';
import './audit-logs.less';
import Icon from '@ant-design/icons';
import { FilterTypes, FilterTypesForOverView } from "./audit-filter-types";
const { Content } = Layout;

export const AuditLogs = () => {
    const { entityId } = useParams();
    const navigate = useNavigate();
    const { state, dispatch } = useExperimentsContext();
    const { loading, auditLogsOverview, auditLogs, error } = state;
    const [isDetailedOrOverviewLogs, setIsDetailedOrOverviewLogs] = useState(false);
    const [selectedFilterTypeItems, setSelectedFilterTypeItems] = useState([]);
    const [auditLogItems, setAuditLogItems] = useState([]);
    useEffect(() => {
        getAuditLogsDispatch(dispatch, entityId)
    }, [entityId]);

    useEffect(() => {
        if (auditLogs) {
            var logs = auditLogs.filter(a => FilterTypesForOverView.some(f => f === a.type));
            setAuditLogItems(logs);
        }
    }, [auditLogs]);

    const getTimelineIcon = (type) => {
        switch (type) {
            case "ENTITY_LOCKED":
            case "ENTITY_LOCKED_AGAINST_EDITING":
                return <LockTwoTone className="icon-fontsize"></LockTwoTone>;

            case "ENTITY_UNLOCKED":
            case "ENTITY_UNLOCKED_AGAINST_EDITING":
                return <UnlockTwoTone className="icon-fontsize"></UnlockTwoTone>;

            case "ENTITY_VERSION_CREATED":
                return <PlusSquareTwoTone className="icon-fontsize"></PlusSquareTwoTone>;

            case "ENTITY_VERSION_UPDATED":
                return <EditOutlined className="icon-fontsize"></EditOutlined>;

            case "Data Added":
                return <PlusSquareTwoTone className="icon-fontsize"></PlusSquareTwoTone>;

            case "Items Added":
                return <PlusCircleOutlined className="icon-fontsize"></PlusCircleOutlined>;

            case "ENTITY_VERSION_SIGNED":
                return <HighlightTwoTone className="icon-fontsize"></HighlightTwoTone>;

            case "SmartFill Data Refreshed":
                return <SyncOutlined className="icon-fontsize"></SyncOutlined>

            case "Data Exchange":
                return <SwapOutlined className="icon-fontsize"></SwapOutlined>

            case "Data Removed":
                return <CloseSquareOutlined className="icon-fontsize"></CloseSquareOutlined>

            case "Items Removed":
                return <CloseCircleOutlined className="icon-fontsize"></CloseCircleOutlined>

            case "Data Changed":
            case "Items Changed":
                return <Icon component={ExchangeSvg} className="icon-fontsize" />

            default:
                break;
        }
    }

    const handleIsDetailedOrOverviewLogs = (isDetailedOrOverviewLogs) => {
        setIsDetailedOrOverviewLogs(isDetailedOrOverviewLogs);
        auditLogsFilterTypes(selectedFilterTypeItems, isDetailedOrOverviewLogs);
    }

    const onChangeFilterType = (selectedItems) => {
       
        setSelectedFilterTypeItems(selectedItems);
        auditLogsFilterTypes(selectedItems,isDetailedOrOverviewLogs);
    }

    const auditLogsFilterTypes =(selectedItems, isDetailedOrOverviewLogsSelected) =>{
        if (selectedItems && selectedItems.length > 0) {
            if (!isDetailedOrOverviewLogsSelected) {
                var logs = auditLogsOverview.filter(a => selectedItems.some(f => f === a.type));
                setAuditLogItems(logs);
            } else {
                var logs = auditLogs.filter(a => selectedItems.some(f => f === a.type));
                setAuditLogItems(logs);
            }
        }else{
            if (!isDetailedOrOverviewLogsSelected) {
                // overview logs
                setAuditLogItems(auditLogsOverview);
            }else{
                //full logs
                setAuditLogItems(auditLogs);
            }
        }
    }

    return (
        <>
            <Layout className="layout-padding">
                <Breadcrumb className="breadcrumb">
                    <Breadcrumb.Item><Link to='/myexperiments'><span className="nav-text">Experiments</span></Link></Breadcrumb.Item>
                    <Breadcrumb.Item><Link to="" onClick={() => navigate(-1)}><span className="nav-text">Dashboard</span></Link></Breadcrumb.Item>
                    <Breadcrumb.Item>Audit Timeline</Breadcrumb.Item>
                </Breadcrumb>
                <Content
                    className="site-layout-background">
                    {loading && <LoadingSpinner />}
                    {error && <Alert message={error} type="error" />}
                    <Row key="1">
                        <Col span="21" className="col-text-align">
                            <Space>
                                <Select className="" mode="multiple" style={{ width: '310px' }} value={selectedFilterTypeItems}
                                    onChange={onChangeFilterType} options={FilterTypes} placeholder="Please select a filter type" size="">

                                </Select>
                                {!isDetailedOrOverviewLogs && <Button type="primary" onClick={() => handleIsDetailedOrOverviewLogs(true)}>Detailed Logs</Button>}
                                {isDetailedOrOverviewLogs && <Button type="primary" onClick={() => handleIsDetailedOrOverviewLogs(false)}>Overview Logs</Button>}
                            </Space>
                        </Col>
                    </Row>
                    <Row></Row>
                    <Space> </Space>
                    {auditLogItems && (<Timeline mode="alternate">
                        {auditLogItems.map((a, index) => (
                            <Timeline.Item dot={getTimelineIcon(a.type)} key={index}>
                                <div> <b>Type :</b>{` ${a.type}`}</div>
                                <div> <b>Date :</b> {`${(moment(a.zoneStamp).format(ConstantsHelper.DateFormat))}`}</div>
                                <div> <b>Message :</b>{` ${a.message}`}</div>
                                {a.reason && <div><b>Reason :</b> {`${a.reason}`}</div>}
                                <div><b>User :</b> {`${a.userFullName}`}</div>
                            </Timeline.Item>))}
                    </Timeline>)}
                </Content>
            </Layout>

        </>
    )
}