import { fetchGet } from "../../../shared/api/http-manager"


export const getLogs = async (entityId) => {
    var queryString = `?entityId=${entityId}`
    var url = `audit/GetLogs${queryString}`
    const data = await fetchGet(url);
    return data;
}

