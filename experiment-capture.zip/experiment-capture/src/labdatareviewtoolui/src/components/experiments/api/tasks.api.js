import { fetchGet, fetchPost } from "../../../shared/api/http-manager"


export const getComments = async (taskId) => {
    var queryString = `?taskId=${taskId}`
    var url = `Task/GetComments${queryString}`
    const data = await fetchGet(url);
    return data;
}

export const taskCancel = async (taskId) => {

    var url = `Task/cancel`
    var body = {
        taskId: taskId
    }
    const response = await fetchPost(url, body)
    return response;
}

export const taskComplete = async (taskId, entityId) => {

    var url = `Task/complete`
    var body = {
        taskId: taskId,
        entityId: entityId
    }
    const response = await fetchPost(url, body)
    return response;
}