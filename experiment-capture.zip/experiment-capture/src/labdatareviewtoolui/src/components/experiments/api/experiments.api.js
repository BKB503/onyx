import { fetchGet } from "../../../shared/api/http-manager"


export const getExperiments = async(dateRange) =>{
    var queryString = `?startDate=${dateRange.startDateFormat}&endDate=${dateRange.endDateFormat}`;
    var url = `Experiment/GetExperimentsByOpenStatus${queryString}`;
    const data = await fetchGet(url);
    return data;
}

export const getExperimentsForMyReview = async(dateRange) =>{
    var queryString = `?startDate=${dateRange.startDateFormat}&endDate=${dateRange.endDateFormat}`;
    var url = `Experiment/GetExperimentsForUserReview${queryString}`;
    const data = await fetchGet(url);
    return data;
}

export const getExperimentsSentForReview = async(dateRange) =>{
    var queryString = `?startDate=${dateRange.startDateFormat}&endDate=${dateRange.endDateFormat}`;
    var url = `Experiment/GetExperimentsSentForReview${queryString}`;
    const data = await fetchGet(url);
    return data;
}
export const getDocumentsByEntityId = async(entityId) =>{
    var queryString = `?entityId=${entityId}`
    var url = `Experiment/GetDocumentsByEntityId${queryString}`;
    const data = await fetchGet(url);
    return data;
}

export const downloadDocument = async(entityId, versionId, fileName) =>{
    var queryString = `?entityId=${entityId}&entityVersionId=${versionId}&fileName=${fileName}`;
    var url = `Experiment/DownloadDocument${queryString}`;
    const data = await fetchGet(url, true);
    return data;
}

export const downloadExperimentPDF = async(entityId) =>{
    var queryString = `?entityId=${entityId}`;
    var url = `Experiment/DownloadPdf${queryString}`;
    const data = await fetchGet(url, true);
    return data;
}