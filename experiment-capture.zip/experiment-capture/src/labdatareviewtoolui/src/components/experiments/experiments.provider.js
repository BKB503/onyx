import React, { createContext, useContext, useReducer } from "react";
import { reduceReducers } from "../store/reducer";
import { reducer } from "./store/reducer";
import  './experiment.less';
export const initialState = {
    loading: false,
    error: null,
    successMessage: null,
    experiments: [], 
    experimentsForMyReview:[],
    experimentsSentForReview:[],
    taskComments:[],
    spotfireDoc: null,
    documentsInfo:[],
    blobDocument: null, 
    filename: null, 
    auditLogs:[], 
    auditLogsOverview:[]
}

const ExperimentsContext = createContext(initialState);

export const useExperimentsContext = () => useContext(ExperimentsContext);

export const ExperimentsProvider = ({ children }) => {
    const [state, dispatch] = useReducer(reduceReducers(reducer), initialState);
    return (
        <ExperimentsContext.Provider value={{ state, dispatch }}>
            {children}
        </ExperimentsContext.Provider>);
};

export default ExperimentsContext;