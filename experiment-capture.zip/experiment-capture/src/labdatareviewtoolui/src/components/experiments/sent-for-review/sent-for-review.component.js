import { useEffect, useRef, useState } from "react";
import { useExperimentsContext } from "../experiments.provider";
import { getExperimentsSentForReviewDispatch } from "../store/actions";
import { Breadcrumb, Layout, Button, Input, Space, Table, Spin, Alert, DatePicker } from 'antd';
import {Link} from 'react-router-dom';
import { SearchOutlined } from '@ant-design/icons';
import Highlighter from 'react-highlight-words';
import moment from 'moment';
import { ConstantsHelper, ExperimentType } from './../../constants';
import { LoadingSpinner } from "../../shared/loading.component";

const { Content } = Layout;
export const SentForReviewExperiments = () => {
    const { state, dispatch } = useExperimentsContext();
    const { loading, experimentsSentForReview, error } = state;
    const [searchText, setSearchText] = useState('');
    const [searchedColumn, setSearchedColumn] = useState('');
    const searchInput = useRef(null);
    const [dateRange, setDateRange] = useState({
        startDate: moment().subtract(120, "days"),
        startDateFormat: moment().subtract(120, "days").format(ConstantsHelper.DateFormat),
        endDate: moment(),
        endDateFormat: moment().format(ConstantsHelper.DateFormat)
    });
    const handleSearch = (selectedKeys, confirm, dataIndex) => {
        confirm();
        setSearchText(selectedKeys[0]);
        setSearchedColumn(dataIndex);
    };

    const handleReset = (clearFilters) => {
        clearFilters();
        setSearchText('');
    };

    const getColumnSearchProps = (dataIndex) => ({
        filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
            <div
                style={{
                    padding: 8,
                }}
            >
                <Input
                    ref={searchInput}
                    placeholder={`Search ${dataIndex}`}
                    value={selectedKeys[0]}
                    onChange={(e) => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                    onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
                    style={{
                        marginBottom: 8,
                        display: 'block',
                    }}
                />
                <Space>
                    <Button
                        type="primary"
                        onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
                        icon={<SearchOutlined />}
                        size="small"
                        style={{
                            width: 90,
                        }}
                    >
                        Search
                    </Button>
                    <Button
                        onClick={() => clearFilters && handleReset(clearFilters)}
                        size="small"
                        style={{
                            width: 90,
                        }}
                    >
                        Reset
                    </Button>
                    <Button
                        type="link"
                        size="small"
                        onClick={() => {
                            confirm({
                                closeDropdown: false,
                            });
                            setSearchText(selectedKeys[0]);
                            setSearchedColumn(dataIndex);
                        }}
                    >
                        Filter
                    </Button>
                </Space>
            </div>
        ),
        filterIcon: (filtered) => (
            <SearchOutlined
                style={{
                    color: filtered ? '#1890ff' : undefined,
                }}
            />
        ),
        onFilter: (value, record) =>
            record[dataIndex].toString().toLowerCase().includes(value.toLowerCase()),
        onFilterDropdownVisibleChange: (visible) => {
            if (visible) {
                setTimeout(() => searchInput.current?.select(), 100);
            }
        },
        render: (text) =>
            searchedColumn === dataIndex ? (
                <Highlighter
                    highlightStyle={{
                        backgroundColor: '#ffc069',
                        padding: 0,
                    }}
                    searchWords={[searchText]}
                    autoEscape
                    textToHighlight={text ? text.toString() : ''}
                />
            ) : (
                text
            ),
    });

    const columns = [{
        title: 'Experiment Id',
        dataIndex: 'experimentId',
        key: 'experimentId',
        ...getColumnSearchProps('experimentId'),
        sorter: (a, b) => a.experimentId.localeCompare(b.experimentId)
    }, {
        title: 'Experiment Name',
        dataIndex: 'experimentName',
        key: 'experimentName',
        ...getColumnSearchProps('experimentName'),
        sorter: (a, b) => a.experimentName.localeCompare(b.experimentName)
    }, {
        title: 'Experiment Display Name',
        dataIndex: 'experimentDisplayName',
        key: 'experimentDisplayName',
        ...getColumnSearchProps('experimentDisplayName'),
        sorter: (a, b) => a.experimentDisplayName.localeCompare(b.experimentDisplayName),
    },
    {
        title: 'Workflow Id',
        dataIndex: 'workflowId',
        key: 'workflowId',
        ...getColumnSearchProps('workflowId'),
        sorter: (a, b) => a.workflowId.localeCompare(b.workflowId),
    },
    {
        title: 'Display Id',
        dataIndex: 'displayId',
        key: 'displayId',
        ...getColumnSearchProps('displayId'),
        sorter: (a, b) => a.displayId.localeCompare(b.displayId),
    },
    {
        title: 'Requested Date',
        dataIndex: 'requestedDate',
        key: 'requestedDate',
        render: (requestedDate) => (moment(requestedDate).format(ConstantsHelper.DisplayDateFormat)),
        sorter: (a, b) => moment(a.requestedDate).unix() - moment(b.requestedDate).unix(),
    },
    {
        title: 'Due Date',
        dataIndex: 'dueDate',
        key: 'dueDate',
        render: (dueDate) => (moment(dueDate).format(ConstantsHelper.DisplayDateFormat)),
        sorter: (a, b) => moment(a.dueDate).unix() - moment(b.dueDate).unix(),
    },
    {
        title: 'Action',
        key: 'action',
        render: (_, record) => (
            
            <Space size="middle">
                <Link to={`/experimentdashboard/${ExperimentType.Workflow}/${record.experimentId}/${record.entityId}/${record.workflowId}`}>
                    <span className="nav-text">View</span>
                </Link>
            </Space>
        ),
      }
    ];

    useEffect(() => {
        getExperimentsSentForReviewDispatch(dispatch, dateRange);
    }, [dateRange]);

    const handleChangeCalendar = ([startData, endData]) => {

        if (startData && endData) {
            setDateRange({
                startDate: startData,
                startDateFormat: startData.format(ConstantsHelper.DateFormat),
                endDate: endData,
                endDateFormat: endData.format(ConstantsHelper.DateFormat)
            })
        }
    };

    const handleDateRangeSearch = () => {
        dateRange && getExperimentsSentForReviewDispatch(dispatch, dateRange)
    };
    return (
        <>
            <Layout className="layout-padding">
                <Breadcrumb className="breadcrumb">
                    <Breadcrumb.Item>Experiments</Breadcrumb.Item>
                    <Breadcrumb.Item>Sent For Review</Breadcrumb.Item>
                </Breadcrumb>
                <Content
                    className="site-layout-background">
                    {loading && <LoadingSpinner />}
                    {error && <Alert message={error} type="error" />}
                    <Space align="center" className="space-align">
                        Requested Date: <DatePicker.RangePicker
                            ranges={{
                                Today: [moment(), moment()],
                                'This Week': [moment().startOf('week'), moment().endOf('week')],
                                'Last Week': [moment().startOf('week').subtract(7, 'days'), moment().endOf('week').subtract(7, 'days')],
                                'This Month': [moment().startOf('month'), moment().endOf('month')],
                                'Last Month': [moment().startOf('month').subtract(1, 'month'), moment().endOf('month').subtract(1, 'month')],
                            }}
                            defaultValue={[dateRange.startDate, dateRange.endDate]}
                            allowClear={true}
                            separator="—"
                            format={ConstantsHelper.DisplayDateFormat}
                            onChange={handleChangeCalendar}
                        />
                        <Button
                            key="table-search"
                            type="primary"
                            onClick={() => handleDateRangeSearch()}
                            icon={<SearchOutlined />}
                            size="medium"
                        >
                            Search
                        </Button>
                    </Space>
                    {experimentsSentForReview && (<Table key="1"
                        pagination={{ defaultPageSize: 10, hideOnSinglePage: true }}
                        rowKey="experimentId" columns={columns}
                        dataSource={experimentsSentForReview}>

                    </Table>)}

                </Content>
            </Layout>

        </>
    )
}