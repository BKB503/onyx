
import { ExperimentsProvider } from '../experiments.provider';
import { SentForReviewExperiments } from './sent-for-review.component';

export const SentForReviewContainer = props => {
    return (<ExperimentsProvider>
        <SentForReviewExperiments {...props} />
    </ExperimentsProvider>)
}
