
import { ForMyReviewExperiments } from "./for-my-review.component";
import { ExperimentsProvider } from '../experiments.provider';

export const ForMyReviewContainer = props => {
    return (<ExperimentsProvider>
        <ForMyReviewExperiments {...props} />
    </ExperimentsProvider>)
}
