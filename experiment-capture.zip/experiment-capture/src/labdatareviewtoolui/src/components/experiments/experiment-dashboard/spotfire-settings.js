
import * as types from './../store/action-types';

export const spotFireCustomization = () => {
    let customization = new spotfire.webPlayer.Customization();
    customization.showCustomizableHeader = false;
    customization.showTopHeader = false;
    customization.showClose = false;
    customization.showAnalysisInfo = false;
    customization.showToolBar = false;
    customization.showExportFile = false;
    customization.showUndoRedo = false;
    customization.showDodPanel = false;
    customization.showFilterPanel = false;
    customization.showPageNavigation = true;
    customization.showStatusBar = false;
    return customization;
}

export const spotFireOpenApplication = (serverUrl, analysisPath, containerName, dispatch) => {
    let customization = spotFireCustomization();
    var app = new spotfire.webPlayer.Application(serverUrl,
        customization,
        analysisPath);

    var onError = function (errorCode, description) {
        let errorMessage = `${errorCode} : ${description}`;
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: errorMessage }
        });

    };
    app.onError(onError);
    app.openDocument(containerName);
}

export const spotFireCreateApplication = (spotfireUrl, analysisPath, containerName, dispatch, parameters) => {
    var app;
    var doc;
    //var parameters = '';
    let reloadInstances = true;
    let apiVersion = "11.4";

    spotfire.webPlayer.createApplication(
        spotfireUrl,
        null,
        analysisPath,
        parameters,
        reloadInstances,
        apiVersion,
        onReadyCallback,
        onCreateLoginElement
    );
    dispatch({
        type: types.REJECT_RESPONSE,
        payload: { error: null }
    });

    function onReadyCallback(response, newApp) {
        app = newApp;
        if (response.status === "OK") {
            let customization = spotFireCustomization();
            // The application is ready, meaning that the api is loaded and that 
            // the analysis path is validated for the current session 
            // (anonymous or logged in user)
            doc = app.openDocument(containerName, 0, customization);
            dispatch({
                type: types.SET_SPOTFIRE_DOC,
                payload: { spotfireDoc : doc }
            });

        }
        else {
            // app.onError(onError);
            console.log("err", response);
            dispatch({
                type: types.REJECT_RESPONSE,
                payload: { error: response.message }
            });
        }
    }

    function onCreateLoginElement() {
        // Optionally create and return a div to host the login button
        return null;
    }

    var onError = function (error) {
        // let errorMessage= `${errorCode} : ${description}`;
        console.log("err", error);
        dispatch({
            type: types.REJECT_RESPONSE,
            payload: { error: error }
        });

    };
}