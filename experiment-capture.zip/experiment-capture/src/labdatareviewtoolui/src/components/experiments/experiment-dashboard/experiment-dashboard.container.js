import { ExperimentsProvider } from "../experiments.provider"
import { ExperimentDashboard } from "./experiment-dashboard.component"

export const ExperimentDashboardContainer = (props) => {
    return <ExperimentsProvider>
                <ExperimentDashboard {...props}/>
           </ExperimentsProvider>
}