import { DownOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { Layout, Breadcrumb, Alert, Space, Button, Row, Col, Modal, Drawer, Divider, Form, Input, message, Menu, Dropdown } from 'antd';
import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useExperimentsContext } from '../experiments.provider';
import './experiment-dashboard.less';
import { spotFireCreateApplication } from './spotfire-settings';
import { downloadDocumentAction, downloadExperimentPDFAction, exportExperimentToPdfAction, getDocumentsByEntityIdDispatch, getTaskComments, taskCancelDispatch, taskCompleteDispatch } from '../store/actions';
import { ExperimentType } from '../../constants';
import { LoadingSpinner } from '../../shared/loading.component';
const { Content } = Layout;
const { confirm } = Modal;
export const ExperimentDashboard = (props) => {
    const [form] = Form.useForm();
    const [dashboardState, setDashboardState] = useState({
        visibleCompleteModal: false,
        visibleCancelModal: false,
        visibleRejectModal: false,
        visibleDrawer: false,
        viewDrawerCommentForm: false,
        isAddCommentClicked: false,
        breadCrumbRouteTo: "",
        breadCrumbText: "",
        documents: []
    })
    const { experimentId, taskId, type, entityId } = useParams();
    const serverUrl = "https://spotfire.gsk.com/spotfire/wp/";
    const analysisPath = '/DDS/HB48419/IDBS/TEST CORE TABLES';
    var parameters = `SetPage(pageTitle="Cover Page"); SetFilter(tableName="experiment", columnName="experimentid", values="${experimentId}");`;

    const spotfireContainer = "spotfire-container";
    const { state, dispatch } = useExperimentsContext();
    const { error, taskComments, spotfireDoc, loading, documentsInfo, blobDocument, filename } = state;

    const showRejectConfirmModal = () => {
        setDashboardState({
            ...dashboardState,
            visibleRejectModal: true
        });
    };

    const showCancelConfirmModal = () => {
        setDashboardState({
            ...dashboardState,
            visibleCancelModal: true
        });
    };

    const hideCancelModal = () => {
        setDashboardState({
            ...dashboardState,
            visibleCancelModal: false
        });
    };

    const hideRejectModal = () => {
        setDashboardState({
            ...dashboardState,
            visibleRejectModal: false
        });
    };

    const showApproveModal = () => {
        setDashboardState({
            ...dashboardState,
            visibleCompleteModal: true
        });
    };

    const hideApproveModal = () => {
        setDashboardState({
            ...dashboardState,
            visibleCompleteModal: false
        });
    };

    const showDrawer = () => {
        setDashboardState({
            ...dashboardState,
            visibleDrawer: true
        });
    };

    const closeDrawer = () => {
        setDashboardState({
            ...dashboardState,
            visibleDrawer: false
        });
    };

    const addCommentClick = () => {
        setDashboardState({
            ...dashboardState,
            viewDrawerCommentForm: true,
            isAddCommentClicked: true
        })
    };

    const setBreadCrumb = (routeTo, breadCrumbText) => {
        setDashboardState({
            ...dashboardState,
            breadCrumbRouteTo: routeTo,
            breadCrumbText: breadCrumbText
        });
    }

    const onFinish = (values) => {
        console.log('Success:', values);
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    const hanldeCompleteOK = async () => {
        await taskCompleteDispatch(dispatch, taskId, entityId);
        setDashboardState({
            ...dashboardState,
            visibleCompleteModal: false
        });
        message.success('Task has successfully completed', 10);
    }
    const handleCancelYes = async () => {
        await taskCancelDispatch(dispatch, taskId);
        setDashboardState({
            ...dashboardState,
            visibleCancelModal: false
        });
        message.success('Task has successfully cancelled', 10);
    }

    const handleRejectOK = async () => {
        form
        .validateFields()
        .then(async value => {
            console.log("vv", value);
          setDashboardState({
            ...dashboardState,
            visibleRejectModal: false
        });
        message.success('Task has successfully rejected', 10);
        })
        .catch(err => {
          console.log(err);
        });
       
    }
    const handleDownloadAsDxp = () => {
        spotfireDoc.downloadAsDxp()
    }

    const handleExportToPdf = () => {
        spotfireDoc.exportToPdf()
    }

 

    const handleExportToPowerPoint = () => {
        spotfireDoc.exportToPowerPoint()
    }

    useEffect(() => {
        spotFireCreateApplication(serverUrl, analysisPath, spotfireContainer, dispatch, parameters);
    }, []);

    useEffect(() => {
        taskId && getTaskComments(dispatch, taskId)
    }, [taskId]);

    useEffect(() => {
        entityId && getDocumentsByEntityIdDispatch(dispatch, entityId);
    }, [entityId])

    useEffect(() => {
        if (type && type == ExperimentType.Task) {
            setBreadCrumb("/formyreview", "For My Review");

        } else if (type && type == ExperimentType.Workflow) {
            setBreadCrumb("/sentforreview", "Sent For Review");
        }
        else {
            setBreadCrumb("/myexperiments", "My Experiments");
        }
    }, [type]);

    useEffect(() => {
        if (blobDocument && filename) {
            const url = window.URL.createObjectURL(blobDocument);
            const anchor = document.createElement('a');
            anchor.href = url;
            anchor.download = filename;
            document.body.appendChild(anchor); // we need to append the element to the dom -> otherwise it will not work in firefox
            anchor.click();
            anchor.remove();
        }
    }, [blobDocument, filename]);

    useEffect(() => {
        if (documentsInfo && documentsInfo.length > 0) {
            const menuItems = documentsInfo.map(e => downloadDocumentMenu(e));
            setDashboardState({
                ...dashboardState,
                documents: menuItems
            });
        }
    }, [documentsInfo])

    const downloadDocumentMenu = (documentItem) => {
        return {
            key: documentItem.entityId,
            label: (
                <Button type="link" onClick={() => downloadDocument(documentItem.entityId, documentItem.versionId, documentItem.fileName)}>
                    {documentItem.fileName}
                </Button>
            ),
        }
    }

    const downloadDocument = (entityId, versionId, fileName) => {
        downloadDocumentAction(dispatch, entityId, versionId, fileName);
    }

    const experimentDownloadToPdf =() =>{
        downloadExperimentPDFAction(dispatch, entityId, experimentId)
    }
    const exportMenu = (
        <Menu
            items={[
                {
                    key: '1',
                    label: (
                        <Button type="link" onClick={handleDownloadAsDxp}>
                            Download DXP File
                        </Button>
                    ),
                },
                {
                    key: '2',
                    label: (
                        <Button type="link" onClick={handleExportToPdf}>
                            Export to Pdf
                        </Button>
                    ),
                },
                {
                    key: '3',
                    label: (
                        <Button type="link" onClick={handleExportToPowerPoint}>
                            Export to Power Point
                        </Button>
                    ),
                }
            ]}
        />
    );

    return (
        <>
            <Layout className="layout-padding">
                <Breadcrumb className="breadcrumb">
                    <Breadcrumb.Item><Link to={dashboardState.breadCrumbRouteTo}><span className="nav-text">{dashboardState.breadCrumbText}</span></Link></Breadcrumb.Item>
                    <Breadcrumb.Item>Dashboard</Breadcrumb.Item>
                </Breadcrumb>
                <Content className="site-layout-background">
                    {loading && <LoadingSpinner />}
                    {error && <Alert message={error} type="error" className="space-align" />}
                    {/* {message && <Alert message={message} type="success" className="space-align" closable />} */}
                    <Row>
                        <Col className="col-text-align">

                            <Space className="space-align">
                                {type && type == ExperimentType.Task &&
                                    <>
                                        {taskId && <Button type="primary" onClick={showDrawer}> Comments</Button>}
                                        <Button type="primary" onClick={showApproveModal}> Complete</Button>
                                        <Button type="danger" onClick={showRejectConfirmModal}> Reject</Button>
                                        <Button type="" onClick={showCancelConfirmModal}> Cancel</Button>
                                    </>
                                }

                            </Space>

                        </Col>
                        <Col span={type && type == ExperimentType.Task ? 18 : 24} className="col-text-align"> <Space className="space-align">
                            <Link to={`/auditlogs/${entityId}`}> <Button type='primary'>Audit Timeline</Button></Link>
                            <Button type="primary" onClick={experimentDownloadToPdf}>Download Pdf</Button>
                            <Dropdown.Button key="sportfire" overlay={exportMenu} icon={<DownOutlined />}>
                                Download Dashboard
                            </Dropdown.Button>
                            {dashboardState.documents && dashboardState.documents.length > 0 && <Dropdown.Button key="idbs" overlay={<Menu items={dashboardState.documents} />} icon={<DownOutlined />}>
                                Download Attachments
                            </Dropdown.Button>
                            }</Space></Col>
                    </Row>
                    <Modal
                        key="ReviewType"
                        title="Review Type"
                        visible={dashboardState.visibleCompleteModal}
                        onOk={hanldeCompleteOK}
                        onCancel={hideApproveModal}
                        okText="Complete"
                        cancelText="Cancel"
                    >
                        <p>Some text here</p>

                    </Modal>

                    <Modal
                        key="CancelType"
                        title={`Cancel Task for ${experimentId}`}
                        visible={dashboardState.visibleCancelModal}
                        onOk={handleCancelYes}
                        onCancel={hideCancelModal}
                        okText="Yes"
                        cancelText="No"
                    >
                        <p>Do you wish to cancel task for experiment {experimentId}?</p>

                    </Modal>

                    <Modal
                        key="RejectTask"
                        icon= {<ExclamationCircleOutlined />}
                        title={`Reject Task for ${experimentId}`}
                        visible={dashboardState.visibleRejectModal}
                        onOk={handleRejectOK}
                        onCancel={hideRejectModal}
                        okText="Submit"
                        cancelText="Cancel"

                    >
                        <p>Do you wish to reject task for experiment {experimentId}?</p>
                        <Form layout="vertical"
                               form={form}>
                                <Row>
                                    <Col span={24}>
                                        <Form.Item name="rejectComment" rules={[
                                            {
                                                required: true,
                                                message: 'Please input your comment!',
                                            },
                                        ]}
                                            label="Comment">
                                            <Input.TextArea key="rejectCommentTextArea" rows={4} placeholder="Please add comment"></Input.TextArea>

                                        </Form.Item>
                                    </Col>
                                </Row>
                               
                            </Form>
                    </Modal>

                    <Drawer
                        title="Comments"
                        placement="left"
                        onClose={closeDrawer}
                        visible={dashboardState.visibleDrawer}

                        extra={
                            <Space>
                                <Button size="small" onClick={closeDrawer}>Cancel</Button>
                                <Button size="small" type="primary" onClick={addCommentClick} disabled={dashboardState.isAddCommentClicked}>
                                    Add Comment
                                </Button>
                            </Space>
                        }>
                        {dashboardState.viewDrawerCommentForm &&
                            <Form layout="vertical"
                                onFinish={onFinish}
                                onFinishFailed={onFinishFailed}>
                                <Row>
                                    <Col span={24}>
                                        <Form.Item name="comment" rules={[
                                            {
                                                required: true,
                                                message: 'Please input your comment!',
                                            },
                                        ]}
                                            label="Comment">
                                            <Input.TextArea rows={4} placeholder="Please add comment"></Input.TextArea>

                                        </Form.Item>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span={24} className="col-text-align">
                                        <Button type="primary" htmlType="submit"> Add</Button>
                                    </Col>
                                </Row>
                            </Form>}
                        {taskComments && taskComments.map(c => (<div key={c.header}><Divider orientation="left"> {c.header}</Divider> <p>{c.text}</p></div>))}
                    </Drawer>
                    <div id={spotfireContainer} className="tibco-dashboard"></div>
                </Content>
            </Layout>

        </>
    )
}