
import { MyExperiments } from "./my-experiment.component";
import { ExperimentsProvider } from '../experiments.provider';

export const MyExperimentsContainer = props => {
    return (<ExperimentsProvider>
        <MyExperiments {...props} />
    </ExperimentsProvider>)
}
