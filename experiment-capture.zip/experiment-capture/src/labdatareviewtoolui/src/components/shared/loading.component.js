import './loading.less';

export const LoadingSpinner = () => {
    return (
        <div className="overlay">
            <div className="overlayContent">
                <div className="loadingSpinner">
                    <div className="loader"></div>
                 </div>
            </div>
        </div>)
}