import { getAccessToken } from "../../services/auth/auth.service";


export const fetchGet = async (endpoint, isBlobResponse = false) => {
    var fullEndPoint = `${process.env.REACT_APP_API_BASEURL}/${endpoint}`;
    try {
        const token = getAuthToken();
        const response = await fetch(fullEndPoint, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${token}`,
                Accept: 'application/json',
                'Content-Type': 'application/json'
            }
        });
        if (response.status === 403) {

        } else if (response.status === 401) {

        } else if (response.status === 200) {
            return mapResponse(response, isBlobResponse);
        } else {
            return mapResponse(response, isBlobResponse);
        }
    } catch (error) {
        throw new Error("Failed to call Api");
    }

}

export const fetchPost = async (endpoint, body) => {
    var fullEndPoint = `${process.env.REACT_APP_API_BASEURL}/${endpoint}`;
    const token = getAuthToken();
    const response = await fetch(fullEndPoint, {
        method: 'POST',
        body: JSON.stringify(body),
        headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
            'Content-Type': 'application/json'
        }
    })

    if (response.status === 403) {

    } else if (response.status === 401) {

    } else {
        return {
            status: response.status,
            data: await response.json()
        }
    }
}

export const fetchPatch = async (endpoint, body) => {
    var fullEndPoint = `${process.env.REACT_APP_API_BASEURL}/${endpoint}`;
    const token = getAuthToken();
    const response = await fetch(fullEndPoint, {
        method: 'PATCH',
        body: JSON.stringify(body),
        headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
            'Content-Type': 'application/json'
        }
    })

    if (response.status === 403) {

    } else if (response.status === 401) {

    } else {
        return {
            status: response.status,
            data: await response.json()
        }
    }
}


const mapResponse = async (response, isBlobResponse) => {
    var apiResponse = { status: response.status, data: null };

    if (isBlobResponse) {
        if (response.status === 200) {
            apiResponse.data = await response.blob();
        } else {
            apiResponse.data = await response.json();
        }
    }
    else {
        apiResponse.data = await response.json();
    }

    return apiResponse;
}

const getAuthToken = () => {
    const token = getAccessToken();

    return token;
}