export const getAccessToken = () => {
    var token = localStorage.getItem('ROCP_token');
    if (token) {
        return token.slice(1, -1);
    }
    return null;
}