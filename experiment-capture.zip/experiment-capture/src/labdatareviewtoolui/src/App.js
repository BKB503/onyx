import React from 'react';
// import './App.css';
 import 'antd/dist/antd.css';
import { MainLayout } from '../src/components/layout/main/main-layout.component'
import {  AuthProvider } from "react-oauth2-code-pkce"

const authConfig = {
    clientId: process.env.REACT_APP_PING_CLIENT_ID,
    authorizationEndpoint: process.env.REACT_APP_PING_AUTHORIZATION_ENDPOINT,
    tokenEndpoint: process.env.REACT_APP_PING_TOKEN_ENDPOINT,
    redirectUri: process.env.REACT_APP_PING_REDIRECT_URI,
    scope: 'openid',
    extraAuthParams:{
      
    }
  }

const App = () => {
  return (
    <AuthProvider authConfig={authConfig}>
      <MainLayout>

      </MainLayout>
    </AuthProvider>

    
  )
}


export default App;
