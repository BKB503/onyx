﻿
using GSK.LDRT.Contracts.Abstractions.IdbsSnowflake;
using GSK.LDRT.Domain.SnowflakeEntites;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Snowflake.Data.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSSnowflake
{
    public class SnowflakeContext : ISnowflakeContext
    {
        private readonly string connectionString;
        private readonly ILogger<SnowflakeContext> logger;

        public SnowflakeContext(string connectionString, ILogger<SnowflakeContext> logger)
        {
            this.connectionString = connectionString;
            this.logger = logger;
        }

        public async Task<IEnumerable<RecordVersionEntity>> GetRecordsByOpenStatus(string username, DateTime startDate, DateTime endDate)
        {
            try
            {
               
                username = "dls23167";
                string sqlQuery = BuildSqlQueryToGetOpenRecords();

                using (var conn = new SnowflakeDbConnection())
                {
                    logger.LogInformation("Connecting to snowflake");
                    conn.ConnectionString = this.connectionString;
                    await conn.OpenAsync();
                    var cmd = conn.CreateCommand();
                    cmd = CreateParametersForOpenRecords(cmd, username, startDate, endDate);

                    cmd.CommandText = sqlQuery;

                    var reader = await cmd.ExecuteReaderAsync();

                    var dataTable = new DataTable();
                    dataTable.Load(reader);

                    var recordVersionEntities = new List<RecordVersionEntity>();

                    if (dataTable.Rows.Count > 0)
                    {
                        var serializedMyObjects = JsonConvert.SerializeObject(dataTable);
                        // Here you get the object
                        recordVersionEntities = (List<RecordVersionEntity>)JsonConvert.DeserializeObject(serializedMyObjects, typeof(List<RecordVersionEntity>));
                    }
                    await conn.CloseAsync();
                    logger.LogInformation("Closed connection to snowflake");
                    return recordVersionEntities;

                }
            }
            catch (Exception e)
            {
                logger.LogError(e, e.Message);
                throw e;
            }
           
        }

      

        public async Task<IEnumerable<WorkFlowEntity>> GetWorkFlowsByStatusInProgressAndNew(string username, DateTime startDate, DateTime endDate)
        {
            string sqlQuery = BuildSqlQueryToGetWorkFlowsWithInProgressOrNew();

            using (var conn = new SnowflakeDbConnection())
            {
                conn.ConnectionString = this.connectionString;
                await conn.OpenAsync();

                var cmd = conn.CreateCommand();

                CreateParametersForWorkFlows(cmd, username, startDate, endDate);

                cmd.CommandText = sqlQuery;

                var reader = await cmd.ExecuteReaderAsync();

                var dataTable = new DataTable();
                dataTable.Load(reader);

                var workFlowEntities = new List<WorkFlowEntity>();

                if (dataTable.Rows.Count > 0)
                {
                    var serializedMyObjects = JsonConvert.SerializeObject(dataTable);
                    // Here you get the object
                    workFlowEntities = (List<WorkFlowEntity>)JsonConvert.DeserializeObject(serializedMyObjects, typeof(List<WorkFlowEntity>));
                }
                await conn.CloseAsync();

                return workFlowEntities;

            }
        }

        public async Task<IEnumerable<TaskEntity>> GetAssignedTasksByWorkFlowStatusInProgress(string username, DateTime startDate, DateTime endDate)
        {
            string sqlQuery = BuildSqlQueryToGetAssignedTasksWithInProgress();

            using (var conn = new SnowflakeDbConnection())
            {
                conn.ConnectionString = this.connectionString;
                await conn.OpenAsync();

                var cmd = conn.CreateCommand();

                CreateParametersForGetAssignedTasksByWorkFlowStatus(username, startDate, endDate, cmd);

                cmd.CommandText = sqlQuery;

                var reader = await cmd.ExecuteReaderAsync();

                var dataTable = new DataTable();
                dataTable.Load(reader);

                var taskEntities = new List<TaskEntity>();

                if (dataTable.Rows.Count > 0)
                {
                    var serializedMyObjects = JsonConvert.SerializeObject(dataTable);
                    // Here you get the object
                    taskEntities = (List<TaskEntity>)JsonConvert.DeserializeObject(serializedMyObjects, typeof(List<TaskEntity>));
                }
                await conn.CloseAsync();

                return taskEntities;

            }
        }

        private static DbCommand CreateParametersForOpenRecords(DbCommand cmd, string username, DateTime startDate, DateTime endDate)
        {
            var userParameter = cmd.CreateParameter();
            userParameter.ParameterName = "1";
            userParameter.Value = username;
            userParameter.DbType = DbType.String;
            cmd.Parameters.Add(userParameter);

            var startDateParameter = cmd.CreateParameter();
            startDateParameter.ParameterName = "2";
            startDateParameter.Value = startDate;
            startDateParameter.DbType = DbType.DateTime;
            cmd.Parameters.Add(startDateParameter);

            var endDateParameter = cmd.CreateParameter();
            endDateParameter.ParameterName = "3";
            endDateParameter.Value = endDate;
            endDateParameter.DbType = DbType.DateTime;
            cmd.Parameters.Add(endDateParameter);
            return cmd;
        }

        private static DbCommand CreateParametersForWorkFlows(DbCommand cmd, string username, DateTime startDate, DateTime endDate)
        {
            var userParameter = cmd.CreateParameter();
            userParameter.ParameterName = "1";
            userParameter.Value = username;
            userParameter.DbType = DbType.String;
            cmd.Parameters.Add(userParameter);

            var startDateParameter = cmd.CreateParameter();
            startDateParameter.ParameterName = "2";
            startDateParameter.Value = startDate;
            startDateParameter.DbType = DbType.DateTime;
            cmd.Parameters.Add(startDateParameter);

            var endDateParameter = cmd.CreateParameter();
            endDateParameter.ParameterName = "3";
            endDateParameter.Value = endDate;
            endDateParameter.DbType = DbType.DateTime;
            cmd.Parameters.Add(endDateParameter);
            return cmd;
        }


        private static void CreateParametersForGetAssignedTasksByWorkFlowStatus(string username, DateTime startDate, DateTime endDate, DbCommand cmd)
        {
            var userParameter = cmd.CreateParameter();
            userParameter.ParameterName = "1";
            userParameter.Value = $"%{username}%";
            userParameter.DbType = DbType.String;
            cmd.Parameters.Add(userParameter);

            var startDateParameter = cmd.CreateParameter();
            startDateParameter.ParameterName = "2";
            startDateParameter.Value = startDate;
            startDateParameter.DbType = DbType.DateTime;
            cmd.Parameters.Add(startDateParameter);

            var endDateParameter = cmd.CreateParameter();
            endDateParameter.ParameterName = "3";
            endDateParameter.Value = endDate;
            endDateParameter.DbType = DbType.DateTime;
            cmd.Parameters.Add(endDateParameter);
        }

        private static string BuildSqlQueryToGetOpenRecords()
        {
            return @"SELECT LRV.*, Experiment.ExperimentID FROM Latest_Record_Versions LRV 
                            JOIN
                                (SELECT LRVA.Record_ID, LRVA.ATTRIBUTE_VALUE as ExperimentID
                                FROM LATEST_RECORD_VERSIONS_ATTRIBUTES as LRVA
                                Where  LRVA.ATTRIBUTE_Name ='Experiment ID'
                                ) Experiment
                            ON LRV.Record_ID = Experiment.Record_ID
     
                        WHERE LRV.Record_Created_BY = (?)
                        AND LRV.Record_Created_TimeStamp >= (?)
                        AND LRV.Record_Created_TimeStamp <= (?)
                        AND LRV.Record_Status='Open' 
                        AND LRV.Record_TYPE ='EXPERIMENT' 
                    ORDER BY LRV.Record_Created_TimeStamp desc";
        }

        private static string BuildSqlQueryToGetWorkFlowsWithInProgressOrNew()
        {
            return @"SELECT WF.*, Experiment.ExperimentID FROM Latest_Record_Versions LRV 
                JOIN
                   (SELECT LRVA.Record_ID, LRVA.ATTRIBUTE_VALUE as ExperimentID
                    FROM LATEST_RECORD_VERSIONS_ATTRIBUTES as LRVA
                    Where  LRVA.ATTRIBUTE_Name ='Experiment ID'
                   ) Experiment
        
             ON LRV.Record_ID = Experiment.Record_ID
             JOIN WorkFlows as WF ON WF.Entity_ID = LRV.RECORD_ID
     
                 WHERE REQUESTOR_NAME = (?) 
               AND WF.REQUESTED_DATE >= (?)
               AND WF.REQUESTED_DATE <= (?)
               AND WORKFLOW_STATUS IN('New','New - Overdue','In-Progress','In-Progress - Overdue')
             ORDER BY WF.REQUESTED_DATE DESC";
        }

        private static string BuildSqlQueryToGetAssignedTasksWithInProgress()
        {
            return @"SELECT T.*, WF.REQUESTOR_NAME, WF.PRIORITY as WORKFLOW_PRIORITY,
                            WF.WORKFLOW_STATUS, LRV.RECORD_NAME ,Experiment.ExperimentID 
                FROM Latest_Record_Versions LRV 
                    JOIN
                       (SELECT LRVA.Record_ID, LRVA.ATTRIBUTE_VALUE as ExperimentID
                        FROM LATEST_RECORD_VERSIONS_ATTRIBUTES as LRVA
                        WHERE  LRVA.ATTRIBUTE_Name ='Experiment ID'
                       ) Experiment
        
                 ON LRV.Record_ID = Experiment.Record_ID
                 JOIN WorkFlows as WF ON WF.Entity_ID = LRV.RECORD_ID
                 JOIN Tasks as T ON T.ENTITY_ID = LRV.RECORD_ID
     
             WHERE T.ASSIGNED_USERS LIKE (?)
                AND T.REQUESTED_DATE >= (?)
                AND T.REQUESTED_DATE <= (?)
                AND WF.WORKFLOW_STATUS IN('In-Progress','In-Progress - Overdue')";
        }
    }
}
