﻿using GSK.LDRT.Contracts.Abstractions.IdbsSnowflake;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace GSK.LDRT.Infrastructure.IDBSSnowflake
{
    public static class ConfigureServices
    {
        public static void AddInfrastructureSnowflake(this IServiceCollection services)
        {
            services.AddTransient<ISnowflakeContext>((ctx =>
            {
                var configuration = ctx.GetService<IConfiguration>();
                var logger = ctx.GetService<ILogger<SnowflakeContext>>();
                var connectionString = configuration["ConnectionStrings:Snowflake"];
                return new SnowflakeContext(connectionString, logger);
            }));
        }
    }
}
