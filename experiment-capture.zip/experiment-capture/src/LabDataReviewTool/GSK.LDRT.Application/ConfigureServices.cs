﻿using AutoMapper;
using GSK.LDRT.Application.Features;
using GSK.LDRT.Application.Features.Experiments;
using GSK.LDRT.Application.Features.Tasks;
using GSK.LDRT.Application.Mappings;
using GSK.LDRT.Contracts.Abstractions.Application;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace GSK.LDRT.Application
{
    public static class ConfigureServices
    {
        public static void AddApplicationServices(this IServiceCollection services)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new AutoMapperProfile());
            });

            var mapper = config.CreateMapper();
            services.AddSingleton(mapper);

            services.AddTransient<IExperimentService, ExperimentService>();
            services.AddTransient<ITaskService, TaskService>();
            services.AddTransient<IUserService, UserService>();
            services.AddTransient<IRecordService, RecordService>();
            services.AddTransient<IAuditService, AuditService>();

        }
    }
}
