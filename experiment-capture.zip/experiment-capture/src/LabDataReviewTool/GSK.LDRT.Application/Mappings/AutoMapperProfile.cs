﻿using AutoMapper;
using GSK.LDRT.Contracts.Models.Audit;
using GSK.LDRT.Contracts.Models.Experiment;
using GSK.LDRT.Domain.IDBSEntities.Audit;
using GSK.LDRT.Domain.IDBSEntities.Entity;
using GSK.LDRT.Domain.IDBSEntities.Task;
using GSK.LDRT.Domain.IDBSEntities.Workflow;
using GSK.LDRT.Domain.SnowflakeEntites;
using System;
using WorkFlowEntity = GSK.LDRT.Domain.SnowflakeEntites.WorkFlowEntity;

namespace GSK.LDRT.Application.Mappings
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Entity, EntityResponse>();
            CreateMap<Entitycore, EntitycoreResponse>();
            // CreateMap<Attribute, AttributeResponse>();
            // CreateMap<Attributes, AttributesResponse>();
            // CreateMap<Values, ValuesResponse>();
            //CreateMap<Displayvalues, DisplayvaluesResponse>();
            CreateMap<RecordVersionEntity, ExperimentResponse>()
                .ForMember(dest => dest.ExperimentName, input => input.MapFrom(i => i.Name))
                .ForMember(dest => dest.EntityId, input => input.MapFrom(i => i.Id))
                .ForMember(dest => dest.ExperimentDisplayName, input => input.MapFrom(i => i.Name))
                .ForMember(dest => dest.ExperimentStatus, input => input.MapFrom(i => i.Status));


            CreateMap<WorkFlowEntity, ExperimentWorkflowResponse>()
                .ForMember(dest => dest.ExperimentName, input => input.MapFrom(i => i.EntityName))
                .ForMember(dest => dest.ExperimentDisplayName, input => input.MapFrom(i => i.EntityName));

            CreateMap<TaskEntity, ExperimentTaskResponse>()
               .ForMember(dest => dest.WorkflowRequester, input => input.MapFrom(i => i.RequestorName))
               .ForMember(dest => dest.ExperimentName, input => input.MapFrom(i => i.EntityName))
               .ForMember(dest => dest.ExperimentDisplayName, input => input.MapFrom(i => i.EntityName));

            CreateMap<ExperimentTaskEntity, ExperimentTaskResponse>();
            CreateMap<ExperimentWorkflowEntity, ExperimentWorkflowResponse>();
            CreateMap<ExperimentDocumentEntity, ExperimentDocumentResponse>();
            CreateMap<DocumentEntity, DocumentResponse>();
            CreateMap<AuditEntity, AuditResponse>()
                .ForMember( dest =>  dest.ZoneStamp, input => input.MapFrom( i => ConvertEpochToDate(i.ZoneStamp)));
               
        }

        private static DateTime ConvertEpochToDate(double epoch)
        {
            return DateTime.UnixEpoch.AddMilliseconds(epoch);
        }

    }
}
