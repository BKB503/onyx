﻿
using GSK.LDRT.Application.Features.Tasks.Models;
using GSK.LDRT.Contracts.Abstractions.Application;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Abstractions.StorageApi;
using GSK.LDRT.Contracts.Models;
using GSK.LDRT.Domain.StorageApi.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSK.LDRT.Application.Features.Tasks
{
    public class TaskService : ITaskService
    {
        private readonly ITaskApiService taskApiService;
        private readonly IRecordApiService recordApiService;
        private readonly IExperimentHtmlService experimentHtmlService;
        private readonly IPdfGenerator pdfGenerator;
        private readonly IStorageApiClient storageApiClient;
        public TaskService(ITaskApiService taskApiService, IRecordApiService recordApiService, IExperimentHtmlService experimentHtmlService, 
            IPdfGenerator pdfGenerator, IStorageApiClient storageApiClient)
        {
            this.taskApiService = taskApiService;
            this.experimentHtmlService = experimentHtmlService;
            this.recordApiService = recordApiService;
            this.pdfGenerator = pdfGenerator;
            this.storageApiClient = storageApiClient;
        }

        public async Task<IEnumerable<TaskCommentResponse>> GetTaskComments(string taskId)
        {

            var taskCommentEntities= await taskApiService.GetTaskComments(taskId);
            var commentResponses = new List<TaskCommentResponse>();

            if (taskCommentEntities != null && taskCommentEntities.Any())
            {
                foreach (var commentEntity in taskCommentEntities)
                {
                    var comment = new TaskCommentResponse
                    {
                        Header = commentEntity.Header,
                        Text = commentEntity.Text
                    };
                    commentResponses.Add(comment);
                }
            }
            return commentResponses;

        }

        public  async Task<Response> CancelTask(string taskId)
        {
            var message = await taskApiService.CancelTask(taskId);
            return new Response { Message = message };
        }

        public async Task<Response> Complete(string taskId, string entityId)
        {
            var recordSummaryEntity = await recordApiService.GetRecordSummaryByEntityId(entityId);
            var htmlNodes = await experimentHtmlService.GenerateHtmlData(recordSummaryEntity);
            var stream = pdfGenerator.Generate(htmlNodes);
            var fileName = $"{recordSummaryEntity.RecordEntity.Entity.EntityCore.EntityName}.pdf";
            var folderName = $"LabDataReviewTool/{recordSummaryEntity.ExperimentId}/Versions/{recordSummaryEntity.RecordEntity.Entity.VersionInfo.VersionNumber}";
           
            var  metadataItems = new List<MetadataItem>();
            metadataItems.Add(new MetadataItem { Key = "ExperimentID", Value = recordSummaryEntity.ExperimentId, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "Title", Value = recordSummaryEntity.Title, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "ExperimentStatus", Value = recordSummaryEntity.ExperimentStatus, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "CreatedOn", Value = recordSummaryEntity.CreatedOn, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "AllianceName", Value = recordSummaryEntity.AllianceName, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "VersionNumber", Value = recordSummaryEntity.RecordEntity.Entity.VersionInfo.VersionNumber.ToString(), IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "VersionType", Value = recordSummaryEntity.RecordEntity.Entity.VersionInfo.VersionState, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "User", Value = recordSummaryEntity.RecordEntity.Entity.VersionInfo.UserFullName, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "UserName", Value = recordSummaryEntity.RecordEntity.Entity.VersionInfo.UserName, IsIndexed = true });
            metadataItems.Add(new MetadataItem { Key = "CreatedBy", Value = recordSummaryEntity.RecordEntity.Entity.VersionInfo.UserName, IsIndexed = true });
            var request = new FileUploadRequest
            {
                MetadataCollections = new MetadataCollections { Items = new List<MetadataItem>() },
                FileStream = stream,
                FileName = fileName,
                FolderName = folderName
            };
            request.MetadataCollections.Items = metadataItems;
            var uploadFileResult = await storageApiClient.UploadFileObjectAsync(request);

            return new Response { Message = "File uploaded to StorageApi" };
        }
    }
}
