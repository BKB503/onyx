﻿using AutoMapper;
using GSK.LDRT.Contracts.Abstractions.Application;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Abstractions.IdbsSnowflake;
using GSK.LDRT.Contracts.Models.Experiment;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GSK.LDRT.Application.Features.Experiments
{
    public class ExperimentService : IExperimentService
    {
        private readonly ITaskApiService taskApiService;
        private readonly IWorkflowApiService workflowApiService;
        private readonly IEntityApiService entityApiService;
        private readonly ISnowflakeContext snowflakeContext;
        private readonly IMapper mapper;
        private readonly IUserService userService;
        public ExperimentService(ITaskApiService taskApiService, IWorkflowApiService workflowApiService, IEntityApiService entityApiService,
            ISnowflakeContext snowflakeContext, IMapper mapper, IUserService userService)
        {
            this.taskApiService = taskApiService;
            this.workflowApiService = workflowApiService;
            this.entityApiService = entityApiService;
            this.snowflakeContext = snowflakeContext;
            this.mapper = mapper;
            this.userService = userService;
        }

        public async Task<IEnumerable<ExperimentTaskResponse>> GetExperimentsForUserReview(DateTime startDate, DateTime endDate)
        {
            var mudId = GetMudId();
            // var taskEntities = await snowflakeContext.GetAssignedTasksByWorkFlowStatusInProgress(username, startDate, endDate);
            //var experimentTaskResponses = mapper.Map<IEnumerable<ExperimentTaskResponse>>(taskEntities);
            
            var experimentTaskEntities = await taskApiService.GetUserAssignedTasks(mudId, startDate, endDate);
            var experimentTaskResponses = mapper.Map<IEnumerable<ExperimentTaskResponse>>(experimentTaskEntities);
            return experimentTaskResponses;
        }

        public async Task<IEnumerable<ExperimentTaskResponse>> GetExperimentsForUserReviewWithHttpClient(DateTime startDate, DateTime endDate)
        {
            var mudId = "bb467396";// GetMudId();
            // var taskEntities = await snowflakeContext.GetAssignedTasksByWorkFlowStatusInProgress(username, startDate, endDate);
            //var experimentTaskResponses = mapper.Map<IEnumerable<ExperimentTaskResponse>>(taskEntities);

            var experimentTaskEntities = await taskApiService.GetUserAssignedTasksWithHttpClient(mudId, startDate, endDate);
            var experimentTaskResponses = mapper.Map<IEnumerable<ExperimentTaskResponse>>(experimentTaskEntities);
            return experimentTaskResponses;
        }



        public async Task<IEnumerable<ExperimentWorkflowResponse>> GetExperimentsSentForReview(DateTime startDate, DateTime endDate)
        {
            var mudId = GetMudId();
            //var workflowEntites = await snowflakeContext.GetWorkFlowsByStatusInProgressAndNew(username, startDate, endDate);
            //var experimentWorkflowResponses = mapper.Map<IEnumerable<ExperimentWorkflowResponse>>(workflowEntites);
            var experimentWorkflowEntites = await workflowApiService.GetUserAssignedWorkFlowsSentForReview(mudId, startDate, endDate);
            var experimentTaskResponses = mapper.Map<IEnumerable<ExperimentWorkflowResponse>>(experimentWorkflowEntites);

            return experimentTaskResponses;
        }

        public async Task<IEnumerable<ExperimentResponse>> GetExperimentsByOpenStatus(DateTime startDate, DateTime endDate)
        {
            var mudId = GetMudId();
            var recordsEntities = await snowflakeContext.GetRecordsByOpenStatus(mudId, startDate, endDate);
            var experimentResponses = mapper.Map<IEnumerable<ExperimentResponse>>(recordsEntities);
            return experimentResponses;
        }

        public async Task<IEnumerable<ExperimentDocumentResponse>> GetDocumentsByEntityId(string entityId)
        {
            var documentEntities = await entityApiService.GetDocumentEntitiesByEntityId(entityId);
            var experimentDocumentResponses = mapper.Map<IEnumerable<ExperimentDocumentResponse>>(documentEntities);
            return experimentDocumentResponses;
        }

        public async Task<DocumentResponse> DownloadDocument(string entityId, string entityVersionId)
        {
            var documentEntity = await entityApiService.DownloadDocument(entityId, entityVersionId);
            var documentResponse = mapper.Map<DocumentResponse>(documentEntity);
            return documentResponse;
        }



        private string GetMudId()
        {
            return userService.GetMudId();
        }

  
    }
}
