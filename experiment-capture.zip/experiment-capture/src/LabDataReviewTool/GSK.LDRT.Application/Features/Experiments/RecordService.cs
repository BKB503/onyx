﻿using GSK.LDRT.Contracts.Abstractions.Application;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Abstractions.StorageApi;
using GSK.LDRT.Domain.IDBSEntities.Record;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GSK.LDRT.Application.Features.Experiments
{
    public class RecordService : IRecordService
    {
        private readonly IRecordApiService recordApiService;
        private readonly IExperimentHtmlService experimentHtmlService;
        private readonly IPdfGenerator pdfGenerator;
        private readonly IStorageApiClient storageApiClient;
        public RecordService(IRecordApiService recordApiService, IExperimentHtmlService experimentHtmlService, IPdfGenerator pdfGenerator, IStorageApiClient storageApiClient)
        {
            this.experimentHtmlService = experimentHtmlService;
            this.recordApiService = recordApiService;
            this.pdfGenerator = pdfGenerator;
            this.storageApiClient = storageApiClient;
        }

        public async Task<Stream> DownloadPdf(string entityId)
        {
            var recordSummaryEntity = await recordApiService.GetRecordSummaryByEntityId(entityId);
            var folder = $"LabDataReviewTool/{recordSummaryEntity.ExperimentId}/Versions/{recordSummaryEntity.RecordEntity.Entity.VersionInfo.VersionNumber}";

            var containerContents = await storageApiClient.GetContainerContentsAsync(folder, null);
            if (containerContents != null && containerContents.Files.Any())
            {
                var fileInfo = containerContents.Files.FirstOrDefault();

                if (fileInfo != null && !string.IsNullOrEmpty(fileInfo.FileName) && !string.IsNullOrEmpty(fileInfo.FileGuid))
                {
                    var stream = await storageApiClient.DownloadFileAsync(fileInfo.FileName, folder, fileInfo.FileGuid);
                    return stream;
                }
                else
                {
                    return await GeneratePdf(recordSummaryEntity);
                }
            }
            else
            {
                return await GeneratePdf(recordSummaryEntity);
            }

        }

        private async Task<Stream> GeneratePdf(RecordSummaryEntity recordSummaryEntity)
        {
            var htmlNodes = await experimentHtmlService.GenerateHtmlData(recordSummaryEntity);
            var stream = pdfGenerator.Generate(htmlNodes);
            return stream;
        }

    }
}
