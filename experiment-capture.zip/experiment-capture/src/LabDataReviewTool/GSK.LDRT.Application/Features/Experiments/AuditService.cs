﻿using AutoMapper;
using GSK.LDRT.Contracts.Abstractions.Application;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Models.Audit;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSK.LDRT.Application.Features.Experiments
{
    public class AuditService : IAuditService
    {
        private readonly IAuditApiService auditApiService;
        private readonly IMapper mapper;

        public AuditService(IAuditApiService auditApiService, IMapper mapper)
        {
            this.auditApiService = auditApiService;
            this.mapper = mapper;
        }
        public async Task<List<AuditResponse>> GetLogs(string entityId)
        {
            var auditEntities = await auditApiService.GetLogs(entityId);
            var auditResponses= mapper.Map<IEnumerable<AuditResponse>>(auditEntities).ToList();
            return auditResponses;
        }
    }
}
