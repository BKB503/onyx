﻿using GSK.LDRT.Contracts.Abstractions.Application;
using Microsoft.AspNetCore.Http;
using System.Linq;

namespace GSK.LDRT.Application.Features
{
    public class UserService : IUserService
    {
        private readonly IHttpContextAccessor httpContextAccessor;
        private const string immutable_id = "immutable_id";

        public UserService(IHttpContextAccessor httpContextAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }
        public string GetMudId()
        {
            var mudId = httpContextAccessor.HttpContext.User?.Claims?.FirstOrDefault(x => x.Type == immutable_id).Value;
            return mudId;
        }
    }
}
