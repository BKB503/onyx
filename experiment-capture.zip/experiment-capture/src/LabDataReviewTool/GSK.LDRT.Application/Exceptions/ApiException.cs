﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Text;

namespace GSK.LDRT.Application.Exceptions
{
    public class ApiException : Exception
    {
        public HttpStatusCode StatusCode { get; set; }
        public ApiException() : base() { }

        public ApiException(string message) : base(message) { }

        public ApiException(string message, HttpStatusCode httpStatusCode) : base(message)
        {
            this.StatusCode = httpStatusCode;
        }

        public ApiException(string message, params object[] args)
            : base(String.Format(CultureInfo.CurrentCulture, message, args))
        {
        }
    }
}
