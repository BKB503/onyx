﻿using GSK.LDRT.Contracts.Abstractions.Common;
using System.IO.Abstractions;


namespace GSK.LDRT.Infrastructure.IDBSApi.Common
{
    public class FileReader : IFileReader
    {
        private readonly IFile file;
        public FileReader(IFile file)
        {
            this.file = file;
        }

        public string ReadAllText(string filePath)
        {
            return !file.Exists(filePath) ? string.Empty : file.ReadAllText(filePath);
        }
    }
}
