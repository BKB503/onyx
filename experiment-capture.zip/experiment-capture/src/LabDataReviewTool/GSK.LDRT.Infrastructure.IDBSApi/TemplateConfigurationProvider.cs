﻿
using GSK.LDRT.Contracts.Abstractions.IdbsApi;

namespace GSK.LDRT.Infrastructure.IDBSApi
{
    public class TemplateConfigurationProvider : ITemplateConfigurationProvider
    {
        public TemplateConfigurationProvider(string appDirectoryPath)
        {
            AppDirectoryPath = appDirectoryPath;
        }

        public string AppDirectoryPath { get; }

        public string GetTasksByWorkflowStatusInProgressFilePath => $"{AppDirectoryPath}/IdbsJsonTemplates/GetTasksByWorkflowStatusInProgress.json";
        public string GetWorkflowsByWorkflowStatusInProgressAndNewFilePath => $"{AppDirectoryPath}/IdbsJsonTemplates/GetWorkflowsByWorkflowStatusInProgressAndNew.json";
        public string GetExperimentsByOpenStatusFilePath => $"{AppDirectoryPath}/IdbsJsonTemplates/GetExperimentsByOpenStatus.json";
        public string GetSpreadSheetTableDataRequest => $"{AppDirectoryPath}/IdbsJsonTemplates/SpreadSheetTableDataRequest.json";
        public string GetSpreadSheetTableListRequest => $"{AppDirectoryPath}/IdbsJsonTemplates/SpreadSheetTableListRequest.json";
        public string GskLogo => $"{AppDirectoryPath}/IdbsJsonTemplates";

        public string GetSpreadSheetImageDataRequest => $"{AppDirectoryPath}/IdbsJsonTemplates/SpreadSheetImageDataRequest.json";
    }
}
