﻿using GSK.LDRT.Application.Exceptions;
using GSK.LDRT.Infrastructure.IDBSApi.Abstraction;
using GSK.LDRT.Infrastructure.IDBSApi.Helper;
using Newtonsoft.Json;
using RestSharp;
using System.Net;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSApi
{
    public class OAuthAuthzTokenProvider : IOAuthAuthzTokenProvider
    {
        private readonly string ClientId = "AUDIT_SERVICE";
        private readonly string[] Scopes = new string[] { "EWB_ALL_SAPI" };
        private readonly RestClient restClient;
        public OAuthAuthzTokenProvider(RestClient restClient)
        {
            this.restClient = restClient;
        }

        public async Task<Cookie> GetAccessToken()
        {
            var code = await GetAuthzCode();

            var authzUrl = "/audit/auth";

            var request = new RestRequest(authzUrl, Method.Post).AddJsonBody(new { oauthCode = code});
            request.AddHeader("Content-Type", "application/json");
            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API AuthZ";
                throw new ApiException(message, response.StatusCode);
            }

            var accessToken = response.Cookies["ewb_token"];

            return accessToken;
           
        }

        private async Task<string> GetAuthzCode()
        {
            var authzUrl = "ewb/services/1.0/oauth/authz/code";

            var request = new RestRequest(authzUrl, Method.Post).AddJsonBody(new { clientId = ClientId, scopes = Scopes });
            request.AddHeader("Content-Type", "application/json");
            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API AuthZ";
                throw new ApiException(message, response.StatusCode);
            }

            var authz = JsonConvert.DeserializeObject<Authz>(response.Content);
            return authz.AuthzCode;

        }
    }
}
