﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using IronPdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace GSK.LDRT.Infrastructure.IDBSApi
{
    public class PdfGenerator : IPdfGenerator
    {
        private readonly ITemplateConfigurationProvider templateConfigurationProvider;
        public PdfGenerator(ITemplateConfigurationProvider templateConfigurationProvider)
        {
            this.templateConfigurationProvider = templateConfigurationProvider;
        }
        public Stream Generate(List<string> htmlNodes)
        {
            var logoPath = templateConfigurationProvider.GskLogo;
            var renderer = new IronPdf.ChromePdfRenderer();
            renderer.RenderingOptions.TextHeader.DrawDividerLine = true;

            renderer.RenderingOptions.HtmlHeader = new HtmlHeaderFooter()
            {
                MaxHeight = 20, //millimeters

                HtmlFragment = "<br/><center><img src='GskLogo.gif' height='40'></center> <br/>",
                BaseUrl = new Uri($"{logoPath}").AbsoluteUri
            };
            renderer.RenderingOptions.TextFooter.DrawDividerLine = true;
            renderer.RenderingOptions.TextFooter.Font = IronPdf.Font.FontTypes.Arial;
            renderer.RenderingOptions.TextFooter.FontSize = 10;
            renderer.RenderingOptions.TextFooter.LeftText = "{date} {time}";
            renderer.RenderingOptions.TextFooter.RightText = "{page} of {total-pages}";

            var concatHtmlNodes = "";
            foreach (var htmlNode in htmlNodes)
            {
                concatHtmlNodes += htmlNode;
            }
            var htmlData = $"<html><head>{Styles()}  </head><body>{concatHtmlNodes}</body></html>";
            renderer.RenderingOptions.FitToPaperMode = IronPdf.Engines.Chrome.FitToPaperModes.AutomaticFit;
            using var pdf2 = renderer.RenderHtmlAsPdf(htmlData);
            return pdf2.Stream;
        }

        private static string Styles()
        {
            return @"<style>
                        * {
                          box-sizing: border-box;
                        }

                        .row {
                          display: flex;
                        }

                        /* Create two equal columns that sits next to each other */
                        .column {
                          flex: 50%;
                          padding: 10px;
                          height: 300px; /* Should be removed. Only for demonstration */
                        }

                        .caption {
	                        background-color: #f26633;
                            color:#fdeae3;
	                        padding: 0.5em;
                        }
                        /* all for prettiness */

                        * {
	                        font-family: Arial;
                        }
                        .h1,
                        .h2 {
	                        color: #ffffff;
	                        background-color: #ff9900;
                        }
                        .table {
	                        min-width: 90%;
	                        border-collapse: collapse;
                            margin-top:35px;
                            margin-bottom:35px;
                        }

                        .table,
                        .th,
                        .td {
	                        border: 1px solid black;
                            text-align:center;
                        }

                        .th,
                        .td {
	                        padding: 10px;
                        } 

                        .td-override{
                            border: 1px solid black;
                            text-align:center;
                            color: red;
                           }

                        .th-border{
                                border: 1px solid black;
                                border-top: dashed;
                            }

                        .th, .th-border{
		                background-color: #404040;
                        color: #fdeae3;
                        border-color:#fdeae3;
		                }   

                        .page-break{
                            page-break-after: always;
                            }

                         .signature{
                            border-style: groove;
                            font-family: sans-serif;
                            font-size: 13px;
                            padding:14px;
                        }
                        .table-wrapper{
                        border-style: groove;
                        padding:14px;
                        margin-bottom:20px;
                        }
                        .header-center{
                            display: flex;
                            justify-content: center;
                        }
                     </style>";
        }

    }
}
