﻿
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class OtherEquipmentDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel SpreadSheetPdfTableModel)
        {
           
            var otherEquipmentDetails = JsonConvert.DeserializeObject<List<OtherEquipmentDetails>>(SpreadSheetPdfTableModel.TableData.ToString()).ToList();

            return CreateHtml(otherEquipmentDetails, SpreadSheetPdfTableModel.TableName) ;
        }

        
        private string CreateHtml(List<OtherEquipmentDetails> otherEquipmentDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr> </thead>";

            foreach (var otherEquipmentDetail in otherEquipmentDetails)
            {
                var calibrationDueDate = "";
                if (otherEquipmentDetail.CalibrationDueDate != null && otherEquipmentDetail.CalibrationDueDate.Value != null && otherEquipmentDetail.CalibrationDueDate.Value.HasValue)
                {
                    calibrationDueDate = otherEquipmentDetail.CalibrationDueDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{otherEquipmentDetail.OtherEquipmentIndex?.Value} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.EquipmentID?.Value} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.RecordName?.Value} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.ItemName?.Value} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.SerialNumber?.Value} </td>";
                tableCells += $"<td class='td'>{calibrationDueDate} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.EquipmentType?.Value} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.EquipmentStatus?.Value} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.EquipmentLocation?.Value} </td>";
                tableCells += $"<td class='td'>{otherEquipmentDetail.EquipmentLink?.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Other Equipment Index",
                "Equipment ID",
                "Record Name",
                "Item Name",
                "Serial Number",
                "Calibration Due Date",
                "Equipment Type",
                "Equipment Status",
                "Equipment Location",
                "Equipment Link"
            };
        }
  
       
    }
}
