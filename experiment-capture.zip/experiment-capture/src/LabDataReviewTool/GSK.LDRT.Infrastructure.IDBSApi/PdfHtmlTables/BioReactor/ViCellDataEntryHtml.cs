﻿
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ViCellDataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var viCellDataEntrys = JsonConvert.DeserializeObject<List<ViCellDataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMViCellDataEntrys = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_ViCell Data Entry");
            var uoMViCellDataEntrysData = (List<UoMViCellDataEntry>)JsonConvert.DeserializeObject<List<UoMViCellDataEntry>>(uoMViCellDataEntrys.Data.ToString());
            var filteredData = new List<ViCellDataEntry>();

            filteredData = viCellDataEntrys.Where(x => !string.IsNullOrEmpty(x.SampleName.Value)).ToList();
           
            return $"{BuildHtml(filteredData, uoMViCellDataEntrysData, spreadSheetPdfTableModel.TableName)}";
        }

      
        private string BuildHtml(List<ViCellDataEntry> viCellDataEntrys, List<UoMViCellDataEntry> uoMViCellDataEntrys, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMViCellDataEntrys))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedVicellAliquotIndexs = viCellDataEntrys.GroupBy(x => x.VicellAliquotIndex.Value, (key, group) => new { VicellAliquotIndex = key, Items = group.ToList() });
            foreach (var groupedVicellAliquotIndex in groupedVicellAliquotIndexs)
            {
                if (groupedVicellAliquotIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedVicellAliquotIndex.Items.Count}'>{groupedVicellAliquotIndex.VicellAliquotIndex} </td>";
                    var groupedInputMethods = groupedVicellAliquotIndex.Items.GroupBy(x => x.InputMethod.Value, (key, group) => new { InputMethod = key, InputMethodValues = group.ToList() });
                    foreach (var inputMethod in groupedInputMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{inputMethod.InputMethodValues.Count}'>{inputMethod.InputMethod} </td>";
                        foreach (var item in inputMethod.InputMethodValues)
                        {   
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.InstrumentSampleIdOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementEquipment?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.TotalCellConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TotalViableCellConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CellCultureViability?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.AverageCellDiameter?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Ignore?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Sample Name",
                "DCA ID",
                "Instrument Sample ID Override",
                "Measurement Equipment",
                "Measurement Date",
                "Total Cell Concentration",
                "Total Viable Cell Concentration",
                "Cell Culture Viability",
                "Average Cell Diameter",
                "Ignore?"

            };
        }

        private List<string> SubHeaders(List<UoMViCellDataEntry> uoMViCellDataEntrys)
        {
            var totalCellConcentration = uoMViCellDataEntrys.FirstOrDefault(x => x.Column.Value == "Total Cell Concentration").UoM.Value;
            var totalViableCellConcentration = uoMViCellDataEntrys.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration").UoM.Value;
            var cellCultureViability = uoMViCellDataEntrys.FirstOrDefault(x => x.Column.Value == "Cell Culture Viability").UoM.Value;
            var averageCellDiameter = uoMViCellDataEntrys.FirstOrDefault(x => x.Column.Value == "Average Cell Diameter").UoM.Value;
            return new List<string>
            {
               "",
                "",
                "",
                "",
                "",
                "",
                "e",
                totalCellConcentration,
                totalViableCellConcentration,
                cellCultureViability,
                averageCellDiameter,
                "Ignore?"
            };
        }



    }
}
