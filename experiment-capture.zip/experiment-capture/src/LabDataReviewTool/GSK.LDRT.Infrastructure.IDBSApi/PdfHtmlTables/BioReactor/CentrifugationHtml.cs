﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class CentrifugationHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var centrifugations = JsonConvert.DeserializeObject<List<Centrifugation>>(spreadSheetPdfTableModel.TableData);
            var uoMCentrifugations = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Centrifugation");
            var uoMCentrifugationsData = (List<UoMCentrifugation>)JsonConvert.DeserializeObject<List<UoMCentrifugation>>(uoMCentrifugations.Data.ToString());
            var filteredData = new List<Centrifugation>();

            filteredData = centrifugations.Where(x => !string.IsNullOrEmpty(x.CentrifugeId.Value)).ToList();

            return $"{BuildHtml(filteredData, uoMCentrifugationsData, spreadSheetPdfTableModel.TableName)}";
        }

       
        private string BuildHtml(List<Centrifugation> centrifugations, List<UoMCentrifugation> uoMCentrifugationsData, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMCentrifugationsData))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var centrifugation in centrifugations)
            {
                var tableCells = "";
               
                tableCells += $"<td class='td'>{centrifugation.CentrifugationSettings?.Value} </td>";
                tableCells += $"<td class='td'>{centrifugation.Centrifuge?.Value} </td>";
                tableCells += $"<td class='td'>{centrifugation.CentrifugeId?.Value} </td>";
                tableCells += $"<td class='td'>{centrifugation.CentrifugationUnit?.Value} </td>";
                tableCells += $"<td class='td'>{centrifugation.Speed?.NumberValue} </td>";
                tableCells += $"<td class='td'>{centrifugation.TemperatureSetpoint?.NumberValue} </td>";
                tableCells += $"<td class='td'>{centrifugation.Duration?.NumberValue} </td>";
                tableCells += $"<td class='td'>{centrifugation.Acceleration?.NumberValue} </td>";
                tableCells += $"<td class='td'>{centrifugation.Deceleration?.NumberValue} </td>";
               
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "Centrifugation Settings",
                "Centrifuge",
                "Centrifuge ID",
                "Centrifugation Unit",
                "Speed",
                "Temperature Setpoint",
                "Duration",
                "Acceleration",
                "Deceleration",
            };
        }

        private List<string> SubHeaders(List<UoMCentrifugation> uoMCultureDetailsData)
        {

            var temperatureSetpoint = uoMCultureDetailsData.FirstOrDefault(x => x.Column.Value == "Temperature Setpoint" || x.Column.Value == "Temperature").UoM.Value;
            var duration = uoMCultureDetailsData.FirstOrDefault(x => x.Column.Value == "Duration").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                temperatureSetpoint,
                duration,
                "",
                "",
            };
        }



    }
}
