﻿
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ProcessResultHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var processResults = JsonConvert.DeserializeObject<List<ProcessResult>>(spreadSheetPdfTableModel.TableData);
            var uoMProcessResults = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Process Results");
            var uoMProcessResultsData = (List<UoMProcessResult>)JsonConvert.DeserializeObject<List<UoMProcessResult>>(uoMProcessResults.Data.ToString());
            var filteredData = new List<ProcessResult>();

            filteredData = processResults.Where(x => x.HFilterHelper.NumberValue == "1.0").ToList();
            return $"{BuildHtml(filteredData, uoMProcessResultsData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<ProcessResult> processResults, List<UoMProcessResult> uoMProcessResults, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMProcessResults))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedReactorIndexs = processResults.GroupBy(x => x.ReactorIndex.Value, (key, group) => new { ReactorIndex = key, Items = group.ToList() });
            foreach (var groupedReactorIndex in groupedReactorIndexs)
            {
                if (groupedReactorIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedReactorIndex.Items.Count}'>{groupedReactorIndex.ReactorIndex} </td>";
                    var groupedDayIndex = groupedReactorIndex.Items.GroupBy(x => x.DayIndex.Value, (key, group) => new { DayIndex = key, DayIndexValues = group.ToList() });
                    foreach (var dayIndex in groupedDayIndex)
                    {
                        tableCells += $"<td class='td' rowspan='{dayIndex.DayIndexValues.Count}'>{dayIndex.DayIndex} </td>";
                        foreach (var item in dayIndex.DayIndexValues)
                        {   
                            tableCells += $"<td class='td'>{item.ParentSampleIndex?.Value} </td>";
                            tableCells += $"<td class='td'>{item.SampleDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.ElapsedTime?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CultureWorkingVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TotalCellConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TotalViableCellConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CellCultureViability?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.AverageCellDiameter?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GrowthRate?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.DoublingTime?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.IncrementalIVCD?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CumulativeIVCD?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TitreCedexBioHT?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TitreHPLCOctet?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.SpecificProductivityCedexBioHP?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.SpecificProductivityHPLC?.NumberValue} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "",
                "Sample Date",
                "Elapsed Time",
                "Culture Working Volume",
                "Total Cell Concentration",
                "Total Viable Cell Concentration",
                "Cell Culture Viability",
                "Average Cell Diameter",
                "Growth Rate",
                "Doubling Time",
                "Incremental IVCD",
                "Cumulative IVCD",
                "Titre - Cedex Bio HT",
                "Titre - HPLC/Octet",
                "Specific Productivity - Cedex Bio HP",
                "Specific Productivity - HPLC"

            };
        }

        private List<string> SubHeaders(List<UoMProcessResult> uoMProcessResults)
        {
            var elapsedTime = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Elapsed Time")?.UoM?.Value;
            var cultureWorkingVolume = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Culture Working Volume" || x.Column.Value == "Current Culture Volume")?.UoM?.Value;
            var totalCellConcentration = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Total Cell Concentration")?.UoM?.Value;
            var totalViableCellConcentration = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration")?.UoM?.Value;
            var cellCultureViability = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Cell Culture Viability")?.UoM?.Value;
            var averageCellDiameter = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Average Cell Diameter")?.UoM?.Value;
            var growthRate = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Growth Rate")?.UoM?.Value;
            var doublingTime = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Doubling Time")?.UoM?.Value;
            var incrementalIVCD = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Incremental IVCD")?.UoM?.Value;
            var cumulativeIVCD = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Cumulative IVCD")?.UoM?.Value;
            var titreCedexBioHT = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Titre - Cedex Bio HT")?.UoM?.Value;
            var titreHPLCOctet = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Titre - HPLC/Octet")?.UoM?.Value;
            var specificProductivityCedexBioHP = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Specific Productivity - Cedex Bio HP")?.UoM?.Value;
            var specificProductivityHPLC = uoMProcessResults.FirstOrDefault(x => x.Column.Value == "Specific Productivity - HPLC")?.UoM?.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                elapsedTime,
                cultureWorkingVolume,
                totalCellConcentration,
                totalViableCellConcentration,
                cellCultureViability,
                averageCellDiameter,
                growthRate,
                doublingTime,
                incrementalIVCD,
                cumulativeIVCD,
                titreCedexBioHT,
                titreHPLCOctet,
                specificProductivityCedexBioHP,
                specificProductivityHPLC
            };
        }



    }
}
