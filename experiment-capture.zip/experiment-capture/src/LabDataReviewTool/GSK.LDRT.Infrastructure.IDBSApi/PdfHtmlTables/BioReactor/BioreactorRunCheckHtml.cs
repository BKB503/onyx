﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class BioreactorRunCheckHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var bioreactorRunChecks = JsonConvert.DeserializeObject<List<BioreactorRunCheck>>(spreadSheetPdfTableModel.TableData);
          //  var filteredData = bioreactorRunChecks.Where(x => !string.IsNullOrEmpty(x.BioreactorEndDateTime.Value)).ToList();
           
            return $"{BuildHtml(bioreactorRunChecks, spreadSheetPdfTableModel.TableName)}";
        }

     
        private string BuildHtml(List<BioreactorRunCheck> bioreactorRunChecks, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string> { "", "" };
            
            foreach (var bioreactorRunCheck in bioreactorRunChecks)
            {
                headers.Add(bioreactorRunCheck?.ReactorIndex?.Value);
            }

            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
           
            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            
            string vesselId=""; string bioreactorEndDateTime = "";string numberofDeviationsObserved = "";
            string excludeThisBatch = ""; string excludeThisBatchFromCalculation = ""; string comment = "";
            foreach (var bioReactorRunCheck in bioreactorRunChecks)
            {
                var bioreactorEndDate = "";
                if (bioReactorRunCheck.BioreactorEndDateTime != null && bioReactorRunCheck.BioreactorEndDateTime.Value != null && bioReactorRunCheck.BioreactorEndDateTime.Value.HasValue)
                {
                    bioreactorEndDate = bioReactorRunCheck.BioreactorEndDateTime.Value.Value.ToString("MMM dd, yyyy");
                }

               vesselId +=  $"<td class='td'>{bioReactorRunCheck.VesselID?.Value} </td>";
               bioreactorEndDateTime += $"<td class='td'>{bioreactorEndDate} </td>";
               numberofDeviationsObserved += $"<td class='td'>{bioReactorRunCheck.NumberofDeviationsObserved?.Value} </td>";
               excludeThisBatch += $"<td class='td'>{bioReactorRunCheck.ExcludeThisBatch?.Value} </td>";
               excludeThisBatchFromCalculation += $"<td class='td'>{bioReactorRunCheck.ExcludeThisBatchFromCalculation?.Value} </td>";
               comment += $"<td class='td'>{bioReactorRunCheck.Comment?.Value} </td>";
              
                if (bioreactorRunChecks.LastIndexOf(bioReactorRunCheck) == bioreactorRunChecks.Count - 1)
                {
                    var tableCells = "";
                    tableCells += $"<tr><td class='th'>Vessel ID</td><td class='th'></td>{vesselId}</tr>";
                    tableCells += $"<tr><td class='th'>Bioreactor End Date/Time</td><td class='th'> </td> {bioreactorEndDateTime} </tr>";
                    tableCells += $"<tr><td class='th'>Number of Deviations Observed</td><td class='th'> </td> {numberofDeviationsObserved}</tr>";
                    tableCells += $"<tr><td class='th'>Exclude this Batch</td><td class='th'> </td> {excludeThisBatch} </tr>";
                    tableCells += $"<tr><td class='th'>Exclude this Batch from Calculation</td><td class='th'> </td> {excludeThisBatchFromCalculation} </tr>";
                    tableCells += $"<tr><td class='th'>Comment</td><td class='th'> </td> {comment} </tr>";
                  
                    tableRows += tableCells;
                }

               
            }


            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        
    }
}
