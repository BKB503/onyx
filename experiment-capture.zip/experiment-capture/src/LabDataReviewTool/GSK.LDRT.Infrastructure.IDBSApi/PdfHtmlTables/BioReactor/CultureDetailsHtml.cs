﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class CultureDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var cultureDetails = JsonConvert.DeserializeObject<List<CultureDetails>>(spreadSheetPdfTableModel.TableData);
            var uoMCultureDetails = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Culture Details");
            var uoMCultureDetailsData = new List<UoMCultureDetails>();
            if(uoMCultureDetails != null && uoMCultureDetails.Data != null)
            {
                uoMCultureDetailsData = JsonConvert.DeserializeObject<List<UoMCultureDetails>>(uoMCultureDetails?.Data.ToString());
            }
            
            var filteredData = new List<CultureDetails>();

            filteredData = cultureDetails.Where(x => !string.IsNullOrEmpty(x.SeedCultureID.Value)).ToList();

            return $"{BuildHtml(filteredData, uoMCultureDetailsData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<CultureDetails> sampleDetails, List<UoMCultureDetails> uoMCultureDetailsData, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMCultureDetailsData))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedCultureDetails = sampleDetails.GroupBy(x => x.Source.Value, (key, group) => new {Source= key, Items = group.ToList()});
            foreach (var cultureDetail in groupedCultureDetails)
            {  

                if (cultureDetail.Items.Any())
                {  
                    foreach (var item in cultureDetail.Items)
                    {
                        var tableCells = "";
                        if ((cultureDetail.Items.IndexOf(item) == 0))
                        {
                            tableCells += $"<td class='td' rowspan='{cultureDetail.Items.Count}'>{cultureDetail.Source} </td>";
                        }
                        tableCells += $"<td class='td'>{item.SeedCultureIdx?.Value} </td>";
                        tableCells += $"<td class='td'>{item.SeedCultureID?.Value} </td>";
                        tableCells += $"<td class='td'>{item.CultureName?.Value} </td>";
                        tableCells += $"<td class='td'>{item.CellLineName?.Value} </td>";
                        tableCells += $"<td class='td'>{item.CompoundId?.Value} </td>";
                        tableCells += $"<td class='td'>{item.TotalViableCellConcentration?.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.CellCultureViability?.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.PassageNumber?.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.GenerationNumber?.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.Project?.Value} </td>";
                        tableCells += $"<td class='td'>{item.CultureLink?.Value} </td>";
                        tableRows += $"<tr>{tableCells}</tr> ";
                    }
                    
                }
                
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "Source",
                "Seed Culture Idx",
                "Seed Culture ID",
                "Culture Name",
                "Cell Line Name",
                "Compound ID",
                "Total Viable Cell Concentration",
                "Cell Culture Viability",
                "Passage Number",
                "Generation Number",
                "Project",
                "Culture Link"
            };
        }

        private List<string> SubHeaders(List<UoMCultureDetails> uoMCultureDetailsData)
        {
            var totalViableCellConcentration = uoMCultureDetailsData.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration")?.UoM?.Value;
            var cellCultureViability = uoMCultureDetailsData.FirstOrDefault(x => x.Column.Value == "Cell Culture Viability")?.UoM?.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
               totalViableCellConcentration,
              cellCultureViability,
                "",
                "",
                "",
                ""
            };
        }



    }
}
