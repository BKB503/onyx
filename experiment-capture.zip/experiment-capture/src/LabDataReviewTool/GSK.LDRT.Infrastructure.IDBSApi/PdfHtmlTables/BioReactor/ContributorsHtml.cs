﻿
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ContributorsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel SpreadSheetPdfTableModel)
        {
           
            var contributors = JsonConvert.DeserializeObject<List<Contributors>>(SpreadSheetPdfTableModel.TableData.ToString()).ToList();

            return CreateHtml(contributors, SpreadSheetPdfTableModel.TableName) ;
        }

       
        private string CreateHtml(List<Contributors> compoundsAndProjects, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in ComppundsAndProjectsHeader())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var compoundsAndProject in compoundsAndProjects)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{compoundsAndProject.ContributorIdx?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.UserId?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.UserName?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.Role?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.Comments?.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> ComppundsAndProjectsHeader()
        {
            return new List<string>
            {
                "Compounds and Projects ID",
                "User ID",
                "User Name",
                "Role",
                "Comments",
              
            };
        }
  
       
    }
}
