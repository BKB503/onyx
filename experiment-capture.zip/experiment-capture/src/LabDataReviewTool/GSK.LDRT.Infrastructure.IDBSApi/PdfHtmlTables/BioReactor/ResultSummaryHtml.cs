﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ResultSummaryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var resultSummaries = JsonConvert.DeserializeObject<List<ResultSummary>>(spreadSheetPdfTableModel.TableData);
            var filteredData = resultSummaries.Where(x => x.HRowshow.NumberValue == "1.0").ToList();
            var uoMresultSummaries = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Pooled Culture Details");
            var uoMresultSummariesData = (List<UoMPooledCultureDetails>)JsonConvert.DeserializeObject<List<UoMPooledCultureDetails>>(uoMresultSummaries.Data.ToString());
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{BuildHtml(filteredData, uoMresultSummariesData, spreadSheetPdfTableModel.TableName)}";
        }

       
        private string BuildHtml(List<ResultSummary> resultSummaries, List<UoMPooledCultureDetails> uoMresultSummaries, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string> { "", "" };
            var ivcdUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "IVCD");
            var averageGrowthRateUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Average Growth Rate");
            var maximumViableCellDensityUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Maximum Viable Cell Density");
            var finalViableCellDensityUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Final Viable Cell Density");
            var finalViabilityUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Final Viability");
            var finalTitreCedexBioHTUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Final Titre Cedex Bio HT");
            var finalTitreHPLCUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Final Titre HPLC");
            var averageSpecificProductivityCedexBioHTUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Average Specific Productivity Cedex Bio HT");
            var averageSpecificProductivityHPLCUoM = uoMresultSummaries.FirstOrDefault(x => x.Column.Value == "Average Specific Productivity HPLC");
            
            foreach (var resultSummary in resultSummaries)
            {
                headers.Add(resultSummary?.ReactorIndex?.Value);
            }

            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
           

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            string ivcd = ""; string averageGrowthRate = "";string maximumViableCellDensity = "";
            string finalViableCellDensity = ""; string finalViability = ""; string finalTitreCedexBioHT = "";
            string finalTitreHPLC = ""; string averageSpecificProductivityCedexBioHT = ""; string averageSpecificProductivityHPLC = "";
            string generationNumber = "";
            foreach (var resultSummary in resultSummaries)
            {
               ivcd +=  $"<td class='td'>{resultSummary.IVCD?.NumberValue} </td>";
               averageGrowthRate += $"<td class='td'>{resultSummary.AverageGrowthRate?.NumberValue} </td>";
               maximumViableCellDensity += $"<td class='td'>{resultSummary.MaximumViableCellDensity?.NumberValue} </td>";
               finalViableCellDensity += $"<td class='td'>{resultSummary.FinalViableCellDensity?.NumberValue} </td>";
               finalViability += $"<td class='td'>{resultSummary.FinalViability?.NumberValue} </td>";
               finalTitreCedexBioHT += $"<td class='td'>{resultSummary.FinalTitreCedexBioHT?.NumberValue} </td>";
               finalTitreHPLC += $"<td class='td'>{resultSummary.FinalTitreHPLC?.NumberValue} </td>";
               averageSpecificProductivityCedexBioHT += $"<td class='td'>{resultSummary.AverageSpecificProductivityCedexBioHT?.NumberValue} </td>";
               averageSpecificProductivityHPLC += $"<td class='td'>{resultSummary.AverageSpecificProductivityHPLC.NumberValue} </td>";
               generationNumber += $"<td class='td'>{resultSummary.GenerationNumber.NumberValue} </td>";
              
               
                if (resultSummaries.LastIndexOf(resultSummary) == resultSummaries.Count - 1)
                {
                    var tableCells = "";
                    tableCells += $"<tr><td class='th'>IVCD</td><td class='th'>{ivcdUoM?.UoM?.Value} </td>{ivcd}</tr>";
                    tableCells += $"<tr><td class='th'>Average Growth Rate</td><td class='th'> { averageGrowthRateUoM?.UoM?.Value}</td> {averageGrowthRate} </tr>";
                    tableCells += $"<tr><td class='th'>Maximum Viable Cell Density</td><td class='th'>{maximumViableCellDensityUoM?.UoM?.Value} </td> {maximumViableCellDensity}</tr>";
                    tableCells += $"<tr><td class='th'>Final Viable Cell Density</td><td class='th'>{finalViableCellDensityUoM?.UoM?.Value} </td> {finalViableCellDensity} </tr>";
                    tableCells += $"<tr><td class='th'>Final Viability</td><td class='th'> {finalViabilityUoM?.UoM?.Value}</td> {finalViability} </tr>";
                    tableCells += $"<tr><td class='th'>Final Titre Cedex Bio HT</td><td class='th'> {finalTitreCedexBioHTUoM?.UoM?.Value}</td> {finalTitreCedexBioHT} </tr>";
                    tableCells += $"<tr><td class='th'>Final Titre HPLC</td><td class='th'>{finalTitreHPLCUoM?.UoM?.Value} </td> {finalTitreHPLC} </tr>";
                    tableCells += $"<tr><td class='th'>Average Specific Productivity Cedex Bio HT</td><td class='th'> {averageSpecificProductivityCedexBioHTUoM?.UoM?.Value}</td> {averageSpecificProductivityCedexBioHT} </tr>";
                    tableCells += $"<tr><td class='th'>Average Specific Productivity HPLC</td><td class='th'> {averageSpecificProductivityHPLCUoM?.UoM?.Value}</td> {averageSpecificProductivityHPLC} </tr>";
                    tableCells += $"<tr><td class='th'>Generation Number</td><td class='th'> </td> {generationNumber} </tr>";
                  
                    tableRows += tableCells;
                }
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        
    }
}
