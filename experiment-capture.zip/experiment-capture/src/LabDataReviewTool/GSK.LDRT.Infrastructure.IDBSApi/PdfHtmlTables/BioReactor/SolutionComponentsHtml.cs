﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class SolutionComponentsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var solutionComponents = JsonConvert.DeserializeObject<List<SolutionComponents>>(spreadSheetPdfTableModel.TableData);
            var filteredData = new List<SolutionComponents>();

            filteredData = solutionComponents.Where(x => x.hRowshow.NumberValue == "1.0").ToList();

            return $"{BuildHtml(filteredData, spreadSheetPdfTableModel.TableName)}";
        }


        private string BuildHtml(List<SolutionComponents> solutionComponents,  string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
           
            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  </thead>";

            var groupedSolutionComponents = solutionComponents.GroupBy(x => x.SolutionIndex.Value, (key, group) => new {SolutionIndex= key, Items = group.ToList()});
            foreach (var solutionComponent in groupedSolutionComponents)
            {  

                if (solutionComponent.Items.Any())
                {  
                    foreach (var item in solutionComponent.Items)
                    {
                        var tableCells = "";
                        if ((solutionComponent.Items.IndexOf(item) == 0))
                        {
                            tableCells += $"<td class='td' rowspan='{solutionComponent.Items.Count}'>{solutionComponent.SolutionIndex} </td>";
                        }
                        tableCells += $"<td class='td'>{item.ComponentIndex.Value} </td>";
                        tableCells += $"<td class='td'>{item.ComponentName.Value} </td>";
                        tableCells += $"<td class='td'>{item.ComponentId.Value} </td>";
                        tableCells += $"<td class='td'>{item.LotNumber.Value} </td>";
                        tableCells += $"<td class='td'>{item.AmountofComponent.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.Unit.Value} </td>";
                        tableCells += $"<td class='td'>{item.AddAnotherComponent.Value} </td>";
                      
                        tableRows += $"<tr>{tableCells}</tr> ";
                    }
                    
                }
                
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "Solution Index",
                "Component Index",
                "Component Name",
                "Component ID",
                "Lot Number",
                "Amount of Component",
                "Unit",
                "Add Another Component?",
              
            };
        }

  


    }
}
