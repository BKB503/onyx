﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ReagentDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel SpreadSheetPdfTableModel)
        {
           
            var reagentDetails = JsonConvert.DeserializeObject<List<ReagentDetails>>(SpreadSheetPdfTableModel.TableData.ToString()).ToList();
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{CreateHtml(reagentDetails, SpreadSheetPdfTableModel.TableName)}"; 
        }

        private string CreateHtml(List<ReagentDetails> reagentDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr> </thead>";

            foreach (var reagentDetail in reagentDetails)
            {
                var expirationDate = "";
                if (reagentDetail.ExpirationDate != null && reagentDetail.ExpirationDate.Value != null && reagentDetail.ExpirationDate.Value.HasValue)
                {
                    expirationDate = reagentDetail.ExpirationDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{reagentDetail.ReagentIdx?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.ReagentId?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.RecordName?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.ItemName?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.LotNumber?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.Composition?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.Type?.Value} </td>";
                tableCells += $"<td class='td'>{expirationDate} </td>";
                tableCells += $"<td class='td'>{reagentDetail.AvailableQuantity?.StringValue} </td>";
                tableCells += $"<td class='td'>{reagentDetail.AvailableQuantityUnit?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.ReagentLocation?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.ReagentExperimentId?.Value} </td>";
                tableCells += $"<td class='td'>{reagentDetail.PreparationLink?.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Reagent Idx",
                "Reagent ID",
                "Record Name",
                "Item Name",
                "Lot Number",
                "Composition",
                "Type",
                "Expiration Date",
                "Available Quantity",
                "Available Quantity Unit",
                "Reagent Location",
                "Reagent Experiment ID",
                "Preparation Link"
            };
        }
  
       
    }
}
