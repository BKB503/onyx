﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class BioHTCedexDataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var bioHTCedexDataEntrys = JsonConvert.DeserializeObject<List<BioHTCedexDataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMBioHTCedexDataEntrys = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_BioHT Cedex Data Entry");
            var uoMBioHTCedexDataEntrysData = (List<UoMBioHTCedexDataEntry>)JsonConvert.DeserializeObject<List<UoMBioHTCedexDataEntry>>(uoMBioHTCedexDataEntrys.Data.ToString());
            var filteredData = new List<BioHTCedexDataEntry>();

            filteredData = bioHTCedexDataEntrys.Where(x => !string.IsNullOrEmpty(x.SampleName.Value)).ToList();
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak} {BuildHtml(filteredData, uoMBioHTCedexDataEntrysData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<BioHTCedexDataEntry> bioHTCedexDataEntrys, List<UoMBioHTCedexDataEntry> uoMBioHTCedexDataEntrys, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMBioHTCedexDataEntrys))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedCedexAliquotIndexs = bioHTCedexDataEntrys.GroupBy(x => x.CedexAliquotIndex.Value, (key, group) => new { CedexAliquotIndex = key, Items = group.ToList() });
            foreach (var groupedCedexAliquotIndex in groupedCedexAliquotIndexs)
            {
                if (groupedCedexAliquotIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedCedexAliquotIndex.Items.Count}'>{groupedCedexAliquotIndex.CedexAliquotIndex} </td>";
                    var groupedInputMethods = groupedCedexAliquotIndex.Items.GroupBy(x => x.InputMethod.Value, (key, group) => new { InputMethod = key, InputMethodValues = group.ToList() });
                    foreach (var inputMethod in groupedInputMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{inputMethod.InputMethodValues.Count}'>{inputMethod.InputMethod} </td>";
                        foreach (var item in inputMethod.InputMethodValues)
                        {   
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.InstrumentSampleIdOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementEquipment?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.AmmoniumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CalciumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GlucoseConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GlutamineConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GlutamateConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.LactateConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.LactateDehydrogenaseConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PotassiumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Titre?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.SodiumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.IronConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.MagnesiumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PhosphateConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Ignore?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Sample Name",
                "DCA ID",
                "Instrument Sample ID Override",
                "Measurement Equipment",
                "Measurement Date",
                "Ammonium Concentration",
                "Calcium Concentration",
                "Glucose Concentration",
                "Glutamine Concentration",
                "Glutamate Concentration",
                "Lactate Concentration",
                "Lactate dehydrogenase concentration",
                "Potassium Concentration",
                "Titre",
                "Sodium Concentration",
                "Iron Concentration",
                "Magnesium Concentration",
                "Phosphate Concentration",
                "Ignore?"

            };
        }

        private List<string> SubHeaders(List<UoMBioHTCedexDataEntry> uoMBioHTCedexDataEntrys)
        {
            var ammoniumConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Ammonium Concentration").UoM?.Value;
            var calciumConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Calcium Concentration").UoM?.Value;
            var glucoseConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Glucose Concentration").UoM?.Value;
            var lactatedehydrogenaseConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Lactate dehydrogenase concentration").UoM?.Value;
            var potassiumConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Potassium Concentration").UoM?.Value;
            var titre = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Titre").UoM?.Value;
            var sodiumConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Sodium Concentration").UoM?.Value;
            var ironConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Iron Concentration").UoM?.Value;
            var magnesiumConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Magnesium Concentration").UoM?.Value;
            var phosphateConcentration = uoMBioHTCedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Phosphate Concentration").UoM?.Value;
         
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                ammoniumConcentration,
                calciumConcentration,
                glucoseConcentration,
                "",
                "",
                "",
                lactatedehydrogenaseConcentration,
                potassiumConcentration,
                titre,
                sodiumConcentration,
                ironConcentration,
                magnesiumConcentration,
                phosphateConcentration,
                ""
            };
        }



    }
}
