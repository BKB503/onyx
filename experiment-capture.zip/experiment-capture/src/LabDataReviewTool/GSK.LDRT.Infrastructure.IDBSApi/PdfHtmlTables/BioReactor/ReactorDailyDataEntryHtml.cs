﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ReactorDailyDataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var reactorDailyDataEntry = JsonConvert.DeserializeObject<List<ReactorDailyDataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMReactorDailyDataEntry = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Reactor Daily Data Entry");
            var uoMReactorDailyDataEntryData = (List<UoMReactorDailyDataEntry>)JsonConvert.DeserializeObject<List<UoMReactorDailyDataEntry>>(uoMReactorDailyDataEntry.Data.ToString());
            var filteredData = new List<ReactorDailyDataEntry>();

            filteredData = reactorDailyDataEntry.Where(x => x.Date?.Value.HasValue == true).ToList();
           
            //return null;
            return $"{BuildHtml(filteredData, uoMReactorDailyDataEntryData, spreadSheetPdfTableModel.TableName)}";
        }

      

        private string BuildHtml(List<ReactorDailyDataEntry> parentSampleDetails, List<UoMReactorDailyDataEntry> uoMReactorDailyDataEntry, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";
          
            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMReactorDailyDataEntry))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedReactorIndexs = parentSampleDetails.GroupBy(x => x.ReactorIndex.Value, (key, group) => new { ReactorIndex = key, Items = group.ToList() });
            foreach (var groupedReactorIndex in groupedReactorIndexs)
            {
                if (groupedReactorIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedReactorIndex.Items.Count}'>{groupedReactorIndex.ReactorIndex} </td>";
                    var groupedDayIndex = groupedReactorIndex.Items.GroupBy(x => x.DayIndex.Value, (key, group) => new { DayIndex = key, DayIndexValues = group.ToList() });
                    foreach (var dayIndex in groupedDayIndex)
                    {
                        tableCells += $"<td class='td' rowspan='{dayIndex.DayIndexValues.Count}'>{dayIndex.DayIndex} </td>";
                        foreach (var item in dayIndex.DayIndexValues)
                        {
                            var date = "";
                            if (item.Date != null && item.Date.Value != null && item.Date.Value.HasValue)
                            {
                                date = item.Date.Value.Value.ToString("MMM dd, yyyy");
                            }

                            var dateTime = "";
                            if (item.Time24h != null && item.Time24h.Value != null && item.Time24h.Value.HasValue)
                            {
                                dateTime = item.Time24h.Value.Value.ToString("MMM dd, yyyy");
                            }

                            tableCells += $"<td class='td'>{item.TimepointIndex?.Value} </td>";
                            tableCells += $"<td class='td'>{item.UserName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.UserId?.Value} </td>";
                            tableCells += $"<td class='td'>{date} </td>";
                            tableCells += $"<td class='td'>{dateTime} </td>";
                            tableCells += $"<td class='td'>{item.Media1PumpTotalVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Media2PumpTotalVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.MediaFlowRate?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Media3PumpTotalVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CellFactor?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.AgitationRate?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.DissolvedOxygen?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.ControllerpH?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.VesselTemperature?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.BaseAdditionPumpTotalVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.AcidAdditionPumpTotalVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.AntifoamAdded?.Value} </td>";
                            tableCells += $"<td class='td'>{item.AddTimepoints?.Value} </td>";
                            tableCells += $"<td class='td'>{item.Comments?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Timepoint Index",
                "User Name",
                "User ID",
                "Date",
                "Time (24h)",
                "Media 1 Pump Total Volume",
                "Media 2 Pump Total Volume",
                "Media Flow Rate",
                "Media 3 Pump Total Volume",
                "Cell Factor",
                "Agitation Rate",
                "Dissolved Oxygen",
                "Controller pH",
                "Vessel Temperature",
                "Base Addition Pump Total Volume",
                "Acid Addition Pump Total Volume",
                "Antifoam Added?",
                "Add Timepoints?",
                "Comments"

            };
        }

        private List<string> SubHeaders(List<UoMReactorDailyDataEntry> uoMReactorDailyDataEntry)
        {
            var cellFactor = uoMReactorDailyDataEntry?.FirstOrDefault(x => x.Column?.Value == "Cell Factor")?.UoM?.Value;
            var agitationRate = uoMReactorDailyDataEntry?.FirstOrDefault(x => x.Column?.Value == "Agitation Rate")?.UoM?.Value;
            var dissolvedOxygen = uoMReactorDailyDataEntry?.FirstOrDefault(x => x.Column?.Value == "Dissolved Oxygen")?.UoM?.Value;
            var vesselTemperature = uoMReactorDailyDataEntry?.FirstOrDefault(x => x.Column?.Value == "Vessel Temperature")?.UoM?.Value;
            var baseAdditionPumpTotalVolume = uoMReactorDailyDataEntry?.FirstOrDefault(x => x.Column?.Value == "Base Addition Pump Total Volume")?.UoM?.Value;
            var acidAdditionPumpTotalVolume = uoMReactorDailyDataEntry?.FirstOrDefault(x => x.Column?.Value == "Acid Addition Pump Total Volume")?.UoM?.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                cellFactor,
                agitationRate,
                dissolvedOxygen,
                "",
                vesselTemperature,
                baseAdditionPumpTotalVolume,
                acidAdditionPumpTotalVolume,
                "",
                "",
                ""
            };
        }



    }
}
