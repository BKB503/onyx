﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class OsmometerDataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var osmometerDataEntrys = JsonConvert.DeserializeObject<List<OsmometerDataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMOsmometerDataEntrys = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Osmometer Data Entry");
            var uoMOsmometerDataEntrysData = (List<UoMOsmometerDataEntry>)JsonConvert.DeserializeObject<List<UoMOsmometerDataEntry>>(uoMOsmometerDataEntrys.Data.ToString());
            var filteredData = new List<OsmometerDataEntry>();

            filteredData = osmometerDataEntrys.Where(x => !string.IsNullOrEmpty(x.SampleName.Value)).ToList();
           
            return $"{BuildHtml(filteredData, uoMOsmometerDataEntrysData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<OsmometerDataEntry> viCellDataEntrys, List<UoMOsmometerDataEntry> uoMOsmometerDataEntrys, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMOsmometerDataEntrys))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedOsmometerAliquotIndexs = viCellDataEntrys.GroupBy(x => x.OsmometerAliquotIndex.Value, (key, group) => new { OsmometerAliquotIndex = key, Items = group.ToList() });
            foreach (var groupedOsmometerAliquotIndex in groupedOsmometerAliquotIndexs)
            {
                if (groupedOsmometerAliquotIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedOsmometerAliquotIndex.Items.Count}'>{groupedOsmometerAliquotIndex.OsmometerAliquotIndex} </td>";
                    var groupedInputMethods = groupedOsmometerAliquotIndex.Items.GroupBy(x => x.InputMethod.Value, (key, group) => new { InputMethod = key, InputMethodValues = group.ToList() });
                    foreach (var inputMethod in groupedInputMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{inputMethod.InputMethodValues.Count}'>{inputMethod.InputMethod} </td>";
                        foreach (var item in inputMethod.InputMethodValues)
                        {   
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.InstrumentSampleIdOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementEquipment?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.Osmolality?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Ignore?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Sample Name",
                "DCA ID",
                "Instrument Sample ID Override",
                "Measurement Equipment",
                "Measurement Date",
                "Osmolality",
                "Ignore?"

            };
        }

        private List<string> SubHeaders(List<UoMOsmometerDataEntry> uoMOsmometerDataEntrys)
        {
            var osmolality = uoMOsmometerDataEntrys.FirstOrDefault(x => x.Column.Value == "Osmolality").UoM.Value;
            return new List<string>
            {
               "",
                "",
                "",
                "",
                "",
                "",
                "",
                osmolality,
                ""
            };
        }



    }
}
