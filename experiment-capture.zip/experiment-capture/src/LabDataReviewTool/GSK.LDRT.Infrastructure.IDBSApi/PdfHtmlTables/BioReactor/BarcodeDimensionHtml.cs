﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class BarcodeDimensionHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var barcodeDimensionModels = JsonConvert.DeserializeObject<List<BarcodeDimensionModel>>(spreadSheetPdfTableModel.TableData);
            return $"{BuildHtml(barcodeDimensionModels, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<BarcodeDimensionModel> barcodeDimensionModels, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var barcodeDimensionModel in barcodeDimensionModels)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{barcodeDimensionModel.BarcodeDimension?.Value} </td>";
               

                tableRows += $"<tr>{tableCells}</tr> ";
            }
            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Barcode Dimension",
              
            };
        }

    }
}
