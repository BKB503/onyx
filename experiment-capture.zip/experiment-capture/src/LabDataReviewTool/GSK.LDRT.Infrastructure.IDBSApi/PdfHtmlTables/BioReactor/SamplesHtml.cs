﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class SamplesHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var samples = JsonConvert.DeserializeObject<List<Samples>>(spreadSheetPdfTableModel.TableData);
            var filteredData = samples.Where(x => !string.IsNullOrEmpty(x.HRowshow.NumberValue)).ToList();
            var spreadSheetTableData = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Samples");
            return $"{BuildHtml(filteredData, spreadSheetPdfTableModel.TableName, spreadSheetTableData.Images)}";
        }


        private string BuildHtml(List<Samples> samples, string tableName, List<ImageResponseEntity> imageResponseEntities)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var sample in samples)
            {
                var imageEntity = imageResponseEntities.FirstOrDefault(x => x.Name == sample.Barcode.Value);
                var image = $"<img  src='data:{imageEntity.MimeType};base64,{imageEntity.Base64}' />";
                var tableCells = "";
                tableCells += $"<td class='td'>{sample.B?.Value} </td>";
                tableCells += $"<td class='td'>{sample.SampleId?.Value} </td>";
                tableCells += $"<td class='td'>{sample.SampleName?.Value} </td>";
                tableCells += $"<td class='td'>{image} </td>";
                
                tableRows += $"<tr>{tableCells}</tr> ";
            }
            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "Sample ID",
                "Sample Name",
                "Barcode"
            };
        }

    }
}
