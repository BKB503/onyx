﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class SampleSetupConfigurationHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
           
            var sampleSetupConfigurations = JsonConvert.DeserializeObject<List<SampleSetupConfiguration>>(spreadSheetPdfTableModel.TableData.ToString()).ToList();
            var uoMSampleSetupConfiguration = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Sample Setup Configuration");
            var uoMSampleSetupConfigurationData = new List<UoMSampleSetupConfiguration>();

            if (uoMSampleSetupConfiguration != null && uoMSampleSetupConfiguration.Data != null)
            {
              uoMSampleSetupConfigurationData = (List<UoMSampleSetupConfiguration>)JsonConvert.DeserializeObject<List<UoMSampleSetupConfiguration>>(uoMSampleSetupConfiguration.Data.ToString());

            }
            var filteredData = sampleSetupConfigurations.Where(x => x.HSamplingPlanFilter?.NumberValue == "1.0").ToList();


            return CreateHtml(filteredData, uoMSampleSetupConfigurationData, spreadSheetPdfTableModel.TableName) ;
        }

        private string CreateHtml(List<SampleSetupConfiguration> sampleSetupConfigurations, List<UoMSampleSetupConfiguration> uoMSampleSetupConfiguration,  string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            foreach (var tableTh in SubHeaders(uoMSampleSetupConfiguration))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }
            tableHeader += $"<thead>{ColSpanHeaders()}<tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedReactorIndexs = sampleSetupConfigurations.GroupBy(x => x.ReactorIndex.Value, (key, group) => new { ReactorIndex = key, Items = group.ToList() });
            foreach (var groupedReactorIndex in groupedReactorIndexs)
            {
                if (groupedReactorIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedReactorIndex.Items.Count}'>{groupedReactorIndex.ReactorIndex} </td>";
                    foreach (var sampleSetupConfiguration in groupedReactorIndex.Items)
                    {
                        //var tableCells = "";
                        
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.PlannedDays?.Value} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.NumberOfSamplesPerDay?.NumberValue} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.GenerateIntermediateCultures?.Value} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.IntermediateCultures?.Value} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.VolumeOfIntermediateCultures?.NumberValue} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.IsCentrifuged?.Value} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.CentrifugeGroup?.Value} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.IsFiltered?.Value} </td>";
                        tableCells += $"<td class='td'>{sampleSetupConfiguration.Comments?.Value} </td>";
                        tableRows += $"<tr>{tableCells}</tr> ";
                        tableCells = "";
                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }


        private string ColSpanHeaders()
        {
            return $"<tr><th class='th' rowspan='2'>Planned Days</th><th class='th' rowspan='2'>Number of Samples per Day</th> <th colspan='7' class='th'>Intermediate Culture Details</th></tr>";
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "Generate Intermediate Cultures?",
                "Intermediate Cultures #",
                "Volume of Intermediate Cultures",
                "Is Centrifuged?",
                "Centrifuge group",
                "Is Filtered?",
                "Comments",
               
            };
        }

        public List<string> SubHeaders(List<UoMSampleSetupConfiguration> uoMSampleSetupConfiguration)
        {
            var vIC = uoMSampleSetupConfiguration.FirstOrDefault(x => x.Column.Value == "Volume of Intermediate Cultures")?.UoM?.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                vIC,
                "",
                "",
                "",
                "",
            };
        }


    }
}
