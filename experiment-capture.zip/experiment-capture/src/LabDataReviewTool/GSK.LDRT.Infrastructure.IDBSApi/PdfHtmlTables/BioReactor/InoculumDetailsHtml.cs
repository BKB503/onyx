﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class InoculumDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var inoculumDetails = JsonConvert.DeserializeObject<List<InoculumDetails>>(spreadSheetPdfTableModel.TableData);
            var uoMInoculumDetails = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Inoculum Details");
            var uoMInoculumDetailsData = new List<UoMInoculumDetails>();
            var filteredData = new List<InoculumDetails>();
            if (uoMInoculumDetails != null && uoMInoculumDetails.Data != null)
            {
                uoMInoculumDetailsData= JsonConvert.DeserializeObject<List<UoMInoculumDetails>>(uoMInoculumDetails.Data.ToString());
              
            }

            filteredData = inoculumDetails.Where(x => !string.IsNullOrEmpty(x.SeedCultureId.Value)).ToList();

            return $"{BuildHtml(filteredData, uoMInoculumDetailsData, spreadSheetPdfTableModel.TableName)}";
        }

       
        private string BuildHtml(List<InoculumDetails> inoculumDetails, List<UoMInoculumDetails> uoMInoculumDetailsData, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMInoculumDetailsData))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var inoculumDetail in inoculumDetails)
            {
                var tableCells = "";

                var inoculationCompletedDateandTime = "";
                if (inoculumDetail.InoculationCompletedDateandTime != null && inoculumDetail.InoculationCompletedDateandTime.Value != null && inoculumDetail.InoculationCompletedDateandTime.Value.HasValue)
                {
                    inoculationCompletedDateandTime = inoculumDetail.InoculationCompletedDateandTime.Value.Value.ToString("MMM dd, yyyy");
                }

                tableCells += $"<td class='td'>{inoculumDetail.InoculationIdx?.Value} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.InoculationSetName?.Value} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.CultureName?.Value} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.SeedCultureId?.Value} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.CellLineName?.Value} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.TotalViableCellConcentration?.NumberValue} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.TotalViableCellConcentrationOverride?.NumberValue} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.TotalViableCellConcentrationTarget?.NumberValue} </td>";
                tableCells += $"<td class='td'>{inoculationCompletedDateandTime} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.CultureMedium?.Value} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.Centrifugegroup?.Value} </td>";
                tableCells += $"<td class='td'>{inoculumDetail.Comments?.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "Inoculation Idx",
                "Inoculation Set Name",
                "Culture Name",
                "Seed Culture ID",
                "Cell Line Name",
                "Total Viable Cell Concentration",
                "Total Viable Cell Concentration Override",
                "Total Viable Cell Concentration Target",
                "Inoculation Completed Date and Time",
                "Culture Medium",
                "Centrifuge group",
                "Comments"
            };
        }

        private List<string> SubHeaders(List<UoMInoculumDetails> uoMInoculumDetails)
        {
            var totalViableCellConcentration = uoMInoculumDetails.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration")?.UoM.Value;
            var totalViableCellConcentrationOverride= uoMInoculumDetails.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration Override")?.UoM.Value;
            var totalViableCellConcentrationTarget = uoMInoculumDetails.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration Target")?.UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
               totalViableCellConcentration,
                totalViableCellConcentrationOverride,
                totalViableCellConcentrationTarget,
                "",
                "",
                "",
                ""
            };
        }



    }
}
