﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class PooledCultureDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var pooledCultureDetails = JsonConvert.DeserializeObject<List<PooledCultureDetails>>(spreadSheetPdfTableModel.TableData);
            var filteredData = pooledCultureDetails.Where(x => !string.IsNullOrEmpty(x.PooledCultureName.Value)).ToList();
            var uoMPooledCultureDetails = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Pooled Culture Details");
            var uoMPooledCultureDetailsData = (List<UoMPooledCultureDetails>)JsonConvert.DeserializeObject<List<UoMPooledCultureDetails>>(uoMPooledCultureDetails.Data.ToString());
            return $"{BuildHtml(filteredData, uoMPooledCultureDetailsData, spreadSheetPdfTableModel.TableName)}";
        }

      
        private string BuildHtml(List<PooledCultureDetails> pooledCultureDetails, List<UoMPooledCultureDetails> uoMPooledCultureDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string> { "", "" };
            var finalViableCellDensityUom = uoMPooledCultureDetails.FirstOrDefault(x => x.Column.Value == "Final Viable Cell Density");
            var finalViabilityUom = uoMPooledCultureDetails.FirstOrDefault(x => x.Column.Value == "Final Viability");
            var titreUom = uoMPooledCultureDetails.FirstOrDefault(x => x.Column.Value == "Titre");
            
            foreach (var pooledCultureDetail in pooledCultureDetails)
            {
                headers.Add(pooledCultureDetail?.PooledCultureIdx?.Value);
            }

            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
           

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            string poolMaterial1 = ""; string poolMaterial1Volume = "";string poolMaterial2 = "";
            string poolMaterial2Volume = ""; string poolMaterial3 = ""; string poolMaterial3Volume = "";
            string poolMaterial4 = ""; string poolMaterial4Volume = ""; string poolMaterialVolumeUnit = ""; string pooledCultureName = "";
            string pooledCultureId = ""; string batchId = ""; string poolVolume = ""; string poolVolumeUnit = "";
            string finalViableCellDensity = ""; string finalViability = ""; string titre = ""; string storageLocationId = "";
            string culturePrintName = ""; string vesselId = ""; string passageNumber = ""; string generationNumber = "";
            foreach (var pooledCultureDetail in pooledCultureDetails)
            {
               poolMaterial1 +=  $"<td class='td'>{pooledCultureDetail.PoolMaterial1?.Value} </td>";
               poolMaterial1Volume += $"<td class='td'>{pooledCultureDetail.PoolMaterial1Volume?.NumberValue} </td>";
               poolMaterial2 += $"<td class='td'>{pooledCultureDetail.PoolMaterial2?.Value} </td>";
               poolMaterial2Volume += $"<td class='td'>{pooledCultureDetail.PoolMaterial2Volume?.NumberValue} </td>";
               poolMaterial3 += $"<td class='td'>{pooledCultureDetail.PoolMaterial3?.Value} </td>";
               poolMaterial3Volume += $"<td class='td'>{pooledCultureDetail.PoolMaterial3Volume?.NumberValue} </td>";
               poolMaterial4 += $"<td class='td'>{pooledCultureDetail.PoolMaterial4?.Value} </td>";
               poolMaterial4Volume += $"<td class='td'>{pooledCultureDetail.PoolMaterial4Volume?.NumberValue} </td>";
               poolMaterialVolumeUnit += $"<td class='td'>{pooledCultureDetail.PoolMaterialVolumeUnit.Value} </td>";
               pooledCultureName += $"<td class='td'>{pooledCultureDetail.PooledCultureName?.Value} </td>";
               pooledCultureId += $"<td class='td'>{pooledCultureDetail.PooledCultureId?.Value} </td>";
               batchId += $"<td class='td'>{pooledCultureDetail.BatchId?.Value} </td>";
               poolVolume += $"<td class='td'>{pooledCultureDetail.PoolVolume?.NumberValue} </td>";
               poolVolumeUnit += $"<td class='td'>{pooledCultureDetail.PoolVolumeUnit?.Value} </td>";
               finalViableCellDensity += $"<td class='td'>{pooledCultureDetail.FinalViableCellDensity?.NumberValue} </td>";
               finalViability += $"<td class='td'>{pooledCultureDetail.FinalViability?.NumberValue} </td>";
               titre += $"<td class='td'>{pooledCultureDetail.Titre?.NumberValue} </td>";
               storageLocationId += $"<td class='td'>{pooledCultureDetail.StorageLocationId?.Value} </td>";
               culturePrintName += $"<td class='td'>{pooledCultureDetail.CulturePrintName?.Value} </td>";
               vesselId += $"<td class='td'>{pooledCultureDetail.VesselId?.Value} </td>";
               passageNumber += $"<td class='td'>{pooledCultureDetail.PassageNumber?.Value} </td>";
               generationNumber+= $"<td class='td'>{pooledCultureDetail.GenerationNumber?.Value} </td>";
               
                if (pooledCultureDetails.LastIndexOf(pooledCultureDetail) == pooledCultureDetails.Count - 1)
                {
                    var tableCells = "";
                    tableCells += $"<tr><td class='th'>Pool Material 1</td><td class='th'> </td>{poolMaterial1}</tr>";
                    tableCells += $"<tr><td class='th'>Pool Material 1 Volume</td><td class='th'> </td> {poolMaterial1Volume} </tr>";
                    tableCells += $"<tr><td class='th'>Pool Material 2</td><td class='th'> </td> {poolMaterial2}</tr>";
                    tableCells += $"<tr><td class='th'>Pool Material 2 Volume</td><td class='th'> </td> {poolMaterial2Volume} </tr>";
                    tableCells += $"<tr><td class='th'>Pool Material 3</td><td class='th'> </td> {poolMaterial3} </tr>";
                    tableCells += $"<tr><td class='th'>Pool Material 3 Volume</td><td class='th'> </td> {poolMaterial3Volume} </tr>";
                    tableCells += $"<tr><td class='th'>Pool Material 4</td><td class='th'> </td> {poolMaterial4} </tr>";
                    tableCells += $"<tr><td class='th'>Pool Material 4 Volume</td><td class='th'> </td> {poolMaterial4Volume} </tr>";
                    tableCells += $"<tr><td class='th'>Pool Material Volume Unit</td><td class='th'> </td> {poolMaterialVolumeUnit} </tr>";
                    tableCells += $"<tr><td class='th'>Pooled Culture Name</td><td class='th'> </td> {pooledCultureName}</tr>";
                    tableCells += $"<tr><td class='th'>Pooled Culture ID</td><td class='th'> </td> {pooledCultureId} </tr>";
                    tableCells += $"<tr><td class='th'>Batch ID</td><td class='th'> </td>{batchId} </tr>";
                    tableCells += $"<tr><td class='th'>Pool Volume</td><td class='th'> </td> {poolVolume}</tr>";
                    tableCells += $"<tr><td class='th'>Pool Volume Unit</td><td class='th'> </td> {poolVolumeUnit}</tr>";
                    tableCells += $"<tr><td class='th'>Final Viable Cell Density</td><td class='th'>{finalViableCellDensityUom?.UoM?.Value} </td> {finalViableCellDensity} </tr>";
                    tableCells += $"<tr><td class='th'>Final Viability</td><td class='th'>{finalViabilityUom?.UoM?.Value} </td> {finalViability}</tr>";
                    tableCells += $"<tr><td class='th'>Titre</td><td class='th'>{titreUom?.UoM?.Value} </td> {titre}</tr>";
                    tableCells += $"<tr><td class='th'>Storage Location ID</td><td class='th'></td> {storageLocationId} </tr>";
                    tableCells += $"<tr><td class='th'>Culture Print Name</td><td class='th'></td> {culturePrintName} </tr>";
                    tableCells += $"<tr><td class='th'>Vessel ID</td><td class='th'></td> {vesselId} </tr>";
                    tableCells += $"<tr><td class='th'>Passage Number</td><td class='th'></td> {passageNumber} </tr>";
                    tableCells += $"<tr><td class='th'>Generation Number</td><td class='th'></td> {generationNumber}</tr>";
               
                    tableRows += tableCells;
                }
            }


            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        
    }
}
