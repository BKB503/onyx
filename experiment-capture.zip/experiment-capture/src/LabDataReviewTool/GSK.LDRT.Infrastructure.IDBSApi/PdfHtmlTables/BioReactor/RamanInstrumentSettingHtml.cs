﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class RamanInstrumentSettingHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var ramanInstrumentSettings = JsonConvert.DeserializeObject<List<RamanInstrumentSetting>>(spreadSheetPdfTableModel.TableData);
            var uoMRamanInstrumentSettings = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Raman Instrument Settings");
            var uoMRamanInstrumentSettingsData = (List<UoMRamanInstrumentSetting>)JsonConvert.DeserializeObject<List<UoMRamanInstrumentSetting>>(uoMRamanInstrumentSettings.Data.ToString());
           
            var filteredData = ramanInstrumentSettings.Where(x => !string.IsNullOrEmpty(x.hRowshow.NumberValue)).ToList();

            return $"{BuildHtml(filteredData, uoMRamanInstrumentSettingsData, spreadSheetPdfTableModel.TableName)}";
        }

       
        private string BuildHtml(List<RamanInstrumentSetting> ramanInstrumentSettings, List<UoMRamanInstrumentSetting> uoMRamanInstrumentSettingsData, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMRamanInstrumentSettingsData))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";


            foreach (var item in ramanInstrumentSettings)
            {
                var dateofInstrumentVerification = "";
                if (item.DateofInstrumentVerification != null && item.DateofInstrumentVerification.Value != null && item.DateofInstrumentVerification.Value.HasValue)
                {
                    dateofInstrumentVerification = item.DateofInstrumentVerification.Value.Value.ToString("MMM dd, yyyy");
                }
                var testStartDateTime = "";
                if (item.TestStartDateTime != null && item.TestStartDateTime.Value != null && item.TestStartDateTime.Value.HasValue)
                {
                    testStartDateTime = item.TestStartDateTime.Value.Value.ToString("MMM dd, yyyy");
                }

                var tableCells = "";
               
                tableCells += $"<td class='td'>{item.ReactorIndex?.Value} </td>";
                tableCells += $"<td class='td'>{item.InstrumentSettingsIndex?.Value} </td>";
                tableCells += $"<td class='td'>{item.ProbeId?.Value} </td>";
                tableCells += $"<td class='td'>{item.AcquisitionTime?.NumberValue} </td>";
                tableCells += $"<td class='td'>{item.LaserPower?.NumberValue} </td>";
                tableCells += $"<td class='td'>{item.LaserWavelength?.NumberValue} </td>";
                tableCells += $"<td class='td'>{item.NumberofScans?.NumberValue} </td>";
                tableCells += $"<td class='td'>{item.ExposureTime?.NumberValue} </td>";
                tableCells += $"<td class='td'>{item.SpectralCoverage?.NumberValue} </td>";
                tableCells += $"<td class='td'>{item.SpectralResolution?.NumberValue} </td>";
                tableCells += $"<td class='td'>{dateofInstrumentVerification} </td>";
                tableCells += $"<td class='td'>{testStartDateTime} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }



            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Probe ID",
                "Acquisition Time",
                "Laser Power",
                "Laser Wavelength",
                "Number of Scans",
                "Exposure Time",
                "Spectral Coverage",
                "Spectral Resolution",
                "Date of Instrument Verification",
                "Test Start Date/ Time",
               
            };
        }

        private List<string> SubHeaders(List<UoMRamanInstrumentSetting> uoMRamanInstrumentSettings)
        {
            var acquisitionTime = uoMRamanInstrumentSettings.FirstOrDefault(x => x.Column.Value == "Acquisition Time").UoM?.Value;
            var laserPower = uoMRamanInstrumentSettings.FirstOrDefault(x => x.Column.Value == "Laser Power").UoM?.Value;
            var laserWavelength = uoMRamanInstrumentSettings.FirstOrDefault(x => x.Column.Value == "Laser Wavelength").UoM?.Value;
            var exposureTime = uoMRamanInstrumentSettings.FirstOrDefault(x => x.Column.Value == "Exposure Time").UoM?.Value;
            var spectralResolution = uoMRamanInstrumentSettings.FirstOrDefault(x => x.Column.Value == "Spectral Resolution").UoM?.Value;
            return new List<string>
            {
                "",
                "",
                "",
                acquisitionTime,
                laserPower,
                laserWavelength,
                "Number of Scans",
                exposureTime,
                "Spectral Coverage",
                spectralResolution,
                "",
                "",

            };
        }



    }
}
