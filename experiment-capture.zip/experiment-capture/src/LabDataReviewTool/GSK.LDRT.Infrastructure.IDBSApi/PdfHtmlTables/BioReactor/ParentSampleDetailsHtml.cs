﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ParentSampleDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var parentSampleDetails = JsonConvert.DeserializeObject<List<ParentSampleDetails>>(spreadSheetPdfTableModel.TableData);
            var uoMParentSampleDetails = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Parent Sample Details");
            var uoMParentSampleDetailsData = (List<UoMParentSampleDetails>)JsonConvert.DeserializeObject<List<UoMParentSampleDetails>>(uoMParentSampleDetails.Data.ToString());
            var filteredData = new List<ParentSampleDetails>();

            filteredData = parentSampleDetails.Where(x => !string.IsNullOrEmpty(x.SampleVolume.NumberValue)).ToList();
          
            return $"{BuildHtml(filteredData, uoMParentSampleDetailsData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<ParentSampleDetails> parentSampleDetails, List<UoMParentSampleDetails> uoMFeedDetailsData, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMFeedDetailsData))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedReactorIndexs = parentSampleDetails.GroupBy(x => x.ReactorIndex.Value, (key, group) => new { ReactorIndex = key, Items = group.ToList() });
            foreach (var groupedReactorIndex in groupedReactorIndexs)
            {
                if (groupedReactorIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedReactorIndex.Items.Count}'>{groupedReactorIndex.ReactorIndex} </td>";
                    var groupedDayIndex = groupedReactorIndex.Items.GroupBy(x => x.DayIndex.Value, (key, group) => new { DayIndex = key, DayIndexValues = group.ToList() });
                    foreach (var dayIndex in groupedDayIndex)
                    {
                        tableCells += $"<td class='td' rowspan='{dayIndex.DayIndexValues.Count}'>{dayIndex.DayIndex} </td>";
                        foreach (var item in dayIndex.DayIndexValues)
                        {
                            var samplingDate = "";
                            if (item.SamplingDate != null && item.SamplingDate.Value != null && item.SamplingDate.Value.HasValue)
                            {
                                samplingDate = item.SamplingDate.Value.Value.ToString("MMM dd, yyyy");
                            }
                            var samplingTime24h = "";
                            if (item.SamplingTime24h != null && item.SamplingTime24h.Value != null && item.SamplingTime24h.Value.HasValue)
                            {
                                samplingTime24h = item.SamplingTime24h.Value.Value.ToString("MMM dd, yyyy");
                            }
                            tableCells += $"<td class='td'>{item.ParentSampleIndex?.Value} </td>";
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.SampleId?.Value} </td>";
                            tableCells += $"<td class='td'>{samplingDate} </td>";
                            tableCells += $"<td class='td'>{samplingTime24h} </td>";
                            tableCells += $"<td class='td'>{item.SampleVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.NumberofAdditionalAliquots?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.ElapsedTime?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.LinkSampleResultstoIntermediateCultures?.Value} </td>";
                            tableCells += $"<td class='td'>{item.CultureWorkingVolume?.Value} </td>";
                            tableCells += $"<td class='td'>{item.Comments?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "",
                "Sample Name",
                "Sample ID",
                "Sampling Date",
                "Sampling Time (24h)",
                "Sample Volume",
                "Number of Additional Aliquots (if >1)",
                "Elapsed Time",
                "Link Sample Results to Intermediate Cultures?",
                "Culture Working Volume",
                "Comments"
              
            };
        }

        private List<string> SubHeaders(List<UoMParentSampleDetails> uoMParentSampleDetails)
        {
            var sampleVolume = uoMParentSampleDetails.FirstOrDefault(x => x.Column?.Value == "Sample Volume").UoM.Value;
            var elapsedTime = uoMParentSampleDetails.FirstOrDefault(x => x.Column?.Value == "Elapsed Time").UoM.Value;
            var cultureWorkingVolume = uoMParentSampleDetails.FirstOrDefault(x => x.Column?.Value == "Culture Working Volume" || x.Column?.Value == "Current Culture Volume").UoM?.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                sampleVolume,
                "",
               elapsedTime,
                "",
                cultureWorkingVolume,
                "Comments"
            };
        }



    }
}
