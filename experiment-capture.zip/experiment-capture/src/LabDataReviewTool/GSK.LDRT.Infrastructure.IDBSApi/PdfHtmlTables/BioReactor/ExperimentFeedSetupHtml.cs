﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ExperimentFeedSetupHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel SpreadSheetPdfTableModel)
        {
           
            var experimentFeedSetups = JsonConvert.DeserializeObject<List<ExperimentFeedSetup>>(SpreadSheetPdfTableModel.TableData.ToString()).ToList();

            return CreateHtml(experimentFeedSetups, SpreadSheetPdfTableModel.TableName) ;
        }

      
        private string CreateHtml(List<ExperimentFeedSetup> experimentFeedSetups, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr> </thead>";

            foreach (var experimentFeedSetup in experimentFeedSetups)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{experimentFeedSetup.FeedConfiguration?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.ConditionName?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed1InventoryItem?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed1FeedUnit?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed1InputType?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed1FeedType?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed2InventoryItem?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed2FeedUnit?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed2InputType?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed2FeedType?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed3InventoryItem?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed3FeedUnit?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed3InputType?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.Feed3FeedType?.Value} </td>";
                tableCells += $"<td class='td'>{experimentFeedSetup.MaximumNumberofFeedEvents?.NumberValue} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Feed Configuration",
                "Condition Name",
                "Feed 1 Inventory Item",
                "Feed 1 Feed Unit",
                "Feed 1 Input Type",
                "Feed 1 Feed Type",
                "Feed 2 Inventory Item",
                "Feed 2 Feed Unit",
                "Feed 2 Input Type",
                "Feed 2 Feed Type",
                "Feed 3 Inventory Item",
                "Feed 3 Feed Unit",
                "Feed 3 Input Type",
                "Feed 3 Feed Type",
                "Maximum Number of Feed Events"
            };
        }
  
       
    }
}
