﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class YSIDataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var ysiDataEntrys = JsonConvert.DeserializeObject<List<YSIDataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMYsiDataEntrys = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_YSI Data Entry");
            var uoMYsiDataEntrysData = (List<UoMYSIDataEntry>)JsonConvert.DeserializeObject<List<UoMYSIDataEntry>>(uoMYsiDataEntrys.Data.ToString());
            var filteredData = new List<YSIDataEntry>();

            filteredData = ysiDataEntrys.Where(x => !string.IsNullOrEmpty(x.SampleName.Value)).ToList();
           
            return $"{BuildHtml(filteredData, uoMYsiDataEntrysData, spreadSheetPdfTableModel.TableName)}";
        }

       
        private string BuildHtml(List<YSIDataEntry> ysiDataEntrys, List<UoMYSIDataEntry> uoMYsiDataEntrys, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMYsiDataEntrys))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedYsiDataEntryIndexs = ysiDataEntrys.GroupBy(x => x.YSIAliquotIndex.Value, (key, group) => new { YSIAliquotIndex = key, Items = group.ToList() });
            foreach (var groupedYsiDataEntryIndex in groupedYsiDataEntryIndexs)
            {
                if (groupedYsiDataEntryIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedYsiDataEntryIndex.Items.Count}'>{groupedYsiDataEntryIndex.YSIAliquotIndex} </td>";
                    var groupedInputMethods = groupedYsiDataEntryIndex.Items.GroupBy(x => x.InputMethod.Value, (key, group) => new { InputMethod = key, InputMethodValues = group.ToList() });
                    foreach (var inputMethod in groupedInputMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{inputMethod.InputMethodValues.Count}'>{inputMethod.InputMethod} </td>";
                        foreach (var item in inputMethod.InputMethodValues)
                        {   
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.InstrumentSampleIdOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementEquipment?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.GlucoseConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.LactateConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Ignore?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Sample Name",
                "DCA ID",
                "Instrument Sample ID Override",
                "Measurement Equipment",
                "Measurement Date",
                "Glucose Concentration",
                "Lactate Concentration",
                "Ignore?"

            };
        }

        private List<string> SubHeaders(List<UoMYSIDataEntry> uoMYsiDataEntrys)
        {
            var glucose = uoMYsiDataEntrys.FirstOrDefault(x => x.Column.Value == "Glucose Concentration").UoM.Value;
            var lactate = uoMYsiDataEntrys.FirstOrDefault(x => x.Column.Value == "Lactate Concentration").UoM.Value;
            return new List<string>
            {
               "",
                "",
                "",
                "",
                "",
                "",
                "",
                glucose,
                lactate,
                ""
            };
        }



    }
}
