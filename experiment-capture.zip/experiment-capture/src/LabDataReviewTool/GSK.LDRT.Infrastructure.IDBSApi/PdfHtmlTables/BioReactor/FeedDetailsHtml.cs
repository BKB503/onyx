﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class FeedDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var feedDetails = JsonConvert.DeserializeObject<List<FeedDetails>>(spreadSheetPdfTableModel.TableData);
            var uoMFeedDetails = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Feed Details");
            var uoMFeedDetailsData = new List<UoMFeedDetails>();
            if (uoMFeedDetails != null && uoMFeedDetails.Data != null)
            {
             uoMFeedDetailsData =   JsonConvert.DeserializeObject<List<UoMFeedDetails>>(uoMFeedDetails.Data.ToString());
            }
            var filteredData = new List<FeedDetails>();

            filteredData = feedDetails.Where(x => x.HFeedRowshow?.NumberValue == "1.0").ToList();
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{BuildHtml(filteredData, uoMFeedDetailsData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<FeedDetails> feedDetails, List<UoMFeedDetails> uoMFeedDetailsData, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMFeedDetailsData))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedReactorIndexs = feedDetails.GroupBy(x => x.ReactorIndex.Value, (key, group) => new { ReactorIndex = key, Items = group.ToList() });
            foreach (var groupedReactorIndex in groupedReactorIndexs)
            {
                if (groupedReactorIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedReactorIndex.Items.Count}'>{groupedReactorIndex.ReactorIndex} </td>";
                    var groupedFeedIndex = groupedReactorIndex.Items.GroupBy(x => x.FeedIndex.Value, (key, group) => new { FeedIndex = key, FeedIndexValues = group.ToList() });
                    foreach (var feedIndex in groupedFeedIndex)
                    {
                        tableCells += $"<td class='td' rowspan='{feedIndex.FeedIndexValues.Count}'>{feedIndex.FeedIndex} </td>";
                        foreach (var item in feedIndex.FeedIndexValues)
                        {
                            var feedDate = "";
                            if (item.FeedDate != null && item.FeedDate.Value != null && item.FeedDate.Value.HasValue)
                            {
                                feedDate = item.FeedDate.Value.Value.ToString("MMM dd, yyyy");
                            }
                            var feedTime24h = "";
                            if (item.FeedTime24h != null && item.FeedTime24h.Value != null && item.FeedTime24h.Value.HasValue)
                            {
                                feedTime24h = item.FeedTime24h.Value.Value.ToString("MMM dd, yyyy");
                            }
                            tableCells += $"<td class='td'>{item.ConditionName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.FeedId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.FeedType?.Value} </td>";
                            tableCells += $"<td class='td'>{item.FeedInputType?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DayIndex.Value} </td>";
                            tableCells += $"<td class='td'>{feedDate} </td>";
                            tableCells += $"<td class='td'>{feedTime24h} </td>";
                            tableCells += $"<td class='td'>{item.FeedAdditionSetpoint?.Value} </td>";
                            tableCells += $"<td class='td'>{item.FeedAdditionSetpointUnit?.Value} </td>";
                            tableCells += $"<td class='td'>{item.FeedAdditionSetpointOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.WorkingVolume?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Condition Name",
                "Feed ID",
                "Feed Type",
                "Feed Input Type",
                "Day_Index",
                "Feed Date",
                "Feed Time (24h)",
                "Feed Addition Setpoint",
                "Feed Addition Setpoint Unit",
                "Feed Addition Setpoint Override",
                "Working Volume"
              
            };
        }

        private List<string> SubHeaders(List<UoMFeedDetails> uoMFeedDetailsData)
        {
            var workingVolume = uoMFeedDetailsData.FirstOrDefault(x => x.Column.Value == "Working Volume")?.UoM.Value;
            return new List<string>
            {
                 "",
                 "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                workingVolume
            };
        }



    }
}
