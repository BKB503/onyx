﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class DCAIdLablesHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var dCAIdLabels = JsonConvert.DeserializeObject<List<DCAIdLabels>>(spreadSheetPdfTableModel.TableData);
            var filteredData = dCAIdLabels.Where(x => !string.IsNullOrEmpty(x.SampleDescription.Value)).ToList();
            return $"{BuildHtml(filteredData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<DCAIdLabels> dCAIdLabels, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var dCAIdLabel in dCAIdLabels)
            {   
                var tableCells = "";
                tableCells += $"<td class='td'>{dCAIdLabel.SampleLabelIndex?.Value} </td>";
                tableCells += $"<td class='td'>{dCAIdLabel.SampleDescription?.Value} </td>";
                tableCells += $"<td class='td'>{dCAIdLabel.SelfAnalysis?.Value} </td>";
                tableCells += $"<td class='td'>{dCAIdLabel.MudId?.Value} </td>";
                tableCells += $"<td class='td'>{dCAIdLabel.SamplingDate?.Value} </td>";
                tableCells += $"<td class='td'>{dCAIdLabel.Bioreactor?.Value} </td>";
                tableCells += $"<td class='td'>{dCAIdLabel.LabelName?.Value} </td>";
                
                tableRows += $"<tr>{tableCells}</tr> ";
            }
            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Sample Label Index",
                "Sample Description",
                "Self-Analysis",
                "MUD ID",
                "Sampling Date",
                "Bioreactor #",
                "Label Name",
            };
        }

    }
}
