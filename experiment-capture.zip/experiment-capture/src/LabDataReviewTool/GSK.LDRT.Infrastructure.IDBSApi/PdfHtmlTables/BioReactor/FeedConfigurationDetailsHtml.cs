﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class FeedConfigurationDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var feedConfigurationDetails = JsonConvert.DeserializeObject<List<FeedConfigurationDetails>>(spreadSheetPdfTableModel.TableData);
            var filteredData = new List<FeedConfigurationDetails>();

            filteredData = feedConfigurationDetails.Where(x => !string.IsNullOrEmpty(x.hFeedFilter.NumberValue)).ToList();

            return $"{BuildHtml(filteredData, spreadSheetPdfTableModel.TableName)}";
        }

       
        private string BuildHtml(List<FeedConfigurationDetails> feedConfigurationDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
       

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedFeedConfigurationDetails = feedConfigurationDetails.GroupBy(x => x.FeedConfiguration.Value, (key, group) => new {FeedConfiguration= key, Items = group.ToList()});
            foreach (var feedConfigurationDetail in groupedFeedConfigurationDetails)
            {  

                if (feedConfigurationDetail.Items.Any())
                {  
                    foreach (var item in feedConfigurationDetail.Items)
                    {
                        var tableCells = "";
                        if ((feedConfigurationDetail.Items.IndexOf(item) == 0))
                        {
                            tableCells += $"<td class='td' rowspan='{feedConfigurationDetail.Items.Count}'>{feedConfigurationDetail.FeedConfiguration} </td>";
                        }
                        tableCells += $"<td class='td'>{item.RowIndex?.Value} </td>";
                        tableCells += $"<td class='td'>{item.DayIndex?.Value} </td>";
                        tableCells += $"<td class='td'>{item.FeedNumber?.Value} </td>";
                        tableCells += $"<td class='td'>{item.FeedAdditionSetpoint?.Value} </td>";
                        tableCells += $"<td class='td'>{item.FeedAdditionSetpointUnit?.Value} </td>";
                        tableCells += $"<td class='td'>{item.FeedInputType?.Value} </td>";
                       
                        tableRows += $"<tr>{tableCells}</tr> ";
                    }
                    
                }
                
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "Feed Configuration",
                "Row Index",
                "Day_Index",
                "Feed Number",
                "Feed Addition Setpoint",
                "Feed Addition Setpoint Unit",
                "Feed Input Type",
              
            };
        }





    }
}
