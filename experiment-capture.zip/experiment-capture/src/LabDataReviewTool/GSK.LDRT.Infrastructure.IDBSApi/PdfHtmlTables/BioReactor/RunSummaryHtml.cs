﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class RunSummaryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var runSummaries = JsonConvert.DeserializeObject<List<RunSummary>>(spreadSheetPdfTableModel.TableData);
            // var filteredData = runSummaries.Where(x => !string.IsNullOrEmpty(x.HRunSummaryReactor.NumberValue)).ToList();
            var uoMRunSummariesData = new List<UoMRunSummary>();
            var uoMRunSummaries = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Run Summary");
            if (uoMRunSummaries != null && uoMRunSummaries.Data != null)
            {
                uoMRunSummariesData = JsonConvert.DeserializeObject<List<UoMRunSummary>>(uoMRunSummaries.Data.ToString());
            }
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{BuildHtml(runSummaries, uoMRunSummariesData, spreadSheetPdfTableModel.TableName)}";
        }

      
        private string BuildHtml(List<RunSummary> runSummaries, List<UoMRunSummary> uoMRunSummaries, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string> { "", "" };
            var subHeaders = new List<string> { "", "" };
            var runDurationUom = uoMRunSummaries.FirstOrDefault(x => x.Column?.Value == "Run Duration");
            var finalVolumeUom = uoMRunSummaries.FirstOrDefault(x => x.Column?.Value == "Final Volume");
            
            foreach (var runSummary in runSummaries)
            {
                headers.Add(runSummary?.ReactorIndex?.Value);
                subHeaders.Add(runSummary?.CulturePrintName?.Value);
            }

            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in subHeaders)
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr><tr>{tableSubHeaderCells} </tr></thead>";
            
            string runDuration=""; string finalVolume = "";string storageLocationId = "";
            string isPoolingRequired = ""; string generalCultureId = ""; string batchId = "";
            string culturePrintName = ""; string isCentrifuged = ""; string centrifugeGroup = ""; 
            foreach (var runSummary in runSummaries)
            {
               runDuration +=  $"<td class='td'>{runSummary.RunDuration?.NumberValue} </td>";
               finalVolume += $"<td class='td'>{runSummary.FinalVolume?.NumberValue} </td>";
               storageLocationId += $"<td class='td'>{runSummary.StorageLocationId?.Value} </td>";
               isPoolingRequired += $"<td class='td'>{runSummary.IsPoolingRequired?.Value} </td>";
               generalCultureId += $"<td class='td'>{runSummary.GeneratedCultureId?.Value} </td>";
               batchId += $"<td class='td'>{runSummary.BatchId?.Value} </td>";
               culturePrintName += $"<td class='td'>{runSummary.CulturePrintName?.Value} </td>";
               isCentrifuged += $"<td class='td'>{runSummary.IsCentrifuged?.Value} </td>";
               centrifugeGroup += $"<td class='td'>{runSummary.CentrifugeGroup?.Value} </td>";
              
                if (runSummaries.LastIndexOf(runSummary) == runSummaries.Count - 1)
                {
                    var tableCells = "";
                    tableCells += $"<tr><td class='th'>Run Duration</td><td class='th'> {runDurationUom?.UoM?.Value}</td>{runDuration}</tr>";
                    tableCells += $"<tr><td class='th'>Final Volume</td><td class='th'> {finalVolumeUom?.UoM?.Value}</td> {finalVolume} </tr>";
                    tableCells += $"<tr><td class='th'>Storage Location ID</td><td class='th'> </td> {storageLocationId}</tr>";
                    tableCells += $"<tr><td class='th'>Is Pooling Required?</td><td class='th'> </td> {isPoolingRequired} </tr>";
                    tableCells += $"<tr><td class='th'>Generated Culture ID</td><td class='th'> </td> {generalCultureId} </tr>";
                    tableCells += $"<tr><td class='th'>Batch ID</td><td class='th'> </td> {batchId} </tr>";
                    tableCells += $"<tr><td class='th'>Culture Print Name</td><td class='th'> </td> {culturePrintName} </tr>";
                    tableCells += $"<tr><td class='th'>Is Centrifuged?</td><td class='th'> </td> {isCentrifuged} </tr>";
                    tableCells += $"<tr><td class='th'>Centrifuge group</td><td class='th'> </td> {centrifugeGroup} </tr>";
                 
                    tableRows += tableCells;
                }

               
            }


            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        
    }
}
