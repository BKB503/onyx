﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class SolutionParametersHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var solutionParameters = JsonConvert.DeserializeObject<List<SolutionParameters>>(spreadSheetPdfTableModel.TableData);
         
           
            return $"{BuildHtml(solutionParameters, spreadSheetPdfTableModel.TableName)}";
        }


        private string BuildHtml(List<SolutionParameters> solutionParameters,  string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
           
            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  </thead>";

            var groupedSolutionParameters = solutionParameters.GroupBy(x => x.SolutionIndex.Value, (key, group) => new {SolutionIndex= key, Items = group.ToList()});
            foreach (var sp in groupedSolutionParameters)
            {  

                if (sp.Items.Any())
                {  
                    foreach (var item in sp.Items)
                    {
                        var preparedOn = "";
                        if (item.PreparedOn != null && item.PreparedOn.Value != null && item.PreparedOn.Value.HasValue)
                        {
                            preparedOn = item.PreparedOn.Value.Value.ToString("MMM dd, yyyy");
                        }
                        var tableCells = "";
                        if ((sp.Items.IndexOf(item) == 0))
                        {
                            tableCells += $"<td class='td' rowspan='{sp.Items.Count}'>{sp.SolutionIndex} </td>";
                        }
                        tableCells += $"<td class='td'>{item.CustomName.Value} </td>";
                        tableCells += $"<td class='td'>{item.Filtered.Value} </td>";
                        tableCells += $"<td class='td'>{item.PreparedBy.Value} </td>";
                        tableCells += $"<td class='td'>{preparedOn} </td>";
                        tableCells += $"<td class='td'>{item.Comments.Value} </td>";
                       
                        tableRows += $"<tr>{tableCells}</tr> ";
                    }
                    
                }
                
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "Solution Index",
                "Custom Name",
                "Filtered?",
                "Prepared By",
                "Prepared On",
                "Comments"
              
            };
        }

  


    }
}
