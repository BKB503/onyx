﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class ExperimentSetupDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel SpreadSheetPdfTableModel)
        {
            var experimentSetupDetails = (List<ExperimentSetupDetails>)JsonConvert.DeserializeObject<List<ExperimentSetupDetails>>(SpreadSheetPdfTableModel.TableData);
            var firstRow = experimentSetupDetails?.FirstOrDefault();
            var keyValues = new Dictionary<string, string>();

            keyValues.Add("Study Number", firstRow.StudyNumber.Value);
            keyValues.Add("Organization", firstRow.Organization.Value);
            keyValues.Add("Experiment Title", firstRow.ExperimentTitle.Value);
            keyValues.Add("Experiment Title Suffix", firstRow.ExperimentTitleSuffix.Value);
            keyValues.Add("Experiment ID", firstRow.ExperimentId.Value);
            keyValues.Add("Experiment Purpose", firstRow.ExperimentPurpose.Value);
            keyValues.Add("Location", firstRow.Location.Value);
            keyValues.Add("Bioreactor Type", firstRow.BioreactorType.Value);
            keyValues.Add("Perfusion Experiment ?", firstRow.PerfusionExperiment.Value);
            if (firstRow.PerfusionExperiment != null && firstRow.PerfusionExperiment.Value != null && firstRow.PerfusionExperiment.Value == "Yes")
            {
                keyValues.Add("Additional Feeding Required?", firstRow.AdditionalFeedingRequired.Value);
                keyValues.Add("Capacitance Controlled?", firstRow.CapacitanceControlled.Value);
            }
            if (firstRow.PerfusionExperiment != null && firstRow.PerfusionExperiment.Value != null && firstRow.PerfusionExperiment.Value == "No")
            {
                keyValues.Add("CSFR Controlled?", firstRow.CSFRControlled.Value);
            }
            if (firstRow.BioreactorType != null && firstRow.BioreactorType.Value != null)
            {
                if (firstRow.BioreactorType.Value == "Ambr" && firstRow.BioreactorType.Value == "Shake Flask")
                {
                    keyValues.Add("Number of Reactors", firstRow.NumberofReactors.NumberValue);
                }
            }

            keyValues.Add("Number of Culture", firstRow.NumberofCulture?.NumberValue);
            keyValues.Add("Number of Inoculation Sets (Auto-populated post Culture Retrieval)", firstRow.NumberofInoculationSets?.NumberValue);
            keyValues.Add("Override Number of Inoculation Sets", firstRow.OverrideNumberofInoculationSets?.NumberValue);
            keyValues.Add("Import Culture from Batch", firstRow.ImportCulturefromBatch?.Value);
            keyValues.Add("Experiment Procedure", firstRow.ExperimentProcedure?.Value);
            if (firstRow.BioreactorType != null && firstRow.BioreactorType.Value != null)
            {
                if (firstRow.BioreactorType.Value == "Ambr")
                {
                    keyValues.Add("ambr Data Export Path", firstRow.AmbrDataExportPath.Value);
                }
            }
            keyValues.Add("Comments", firstRow.Comments.Value);

            return BuildFirstRowTableHtml(keyValues, SpreadSheetPdfTableModel.TableName);
        }

        private string BuildFirstRowTableHtml(Dictionary<string, string> data, string tableName)
        {
            var tableRows = "";
            foreach (var item in data)
            {
                tableRows += $"<tr><td class='td'> <b>{item.Key}</b> </td> <td class='td'> {item.Value} </td> </tr>";
            }
            var tableBody = $"<tbody> {tableRows}</tbody>";
            var table = $"<table class='table'> <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody} </table>";
            return table;
        }
    }
}
