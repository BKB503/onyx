﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class RAPIDPoint500DataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var rapidPoint500DataEntrys = JsonConvert.DeserializeObject<List<RAPIDPoint500DataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMRapidPoint500DataEntrys = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_RAPIDPoint 500 Data Entry");
            var uoMRapidPoint500Data = (List<UoMRAPIDPoint500DataEntry>)JsonConvert.DeserializeObject<List<UoMRAPIDPoint500DataEntry>>(uoMRapidPoint500DataEntrys.Data.ToString());
            var filteredData = new List<RAPIDPoint500DataEntry>();

            filteredData = rapidPoint500DataEntrys.Where(x => !string.IsNullOrEmpty(x.SampleName.Value)).ToList();
           
            return $"{BuildHtml(filteredData, uoMRapidPoint500Data, spreadSheetPdfTableModel.TableName)}";
        }

       
        private string BuildHtml(List<RAPIDPoint500DataEntry> rapidPoint500DataEntrys, List<UoMRAPIDPoint500DataEntry> uoMRapidPoint500DataEntrys, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMRapidPoint500DataEntrys))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedRAPIDPointAliquotIndexs = rapidPoint500DataEntrys.GroupBy(x => x.RAPIDPointAliquotIndex.Value, (key, group) => new { RAPIDPointAliquotIndex = key, Items = group.ToList() });
            foreach (var groupedRAPIDPointAliquotIndex in groupedRAPIDPointAliquotIndexs)
            {
                if (groupedRAPIDPointAliquotIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedRAPIDPointAliquotIndex.Items.Count}'>{groupedRAPIDPointAliquotIndex.RAPIDPointAliquotIndex} </td>";
                    var groupedInputMethods = groupedRAPIDPointAliquotIndex.Items.GroupBy(x => x.InputMethod.Value, (key, group) => new { InputMethod = key, InputMethodValues = group.ToList() });
                    foreach (var inputMethod in groupedInputMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{inputMethod.InputMethodValues.Count}'>{inputMethod.InputMethod} </td>";
                        foreach (var item in inputMethod.InputMethodValues)
                        {   
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.InstrumentSampleIdOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementEquipment?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.CalciumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GlucoseConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.LactateConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PH?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PCO2?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PO2?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PotassiumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.SodiumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.ChlorideConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PCO2AtTemperature?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PO2AtTemperature?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PHAtTemperature?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TemperatureSetpoint?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Ignore?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Sample Name",
                "DCA ID",
                "Instrument Sample ID Override",
                "Measurement Equipment",
                "Measurement Date",
                "Calcium Concentration",
                "Glucose Concentration",
                "Lactate Concentration",
                "pH",
                "pCO2",
                "pO2",
                "Potassium Concentration",
                "Sodium Concentration",
                "Chloride Concentration",
                "pCO2 at temperature",
                "pO2 at Temperature",
                "pH at Temperature",
                "Temperature Setpoint",
                "Ignore?"

            };
        }

        private List<string> SubHeaders(List<UoMRAPIDPoint500DataEntry> uoMFlex2CedexDataEntrys)
        {
            var calciumConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Calcium Concentration")?.UoM?.Value;
            var glucoseConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Glucose Concentration")?.UoM?.Value;
            var pCO2 = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pCO2")?.UoM?.Value;
            var pO2 = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pO2")?.UoM?.Value;
            var potassiumConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Potassium Concentration")?.UoM?.Value;
            var sodiumConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Sodium Concentration")?.UoM?.Value;
            var chlorideConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Chloride Concentration")?.UoM?.Value;
            var pCO2attemperature = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pCO2 at temperature")?.UoM?.Value;
            var pO2atTemperature = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pO2 at Temperature")?.UoM?.Value;
            var temperatureSetpoint = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Temperature Setpoint" || x.Column.Value == "Temperature")?.UoM?.Value;
           
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                calciumConcentration,
                glucoseConcentration,
                "",
                "",
                pCO2,
                pO2,
                potassiumConcentration,
                sodiumConcentration,
                chlorideConcentration,
                pCO2attemperature,
                pO2atTemperature,
                "",
                temperatureSetpoint,
                ""
            };
        }



    }
}
