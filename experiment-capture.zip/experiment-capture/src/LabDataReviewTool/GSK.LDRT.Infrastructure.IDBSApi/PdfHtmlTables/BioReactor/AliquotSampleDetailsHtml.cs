﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class AliquotSampleDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var aliquotSampleDetails = JsonConvert.DeserializeObject<List<AliquotSampleDetails>>(spreadSheetPdfTableModel.TableData);
            var uoMAliquotSampleDetails = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Aliquot Sample Details");
            var uoMAliquotSampleDetailsData = (List<UoMAliquotSampleDetails>)JsonConvert.DeserializeObject<List<UoMAliquotSampleDetails>>(uoMAliquotSampleDetails.Data.ToString());
            var filteredData = new List<AliquotSampleDetails>();

            filteredData = aliquotSampleDetails.Where(x => x.HAliquotFilter.NumberValue == "1.0").ToList();
            
            return $"{BuildHtml(filteredData, uoMAliquotSampleDetailsData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<AliquotSampleDetails> aliquotSampleDetails, List<UoMAliquotSampleDetails> uoMAliquotSampleDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMAliquotSampleDetails))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedReactorIndexs = aliquotSampleDetails.GroupBy(x => x.ReactorIndex.Value, (key, group) => new { ReactorIndex = key, Items = group.ToList() });
            foreach (var groupedReactorIndex in groupedReactorIndexs)
            {
                if (groupedReactorIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedReactorIndex.Items.Count}'>{groupedReactorIndex.ReactorIndex} </td>";
                    var groupedDayIndex = groupedReactorIndex.Items.GroupBy(x => x.DayIndex.Value, (key, group) => new { DayIndex = key, DayIndexValues = group.ToList() });
                    foreach (var dayIndex in groupedDayIndex)
                    {
                        tableCells += $"<td class='td' rowspan='{dayIndex.DayIndexValues.Count}'>{dayIndex.DayIndex} </td>";
                        foreach (var item in dayIndex.DayIndexValues)
                        {
                            tableCells += $"<td class='td'>{item.ParentSampleIndex?.Value} </td>";
                            tableCells += $"<td class='td'>{item.AliquotIndex?.Value} </td>";
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.SampleId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.TestingType?.Value} </td>";
                            tableCells += $"<td class='td'>{item.SelfAnalysis?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.SampleVolume?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.SubmitToAnalyst?.Value} </td>";
                            tableCells += $"<td class='td'>{item.LotType?.Value} </td>";
                            tableCells += $"<td class='td'>{item.AnalyticalAssay?.Value} </td>";
                            tableCells += $"<td class='td'>{item.AssayVariation?.Value} </td>";
                            tableCells += $"<td class='td'>{item.Titre?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.NLSException?.Value} </td>";
                            tableCells += $"<td class='td'>{item.NLSSampleNumber?.Value} </td>";
                            tableCells += $"<td class='td'>{item.NLSExperimentNumber?.Value} </td>";
                            tableCells += $"<td class='td'>{item.Comments?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "Sample Name",
                "Sample ID",
                "Testing Type",
                "Self-Analysis",
                "DCA ID",
                "Sample Volume",
                "Submit to Analyst",
                "Lot Type",
                "Analytical Assay",
                "Assay Variatione",
                "Titre",
                "NLS Exception",
                "NLS Sample Number",
                "NLS Experiment Number",
                "Comments"

            };
        }

        private List<string> SubHeaders(List<UoMAliquotSampleDetails> uoMAliquotSampleDetails)
        {
            var sampleVolume = uoMAliquotSampleDetails.FirstOrDefault(x => x.Column.Value == "Sample Volume").UoM.Value;
            var titre = uoMAliquotSampleDetails.FirstOrDefault(x => x.Column.Value == "Titre").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                sampleVolume,
                "",
                "",
                "",
                "",
                titre,
                "",
                "",
                "",
                ""
            };
        }



    }
}
