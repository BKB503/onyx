﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class AnalyticalSampleLabelHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var analyticalSampleLabels = JsonConvert.DeserializeObject<List<AnalyticalSampleLabel>>(spreadSheetPdfTableModel.TableData);
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{BuildHtml(analyticalSampleLabels, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<AnalyticalSampleLabel> analyticalSampleLabels, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var analyticalSampleLabel in analyticalSampleLabels)
            {
                var date = "";
                if (analyticalSampleLabel.Date != null && analyticalSampleLabel.Date.Value != null && analyticalSampleLabel.Date.Value.HasValue)
                {
                    date = analyticalSampleLabel.Date.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{analyticalSampleLabel.AnalyticalSampleLabelIndex.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.ExperimentId?.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.UserId?.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.SampleName?.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.CompoundId?.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.SampleId?.Value} </td>";
                tableCells += $"<td class='td'>{date} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.Concentration?.NumberValue} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.ConcentrationUnit?.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.TestAnalysis?.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.TestVariation?.Value} </td>";
                tableCells += $"<td class='td'>{analyticalSampleLabel.SampleDescription?.Value} </td>";

                tableRows += $"<tr>{tableCells}</tr> ";
            }
            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Analytical Sample Label Index",
                "Experiment ID",
                "User ID",
                "Sample Name",
                "Compound ID",
                "Sample ID",
                "Date",
                "Concentration",
                "Concentration Unit",
                "Test Analysis",
                "Test Variation",
                "Sample Description"
            };
        }

    }
}
