﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class CompoundsAndProjectsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel SpreadSheetPdfTableModel)
        {
           
            var compoundsAndProjectsData = JsonConvert.DeserializeObject<List<CompoundsAndProjects>>(SpreadSheetPdfTableModel.TableData.ToString()).ToList();

            var getCompoundAndProjectsFilter = SpreadSheetPdfTableModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Compounds and Projects").FilterIdentifier;
            //var filteredData = compoundsAndProjectsData.Where(x => x.CompoundsAndProjectsId.Value != getCompoundAndProjectsFilter.Value).ToList();
            return CreateCompundsAndProjectHtml(compoundsAndProjectsData, SpreadSheetPdfTableModel.TableName) ;
        }

        private string CreateCompundsAndProjectHtml(List<CompoundsAndProjects> compoundsAndProjects, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in ComppundsAndProjectsHeader())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var compoundsAndProject in compoundsAndProjects)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{compoundsAndProject.CompoundsAndProjectsId?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.CompoundId?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.Project?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.ProjectId?.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.ProjectIdOverride?.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> ComppundsAndProjectsHeader()
        {
            return new List<string>
            {
                "Compounds and Projects ID",
                "Compound ID",
                "Project",
                "Project ID",
                "Project ID Override",
              
            };
        }
  
       
    }
}
