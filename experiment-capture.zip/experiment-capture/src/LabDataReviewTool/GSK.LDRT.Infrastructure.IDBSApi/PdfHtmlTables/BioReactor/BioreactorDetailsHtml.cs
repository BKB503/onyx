﻿
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{

    public class BioreactorDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel SpreadSheetPdfTableModel)
        {  
            var bioreactorDetails = JsonConvert.DeserializeObject<List<BioreactorDetails>>(SpreadSheetPdfTableModel.TableData.ToString()).ToList();

            return CreateHtml(bioreactorDetails, SpreadSheetPdfTableModel.TableName) ;
        }

        
        private string CreateHtml(List<BioreactorDetails> bioreactorDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr> </thead>";

            foreach (var bioreactorDetail in bioreactorDetails)
            {
                var calibrationDueDate = "";
                if (bioreactorDetail.CalibrationDueDate != null && bioreactorDetail.CalibrationDueDate.Value != null && bioreactorDetail.CalibrationDueDate.Value.HasValue)
                {
                    calibrationDueDate = bioreactorDetail.CalibrationDueDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{bioreactorDetail.BioreactorIndex?.Value} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.EquipmentID?.Value} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.RecordName?.Value} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.ItemName?.Value} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.SerialNumber?.Value} </td>";
                tableCells += $"<td class='td'>{calibrationDueDate} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.EquipmentType?.Value} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.EquipmentStatus?.Value} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.EquipmentLocation?.Value} </td>";
                tableCells += $"<td class='td'>{bioreactorDetail.EquipmentLink?.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Bioreactor Index",
                "Equipment ID",
                "Record Name",
                "Item Name",
                "Serial Number",
                "Calibration Due Date",
                "Equipment Type",
                "Equipment Status",
                "Equipment Location",
                "Equipment Link"
            };
        }
  
       
    }
}
