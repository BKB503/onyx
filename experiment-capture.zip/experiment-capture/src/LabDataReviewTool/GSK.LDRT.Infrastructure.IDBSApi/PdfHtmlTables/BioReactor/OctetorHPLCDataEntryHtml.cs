﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class OctetorHPLCDataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var octetorHPLCDataEntrys = JsonConvert.DeserializeObject<List<OctetorHPLCDataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMOctetorHPLCDataEntrys = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Octet or HPLC Data Entry");
            var uoMOctetorHPLCDataEntrysData = new List<UoMOctetorHPLCDataEntry>();
            if (uoMOctetorHPLCDataEntrys != null && uoMOctetorHPLCDataEntrys.Data != null)
            {
                uoMOctetorHPLCDataEntrysData = JsonConvert.DeserializeObject<List<UoMOctetorHPLCDataEntry>>(uoMOctetorHPLCDataEntrys.Data.ToString());

            }
            var filteredData = new List<OctetorHPLCDataEntry>();

            filteredData = octetorHPLCDataEntrys.Where(x => !string.IsNullOrEmpty(x.SampleName.Value)).ToList();

            return $"{BuildHtml(filteredData, uoMOctetorHPLCDataEntrysData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<OctetorHPLCDataEntry> octetorHPLCDataEntrys, List<UoMOctetorHPLCDataEntry> uoMOctetorHPLCDataEntrys, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMOctetorHPLCDataEntrys))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedOctetorHPLCDataEntryIndexs = octetorHPLCDataEntrys.GroupBy(x => x.HPLCAliquotIndex.Value, (key, group) => new { HPLCAliquotIndex = key, Items = group.ToList() });
            foreach (var groupedOctetorHPLCDataEntryIndex in groupedOctetorHPLCDataEntryIndexs)
            {
                if (groupedOctetorHPLCDataEntryIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedOctetorHPLCDataEntryIndex.Items.Count}'>{groupedOctetorHPLCDataEntryIndex.HPLCAliquotIndex} </td>";
                    var groupedInputMethods = groupedOctetorHPLCDataEntryIndex.Items.GroupBy(x => x.InputMethod.Value, (key, group) => new { InputMethod = key, InputMethodValues = group.ToList() });
                    foreach (var inputMethod in groupedInputMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{inputMethod.InputMethodValues.Count}'>{inputMethod.InputMethod} </td>";
                        foreach (var item in inputMethod.InputMethodValues)
                        {   
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.InstrumentSampleIdOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementEquipment?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.Titre?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Ignore?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Sample Name",
                "DCA ID",
                "Instrument Sample ID Override",
                "Measurement Equipment",
                "Measurement Date",
                "Titre",
                "Ignore?"

            };
        }

        private List<string> SubHeaders(List<UoMOctetorHPLCDataEntry> uoMOctetorHPLCDataEntrys)
        {
            var titre = uoMOctetorHPLCDataEntrys.FirstOrDefault(x => x.Column.Value == "Titre")?.UoM?.Value;
            return new List<string>
            {
               "",
                "",
                "",
                "",
                "",
                "",
                "",
                titre,
                ""
            };
        }



    }
}
