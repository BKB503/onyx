﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class SetpointsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var experimentSetupDetailsData = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Experiment Setup Details" || x.TableName == "Experiment Setup");
            var experimentSetupDetails = (List<ExperimentSetupDetails>)JsonConvert.DeserializeObject<List<ExperimentSetupDetails>>(experimentSetupDetailsData.Data.ToString());
            var experimentSetupDetail = experimentSetupDetails.FirstOrDefault();
            var setpoints = JsonConvert.DeserializeObject<List<Setpoints>>(spreadSheetPdfTableModel.TableData);
            var uoMSetpoints = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Setpoints");
            var uoMSetpointsData = new List<UoMSetpoints>();

            if(uoMSetpoints != null && uoMSetpoints.Data != null)
            {
                uoMSetpointsData = JsonConvert.DeserializeObject<List<UoMSetpoints>>(uoMSetpoints.Data.ToString());
            }
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{BuildHtml(setpoints, uoMSetpointsData, spreadSheetPdfTableModel.TableName, experimentSetupDetail)}";
        }

        private string BuildHtml(List<Setpoints> setpoints, List<UoMSetpoints> uoMSetpoints, string tableName, ExperimentSetupDetails experimentSetupDetails)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string> { "", "" };
            var bioreactorType = experimentSetupDetails.BioreactorType?.Value;
            var perfusionExperiment = experimentSetupDetails.PerfusionExperiment?.Value;
            var doSetPoint = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "Dissolved Oxygen Setpoint");
            var agitationSetPoint1 = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "Agitation Setpoint 1");
            var agitationSetPoint2 = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "Agitation Setpoint 2");
            var tempSetPoint1 = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "Temperature Setpoint 1");
            var tempSetPoint2 = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "Temperature Setpoint 2");
            var co2SetPoint = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "CO2 Setpoint");
            var headspaceFlowrate = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "Headspace Flowrate");
            var maxO2Comp = uoMSetpoints.FirstOrDefault(x => x.Column?.Value == "Max O2 Comp");
            foreach (var setpoint in setpoints)
            {
                headers.Add(setpoint.SetpointIdx?.Value);
            }

            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th>{tableTh} </th>";
            }
           
            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var setpoint in setpoints)
            {
                var tableCells = "";
                tableCells += $"<tr><td class='th'>Setpoint Name</td><td class='th'> </td> <td class='td'>{setpoint.SetpointName?.Value} </td></tr>";

                if (bioreactorType == "Ambr" || bioreactorType == "Individual")
                {
                    tableCells += $"<tr><td class='th'>pH Setpoint 1</td><td class='th'> </td> <td class='td'>{setpoint.pHSetpoint1?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Lower pH Deadband Setpoint 1</td><td class='th'> </td> <td class='td'>{setpoint.LowerpHDeadbandSetpoint1?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Upper pH Deadband Setpoint 1</td><td class='th'> </td> <td class='td'>{setpoint.UpperpHDeadbandSetpoint1?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>pH Setpoint 2</td><td class='th'> </td> <td class='td'>{setpoint.pHSetpoint2?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Lower pH Deadband Setpoint 2</td><td class='th'> </td> <td class='td'>{setpoint.LowerpHDeadbandSetpoint2?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Upper pH Deadband Setpoint 2</td><td class='th'> </td> <td class='td'>{setpoint.UpperpHDeadbandSetpoint2?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>pH Setpoint Change Day</td><td class='th'> </td> <td class='td'>{setpoint.pHSetpointChangeDay?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Dissolved Oxygen Setpoint</td><td class='th'>{doSetPoint?.UoM.Value} </td> <td class='td'>{setpoint.DissolvedOxygenSetpoint?.NumberValue} </td></tr>";

                    if (perfusionExperiment!= null &&  perfusionExperiment.ToLower() == "yes")
                    {
                        tableCells += $"<tr><td class='th'>Cell Specific Perfusion Rate</td><td class='th'> </td> <td class='td'>{setpoint.CellSpecificPerfusionRate?.NumberValue} </td></tr>";
                    }

                    tableCells += $"<tr><td class='th'>Agitation Setpoint 1</td><td class='th'>{agitationSetPoint1?.UoM.Value} </td> <td class='td'>{setpoint.AgitationSetpoint1?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Agitation Setpoint 2</td><td class='th'>{agitationSetPoint2?.UoM.Value} </td> <td class='td'>{setpoint.AgitationSetpoint2?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Agitation Setpoint Change Day</td><td class='th'> </td> <td class='td'>{setpoint.AgitationSetpointChangeDay?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Temperature Setpoint 1</td><td class='th'> {tempSetPoint1?.UoM.Value}</td> <td class='td'>{setpoint.TemperatureSetpoint1?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Temperature Setpoint 2</td><td class='th'> {tempSetPoint2?.UoM.Value}</td> <td class='td'>{setpoint.TemperatureSetpoint2?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>Temperature Setpoint Change Day</td><td class='th'> </td> <td class='td'>{setpoint.TemperatureSetpointChangeDay?.NumberValue} </td></tr>";
                    tableCells += $"<tr><td class='th'>CO2 Setpoint</td><td class='th'>{co2SetPoint?.UoM.Value} </td> <td class='td'>{setpoint.CO2Setpoint?.NumberValue} </td></tr>";

                    if (bioreactorType == "Ambr" || bioreactorType == "Individual")
                    {
                        tableCells += $"<tr><td class='th'>Headspace Gas</td><td class='th'> </td> <td class='td'>{setpoint.HeadspaceGas?.Value} </td></tr>";
                        tableCells += $"<tr><td class='th'>Headspace Flowrate</td><td class='th'> {headspaceFlowrate?.UoM?.Value}</td> <td class='td'>{setpoint.HeadspaceFlowrate?.NumberValue} </td></tr>";
                        tableCells += $"<tr><td class='th'>Impeller Config</td><td class='th'> </td> <td class='td'>{setpoint.ImpellerConfig?.Value} </td></tr>";
                        tableCells += $"<tr><td class='th'>Max O2 Comp</td><td class='th'>{maxO2Comp?.UoM?.Value} </td> <td class='td'>{setpoint.MaxO2Comp?.NumberValue} </td></tr>";
                        tableCells += $"<tr><td class='th'>Sparger 1 Config</td><td class='th'> </td> <td class='td'>{setpoint.Sparger1Config?.Value} </td></tr>";
                        tableCells += $"<tr><td class='th'>Sparger 1 Gases</td><td class='th'> </td> <td class='td'>{setpoint.Sparger1Gases?.Value} </td></tr>";
                        tableCells += $"<tr><td class='th'>Sparger 2 Config</td><td class='th'> </td> <td class='td'>{setpoint.Sparger2Config?.Value} </td></tr>";
                        tableCells += $"<tr><td class='th'>Sparger 2 Gases</td><td class='th'> </td> <td class='td'>{setpoint.Sparger2Gases?.Value} </td></tr>";
                    }

                    if (perfusionExperiment != null && perfusionExperiment.ToLower() == "yes")
                    {
                        tableCells += $"<tr><td class='th'>Cycle Rate</td><td class='th'> </td> <td class='td'>{setpoint.CycleRate?.NumberValue} </td></tr>";
                        tableCells += $"<tr><td class='th'>Perfusion Media 1</td><td class='th'> </td> <td class='td'>{setpoint.PerfusionMedia1?.Value} </td></tr>";
                        tableCells += $"<tr><td class='th'>Perfusion Media 2</td><td class='th'> </td> <td class='td'>{setpoint.PerfusionMedia2?.Value} </td></tr>";
                        tableCells += $"<tr><td class='th'>Perfusion Media 3</td><td class='th'> </td> <td class='td'>{setpoint.PerfusionMedia3?.Value} </td></tr>";
                    }
                }
              
                    tableRows += tableCells;
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

    }
}
