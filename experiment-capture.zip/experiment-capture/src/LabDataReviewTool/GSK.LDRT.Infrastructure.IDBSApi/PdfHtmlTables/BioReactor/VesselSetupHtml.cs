﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class VesselSetupHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var experimentSetupDetailsData = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Experiment Setup Details" || x.TableName == "Experiment Setup");
            var experimentSetupDetails = (List<ExperimentSetupDetails>)JsonConvert.DeserializeObject<List<ExperimentSetupDetails>>(experimentSetupDetailsData.Data.ToString());
            var experimentSetupDetail = experimentSetupDetails.FirstOrDefault();
            var vesselSetups = JsonConvert.DeserializeObject<List<VesselSetup>>(spreadSheetPdfTableModel.TableData);
            var uoMVesselSetups = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Vessel Setup");
            var uoMVesselSetupsData = (List<UoMVesselSetup>)JsonConvert.DeserializeObject<List<UoMVesselSetup>>(uoMVesselSetups.Data.ToString());
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{BuildHtml(vesselSetups, uoMVesselSetupsData, spreadSheetPdfTableModel.TableName, experimentSetupDetail)}";
        }

        

        private string BuildHtml(List<VesselSetup> vesselSetups, List<UoMVesselSetup> uoMVesselSetups, string tableName, ExperimentSetupDetails experimentSetupDetails)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string> { "", "" };
            var subHeaders = new List<string> { "", "" };
            var durationUom = uoMVesselSetups.FirstOrDefault(x => x.Column.Value == "Duration");
            var workingVolumeSetpointUom = uoMVesselSetups.FirstOrDefault(x => x.Column.Value == "Working Volume Setpoint");
            var inoculumVolumeSetpointUom = uoMVesselSetups.FirstOrDefault(x => x.Column.Value == "Inoculum Volume Setpoint");
            var inoculumVolumeUom = uoMVesselSetups.FirstOrDefault(x => x.Column.Value == "Inoculum Volume");
            var totalViableCellConcentrationUom = uoMVesselSetups.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration");
            var mediaFillVolumeUom = uoMVesselSetups.FirstOrDefault(x => x.Column.Value == "Media Fill Volume");
            var workingVolumeUom = uoMVesselSetups.FirstOrDefault(x => x.Column.Value == "Working Volume");
            
            foreach (var vesselSetup in vesselSetups)
            {
                headers.Add(vesselSetup?.ReactorIndex?.Value);
                subHeaders.Add(vesselSetup?.hBioreactorCultureUserId?.Value);
            }

            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in subHeaders)
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr><tr>{tableSubHeaderCells} </tr></thead>";
            string processRecipeName=""; string setpointGroup = "";string inoculationGroup = "";
            string feedScheduleGroup1 = ""; string feedScheduleGroup2 = ""; string feedScheduleGroup3 = "";
            string duration = ""; string cultureName = ""; string inoculationCompletedDate = ""; string cellLineName = "";
            string reactor = ""; string bioreactorCultureDescription = ""; string vesselId = ""; string vesselIdOverride = "";
            string workingVolumeSetpoint = ""; string inoculumVolumeSetpoint = ""; string inoculumVolume = ""; string totalViableCellConcentration = "";
            string mediaFillVolume = ""; string workingVolume = ""; string seedSplitRatio = ""; string cultureMediumInventoryLink = ""; string comments = "";
            foreach (var vesselSetup in vesselSetups)
            {
                var inoculationCompletedDateandTime = "";
                if (vesselSetup.InoculationCompletedDateandTime != null && vesselSetup.InoculationCompletedDateandTime.Value != null && vesselSetup.InoculationCompletedDateandTime.Value.HasValue)
                {
                    inoculationCompletedDateandTime = vesselSetup.InoculationCompletedDateandTime.Value.Value.ToString("MMM dd, yyyy");
                }

               processRecipeName +=  $"<td class='td'>{vesselSetup.ProcessRecipeName?.Value} </td>";
               setpointGroup += $"<td class='td'>{vesselSetup.SetpointGroup?.Value} </td>";
               inoculationGroup += $"<td class='td'>{vesselSetup.InoculationGroup?.Value} </td>";
               feedScheduleGroup1 += $"<td class='td'>{vesselSetup.FeedScheduleGroup1?.Value} </td>";
               feedScheduleGroup2 += $"<td class='td'>{vesselSetup.FeedScheduleGroup2?.Value} </td>";
               feedScheduleGroup3 += $"<td class='td'>{vesselSetup.FeedScheduleGroup3?.Value} </td>";
               duration += $"<td class='td'>{vesselSetup.Duration?.Value} </td>";
               cultureName+= $"<td class='td'>{vesselSetup.CultureName?.Value} </td>";
               inoculationCompletedDate += $"<td class='td'>{inoculationCompletedDateandTime} </td>";
               cellLineName += $"<td class='td'>{vesselSetup.CellLineName?.Value} </td>";
               reactor += $"<td class='td'>{vesselSetup.Reactor?.Value} </td>";
               bioreactorCultureDescription += $"<td class='td'>{vesselSetup.BioreactorCultureDescription?.Value} </td>";
               vesselId += $"<td class='td'>{vesselSetup.VesselId?.Value} </td>";
               vesselIdOverride += $"<td class='td'>{vesselSetup.VesselIdOverride?.NumberValue} </td>";
               workingVolumeSetpoint += $"<td class='td'>{vesselSetup.WorkingVolumeSetpoint?.NumberValue} </td>";
               inoculumVolumeSetpoint += $"<td class='td'>{vesselSetup.InoculumVolumeSetpoint?.NumberValue} </td>";
               inoculumVolume += $"<td class='td'>{vesselSetup.InoculumVolume?.NumberValue} </td>";
               totalViableCellConcentration += $"<td class='td'>{vesselSetup.TotalViableCellConcentration?.NumberValue} </td>";
               mediaFillVolume += $"<td class='td'>{vesselSetup.MediaFillVolume?.NumberValue} </td>";
               workingVolume += $"<td class='td'>{vesselSetup.WorkingVolume?.NumberValue} </td>";
               seedSplitRatio += $"<td class='td'>{vesselSetup.SeedSplitRatio?.NumberValue} </td>";
               cultureMediumInventoryLink+= $"<td class='td'>{vesselSetup.CultureMediumInventoryLink?.Value} </td>";
               comments += $"<td class='td'>{vesselSetup.Comments?.Value} </td>";

                if (vesselSetups.LastIndexOf(vesselSetup) == vesselSetups.Count - 1)
                {
                    var tableCells = "";
                    tableCells += $"<tr><td class='th'>Process Recipe Name</td><td class='th'> </td>{processRecipeName}</tr>";
                    tableCells += $"<tr><td class='th'>Setpoint Group</td><td class='th'> </td> {setpointGroup} </tr>";
                    tableCells += $"<tr><td class='th'>Inoculation Group</td><td class='th'> </td> {inoculationGroup}</tr>";
                    tableCells += $"<tr><td class='th'>Feed Schedule Group 1</td><td class='th'> </td> {feedScheduleGroup1} </tr>";
                    tableCells += $"<tr><td class='th'>Feed Schedule Group 2</td><td class='th'> </td> {feedScheduleGroup2} </tr>";
                    tableCells += $"<tr><td class='th'>Feed Schedule Group 3</td><td class='th'> </td> {feedScheduleGroup3} </tr>";
                    tableCells += $"<tr><td class='th'>Duration</td><td class='th'>{durationUom?.UoM?.Value} </td> {duration} </tr>";
                    tableCells += $"<tr><td class='th'>Culture Name</td><td class='th'> </td> {cultureName} </tr>";
                    tableCells += $"<tr><td class='th'>Inoculation Completed Date and Time</td><td class='th'> </td> {inoculationCompletedDate} </tr>";
                    tableCells += $"<tr><td class='th'>Cell Line Name</td><td class='th'> </td> {cellLineName}</tr>";
                    tableCells += $"<tr><td class='th'>Reactor</td><td class='th'> </td> {reactor} </tr>";
                    tableCells += $"<tr><td class='th'>Bioreactor Culture Description</td><td class='th'> </td>{bioreactorCultureDescription} </tr>";
                    tableCells += $"<tr><td class='th'>Vessel ID</td><td class='th'> </td> {vesselId}</tr>";
                    tableCells += $"<tr><td class='th'>Vessel ID Override</td><td class='th'> </td> {vesselIdOverride}</tr>";
                    tableCells += $"<tr><td class='th'>Working Volume Setpoint</td><td class='th'>{workingVolumeSetpointUom?.UoM?.Value} </td> {workingVolumeSetpoint} </tr>";
                    tableCells += $"<tr><td class='th'>Inoculum Volume Setpoint</td><td class='th'>{inoculumVolumeSetpointUom?.UoM?.Value} </td> {inoculumVolumeSetpoint}</tr>";
                    tableCells += $"<tr><td class='th'>Inoculum Volume</td><td class='th'>{inoculumVolumeUom?.UoM?.Value} </td> {inoculumVolume}</tr>";
                    tableCells += $"<tr><td class='th'>Total Viable Cell Concentration</td><td class='th'>{totalViableCellConcentrationUom?.UoM?.Value} </td> {totalViableCellConcentration} </tr>";
                    tableCells += $"<tr><td class='th'>Media Fill Volume</td><td class='th'>{mediaFillVolumeUom?.UoM?.Value} </td> {mediaFillVolume} </tr>";
                    tableCells += $"<tr><td class='th'>Working Volume</td><td class='th'>{workingVolumeUom?.UoM?.Value} </td> {workingVolume} </tr>";
                    tableCells += $"<tr><td class='th'>Seed Split Ratio</td><td class='th'></td> {seedSplitRatio} </tr>";
                    tableCells += $"<tr><td class='th'>Culture Medium Inventory Link</td><td class='th'></td> {cultureMediumInventoryLink}</tr>";
                    tableCells += $"<tr><td class='th'>Comments</td><td class='th'></td> {comments}</tr>";

                    tableRows += tableCells;
                }

               
            }


            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        
    }
}
