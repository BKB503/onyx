﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class Flex2DataEntryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var flex2CedexDataEntrys = JsonConvert.DeserializeObject<List<Flex2DataEntry>>(spreadSheetPdfTableModel.TableData);
            var uoMFlex2CedexDataEntrys = spreadSheetPdfTableModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Flex2 Data Entry");
            var uoMFlex2CedexDataEntryData = (List<UoMFlex2CedexDataEntry>)JsonConvert.DeserializeObject<List<UoMFlex2CedexDataEntry>>(uoMFlex2CedexDataEntrys.Data.ToString());
            var filteredData = new List<Flex2DataEntry>();

            filteredData = flex2CedexDataEntrys.Where(x => !string.IsNullOrEmpty(x.SampleName.Value)).ToList();
           
            return $"{BuildHtml(filteredData, uoMFlex2CedexDataEntryData, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<Flex2DataEntry> flex2CedexDataEntrys, List<UoMFlex2CedexDataEntry> uoMFlex2CedexDataEntrys, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMFlex2CedexDataEntrys))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            var groupedFlexAliquotIndexs = flex2CedexDataEntrys.GroupBy(x => x.FlexAliquotIndex.Value, (key, group) => new { FlexAliquotIndex = key, Items = group.ToList() });
            foreach (var groupedFlexAliquotIndex in groupedFlexAliquotIndexs)
            {
                if (groupedFlexAliquotIndex.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{groupedFlexAliquotIndex.Items.Count}'>{groupedFlexAliquotIndex.FlexAliquotIndex} </td>";
                    var groupedInputMethods = groupedFlexAliquotIndex.Items.GroupBy(x => x.InputMethod.Value, (key, group) => new { InputMethod = key, InputMethodValues = group.ToList() });
                    foreach (var inputMethod in groupedInputMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{inputMethod.InputMethodValues.Count}'>{inputMethod.InputMethod} </td>";
                        foreach (var item in inputMethod.InputMethodValues)
                        {   
                            tableCells += $"<td class='td'>{item.SampleName?.Value} </td>";
                            tableCells += $"<td class='td'>{item.DCAId?.Value} </td>";
                            tableCells += $"<td class='td'>{item.InstrumentSampleIdOverride?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementEquipment?.Value} </td>";
                            tableCells += $"<td class='td'>{item.MeasurementDate?.Value} </td>";
                            tableCells += $"<td class='td'>{item.Osmolality?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.AmmoniumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CalciumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GlucoseConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GlutamineConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.GlutamateConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.LactateConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PH?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PCO2?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PO2?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PotassiumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.SodiumConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PCO2AtTemperature?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PO2AtTemperature?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.PHAtTemperature?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TotalCellConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.TotalViableCellConcentration?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.CellCultureViability?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.AverageCellDiameter?.NumberValue} </td>";
                            tableCells += $"<td class='td'>{item.Ignore?.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }

                    }
                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

      
        private List<string> Headers()
        {
            return new List<string>
            {
                "",
                "",
                "Sample Name",
                "DCA ID",
                "Instrument Sample ID Override",
                "Measurement Equipment",
                "Measurement Date",
                "Osmolality",
                "Ammonium Concentration",
                "Calcium Concentration",
                "Glucose Concentration",
                "Glutamine Concentration",
                "Glutamate Concentration",
                "Lactate Concentration",
                "pH",
                "pCO2",
                "pO2",
                "Potassium Concentration",
                "Sodium Concentration",
                "pCO2 at temperature",
                "pO2 at Temperature",
                "pH at Temperature",
                "Total Cell Concentration",
                "Total Viable Cell Concentration",
                "Cell Culture Viability",
                "Average Cell Diameter",
                "Ignore?"

            };
        }

        private List<string> SubHeaders(List<UoMFlex2CedexDataEntry> uoMFlex2CedexDataEntrys)
        {
            var osmolality = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Osmolality").UoM?.Value;
            var ammoniumConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Ammonium Concentration").UoM?.Value;
            var calciumConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Calcium Concentration").UoM?.Value;
            var glucoseConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Glucose Concentration").UoM?.Value;
            var pCO2 = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pCO2").UoM?.Value;
            var pO2 = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pO2").UoM?.Value;
            var potassiumConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Potassium Concentration").UoM?.Value;
            var sodiumConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Sodium Concentration").UoM?.Value;
            var pCO2attemperature = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pCO2 at temperature").UoM?.Value;
            var pO2atTemperature = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "pO2 at Temperature").UoM?.Value;
            var totalCellConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Total Cell Concentration").UoM?.Value;
            var totalViableCellConcentration = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Total Viable Cell Concentration").UoM?.Value;
            var cellCultureViability = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Cell Culture Viability")?.UoM?.Value;
            var averageCellDiameter = uoMFlex2CedexDataEntrys.FirstOrDefault(x => x.Column.Value == "Average Cell Diameter")?.UoM?.Value;
         
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                osmolality,
                ammoniumConcentration,
                calciumConcentration,
                glucoseConcentration,
                "",
                "",
                "",
                "",
                pCO2,
                pO2,
                potassiumConcentration,
                sodiumConcentration,
                pCO2attemperature,
                pO2atTemperature,
                "",
                totalCellConcentration,
                totalViableCellConcentration,
                cellCultureViability,
                averageCellDiameter,
                ""
            };
        }



    }
}
