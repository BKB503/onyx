﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor
{
    public class CultureLabelsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel spreadSheetPdfTableModel)
        {
            var cultureLabels = JsonConvert.DeserializeObject<List<CultureLabels>>(spreadSheetPdfTableModel.TableData);
            return $"{BuildHtml(cultureLabels, spreadSheetPdfTableModel.TableName)}";
        }

        private string BuildHtml(List<CultureLabels> cultureLabels, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var cultureLabel in cultureLabels)
            {
                var seedDate = "";
                if (cultureLabel.SeedDate != null && cultureLabel.SeedDate.Value != null && cultureLabel.SeedDate.Value.HasValue)
                {
                    seedDate = cultureLabel.SeedDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{cultureLabel.CultureIndex.Value} </td>";
                tableCells += $"<td class='td'>{cultureLabel.ExperimentId?.Value} </td>";
                tableCells += $"<td class='td'>{cultureLabel.CompoundId?.Value} </td>";
                tableCells += $"<td class='td'>{cultureLabel.ProjectId?.Value} </td>";
                tableCells += $"<td class='td'>{cultureLabel.SystemId?.Value} </td>";
                tableCells += $"<td class='td'>{cultureLabel.CellLine?.Value} </td>";
                tableCells += $"<td class='td'>{cultureLabel.CulturePrintName?.Value} </td>";
                tableCells += $"<td class='td'>{seedDate} </td>";
                tableCells += $"<td class='td'>{cultureLabel.UserId?.Value} </td>";
                
                tableRows += $"<tr>{tableCells}</tr> ";
            }
            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Culture Index",
                "Experiment ID",
                "Compound ID",
                "Project ID",
                "System ID",
                "Cell Line",
                "Culture Print Name",
                "Cell Line Name",
                "Seed Date",
                "User ID"
            };
        }

    }
}
