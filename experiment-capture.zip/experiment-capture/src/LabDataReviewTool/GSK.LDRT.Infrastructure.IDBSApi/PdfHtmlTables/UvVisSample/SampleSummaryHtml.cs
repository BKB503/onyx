﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class SampleSummaryHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var uoMSampleFinalSummaryData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Sample Final Summary");
            var uoMSampleFinalSummary = JsonConvert.DeserializeObject<List<UoMSampleFinalSummary>>(uoMSampleFinalSummaryData.Data.ToString());

            var sampleSummaries = JsonConvert.DeserializeObject<List<SampleSummary>>(uvVisSampleTestingModel.TableData);
            var filteredData = sampleSummaries.Where(x => x.SampleSummaryIdx.Value != "<>").ToList();
            var pageBreak = " <div class='page-break'></div>";
            var tableHtml = BuildHtml(filteredData, uoMSampleFinalSummary, uvVisSampleTestingModel.TableName);
            return $"{pageBreak}{tableHtml}";
        }


        private string BuildHtml(List<SampleSummary> sampleSummaries, List<UoMSampleFinalSummary> uoMSampleFinalSummaries, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uoMSampleFinalSummaries))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";
            foreach (var sampleSummary in sampleSummaries)
            {
                var tableCells = "";

                tableCells += $"<td class='td'>{sampleSummary.SampleSummaryIdx.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.SampleId.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.SampleName.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.CompoundId.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.Project.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.ProjectId.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.ExperimentId.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.StudyName.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.ExtinctionCoefficient.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleSummary.Concentration.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleSummary.ConcentrationOverride.Value} </td>";
                tableCells += $"<td class='td'>{sampleSummary.ConcentrationUnit.Value} </td>";


                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Sample Summary Index",
                "Sample ID",
                "Sample Name",
                "Compound ID",
                "Project",
                "Project ID",
                "Experiment ID",
                "Study Name",
                "Extinction Coefficient",
                "Concentration",
                "Concentration Override",
                "Concentration Unit",
            };
        }

        private List<string> SubHeaders(List<UoMSampleFinalSummary> uoMSampleFinalSummaries)
        {
            var extinctionCoefficient = uoMSampleFinalSummaries.FirstOrDefault(x => x.Data.Value == "Extinction Coefficient").Uom.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                extinctionCoefficient,
                "",
                "",
                "",
            };
        }

    }
}
