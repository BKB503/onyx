﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class SampleResultsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var uoM_SampleAliquotDetails = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Sample Results");
            var uoM_SampleAliquotDetailsData = JsonConvert.DeserializeObject<List<UoMSampleResults>>(uoM_SampleAliquotDetails.Data.ToString());

            var sampleDetails = JsonConvert.DeserializeObject<List<SampleResults>>(uvVisSampleTestingModel.TableData);
            var getFilter = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "Sample Results" && x.FilterIdentifier.Value == "View Filter").FilterValues;
            var filteredData = sampleDetails.Where(x => x.MethodType.Value == uvVisSampleTestingModel.MethodName && x.RowShow.NumberValue == getFilter.NumberValue).ToList();

            return BuildTable(filteredData, uoM_SampleAliquotDetailsData, uvVisSampleTestingModel.TableName, uvVisSampleTestingModel.MethodName);
        }



        private string BuildTable(List<SampleResults> sampleResults, List<UoMSampleResults> uomStandardResults, string tableName, string methodName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string>();
            var subHeaders = new List<string>();

            if (methodName == "SoloVPE" || methodName == "Nanodrop")
            {
                headers = SoloVPEOrNanodropHeaders();
                subHeaders = SoloVPEOrNanDropSubHeaders(uomStandardResults);
            }
            else if (methodName == "Lunatic")
            {
                headers = LunaticHeaders();
                subHeaders = LunaticSubHeaders(uomStandardResults);
            }


            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in subHeaders)
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }
            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";
            var groupedRunNumbers = sampleResults.GroupBy(x => x.RunNumber.Value, (key, group) => new { RunNumber = key, Items = group.ToList() });

            foreach (var runNumber in groupedRunNumbers)
            {
                var tableCells = "";
                tableCells += $"<td class='td' rowspan='{runNumber.Items.Count}'>{runNumber.RunNumber} </td>";

                var groupedSamples = runNumber.Items.GroupBy(x => x.SampleResultIdx.Value, (key, group) => new { SampleResultId = key, SampleResults = group.ToList() });
                foreach (var sampleResultsGroup in groupedSamples)
                {
                    tableCells += $"<td class='td' rowspan='{sampleResultsGroup.SampleResults.Count}'>{sampleResultsGroup.SampleResultId} </td>";
                    foreach (var sampleResult in sampleResultsGroup.SampleResults)
                    {

                        tableCells += $"<td class='td'>{sampleResult.RepIndex.Value} </td>";
                        tableCells += $"<td class='td'>{sampleResult.SampleName.Value} </td>";
                        tableCells += $"<td class='td'>{sampleResult.SampleId.Value} </td>";
                        tableCells += $"<td class='td'>{sampleResult.SubAliquotId.Value} </td>";
                        tableCells += $"<td class='td'>{sampleResult.DCAId.Value} </td>";
                        tableCells += $"<td class='td'>{sampleResult.ExpectedConcentration.NumberValue} </td>";
                        tableCells += $"<td class='td'>{sampleResult.Concentration.NumberValue} </td>";
                        tableCells += $"<td class='td'>{sampleResult.AverageConcentration.NumberValue} </td>";

                        if (methodName == "SoloVPE" || methodName == "Nanodrop")
                        {
                            tableCells += $"<td class='td'>{sampleResult.StandardMinR.NumberValue} </td>";
                        }

                        tableCells += $"<td class='td'>{sampleResult.PercentageRSD.NumberValue} </td>";
                        if (methodName == "Lunatic")
                        {
                            tableCells += $"<td class='td'>{sampleResult.PercentageResidue.NumberValue} </td>";
                            tableCells += $"<td class='td'>{sampleResult.A560.NumberValue} </td>";
                        }
                        tableCells += $"<td class='td'>{sampleResult.SuitabilityResults.Value} </td>";
                        tableCells += $"<td class='td'>{sampleResult.SuitabilityResultsOverride.Value} </td>";
                        tableCells += $"<td class='td'>{sampleResult.Comments.Value} </td>";
                        tableRows += $"<tr>{tableCells}</tr> ";
                        tableCells = "";
                    }

                }
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }

        private List<string> SoloVPEOrNanodropHeaders()
        {
            return new List<string>
            {
                "Run Number",
                "Sample Result Idx",
                "Rep Index",
                "Sample Name",
                "Sample ID",
                "Subaliquot ID",
                "DCA ID",
                "Expected Concentration",
                "Concentration",
                "Average Concentration",
                "R²",
                "%RSD",
                "Suitability Results",
                "Suitability Results Override",
                "Comments"
            };
        }

        private List<string> LunaticHeaders()
        {
            return new List<string>
            {
                "Run Number",
                "Sample Result Idx",
                "Rep Index",
                "Sample Name",
                "Sample ID",
                "Subaliquot ID",
                "DCA ID",
                "Expected Concentration",
                "Concentration",
                "Average Concentration",
                "%RSD",
                "% Residue",
                "A560",
                "Suitability Results",
                "Suitability Results Override",
                "Comments"
            };
        }
        private List<string> SoloVPEOrNanDropSubHeaders(List<UoMSampleResults> uoMSampleResults)
        {
            var expectedConcentration = uoMSampleResults.FirstOrDefault(x => x.Data.Value == "Expected Concentration").Uom.Value;
            var concentration = uoMSampleResults.FirstOrDefault(x => x.Data.Value == "Concentration").Uom.Value;
            var averageConcentration = uoMSampleResults.FirstOrDefault(x => x.Data.Value == "Average Concentration").Uom.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                expectedConcentration,
                concentration,
                averageConcentration,
                "",
                "",
                "",
                "",
                ""
            };
        }

        private List<string> LunaticSubHeaders(List<UoMSampleResults> uoMSampleResults)
        {
            var expectedConcentration = uoMSampleResults.FirstOrDefault(x => x.Data.Value == "Expected Concentration").Uom.Value;
            var concentration = uoMSampleResults.FirstOrDefault(x => x.Data.Value == "Concentration").Uom.Value;
            var averageConcentration = uoMSampleResults.FirstOrDefault(x => x.Data.Value == "Average Concentration").Uom.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                expectedConcentration,
                concentration,
                averageConcentration,
                "",
                "",
                "",
                "",
                "",
                ""
            };
        }

    }
}
