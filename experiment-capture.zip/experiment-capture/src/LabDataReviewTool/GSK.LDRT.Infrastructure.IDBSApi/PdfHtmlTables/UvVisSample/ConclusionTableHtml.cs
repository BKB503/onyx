﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class ConclusionTableHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var conclusionTable = JsonConvert.DeserializeObject<List<ConclusionTable>>(uvVisSampleTestingModel.TableData);
            var firstRow = conclusionTable.FirstOrDefault();
            var keyValueAssayData = new Dictionary<string, string>();

            keyValueAssayData.Add("Conclusion", firstRow.Conclusion.Value);


            return BuildFirstRowTableHtml(keyValueAssayData, uvVisSampleTestingModel.TableName);
        }

        private string BuildFirstRowTableHtml(Dictionary<string, string> data, string tableName)
        {
            var tableRows = "";
            foreach (var item in data)
            {
                tableRows += $"<tr><td class='td'> <b>{item.Key}</b> </td> <td class='td'> {item.Value} </td> </tr>";
            }
            var tableBody = $"<tbody> {tableRows}</tbody>";
            var table = $"<div class='table-wrapper'><table class='table'> <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody} </table></div>";
            return table;
        }


    }
}
