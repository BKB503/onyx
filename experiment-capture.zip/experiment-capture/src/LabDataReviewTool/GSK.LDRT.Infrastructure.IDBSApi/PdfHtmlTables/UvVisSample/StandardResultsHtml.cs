﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class StandardResultsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var materialDetailsData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Material Details");
            var materialDetails = JsonConvert.DeserializeObject<List<MaterialDetails>>(materialDetailsData.Data.ToString());
            var categories = new List<string> { "Standard", "Suitability Standard" };
            var hasCategoryForMaterial = materialDetails.Any(x => categories.Any(h => x.Category.Value == h));

            var reagentPreparationData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Reagent Preparation");
            var reagentPreparation = JsonConvert.DeserializeObject<List<ReagentPreparation>>(reagentPreparationData.Data.ToString());

            var hasCategoryForReagent = reagentPreparation.Any(x => categories.Any(h => x.Category.Value == h));

            var uomControlResultsData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Standard Results");
            var uomControlResults = JsonConvert.DeserializeObject<List<UoMStandardResults>>(uomControlResultsData.Data.ToString());

            var standardResults = JsonConvert.DeserializeObject<List<StandardResults>>(uvVisSampleTestingModel.TableData);

            var getControlFilter = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "Standard Results" && x.FilterIdentifier.Value == "View Filter");
            var filteredData = standardResults.Where(x => x.RowShow.NumberValue == getControlFilter.FilterValues.NumberValue && x.MethodType.Value == uvVisSampleTestingModel.MethodName).ToList();
            return BuildTable(filteredData, uomControlResults, uvVisSampleTestingModel.TableName, uvVisSampleTestingModel.MethodName, uvVisSampleTestingModel.MethodId, hasCategoryForMaterial, hasCategoryForReagent);
        }


        private string BuildTable(List<StandardResults> standardResults, List<UoMStandardResults> uomStandardResults, string tableName, string methodName, string methodId, bool hasCategoryForMaterial, bool hasCategoryForReagent)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = $"";
            var tableRows = "";
            var headers = new List<string>();
            var subHeaders = new List<string>();
            var filteredStandardResults = new List<StandardResults>();
            if (hasCategoryForMaterial || hasCategoryForReagent)
            {
                if (methodName == "SoloVPE" || methodName == "Lunatic")
                {
                    if (methodName == "SoloVPE")
                    {
                        var waveLengths = new List<string> { "260 nm", "310 nm" };
                        filteredStandardResults = standardResults.Where(s => waveLengths.Any(w => w == s.WaveLength.Value)).ToList();
                        headers = SoloVPEHeaders();
                        subHeaders = SoloVPESubHeaders(uomStandardResults);
                    }
                    else if (methodName == "Lunatic")
                    {
                        var waveLengths = new List<string> { "260 nm", "280 nm", "310 nm" };
                        if (methodId == "M2020N450453")
                        {
                            filteredStandardResults = standardResults.Where(s => s.WaveLength.Value == "560 nm").ToList();
                        }
                        else
                        {
                            filteredStandardResults = standardResults.Where(s => waveLengths.Any(w => w == s.WaveLength.Value)).ToList();
                        }
                        headers = LunaticHeaders();
                        subHeaders = LunaticSubHeaders(uomStandardResults);
                    }



                    foreach (var tableTh in headers)
                    {
                        tableHeaderCells += $"<th class='th'>{tableTh} </th>";
                    }
                    foreach (var tableTh in subHeaders)
                    {
                        tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
                    }
                    tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

                    var groupedRunNumbers = filteredStandardResults.GroupBy(x => x.RunNumber?.Value, (key, group) => new { RunNumber = key, Items = group.ToList() });
                    foreach (var runNumber in groupedRunNumbers)
                    {
                        foreach (var standardResult in runNumber.Items)
                        {
                            var tableCells = "";
                            if (runNumber.Items.IndexOf(standardResult) == 0)
                            {
                                tableCells += $"<td class='td' rowspan='{runNumber.Items.Count}'>{runNumber.RunNumber} </td>";
                            }
                            tableCells += $"<td class='td'>{standardResult.ControlName.Value} </td>";
                            tableCells += $"<td class='td'>{standardResult.ControlId.Value} </td>";
                            tableCells += $"<td class='td'>{standardResult.SubAliquotId.Value} </td>";
                            tableCells += $"<td class='td'>{standardResult.DCAId.Value} </td>";
                            tableCells += $"<td class='td'>{standardResult.CertifiedAbsorbance.NumberValue} </td>";
                            tableCells += $"<td class='td'>{standardResult.SuitabilityCriteriaForAbsorbance.Value} </td>";
                            tableCells += $"<td class='td'>{standardResult.MeasuredAbsorbance.NumberValue} </td>";
                            tableCells += $"<td class='td'>{standardResult.AverageSlope.NumberValue} </td>";
                            tableCells += $"<td class='td'>{standardResult.PercentageRSD.NumberValue} </td>";
                            if (methodName == "SoloVPE")
                            {
                                tableCells += $"<td class='td'>{standardResult.StandardMinR.NumberValue} </td>";
                            }
                            tableCells += $"<td class='td'>{standardResult.SuitabilityResults.Value} </td>";
                            tableCells += $"<td class='td'>{standardResult.SuitabilityResultsOverride.Value} </td>";
                            tableCells += $"<td class='td'>{standardResult.Comments.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                        }
                    }
                }
                var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
                var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
                return tableHtml;
            }
            else
            {
                var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption></table></div>";
                return tableHtml;
            }
        }

        private List<string> SoloVPEHeaders()
        {
            return new List<string>
            {
                 "Run Number",
                "Standard Name",
                "Standard ID",
                "Subaliquot ID",
                "DCA ID",
                "Certified Absorbance",
                "Suitability Criteria for Absorbance",
                "Measured Absorbance",
                "Average Slope",
                "%RSD",
                "R²",
                "Suitability Results",
                "Suitability Results Override",
                "Comments"
            };
        }

        private List<string> LunaticHeaders()
        {
            return new List<string>
            {
                 "Run Number",
                "Standard Name",
                "Standard ID",
                "Subaliquot ID",
                "DCA ID",
                "Certified Absorbance",
                "Suitability Criteria for Absorbance",
                "Measured Absorbance",
                "Average Slope",
                "%RSD",
                "Suitability Results",
                "Suitability Results Override",
                "Comments"
            };
        }
        private List<string> SoloVPESubHeaders(List<UoMStandardResults> uomStandardResults)
        {
            var measuredAbsorbance = uomStandardResults.FirstOrDefault(x => x.Data.Value == "Measured Absorbance").UoM.Value;
            var averageSlope = uomStandardResults.FirstOrDefault(x => x.Data.Value == "Average Slope").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                measuredAbsorbance,
                averageSlope,
                "",
                "",
                "",
                "",
                ""
            };
        }

        private List<string> LunaticSubHeaders(List<UoMStandardResults> uomStandardResults)
        {
            var measuredAbsorbance = uomStandardResults.FirstOrDefault(x => x.Data.Value == "Measured Absorbance").UoM.Value;
            var averageSlope = uomStandardResults.FirstOrDefault(x => x.Data.Value == "Average Slope").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                measuredAbsorbance,
                averageSlope,
                "",
                "",
                "",
                ""
            };
        }


    }
}
