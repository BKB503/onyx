﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class ControlResultsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var materialDetailsData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Material Details");
            var materialDetails = JsonConvert.DeserializeObject<List<MaterialDetails>>(materialDetailsData.Data.ToString());

            var hasCategoryWithControlForMaterial = materialDetails.Any(x => x.Category.Value == "Control");

            var reagentPreparationData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Reagent Preparation");
            var reagentPreparation = JsonConvert.DeserializeObject<List<ReagentPreparation>>(reagentPreparationData.Data.ToString());

            var hasCategoryWithControlForReagent = reagentPreparation.Any(x => x.Category.Value == "Control");

            var uomControlResultsData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Control Results");
            var uomControlResults = JsonConvert.DeserializeObject<List<UoMControlResults>>(uomControlResultsData.Data.ToString());

            var controlResults = JsonConvert.DeserializeObject<List<ControlResults>>(uvVisSampleTestingModel.TableData);

            var getControlFilter = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "Control Results" && x.FilterIdentifier.Value == "View Filter");
            var filteredData = controlResults.Where(x => x.RowShow.NumberValue == getControlFilter.FilterValues.NumberValue && x.MethodType.Value == uvVisSampleTestingModel.MethodName).ToList();
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak}{BuildTable(filteredData, uomControlResults, uvVisSampleTestingModel.TableName, uvVisSampleTestingModel.MethodName, hasCategoryWithControlForMaterial, hasCategoryWithControlForReagent)}";
        }


        private string BuildTable(List<ControlResults> controlResults, List<UoMControlResults> uomControlResults,
                                  string tableName, string methodName, bool hasCategoryWithControlForMaterial, bool hasCategoryWithControlForReagent)
        {
            var tableHeader = "";
            var tableHeaderCells = "";
            var tableSubHeaderCells = "";
            var tableRows = "";
            var headers = new List<string>();
            var subHeaders = new List<string>();
            if (hasCategoryWithControlForMaterial || hasCategoryWithControlForReagent)
            {
                if (methodName == "SoloVPE" || methodName == "Lunatic")
                {
                    if (methodName == "SoloVPE")
                    {
                        headers = SoloVPEHeaders();
                    }
                    else if (methodName == "Lunatic")
                    {
                        headers = LunaticHeaders();
                    }

                    if (methodName == "SoloVPE")
                    {
                        subHeaders = SoloVPESubHeaders(uomControlResults);
                    }
                    else if (methodName == "Lunatic")
                    {
                        subHeaders = LunaticSubHeaders(uomControlResults);
                    }

                    foreach (var tableTh in headers)
                    {
                        tableHeaderCells += $"<th class='th'>{tableTh} </th>";
                    }
                    foreach (var tableTh in subHeaders)
                    {
                        tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
                    }
                    tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

                    var groupedRunNumbers = controlResults.GroupBy(x => x.RunNumber?.Value, (key, group) => new { RunNumber = key, Items = group.ToList() });
                    foreach (var runNumber in groupedRunNumbers)
                    {
                        foreach (var controlResult in runNumber.Items)
                        {
                            var tableCells = "";
                            if (runNumber.Items.IndexOf(controlResult) == 0)
                            {
                                tableCells += $"<td class='td' rowspan='{runNumber.Items.Count}'>{runNumber.RunNumber} </td>";
                            }
                            tableCells += $"<td class='td'>{controlResult.ControlName.Value} </td>";
                            tableCells += $"<td class='td'>{controlResult.ControlId.Value} </td>";
                            tableCells += $"<td class='td'>{controlResult.SubAliquotId.Value} </td>";
                            tableCells += $"<td class='td'>{controlResult.DCAId.Value} </td>";
                            tableCells += $"<td class='td'>{controlResult.ExpectedConcentration.NumberValue} </td>";
                            tableCells += $"<td class='td'>{controlResult.Concentration.NumberValue} </td>";
                            tableCells += $"<td class='td'>{controlResult.AverageConcentration.NumberValue} </td>";
                            tableCells += $"<td class='td'>{controlResult.PercentageRSD.NumberValue} </td>";
                            if (methodName == "SoloVPE")
                            {
                                tableCells += $"<td class='td'>{controlResult.StandardMinR.NumberValue} </td>";
                            }
                            tableCells += $"<td class='td'>{controlResult.PercentageRecovery.NumberValue} </td>";
                            tableCells += $"<td class='td'>{controlResult.SuitabilityResults.Value} </td>";
                            tableCells += $"<td class='td'>{controlResult.SuitabilityResultsOverride.Value} </td>";
                            tableCells += $"<td class='td'>{controlResult.Comments.Value} </td>";
                            tableRows += $"<tr>{tableCells}</tr> ";
                        }
                    }
                }
                var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
                var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
                return tableHtml;
            }
            else
            {
                var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption></table></div>";
                return tableHtml;
            }
        }

        private List<string> SoloVPEHeaders()
        {
            return new List<string>
            {
                "Run Number",
                "Control Name",
                "Control ID",
                "Subaliquot ID",
                "DCA ID",
                "Expected Concentration",
                "Concentration",
                "Average Concentration",
                "%RSD",
                "R²",
                "%Recovery",
                "Suitability Results",
                "Suitability Results Override",
                "Comments"
            };
        }

        private List<string> LunaticHeaders()
        {
            return new List<string>
            {
                "Run Number",
                "Control Name",
                "Control ID",
                "Subaliquot ID",
                "DCA ID",
                "Expected Concentration",
                "Concentration",
                "Average Concentration",
                "%RSD",
                "%Recovery",
                "Suitability Results",
                "Suitability Results Override",
                "Comments"
            };
        }
        private List<string> SoloVPESubHeaders(List<UoMControlResults> uomControlResults)
        {
            var expectedConcentration = uomControlResults.FirstOrDefault(x => x.Data.Value == "Expected Concentration").UoM.Value;
            var concentration = uomControlResults.FirstOrDefault(x => x.Data.Value == "Concentration").UoM.Value;
            var averageConcentration = uomControlResults.FirstOrDefault(x => x.Data.Value == "Average Concentration").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                expectedConcentration,
                concentration,
                averageConcentration,
                "",
                "",
                "",
                "",
                "",
                ""
            };
        }

        private List<string> LunaticSubHeaders(List<UoMControlResults> uomControlResults)
        {
            var expectedConcentration = uomControlResults.FirstOrDefault(x => x.Data.Value == "Expected Concentration").UoM.Value;
            var concentration = uomControlResults.FirstOrDefault(x => x.Data.Value == "Concentration").UoM.Value;
            var averageConcentration = uomControlResults.FirstOrDefault(x => x.Data.Value == "Average Concentration").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                expectedConcentration,
                concentration,
                averageConcentration,
                "",
                "",
                "",
                "",
                ""
            };
        }


    }
}
