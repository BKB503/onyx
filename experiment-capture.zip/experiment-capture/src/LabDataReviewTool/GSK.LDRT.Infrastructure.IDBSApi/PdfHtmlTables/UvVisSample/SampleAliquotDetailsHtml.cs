﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class SampleAliquotDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var uoMSampleAliquotDetails = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Sample Aliquot Details");
            var uoMSampleAliquotDetailsData = JsonConvert.DeserializeObject<List<UoMSampleAliquotDetails>>(uoMSampleAliquotDetails.Data.ToString());

            var filteredData = new List<SampleAliquotDetails>();
            var sampleAliquotDetails = JsonConvert.DeserializeObject<List<SampleAliquotDetails>>(uvVisSampleTestingModel.TableData);
            var getSampleAliquotDetailsFilter = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "Sample Aliquot Details" && x.FilterIdentifier.Value == "RowShow").FilterValues;
            if (getSampleAliquotDetailsFilter != null && getSampleAliquotDetailsFilter.NumberValue != null)
            {
                filteredData = sampleAliquotDetails.Where(x => x.RowShow.NumberValue == getSampleAliquotDetailsFilter.NumberValue).ToList();
            }
            else
            {
                filteredData = sampleAliquotDetails.Where(x => x.RowShow.NumberValue == "1.0").ToList();
            }
            return BuildHtml(filteredData, uoMSampleAliquotDetailsData, uvVisSampleTestingModel.TableName);
        }


        private string BuildHtml(List<SampleAliquotDetails> sampleAliquotDetails, List<UoMSampleAliquotDetails> uoMSampleAliquotDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var tableSubHeaderCells = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            foreach (var tableTh in SubHeaders(uoMSampleAliquotDetails))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr><tr> {tableSubHeaderCells}</tr></thead>";
            var groupedRunNumbers = sampleAliquotDetails.GroupBy(x => x.RunNumber?.Value, (key, group) => new { Run = key, Items = group.ToList() });

            foreach (var runSampleAliquotDetail in groupedRunNumbers)
            {

                if (runSampleAliquotDetail.Items.Any())
                {
                    foreach (var item in runSampleAliquotDetail.Items)
                    {
                        var tableCells = "";
                        if (runSampleAliquotDetail.Items.IndexOf(item) == 0)
                        {
                            tableCells += $"<td class='td' rowspan='{runSampleAliquotDetail.Items.Count}'>{runSampleAliquotDetail.Run} </td>";
                        }
                        tableCells += $"<td class='td'>{item.RepIndex.Value} </td>";
                        tableCells += $"<td class='td'>{item.SubAliquotID.Value} </td>";
                        tableCells += $"<td class='td'>{item.NumberOfReplicates.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.ReplicateName.Value} </td>";
                        tableCells += $"<td class='td'>{item.Concentration.Value} </td>";
                        tableCells += $"<td class='td'>{item.DCAId.Value} </td>";
                        tableCells += $"<td class='td'>{item.PlateId.Value} </td>";
                        tableCells += $"<td class='td'>{item.WellPosition.Value} </td>";
                        tableCells += $"<td class='td'>{item.WellPositionOverride.Value} </td>";
                        tableRows += $"<tr>{tableCells}</tr> ";
                    }

                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
            // return null;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Run Number",
                "Rep Index",
                "Sub Aliquot ID",
                "Number of Replicates",
                "Replicate Name",
                "Concentration",
                "DCA ID",
                "Plate ID",
                "Well Position",
                "Well Position Override"
            };
        }

        private List<string> SubHeaders(List<UoMSampleAliquotDetails> uoMSampleAliquotDetails)
        {
            var concentration = uoMSampleAliquotDetails.FirstOrDefault(x => x.AliquotData.Value == "Concentration").SampleAliquotsUoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                concentration,
                "",
                "",
                "",
                ""
            };
        }

    }
}
