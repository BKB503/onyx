﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class ImportFilenameHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {

            var importFilenames = JsonConvert.DeserializeObject<List<ImportFilename>>(uvVisSampleTestingModel.TableData);

            var filteredData = importFilenames.Where(x => x.ExcludeDataFromFile.Value != "").ToList();
            return BuildHtml(filteredData, uvVisSampleTestingModel.TableName);

        }


        private string BuildHtml(List<ImportFilename> importFilenames, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            if (importFilenames.Any())
            {
                foreach (var runSetup in importFilenames)
                {
                    var tableCells = "";

                    tableCells += $"<td class='td'>{runSetup.ImportFileName.Value} </td>";
                    tableCells += $"<td class='td'>{runSetup.ExcludeDataFromFile.Value} </td>";

                    tableRows += $"<tr>{tableCells}</tr> ";
                }
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Import Filename",
                "Exclude Data from File?",

            };
        }



    }
}
