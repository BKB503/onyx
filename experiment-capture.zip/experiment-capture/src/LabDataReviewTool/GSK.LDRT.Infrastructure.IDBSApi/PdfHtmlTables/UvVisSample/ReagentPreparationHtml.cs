﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class ReagentPreparationHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var uoMReagentPreparation = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Reagent Preparation");
            var uoMReagentPreparationData = JsonConvert.DeserializeObject<List<UoMReagentPreparation>>(uoMReagentPreparation.Data.ToString());
            var filteredData = new List<ReagentPreparation>();
            var reagentPreparations = JsonConvert.DeserializeObject<List<ReagentPreparation>>(uvVisSampleTestingModel.TableData);
            var getReagentPreparationFilter = uvVisSampleTestingModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Reagent Preparation").FilterValues;

            if (getReagentPreparationFilter != null && getReagentPreparationFilter.NumberValue != null)
            {
                filteredData = reagentPreparations.Where(x => x.RowShow.NumberValue == getReagentPreparationFilter.NumberValue).ToList();
            }
            else
            {
                filteredData = reagentPreparations.Where(x => x.RowShowString.Value == getReagentPreparationFilter.StringValue).ToList();
            }

            var tableHtml = BuildReagentPreparationAutoFitTable1Html(filteredData, uoMReagentPreparationData, uvVisSampleTestingModel.TableName);
            tableHtml += BuildReagentPreparationAutoFitTable2Html(filteredData, uoMReagentPreparationData, uvVisSampleTestingModel.TableName);
            var html = $"<div class='table-wrapper'>{tableHtml}</div>";
            return html;
        }


        private string BuildReagentPreparationAutoFitTable1Html(List<ReagentPreparation> reagentPreparations, List<UoMReagentPreparation> uoMReagentPreparations, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in ReagentPreparationAutoFitTable1Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in ReagentPreparationAutoFitTable1SubHeaders(uoMReagentPreparations))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var reagentPreparation in reagentPreparations)
            {
                var expiryDate = "";
                if (reagentPreparation.ExpiryDate != null && reagentPreparation.ExpiryDate.Value != null && reagentPreparation.ExpiryDate.Value.HasValue)
                {
                    expiryDate = reagentPreparation.ExpiryDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var preparationDate = "";
                if (reagentPreparation.PreparationDate != null && reagentPreparation.PreparationDate.Value != null && reagentPreparation.PreparationDate.Value.HasValue)
                {
                    preparationDate = reagentPreparation.PreparationDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{reagentPreparation.ReagentIndex.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ReagentComponentIndex.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.IDBSSampleID.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.SolutionName.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ReagentType.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ConcentrationUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.NumberofComponents.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.NameofComponent.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.Amount.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.AmountUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.MolecularWeight.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
            // return null;
        }


        private List<string> ReagentPreparationAutoFitTable1Headers()
        {
            return new List<string>
            {
                "Reagent Index",
                "Reagent Component Index",
                "IDBS Sample ID",
                "Solution Name",
                "Reagent Type",
                "Concentration Unit",
                "Number of Components",
                "Name of Component",
                "Amount",
                "Amount Unit",
                "Molecular Weight"
            };
        }

        private List<string> ReagentPreparationAutoFitTable1SubHeaders(List<UoMReagentPreparation> uoMReagentPreparations)
        {
            var molecularWeight = uoMReagentPreparations.FirstOrDefault(x => x.ReagentData.Value == "Molecular Weight").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                molecularWeight
            };
        }


        private string BuildReagentPreparationAutoFitTable2Html(List<ReagentPreparation> reagentPreparations, List<UoMReagentPreparation> uoMReagentPreparations, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in ReagentPreparationAutoFitTable2Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in ReagentPreparationAutoFitTable2SubHeaders(uoMReagentPreparations))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var reagentPreparation in reagentPreparations)
            {
                var expiryDate = "";
                if (reagentPreparation.ExpiryDate != null && reagentPreparation.ExpiryDate.Value != null && reagentPreparation.ExpiryDate.Value.HasValue)
                {
                    expiryDate = reagentPreparation.ExpiryDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var preparationDate = "";
                if (reagentPreparation.PreparationDate != null && reagentPreparation.PreparationDate.Value != null && reagentPreparation.PreparationDate.Value.HasValue)
                {
                    preparationDate = reagentPreparation.PreparationDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{reagentPreparation.ReagentIndex.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ReagentComponentIndex.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.DiluentName.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.DiluentVolume.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TotalVolume.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.Concentration.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.InitialConcentrationUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.DilutionRequired.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.InitialpH.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.FinalpH.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.pHAdjustmentSubstance.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.Category.Value} </td>";
                tableCells += $"<td class='td'>{preparationDate} </td>";
                tableCells += $"<td class='td'>{expiryDate} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.Comments.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
            // return null;
        }


        private List<string> ReagentPreparationAutoFitTable2Headers()
        {
            return new List<string>
            {
                "Reagent Index",
                "Reagent Component Index",
                "Diluent Name",
                "Diluent Volume",
                "Total Volume",
                "Concentration",
                "Initial Concentration  Unit",
                "Dilution Required?",
                "Initial pH",
                "Final pH",
                "pH Adjustment Substance",
                "Category",
                "Preparation Date",
                "Expiry Date",
                "Comments"

            };
        }

        private List<string> ReagentPreparationAutoFitTable2SubHeaders(List<UoMReagentPreparation> uoMReagentPreparations)
        {
            var molecularWeight = uoMReagentPreparations.FirstOrDefault(x => x.ReagentData.Value == "Molecular Weight").UoM.Value;
            var diluentVolume = uoMReagentPreparations.FirstOrDefault(x => x.ReagentData.Value == "Diluent Volume").UoM.Value;
            var totalVolume = uoMReagentPreparations.FirstOrDefault(x => x.ReagentData.Value == "Total Volume").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
               diluentVolume,
               totalVolume,
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                ""
            };
        }


    }
}
