﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class MaterialAndReagentDilutionHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {

            var materialAndReagentDilutions = JsonConvert.DeserializeObject<List<MaterialAndReagentDilution>>(uvVisSampleTestingModel.TableData);
            var filteredData = new List<MaterialAndReagentDilution>();
            var getReagentPreparationFilter = uvVisSampleTestingModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Material and Reagent Dilution").FilterValues;

            if (getReagentPreparationFilter != null && getReagentPreparationFilter.NumberValue != null)
            {
                filteredData = materialAndReagentDilutions.Where(x => x.RowShow.NumberValue == getReagentPreparationFilter.NumberValue).ToList();
            }
            else
            {
                filteredData = materialAndReagentDilutions.Where(x => x.RowShowString.Value == getReagentPreparationFilter.StringValue).ToList();
            }

            var table1Html = BuildAutoFitTable1Html(filteredData, uvVisSampleTestingModel.TableName);
            var table2Html = BuildAutoFitTable2Html(filteredData, uvVisSampleTestingModel.TableName);
            var html = $"<div class='table-wrapper'> {table1Html} {table2Html}</div>";
            return html;
        }

        private string BuildAutoFitTable1Html(List<MaterialAndReagentDilution> reagentPreparations, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in BuildAutoFitTable1Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }


            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var reagentPreparation in reagentPreparations)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{reagentPreparation.DilutionsList.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.DilutionIndex.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ReagentComponentIndex.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.SolutionName.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.NameofComponent?.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.InitialConcentration.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.InitialConcentrationUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.DiluentName.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TotalVolume.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TotalVolumeUnit.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
            // return null;
        }


        private List<string> BuildAutoFitTable1Headers()
        {
            return new List<string>
            {
                "Dilutions List",
                "Dilution Index",
                "Reagent Component Index",
                "Solution Name",
                "Name of Component",
                "Initial Concentration",
                "Initial Concentration  Unit",
                "Diluent Name",
                "Total Volume",
                "Total Volume Unit"
            };
        }

        private string BuildAutoFitTable2Html(List<MaterialAndReagentDilution> reagentPreparations, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in BuildAutoFitTable2Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }


            tableHeader += $"<thead>{ColSpanHeaders()}<tr>{tableHeaderCells}</tr></thead>";

            foreach (var reagentPreparation in reagentPreparations)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{reagentPreparation.DilutionsList.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.DilutionIndex.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TargetFinalConcentration.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TargetFinalConcentrationUnit.StringValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TargetConcentrationUnitOverride.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TargetStockVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TargetStockVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TargetDiluentVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.TargetDiluentVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ActualFinalConcentration.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ActualFinalConcentrationOverride.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ActualConcentrationUnit.StringValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ActualStockVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ActualStockVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ActualDiluentVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.ActualDiluentVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{reagentPreparation.FurtherDilutionRequired.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
            // return null;
        }

        private string ColSpanHeaders()
        {
            return $"<tr><th class='th' rowspan='2'>Dilutions List</th> <th class='th' rowspan='2'> Dilution Index</th><th colspan='7' class='th'>Target</th><th colspan='7' class='th'>Actual</th><th class='th' rowspan='2'>Further Dilution Required? </th></tr>";
        }

        private List<string> BuildAutoFitTable2Headers()
        {
            return new List<string>
            {
                "Final Concentration",
                "Final Concentration Unit",
                "Concentration Unit Override",
                "Stock Volume",
                "Stock Volume Unit",
                "Diluent Volume",
                "Diluent Volume Unit",
                "Final  Concentration",
                "Final Concentration Override",
                "Concentration  Unit",
                "Stock  Volume",
                "Stock Volume  Unit",
                "Diluent  Volume",
                "Diluent  Volume Unit",
                //"Further Dilution Required?"
            };
        }

    }
}
