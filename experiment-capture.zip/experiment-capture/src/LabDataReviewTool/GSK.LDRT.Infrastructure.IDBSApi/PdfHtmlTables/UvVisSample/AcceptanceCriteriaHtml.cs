﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class AcceptanceCriteriaHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var acceptanceCriterias = JsonConvert.DeserializeObject<List<AcceptanceCriteria>>(uvVisSampleTestingModel.TableData);

            return BuildHtml(acceptanceCriterias, uvVisSampleTestingModel.TableName, uvVisSampleTestingModel.MethodName, uvVisSampleTestingModel.MethodId);

        }


        private string BuildHtml(List<AcceptanceCriteria> acceptanceCriterias, string tableName, string methodName, string methodId)
        {
            var tableHeader = $"<thead>{BuildHeaders(methodName, methodId)}</thead>";
            var tableRows = BuildTableBody(acceptanceCriterias, methodName, methodId);

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }




        private string BuildTableBody(List<AcceptanceCriteria> acceptanceCriterias, string methodName, string methodId)
        {
            var tableRows = "";
            var minOrMax = new List<string> { "Min", "Max" };
            var filteredData = new List<AcceptanceCriteria>();
            if (methodName == "Lunatic" && methodId == "M2020N450453")
            {
                filteredData = acceptanceCriterias.Where(x => x.SystemSuitabiliityFilterIdx.Value == "System Suitabiliity 2" && minOrMax.Any(m => m == x.MaxMin.Value)).ToList();
            }
            else
            {
                filteredData = acceptanceCriterias.Where(x => x.SystemSuitabiliityFilterIdx.Value == "System Suitabiliity" && minOrMax.Any(m => m == x.MaxMin.Value)).ToList();
            }
            var groupedAcceptanceCritiers = filteredData.GroupBy(x => x.RunNumber.Value, (key, group) => new { RunNumber = key, Items = group.ToList() });

            foreach (var acceptanceCriteria in groupedAcceptanceCritiers)
            {
                var tableCells = "";
                if (methodName == "Lunatic" && (methodId == "M2020N450453" || methodId == "INS837897"))
                {
                    var standardMinR = acceptanceCriteria.Items?.FirstOrDefault(x => x.MaxMin.Value == "Min")?.StandardMinR?.NumberValue;
                    var percentageRSD = acceptanceCriteria.Items?.FirstOrDefault(x => x.MaxMin.Value == "Max")?.PercentageRSD?.NumberValue;
                    var minA560 = acceptanceCriteria.Items?.FirstOrDefault(x => x.MaxMin.Value == "Min")?.A560?.NumberValue;
                    var maxA560 = acceptanceCriteria.Items?.FirstOrDefault(x => x.MaxMin.Value == "Max")?.A560?.NumberValue;
                    if (methodId == "M2020N450453")
                    {

                        tableCells += $"<td class='td'>{acceptanceCriteria.RunNumber} </td>";

                        tableCells += $"<td class='td'>{standardMinR}</td>";
                        tableCells += $"<td class='td'>{percentageRSD}</td>";
                        tableCells += $"<td class='td'>{minA560}</td>";
                        tableCells += $"<td class='td'>{maxA560}</td>";
                    }
                    else if (methodId == "INS837897")
                    {
                        var percentageResidue = acceptanceCriteria.Items?.FirstOrDefault(x => x.MaxMin.Value == "Max")?.PercentageResidue?.NumberValue;

                        tableCells += $"<td class='td'>{acceptanceCriteria.RunNumber} </td>";
                        tableCells += $"<td class='td'>{standardMinR}</td>";
                        tableCells += $"<td class='td'>{percentageRSD}</td>";
                        tableCells += $"<td class='td'>{percentageResidue}</td>";
                        tableCells += $"<td class='td'>{minA560}</td>";
                        tableCells += $"<td class='td'>{maxA560}</td>";
                    }
                }

                else
                {
                    foreach (var item in acceptanceCriteria.Items)
                    {
                        if (acceptanceCriteria.Items.IndexOf(item) == 0)
                        {
                            tableCells += $"<td class='td'>{acceptanceCriteria.RunNumber} </td>";
                        }
                        if (item.MaxMin.Value == "Min")
                        {
                            tableCells += $"<td class='td'>{item.StandardMinR.NumberValue} </td>";
                        }
                        else
                        {
                            tableCells += $"<td class='td'>{item.PercentageRSD.NumberValue} </td>";
                        }
                    }
                    tableRows += $"<tr>{tableCells}</tr> ";
                }


            }
            return tableRows;
        }

        private string BuildHeaders(string methodName, string methodId)
        {
            if (methodName == "Lunatic" && methodId == "INS837897")
            {
                return $"<tr><th class='th' rowspan='2'>Run Number </th><th class='th'>R² </th><th class='th'>% RSD</th> <th class='th'>% Residue </th>" +
                    $"</tr> <tr> <th class='th'> Min </th> <th class='th'>Max </th> <th class='th'>Max </th></tr>";
            }
            else if (methodName == "Lunatic" && methodId == "M2020N450453")
            {
                return $"<tr><th class='th' rowspan='2'>Run Number </th><th class='th'>R² </th><th class='th'>% RSD</th><th class='th' colspan='2'>A560</th>" +
                    $"</tr> <tr> <th class='th'> Min </th> <th class='th'>Max </th> <th class='th'>Min</th> <th class='th'>Max</th></tr>";
            }
            else if (methodName == "Lunatic" && methodId == "INS837897")
            {
                return $"<tr><th class='th' rowspan='2'>Run Number </th><th class='th'>R² </th><th class='th'>% RSD</th><th class='th'>%Residue </th><th class='th' colspan='2'>A560</th>" +
                    $"</tr> <tr> <th class='th'> Min </th> <th class='th'>Max </th><th class='th'>Max </th> <th class='th'>Min</th> <th class='th'>Max</th></tr>";
            }

            return $"<tr><th class='th' rowspan='2'>Run Number </th><th class='th'>R² </th><th class='th'>% RSD</th></tr> " +
                $"<tr> <th class='th'> Min </th> <th class='th'>Max </th></tr>";
        }

    }
}
