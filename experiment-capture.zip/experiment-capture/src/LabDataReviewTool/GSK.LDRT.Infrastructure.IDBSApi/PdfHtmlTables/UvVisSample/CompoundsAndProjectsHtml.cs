﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class CompoundsAndProjectsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var uomCompundsAndProjects = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Compounds and Projects");
            var uomCompundsAndProjectsData = JsonConvert.DeserializeObject<List<UoMCompoundsAndProjects>>(uomCompundsAndProjects.Data);

            var compoundsAndProjectsData = JsonConvert.DeserializeObject<List<CompoundsAndProjects>>(uvVisSampleTestingModel.TableData);

            var getCompoundAndProjectsFilter = uvVisSampleTestingModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Compound and Projects").FilterIdentifier;
            var filteredData = compoundsAndProjectsData.Where(x => x.CompoundsAndProjectsId.Value != getCompoundAndProjectsFilter.Value).ToList();
            return BuildHtml(filteredData, uomCompundsAndProjectsData, uvVisSampleTestingModel.TableName);
        }

        private string BuildHtml(List<CompoundsAndProjects> compoundsAndProjects, List<UoMCompoundsAndProjects> uomCompoundsAndProjects, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in SubHeaders(uomCompoundsAndProjects))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }
            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var compoundsAndProject in compoundsAndProjects)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{compoundsAndProject.CompoundsAndProjectsId.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.CompoundId.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.Project.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.ProjectId.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.ProjectIdOverride.Value} </td>";
                tableCells += $"<td class='td'>{compoundsAndProject.ExtinctionCoefficient.Value} </td>";
                tableCells += $"<td class='td-override'><b>{compoundsAndProject.ExtinctionCoefficientOverride.Value}</b> </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }

        private List<string> Headers()
        {
            return new List<string>
            {
                "Compounds and Projects ID",
                "Compound ID",
                "Project",
                "Project ID",
                "Project ID Override",
                "Extinction Coefficient",
                "Extinction Coefficient Override"
            };
        }
        private List<string> SubHeaders(List<UoMCompoundsAndProjects> uomCompoundsAndProjects)
        {
            var extinctionCoeff = uomCompoundsAndProjects.FirstOrDefault(x => x.CompoundsandProjectsData.Value == "Extinction Coefficient").UoM.Value;
            var extinctionCoeffOverride = uomCompoundsAndProjects.FirstOrDefault(x => x.CompoundsandProjectsData.Value == "Extinction Coefficient Override").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                extinctionCoeff,
                extinctionCoeffOverride
            };
        }


    }
}
