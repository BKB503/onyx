﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class SampleDilutionHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {

            var sampleDilutions = JsonConvert.DeserializeObject<List<SampleDilution>>(uvVisSampleTestingModel.TableData);
            var getSampleDilutionFilter = uvVisSampleTestingModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Sample Dilution").FilterValues;
            var filteredData = new List<SampleDilution>();

            filteredData = sampleDilutions.Where(x => x.RowShow?.NumberValue == getSampleDilutionFilter.NumberValue).ToList();
            if (!filteredData.Any())
            {
                filteredData = sampleDilutions.Where(x => x.RowShowNumber?.NumberValue == getSampleDilutionFilter.NumberValue).ToList();
            }


            var tableHtml = BuildAutoFitTable1Html(filteredData, uvVisSampleTestingModel.TableName);
            tableHtml += BuildAutoFitTable2Html(filteredData, uvVisSampleTestingModel.TableName);
            var html = $"<div class='table-wrapper'>{tableHtml} </div>";
            return html;
        }


        private string BuildAutoFitTable1Html(List<SampleDilution> sampleDilutions, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in BuildAutoFitTable1Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }


            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var sampleDilution in sampleDilutions)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{sampleDilution.SampleId.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.SampleDilutionCountIndex.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.SampleId.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.SubAliquotId.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.SampleName.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.InitialConcentration.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.InitialConcentrationUnit.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.DiluentName.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TotalVolume.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TotalVolumeUnit.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
            // return null;
        }


        private List<string> BuildAutoFitTable1Headers()
        {
            return new List<string>
            {
                "Sample Dilution Index",
                "Sample Dilution Count Index",
                "Sample ID",
                "Sub Aliquot ID",
                "Sample Name",
                "Initial Concentration",
                "Initial Concentration  Unit",
                "Diluent Name",
                "Total Volume",
                "Total Volume Unit"
            };
        }

        private string BuildAutoFitTable2Html(List<SampleDilution> sampleDilutions, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in BuildAutoFitTable2Headers())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }


            tableHeader += $"<thead>{ColSpanHeaders()}<tr>{tableHeaderCells}</tr></thead>";

            foreach (var sampleDilution in sampleDilutions)
            {
                var tableCells = "";
                tableCells += $"<td class='td'>{sampleDilution.SampleId.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.SampleDilutionCountIndex.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TargetDilutionFactor.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TargetFinalConcentration.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TargetConcentrationUnit.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TargetStockVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TargetStockVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TargetDiluentVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.TargetDiluentVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.ActualFinalConcentration.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.ActualFinalConcentrationOverride.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.ActualConcentrationUnit.StringValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.ActualStockVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.ActualStockVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.ActualDiluentVolume.NumberValue} </td>";
                tableCells += $"<td class='td'>{sampleDilution.ActualDiluentVolumeUnit.Value} </td>";
                tableCells += $"<td class='td'>{sampleDilution.FurtherDilutionRequired.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table>";
            return tableHtml;
            // return null;
        }

        private string ColSpanHeaders()
        {
            return $"<tr><th class='th' rowspan='2'>Sample Dilution Index</th> <th class='th' rowspan='2'> Sample Dilution Count Index</th>" +
                $"<th colspan='7' class='th'>Target</th><th colspan='7' class='th'>Actual</th><th class='th' rowspan='2'>Further Dilution Required? </th></tr>";
        }

        private List<string> BuildAutoFitTable2Headers()
        {
            return new List<string>
            {
                "Dilution Factor",
                "Final Concentration",
                "Concentration Unit",
                "Stock Volume",
                "Stock Volume Unit",
                "Diluent Volume",
                "Diluent Volume Unit",
                "Final  Concentration",
                "Final Concentration Override",
                "Concentration  Unit",
                "Stock  Volume",
                "Stock Volume  Unit",
                "Diluent  Volume",
                "Diluent  Volume Unit",
                //"Further Dilution Required?"
            };
        }

    }
}
