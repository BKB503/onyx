﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class EquipmentDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var equipmentDetails = JsonConvert.DeserializeObject<List<EquipmentDetails>>(uvVisSampleTestingModel.TableData);
            var getEquipmentDetailsFilter = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "Equipment Details" && x.FilterIdentifier.Value == "RowShow").FilterValues;
            if (getEquipmentDetailsFilter != null && getEquipmentDetailsFilter.NumberValue != null)
            {
                var filteredData = equipmentDetails.Where(x => x.RowShow.NumberValue == getEquipmentDetailsFilter.NumberValue).ToList();
                return BuildEquimentDetailsHtml(filteredData, uvVisSampleTestingModel.TableName);
            }
            else
            {
                var filteredData = equipmentDetails.Where(x => x.RowShowString.Value == getEquipmentDetailsFilter.StringValue).ToList();
                return BuildEquimentDetailsHtml(filteredData, uvVisSampleTestingModel.TableName);
            }
        }

        private string BuildEquimentDetailsHtml(List<EquipmentDetails> equipmentDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in EquipmentDeatilsHeader())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";

            foreach (var equipment in equipmentDetails)
            {
                var calibDueDate = "";
                if (equipment.CalibrationDueDate != null && equipment.CalibrationDueDate.Value != null && equipment.CalibrationDueDate.Value.HasValue)
                {
                    calibDueDate = equipment.CalibrationDueDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{equipment.EntryMode.Value} </td>";
                tableCells += $"<td class='td'>{equipment.EquipmentIndex.Value} </td>";
                tableCells += $"<td class='td'>{equipment.EquipmentId.Value} </td>";
                tableCells += $"<td class='td'>{equipment.EquipmentName.Value} </td>";
                tableCells += $"<td class='td'>{equipment.EquipmentType.Value} </td>";
                tableCells += $"<td class='td'>{equipment.SerialNumber.Value} </td>";
                tableCells += $"<td class='td'>{equipment.VendorSupplier.Value} </td>";
                tableCells += $"<td class='td'>{equipment.CalibrationStatus.Value} </td>";
                tableCells += $"<td class='td'>{calibDueDate} </td>";
                tableCells += $"<td class='td'>{equipment.Location.Value} </td>";
                tableCells += !string.IsNullOrEmpty(equipment.InventoryLink?.Value) ? $"<td class='td'><a href='{equipment.InventoryLink.Value}'>{equipment.EquipmentId.Value} </a></td>" : $"<td class='td'>{equipment.InventoryLink?.Value}</td>";
                tableCells += $"<td class='td'>{equipment.Comments.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> EquipmentDeatilsHeader()
        {
            return new List<string>
            {
                "Entry Mode",
                "Equipment Index",
                "Equipment ID",
                "Equipment Name",
                "Equipment Type",
                "Serial Number",
                "Vendor/Supplier",
                "Calibration Status",
                "Calibration Due Date",
                "Location",
                "Inventory Link",
                "Comments"
            };
        }

    }
}
