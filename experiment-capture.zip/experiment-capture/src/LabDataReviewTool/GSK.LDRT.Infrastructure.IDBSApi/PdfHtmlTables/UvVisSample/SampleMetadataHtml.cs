﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class SampleMetadataHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var sampleMetadatas = JsonConvert.DeserializeObject<List<SampleMetadata>>(uvVisSampleTestingModel.TableData);

            return BuildHtml(sampleMetadatas, "Sample Dashboard");

        }



        private string BuildHtml(List<SampleMetadata> sampleMetadatas, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            foreach (var sampleMetadata in sampleMetadatas)
            {
                var tableCells = "";

                tableCells += $"<td class='td'>{sampleMetadata.DashSampleIdx.Value} </td>";
                tableCells += $"<td class='td'>{sampleMetadata.SampleId.Value} </td>";
                tableCells += $"<td class='td'>{sampleMetadata.SampleName.Value} </td>";
                tableCells += $"<td class='td'>{sampleMetadata.ExperimentId.Value} </td>";
                tableCells += $"<td class='td'>{sampleMetadata.ExperimentName.Value} </td>";
                tableCells += $"<td class='td'>{sampleMetadata.ExperimentPath.Value} </td>";
                tableCells += $"<td class='td'>{sampleMetadata.ParentMaterialId.Value} </td>";
                tableCells += $"<td class='td'>{sampleMetadata.ParentMaterialName.Value} </td>";


                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Index",
                "Sample ID",
                "Sample Name",
                "Experiment ID",
                "Experiment Name",
                "Experiment Path",
                "Parent Material ID",
                "Parent Material Name",
            };
        }



    }
}
