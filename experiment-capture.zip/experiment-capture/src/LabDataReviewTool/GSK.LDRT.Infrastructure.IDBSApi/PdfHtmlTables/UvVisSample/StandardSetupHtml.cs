﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class StandardSetupHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {

            var standardSetups = JsonConvert.DeserializeObject<List<StandardSetup>>(uvVisSampleTestingModel.TableData);

            return BuildHtml(standardSetups, uvVisSampleTestingModel.TableName);

        }


        private string BuildHtml(List<StandardSetup> runSetups, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            foreach (var runSetup in runSetups)
            {
                var tableCells = "";

                tableCells += $"<td class='td'>{runSetup.RunNumber.Value} </td>";
                tableCells += $"<td class='td'>{runSetup.NumberofRows.NumberValue} </td>";
                tableCells += $"<td class='td'>{runSetup.ConcentrationUnit.Value} </td>";


                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Run Number",
                "Number of Rows",
                "Concentration Unit"
            };
        }



    }
}
