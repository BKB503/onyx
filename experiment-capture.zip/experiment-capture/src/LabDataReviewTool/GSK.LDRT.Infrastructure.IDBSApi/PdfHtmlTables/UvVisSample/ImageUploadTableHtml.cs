﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class ImageUploadTableHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var filterValue = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "Image Upload" && x.FilterIdentifier.Value == "Row Show").FilterValues;
            var imageUploadTables = JsonConvert.DeserializeObject<List<ImageUploadTable>>(uvVisSampleTestingModel.TableData);
            var filteredData = new List<ImageUploadTable>();

            filteredData = imageUploadTables.Where(x => x.RowShow?.NumberValue == filterValue.NumberValue).ToList();
            if (!filteredData.Any())
            {
                filteredData = imageUploadTables.Where(x => x.RowShowWithSpace?.NumberValue == filterValue.NumberValue).ToList();
            }
            var spreadSheetTableData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Image Upload Table");
            var pageBreak = " <div class='page-break'></div>";
            var tableHtml = BuildHtml(filteredData, uvVisSampleTestingModel.TableName, spreadSheetTableData.Images);
            return $"{pageBreak}{tableHtml}";

        }

        private string BuildHtml(List<ImageUploadTable> imageUploadTables, string tableName, List<ImageResponseEntity> imageResponseEntities)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            foreach (var imageUploadTable in imageUploadTables)
            {
                var tableCells = "";
                var imageEntity = imageResponseEntities.FirstOrDefault(x => x.Name == imageUploadTable.Image.Value);
                var image = $"<img  src='data:{imageEntity.MimeType};base64,{imageEntity.Base64}' />";
                tableCells += $"<td class='td'>{imageUploadTable.RunNumber.Value} </td>";
                tableCells += $"<td class='td'>{imageUploadTable.ImageIndex.Value} </td>";
                // tableCells += $"<td class='td'>{imageUploadTable.Image.Value} </td>";
                tableCells += $"<td class='td'>{image} </td>";
                tableCells += $"<td class='td'>{imageUploadTable.Comments.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Run Number",
                "Image Index",
                "Image",
                "Comments"
            };
        }

    }
}
