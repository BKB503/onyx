﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class MethodParametersHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var methodParameters = JsonConvert.DeserializeObject<List<MethodParameters>>(uvVisSampleTestingModel.TableData);
            var filteredData = new List<MethodParameters>();
            if (uvVisSampleTestingModel.MethodName == "Nanodrop")
            {
                filteredData = methodParameters.Where(x => x.Method.Value == uvVisSampleTestingModel.MethodName && x.ParametersGroup.Value == "Setup" && x.ParameterName.Value != "").ToList();
            }
            else if (uvVisSampleTestingModel.MethodName == "Lunatic")
            {
                filteredData = methodParameters.Where(x => x.Method.Value == uvVisSampleTestingModel.MethodName && x.ParametersGroup.Value == "Setup" && x.ParameterName.Value != "").ToList();
            }
            else
            {
                filteredData = methodParameters.Where(x => x.Method.Value == uvVisSampleTestingModel.MethodName && x.ParametersGroup.Value != "Setup").ToList();
            }


            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak} {BuildHtml(filteredData, uvVisSampleTestingModel.TableName, uvVisSampleTestingModel.MethodName)}";
        }


        private string BuildHtml(List<MethodParameters> methodParameters, string tableName, string methodName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr><th class='th' colspan={headers.Count}>{methodName} </th> </tr><tr>{tableHeaderCells}</tr></thead>";
            var groupedRunNumbers = methodParameters.GroupBy(x => x.RunNumber.Value, (key, group) => new { RunNumber = key, Items = group.ToList() });
            foreach (var runNumber in groupedRunNumbers)
            {
                if (runNumber.Items.Any())
                {
                    var tableCells = "";
                    tableCells += $"<td class='td' rowspan='{runNumber.Items.Count}'>{runNumber.RunNumber} </td>";
                    var groupedMethods = runNumber.Items.GroupBy(x => x.ParametersGroup.Value, (key, group) => new { ParameterGroup = key, ParameterValues = group.ToList() });
                    foreach (var method in groupedMethods)
                    {
                        tableCells += $"<td class='td' rowspan='{method.ParameterValues.Count}'>{method.ParameterGroup} </td>";
                        foreach (var parameter in method.ParameterValues)
                        {
                            tableCells += $"<td class='td'>{parameter.Parameter.Value} </td>";
                            tableCells += $"<td class='td'>{parameter.ParameterName.Value} </td>";
                            tableCells += $"<td class='td'>{parameter.ParameterValue.Value} </td>";
                            tableCells += $"<td class='td'>{parameter.ParameterValueOverride.Value} </td>";
                            tableCells += $"<td class='td'>{parameter.Comments.Value} </td>";

                            tableRows += $"<tr>{tableCells}</tr> ";
                            tableCells = "";
                        }
                    }
                }
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Run Number",
                "Parameters Group",
                "Parameter",
                "Parameter Name",
                "Parameter Value",
                "Parameter Value Override",
                "Comments"
            };
        }



    }
}
