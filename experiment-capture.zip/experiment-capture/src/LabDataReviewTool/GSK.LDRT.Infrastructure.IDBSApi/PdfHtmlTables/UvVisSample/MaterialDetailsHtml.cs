﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class MaterialDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var uomMaterialDetails = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "UoM_Material Details");
            var uomMaterialDetailsData = JsonConvert.DeserializeObject<List<UoMMaterialDetails>>(uomMaterialDetails.Data.ToString());

            var filteredData = new List<MaterialDetails>();
            var materialDetails = JsonConvert.DeserializeObject<List<MaterialDetails>>(uvVisSampleTestingModel.TableData);

            var getMaterialDetailsFilter = uvVisSampleTestingModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Material Details").FilterValues;
            if (getMaterialDetailsFilter != null && getMaterialDetailsFilter.NumberValue != null)
            {
                filteredData = materialDetails.Where(x => x.RowShow.NumberValue == getMaterialDetailsFilter.NumberValue).ToList();
            }
            else
            {
                filteredData = materialDetails.Where(x => x.RowShowString.Value == getMaterialDetailsFilter.StringValue).ToList();
            }
            var pageBreak = " <div class='page-break'></div>";
            var table = BuildMaterialDetailsHtml(filteredData, uomMaterialDetailsData, uvVisSampleTestingModel.TableName);
            return $"{pageBreak}{table}";
        }

        private string BuildMaterialDetailsHtml(List<MaterialDetails> materialDetails, List<UoMMaterialDetails> uomMaterials, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableSubHeaderCells = "";
            var tableRows = "";

            foreach (var tableTh in MaterialDetailsHeaders())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }
            foreach (var tableTh in MaterialDetailsSubHeaders(uomMaterials))
            {
                tableSubHeaderCells += $"<th class='th-border'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr>  <tr> {tableSubHeaderCells}</tr></thead>";

            foreach (var material in materialDetails)
            {
                var expiryDate = "";
                if (material.ExpiryDate != null && material.ExpiryDate.Value != null && material.ExpiryDate.Value.HasValue)
                {
                    expiryDate = material.ExpiryDate.Value.Value.ToString("MMM dd, yyyy");
                }
                var tableCells = "";
                tableCells += $"<td class='td'>{material.MaterialIndex.Value} </td>";
                tableCells += $"<td class='td'>{material.EntryMode.Value} </td>";
                tableCells += $"<td class='td'>{material.MaterialId.Value} </td>";
                tableCells += $"<td class='td'>{material.MaterialName.Value} </td>";
                tableCells += $"<td class='td'>{material.MaterialType.Value} </td>";
                tableCells += $"<td class='td'>{material.CatalogNumber.Value} </td>";
                tableCells += $"<td class='td'>{material.LotNumber.Value} </td>";
                tableCells += $"<td class='td'>{material.VendorSupplier.Value} </td>";
                tableCells += $"<td class='td'>{material.SolidLiquid.Value} </td>";
                tableCells += $"<td class='td'>{material.Concentration.Value} </td>";
                tableCells += $"<td class='td'>{material.ConcentrationUnit.Value} </td>";
                tableCells += $"<td class='td'>{material.MolecularWeight.NumberValue} </td>";
                tableCells += $"<td class='td'>{material.SafetyInformation.Value} </td>";
                tableCells += $"<td class='td'>{material.Category.Value} </td>";
                tableCells += $"<td class='td'>{expiryDate} </td>";
                tableCells += !string.IsNullOrEmpty(material.InventoryLink.Value) ? $"<td class='td'><a href='{material.InventoryLink.Value}'>{material.MaterialId.Value} </a></td>" : $"<td class='td'>{material.InventoryLink.Value}</td>";
                tableCells += $"<td class='td'>{material.DilutionRequired.Value} </td>";
                tableCells += $"<td class='td'>{material.Comments.Value} </td>";
                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
            // return null;
        }


        private List<string> MaterialDetailsHeaders()
        {
            return new List<string>
            {
                "Material Index",
                "Entry Mode",
                "Material ID",
                "Material Name",
                "Material Type",
                "Catalog Number",
                "Lot Number",
                "Vendor/ Supplier",
                "Solid/ Liquid",
                "Concentration",
                "Concentration Unit",
                "Molecular Weight",
                "Safety Information",
                "Category",
                "Expiry Date",
                "Inventory Link",
                "Dilution Required?",
                "Comments"
            };
        }

        private List<string> MaterialDetailsSubHeaders(List<UoMMaterialDetails> uomMaterialDetails)
        {
            var molecularWeight = uomMaterialDetails.FirstOrDefault(x => x.MaterialsData.Value == "Molecular Weight").UoM.Value;
            return new List<string>
            {
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                molecularWeight,
                "",
                "",
                "",
                "",
                "",
                ""
            };
        }


    }
}
