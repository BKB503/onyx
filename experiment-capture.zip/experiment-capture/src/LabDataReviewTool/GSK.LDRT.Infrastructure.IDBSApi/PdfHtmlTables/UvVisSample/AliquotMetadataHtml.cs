﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class AliquotMetadataHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var aliquotMetadata = JsonConvert.DeserializeObject<List<AliquotMetadata>>(uvVisSampleTestingModel.TableData);
            if (uvVisSampleTestingModel.TableName == "Aliquot Details- Dashboard")
            {
                var filter = uvVisSampleTestingModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Aliquot Details- Dashboard" && x.FilterIdentifier.Value == "RowShow").FilterValues;
                var filteredData = aliquotMetadata.Where(x => x.RowShow.NumberValue == filter.NumberValue).ToList();
                return BuildHtml(filteredData, "Aliquot Dashboard");
            }
            else
            {
                var filter = uvVisSampleTestingModel.JsonFilterTables.FirstOrDefault(x => x.TableName.Value == "Aliquot Metadata" && x.FilterIdentifier.Value == "RowShow").FilterValues;
                var filteredData = aliquotMetadata.Where(x => x.RowShow.NumberValue == filter.NumberValue).ToList();
                return BuildHtml(filteredData, "Aliquot Dashboard");
            }

        }


        private string BuildHtml(List<AliquotMetadata> aliquotMetadata, string tableName)
        {
            var tableHeader = "";
            var tableHeaderCells = "";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            foreach (var aliquotMetadataItem in aliquotMetadata)
            {
                var tableCells = "";

                tableCells += $"<td class='td'>{aliquotMetadataItem.DashAliquotIdx.Value} </td>";
                tableCells += $"<td class='td'>{aliquotMetadataItem.AliquotId.Value} </td>";
                tableCells += $"<td class='td'>{aliquotMetadataItem.AliquotName.Value} </td>";
                tableCells += $"<td class='td'>{aliquotMetadataItem.SampleId.Value} </td>";
                tableCells += $"<td class='td'>{aliquotMetadataItem.AliquotConcentration.Value} </td>";
                tableCells += $"<td class='td'>{aliquotMetadataItem.AliquotConcentrationUnit.Value} </td>";
                tableCells += $"<td class='td'>{aliquotMetadataItem.AliquotVolume.Value} </td>";
                tableCells += $"<td class='td'>{aliquotMetadataItem.AliquotVolumeUnit.Value} </td>";


                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Index",
                "Aliquot ID",
                "Aliquot Name",
                "Sample ID",
                "Aliquot Concentration",
                "Aliquot Concentration Unit",
                "Aliquot Volume",
                "Aliquot Volume Unit",
            };
        }
    }
}
