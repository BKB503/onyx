﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class SystemSuitabilityHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var materialDetailsData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Material Details");
            var materialDetails = JsonConvert.DeserializeObject<List<MaterialDetails>>(materialDetailsData.Data.ToString());
            var categories = new List<string> { "Standard", "Suitability Standard", "Control" };
            var hasCategoryForMaterial = materialDetails.Any(x => categories.Any(h => x.Category.Value == h));

            var reagentPreparationData = uvVisSampleTestingModel.SpreadSheetTableAndData.FirstOrDefault(x => x.TableName == "Reagent Preparation");
            var reagentPreparation = JsonConvert.DeserializeObject<List<ReagentPreparation>>(reagentPreparationData.Data.ToString());

            var hasCategoryForReagent = reagentPreparation.Any(x => categories.Any(h => x.Category.Value == h));

            var systemSuitabilitys = JsonConvert.DeserializeObject<List<SystemSuitability>>(uvVisSampleTestingModel.TableData);
            var pageBreak = " <div class='page-break'></div>";
            var tableHtml = BuildHtml(systemSuitabilitys, uvVisSampleTestingModel.TableName, uvVisSampleTestingModel.MethodName,
                                            uvVisSampleTestingModel.MethodId, hasCategoryForMaterial, hasCategoryForReagent);
            return $"{pageBreak}{tableHtml}";

        }


        private string BuildHtml(List<SystemSuitability> systemSuitabilities, string tableName, string methodName, string methodId, bool hasCategoryForMaterial, bool hasCategoryForReagent)
        {
            var tableHeader = "";
            var tableRows = "";

            if (hasCategoryForMaterial || hasCategoryForReagent)
            {
                tableHeader = Headers(methodName);
                tableRows = BuildTableBody(systemSuitabilities, methodName, methodId);
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }

        private string BuildTableBody(List<SystemSuitability> systemSuitabilities, string methodName, string methodId)
        {
            var tableRows = "";
            var minOrMax = new List<string> { "Min", "Value" };
            var filteredData = new List<SystemSuitability>();
            if (methodName == "Lunatic")
            {
                if (methodId == "M2020N450453")
                {
                    filteredData = systemSuitabilities.Where(x => x.SutabilityFilterHelper.Value == "S2" && minOrMax.Any(m => m == x.MaxMin.Value)).ToList();
                }
                else
                {
                    filteredData = systemSuitabilities.Where(x => x.SutabilityFilterHelper.Value == "S1" && minOrMax.Any(m => m == x.MaxMin.Value)).ToList();
                }

            }
            else
            {
                filteredData = systemSuitabilities.Where(x => x.SutabilityFilterHelper.Value == "S1" && minOrMax.Any(m => m == x.MaxMin.Value)).ToList();
            }
            var groupedSystemSuitabilities = filteredData.GroupBy(x => x.RunNumber.Value, (key, group) => new { RunNumber = key, Items = group.ToList() });

            foreach (var systemSuitability in groupedSystemSuitabilities)
            {
                var tableCells = "";
                if (methodName == "Lunatic")
                {
                    var standardMinR = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Standard" && x.MaxMin.Value == "Min")?.StandardMinR?.NumberValue;
                    var percentageRSD = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Standard" && x.MaxMin.Value == "Value")?.ToleranceForAbsorbance?.NumberValue;
                    var percentageRecovery = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Control" && x.MaxMin.Value == "Min")?.PercentageRecovery?.NumberValue;
                    var controlStandardMinR = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Control" && x.MaxMin.Value == "Min")?.StandardMinR?.NumberValue;
                    tableCells += $"<td class='td'>{systemSuitability.RunNumber} </td>";

                    tableCells += $"<td class='td'>{standardMinR}</td>";
                    tableCells += $"<td class='td'>{percentageRSD}</td>";
                    tableCells += $"<td class='td'>{percentageRecovery}</td>";
                    tableCells += $"<td class='td'>{controlStandardMinR}</td>";
                }
                else
                {
                    var percentageTMin = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Instrument Check" && x.MaxMin.Value == "Min")?.PercentageT?.NumberValue;
                    var percentageTValue = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Instrument Check" && x.MaxMin.Value == "Value")?.PercentageT?.NumberValue;
                    var systemSuitablityResult = "";
                    if (percentageTValue != null && percentageTMin != null && Convert.ToDecimal(percentageTValue) > Convert.ToDecimal(percentageTMin))
                    {
                        systemSuitablityResult = "Pass";
                    }
                    else
                    {
                        systemSuitablityResult = "Fail";
                    }
                    var standardMinR = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Standard" && x.MaxMin.Value == "Min")?.StandardMinR?.NumberValue;
                    var percentageRSD = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Standard" && x.MaxMin.Value == "Value")?.ToleranceForAbsorbance?.NumberValue;
                    var percentageRecovery = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Control" && x.MaxMin.Value == "Min")?.PercentageRecovery?.NumberValue;
                    var controlStandardMinR = systemSuitability.Items?.FirstOrDefault(x => x.SystemType.Value == "Control" && x.MaxMin.Value == "Min")?.StandardMinR?.NumberValue;
                    tableCells += $"<td class='td'>{systemSuitability.RunNumber} </td>";
                    tableCells += $"<td class='td'>{percentageTMin} </td>";
                    tableCells += $"<td class='td'>{percentageTValue} </td>";
                    tableCells += $"<td class='td'>{systemSuitablityResult} </td>";

                    tableCells += $"<td class='td'>{standardMinR}</td>";
                    tableCells += $"<td class='td'>{percentageRSD}</td>";
                    tableCells += $"<td class='td'>{percentageRecovery}</td>";
                    tableCells += $"<td class='td'>{controlStandardMinR}</td>";
                }

                tableRows += $"<tr>{tableCells}</tr> ";
            }
            return tableRows;
        }


        private string Headers(string methodName)
        {
            if (methodName == "SoloVPE")
            {
                return $"<tr><th class='th' rowspan='3'>Run Number </th><th class='th' colspan='3'>Instrument Check</th><th class='th' colspan='2'>Standard</th> <th class='th' colspan='2'>Control </th> </tr> " +
                    $"<tr> <th class='th' colspan='2'> %T </th> <th class='th'>System Suitability Result </th> <th class='th'>R² </th><th class='th'>Tolerance for Absorbance (+/-)</th><th class='th'>% Recovery </th><th class='th'>R² </th></tr>" +
                    $"<tr> <th class='th'> Min </th> <th class='th'>Value </th> <th class='th'> </th> <th class='th'>Min </th> <th class='th'> Value </th> <th class='th'> Min</th> <th class='th'>Min </th></tr>";
            }
            else
            {
                return $"<tr><th class='th' rowspan='3'>Run Number </th><th class='th' colspan='2'>Standard</th> <th class='th' colspan='2'>Control </th> </tr> " +
                   $"<tr> <th class='th'>R² </th><th class='th'>Tolerance for Absorbance (+/-)</th><th class='th'>% Recovery </th><th class='th'>R² </th></tr>" +
                   $"<tr>  <th class='th'>Min </th> <th class='th'> Value </th> <th class='th'> Min</th> <th class='th'>Min </th></tr>";
            }
        }



    }
}
