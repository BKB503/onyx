﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class SampleDetailsHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var sampleDetails = JsonConvert.DeserializeObject<List<SampleDetails>>(uvVisSampleTestingModel.TableData);
            var getSampleDetailsFilter = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "Sample Details" && x.FilterIdentifier.Value == "RowShow").FilterValues;
            var filteredData = new List<SampleDetails>();
            if (getSampleDetailsFilter != null && getSampleDetailsFilter.NumberValue != null)
            {
                filteredData = sampleDetails.Where(x => x.RowShow.NumberValue == getSampleDetailsFilter.NumberValue).ToList();
            }
            else
            {
                filteredData = sampleDetails.Where(x => x.RowShowNumber.NumberValue == "1.0").ToList();
            }
            var pageBreak = " <div class='page-break'></div>";
            return $"{pageBreak} {BuildHtml(filteredData, uvVisSampleTestingModel.TableName)}";
        }


        private string BuildHtml(List<SampleDetails> sampleDetails, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";

            foreach (var tableTh in SampleDetailsHeader())
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            var groupedSampleModes = sampleDetails.GroupBy(x => x.SampleEntryMode.Value, (key, group) => new { Mode = key, Items = group.ToList() });
            foreach (var sampleMode in groupedSampleModes)
            {

                if (sampleMode.Items.Any())
                {
                    foreach (var item in sampleMode.Items)
                    {
                        var tableCells = "";
                        if (sampleMode.Items.IndexOf(item) == 0)
                        {
                            tableCells += $"<td class='td' rowspan='{sampleMode.Items.Count}'>{sampleMode.Mode} </td>";
                        }
                        tableCells += $"<td class='td'>{item.SampleIndex.Value} </td>";
                        tableCells += $"<td class='td'>{item.SampleID.Value} </td>";
                        tableCells += $"<td class='td'>{item.SampleName.Value} </td>";
                        tableCells += $"<td class='td'>{item.BatchOrLotNumber.Value} </td>";
                        tableCells += $"<td class='td'>{item.CompoundId.Value} </td>";
                        tableCells += $"<td class='td'>{item.Concentration.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.ConcentrationOverride.NumberValue} </td>";
                        tableCells += $"<td class='td'>{item.ConcentrationUnit.Value} </td>";
                        tableCells += $"<td class='td'>{item.ConcentrionUnitOverride.Value} </td>";
                        tableCells += $"<td class='td'>{item.DilutionRequired.Value} </td>";
                        tableCells += $"<td class='td'>{item.Comments.Value} </td>";
                        tableRows += $"<tr>{tableCells}</tr> ";
                    }

                }

            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> SampleDetailsHeader()
        {
            return new List<string>
            {
                "Sample Entry Mode",
                "Sample Index",
                "Sample ID",
                "Sample Name",
                "Batch/Lot Number",
                "Compound ID",
                "Concentration",
                "Concentration Override",
                "Concentration Unit",
                "Concentrion Unit Override",
                "Dilution Required?",
                "Comments"
            };
        }

    }
}
