﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample
{
    public class FileAttachmentReferenceHtml : IHtmlTableGeneration
    {
        public string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            var filterValue = uvVisSampleTestingModel.JsonFilterTables.First(x => x.TableName.Value == "File Attachment Reference" && x.FilterIdentifier.Value == "RowShow").FilterValues;
            var fileAttachmentReferences = JsonConvert.DeserializeObject<List<FileAttachmentReference>>(uvVisSampleTestingModel.TableData);
            var filteredData = fileAttachmentReferences.Where(x => x.RowShow.NumberValue == filterValue.NumberValue).ToList();

            return BuildHtml(filteredData, uvVisSampleTestingModel.TableName);

        }

        private string BuildHtml(List<FileAttachmentReference> fileAttachmentReferences, string tableName)
        {
            var tableHeader = $"";
            var tableHeaderCells = $"";
            var tableRows = "";
            var headers = Headers();
            foreach (var tableTh in headers)
            {
                tableHeaderCells += $"<th class='th'>{tableTh} </th>";
            }

            tableHeader += $"<thead><tr>{tableHeaderCells}</tr></thead>";
            foreach (var fileAttachmentReference in fileAttachmentReferences)
            {
                var tableCells = "";

                tableCells += $"<td class='td'>{fileAttachmentReference.AttachmentIndex.Value} </td>";
                tableCells += $"<td class='td'>{fileAttachmentReference.AttachmentLink.Value} </td>";
                tableCells += $"<td class='td'>{fileAttachmentReference.AttachmentDescription.Value} </td>";


                tableRows += $"<tr>{tableCells}</tr> ";
            }

            var tableBody = $"{tableHeader}<tbody>{tableRows} </tbody>";
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{tableName}</h2> </caption>{tableBody}</table></div>";
            return tableHtml;
        }


        private List<string> Headers()
        {
            return new List<string>
            {
                "Attachment Index",
                "Attachment Link",
                "Attachment Description"
            };
        }

    }
}
