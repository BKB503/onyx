﻿
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.UvVisSample;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlContext
{
    public class UvVisSampleContext : IUvVisSampleContext
    {
        private readonly Dictionary<string, IHtmlTableGeneration> _uvVisSampleStrategy = new Dictionary<string, IHtmlTableGeneration>();
        public UvVisSampleContext()
        {
            _uvVisSampleStrategy.Add("Assay Metadata", new AssayMetadataHtml());
            _uvVisSampleStrategy.Add("Experiment Information", new ExperimentInformationHtml());
            _uvVisSampleStrategy.Add("Compounds and Projects", new CompoundsAndProjectsHtml());
            _uvVisSampleStrategy.Add("Equipment Details", new EquipmentDetailsHtml());
            _uvVisSampleStrategy.Add("Material Details", new MaterialDetailsHtml());
            _uvVisSampleStrategy.Add("Reagent Preparation", new ReagentPreparationHtml());
            _uvVisSampleStrategy.Add("Material and Reagent Dilution", new MaterialAndReagentDilutionHtml());
            _uvVisSampleStrategy.Add("Sample Details", new SampleDetailsHtml());
            _uvVisSampleStrategy.Add("Sample Dilution", new SampleDilutionHtml());
            _uvVisSampleStrategy.Add("Sample Aliquot Details", new SampleAliquotDetailsHtml());
            _uvVisSampleStrategy.Add("Sample Metadata", new SampleMetadataHtml());
            _uvVisSampleStrategy.Add("Sample Details- Dashboard", new SampleMetadataHtml());
            _uvVisSampleStrategy.Add("Aliquot Metadata", new AliquotMetadataHtml());
            _uvVisSampleStrategy.Add("Aliquot Details- Dashboard", new AliquotMetadataHtml());
            _uvVisSampleStrategy.Add("Method Parameters", new MethodParametersHtml());
            _uvVisSampleStrategy.Add("Run Setup", new RunSetuphHtml());
            _uvVisSampleStrategy.Add("Standard Setup", new StandardSetupHtml());
            _uvVisSampleStrategy.Add("Standard Curve Details", new StandardCurveDetailsHtml());
            _uvVisSampleStrategy.Add("System Suitability", new SystemSuitabilityHtml());
            _uvVisSampleStrategy.Add("Acceptance Criteria", new AcceptanceCriteriaHtml());
            _uvVisSampleStrategy.Add("Import Filename", new ImportFilenameHtml());
            _uvVisSampleStrategy.Add("Control Results", new ControlResultsHtml());
            _uvVisSampleStrategy.Add("Standard Results", new StandardResultsHtml());
            _uvVisSampleStrategy.Add("Sample Results", new SampleResultsHtml());
            _uvVisSampleStrategy.Add("Image Upload Table", new ImageUploadTableHtml());
            _uvVisSampleStrategy.Add("Sample Summary", new SampleSummaryHtml());
            _uvVisSampleStrategy.Add("Conclusion Table", new ConclusionTableHtml());
            _uvVisSampleStrategy.Add("File Attachment  Reference", new FileAttachmentReferenceHtml());
        }
        public string GetHtmlNode(string tableType, SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            
            //var tt = _uvVisSampleStrategy[tableType].BuildTableHtml(uvVisSampleTestingModel);
            return _uvVisSampleStrategy[tableType].BuildTableHtml(uvVisSampleTestingModel);
        }
    }
}
