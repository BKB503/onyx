﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlTables.BioReactor;
using System.Collections.Generic;

namespace GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlContext
{
    public class BioReactorContext : IBioReactorContext
    {
        private readonly Dictionary<string, IHtmlTableGeneration> _bioReactorStrategy = new Dictionary<string, IHtmlTableGeneration>();

        public BioReactorContext()
        {
            _bioReactorStrategy.Add("Experiment Setup Details", new ExperimentSetupDetailsHtml());
            _bioReactorStrategy.Add("Experiment Setup", new ExperimentSetupDetailsHtml());
            _bioReactorStrategy.Add("Compounds and Projects", new CompoundsAndProjectsHtml());
            _bioReactorStrategy.Add("Contributors", new ContributorsHtml());
            _bioReactorStrategy.Add("Bioreactor Details", new BioreactorDetailsHtml());
            _bioReactorStrategy.Add("Other Equipment Details", new OtherEquipmentDetailsHtml());
            _bioReactorStrategy.Add("Reagent Details", new ReagentDetailsHtml());
            _bioReactorStrategy.Add("Material Details", new MaterialDetailsHtml());
            _bioReactorStrategy.Add("Culture Details", new CultureDetailsHtml());
            _bioReactorStrategy.Add("Solution Components", new SolutionComponentsHtml());
            _bioReactorStrategy.Add("Solution Parameters", new SolutionParametersHtml());
            _bioReactorStrategy.Add("Centrifugation", new CentrifugationHtml());
            _bioReactorStrategy.Add("Inoculum Details", new InoculumDetailsHtml());
            _bioReactorStrategy.Add("Setpoints", new SetpointsHtml());
            _bioReactorStrategy.Add("Experiment Feed Setup", new ExperimentFeedSetupHtml());
            _bioReactorStrategy.Add("Feed Configuration", new FeedConfigurationDetailsHtml());
            _bioReactorStrategy.Add("Vessel Setup", new VesselSetupHtml());
            _bioReactorStrategy.Add("Sample Setup Configuration", new SampleSetupConfigurationHtml());
            _bioReactorStrategy.Add("Raman Instrumentation", new RamanInstrumentationHtml());
            _bioReactorStrategy.Add("Raman Data", new RamanDataHtml());
            _bioReactorStrategy.Add("Raman Instrument Settings", new RamanInstrumentSettingHtml());
            _bioReactorStrategy.Add("Raman Model", new RamanModelHtml());
            _bioReactorStrategy.Add("Feed Details", new FeedDetailsHtml());
            _bioReactorStrategy.Add("Parent Sample Details", new ParentSampleDetailsHtml());
            _bioReactorStrategy.Add("Aliquot Sample Details", new AliquotSampleDetailsHtml());
            _bioReactorStrategy.Add("DCA ID Generation", new DCAIdGenerationHtml());
            _bioReactorStrategy.Add("Barcode Dimension", new BarcodeDimensionHtml());
            _bioReactorStrategy.Add("Samples", new SamplesHtml());
            _bioReactorStrategy.Add("Run Summary", new RunSummaryHtml());
            _bioReactorStrategy.Add("Pooled Culture Details", new PooledCultureDetailsHtml());
            _bioReactorStrategy.Add("Bioreactor Run Check", new BioreactorRunCheckHtml());
            _bioReactorStrategy.Add("Sample Labels", new SampleLabelsHtml());
            _bioReactorStrategy.Add("DCA ID Labels", new DCAIdLablesHtml());
            _bioReactorStrategy.Add("Culture Labels", new CultureLabelsHtml());
            _bioReactorStrategy.Add("Analytical Sample Label", new AnalyticalSampleLabelHtml());
            _bioReactorStrategy.Add("Box Label Printing", new BoxLabelPrintingHtml());
            _bioReactorStrategy.Add("Incomplete Count", new IncompleteCountHtml());
            _bioReactorStrategy.Add("Reactor Daily Data Entry Units", new ReactorDailyDataEntryUnitsHtml());
            _bioReactorStrategy.Add("Reactor Daily Data Entry", new ReactorDailyDataEntryHtml());
            _bioReactorStrategy.Add("ViCell Data Entry", new ViCellDataEntryHtml());
            _bioReactorStrategy.Add("Osmometer Data Entry", new OsmometerDataEntryHtml());
            _bioReactorStrategy.Add("BioHT Cedex Data Entry", new BioHTCedexDataEntryHtml());
            _bioReactorStrategy.Add("Flex2 Data Entry", new Flex2DataEntryHtml());
            _bioReactorStrategy.Add("RAPIDPoint 500 Data Entry", new RAPIDPoint500DataEntryHtml());
            _bioReactorStrategy.Add("YSI Data Entry", new YSIDataEntryHtml());
            _bioReactorStrategy.Add("Octet or HPLC Data Entry", new OctetorHPLCDataEntryHtml());
            _bioReactorStrategy.Add("Process Results", new ProcessResultHtml());
            _bioReactorStrategy.Add("Result Summary", new ResultSummaryHtml());

        }

        public string GetHtmlNode(string tableType, SpreadSheetPdfTableModel uvVisSampleTestingModel)
        {
            return _bioReactorStrategy[tableType].BuildTableHtml(uvVisSampleTestingModel);
        }


    }
}
