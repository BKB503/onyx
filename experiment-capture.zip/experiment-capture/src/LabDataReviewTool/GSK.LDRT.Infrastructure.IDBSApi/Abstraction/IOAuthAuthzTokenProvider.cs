﻿using System.Net;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSApi.Abstraction
{
    public interface IOAuthAuthzTokenProvider
    {
        Task<Cookie> GetAccessToken();
    }
}
