﻿using AutoMapper;
using GSK.LDRT.Contracts.Abstractions.Common;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Infrastructure.IDBSApi.Abstraction;
using GSK.LDRT.Infrastructure.IDBSApi.Common;
using GSK.LDRT.Infrastructure.IDBSApi.PdfHtmlContext;
using GSK.LDRT.Infrastructure.IDBSApi.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.IO.Abstractions;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;

namespace GSK.LDRT.Infrastructure.IDBSApi
{
    public static class ConfigureServices
    {
        public static void AddInfrastructureIdbsApi(this IServiceCollection services)
        {

            services.AddTransient<IFile, FileWrapper>(wrp => new FileWrapper(new FileSystem()));

            services.AddTransient<IFileReader, FileReader>();

            services.AddTransient<ITemplateConfigurationProvider, TemplateConfigurationProvider>(cp =>
            {
                var appPath = AppContext.BaseDirectory;
                return new TemplateConfigurationProvider(appPath);
            });
            services.AddTransient<IEntityApiService>((ctx =>
            {
                var restClient = GetRestClientWithAuth(ctx);
                var fileReaderService = ctx.GetService<IFileReader>();
                var configurationProvider = ctx.GetService<ITemplateConfigurationProvider>();
                return new EntityApiService(restClient, fileReaderService, configurationProvider);
            }));
            services.AddHttpClient("idbsclient", (sp, c) =>
            {
                var configuration = sp.GetService<IConfiguration>();
                var idbsBaseUrl = configuration["IDBSAPI:BaseUrl"];
                var username = configuration["IDBSAPI:Username"];
                var password = configuration["IDBSAPI:Password"];
                var authenticationString = $"{username}:{password}";
                var base64EncodedAuthenticationString = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(authenticationString));

                c.BaseAddress = new Uri(idbsBaseUrl);
                c.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //c.DefaultRequestHeaders.Add("Content-Type", "application/json");
                c.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", base64EncodedAuthenticationString);
            }).ConfigurePrimaryHttpMessageHandler(_ => new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; }

            });
            services.AddTransient<ITaskApiService>((ctx =>
            {
                var fileReaderService = ctx.GetService<IFileReader>();
                var entityApiService = ctx.GetService<IEntityApiService>();
                var configurationProvider = ctx.GetService<ITemplateConfigurationProvider>();
                var httpClientFactory = ctx.GetService<IHttpClientFactory>();
                var logger = ctx.GetService<ILogger<TaskApiService>>();
                var restClient = GetRestClientWithAuth(ctx);

                return new TaskApiService(restClient, fileReaderService, configurationProvider,
                    entityApiService, httpClientFactory, logger);
            }));

            services.AddTransient<IWorkflowApiService>((ctx =>
            {
                var fileReaderService = ctx.GetService<IFileReader>();
                var entityApiService = ctx.GetService<IEntityApiService>();
                var configurationProvider = ctx.GetService<ITemplateConfigurationProvider>();
                var restClient = GetRestClientWithAuth(ctx);

                return new WorkflowApiService(restClient, fileReaderService, configurationProvider, entityApiService);
            }));

            services.AddTransient<IRecordApiService>((ctx =>
            {
                var restClient = GetRestClientWithAuth(ctx);

                return new RecordApiService(restClient);
            }));

            services.AddTransient<ISpreadSheetService>((ctx =>
            {
                var fileReaderService = ctx.GetService<IFileReader>();
                var configurationProvider = ctx.GetService<ITemplateConfigurationProvider>();
                var restClient = GetRestClientWithAuth(ctx);

                return new SpreadSheetService(restClient, fileReaderService, configurationProvider);
            }));
            services.AddTransient<IUvVisSampleContext, UvVisSampleContext>();
            services.AddTransient<IBioReactorContext, BioReactorContext>();
            services.AddTransient<IPdfGenerator, PdfGenerator>();
            services.AddTransient<IExperimentHtmlService>((ctx =>
            {
                var spreadSheetService = ctx.GetService<ISpreadSheetService>();
                var entityApiService = ctx.GetService<IEntityApiService>();
                var uvVisSampleContext = ctx.GetService<IUvVisSampleContext>();
                var bioReactorContext = ctx.GetService<IBioReactorContext>();

                return new ExperimentHtmlService(entityApiService, spreadSheetService, uvVisSampleContext, bioReactorContext);
            }));
            services.AddTransient<IOAuthAuthzTokenProvider>((ctx =>
            {
                var restClient = GetRestClientWithAuth(ctx);
                return new OAuthAuthzTokenProvider(restClient);
            }));
            services.AddTransient<IAuditApiService>((ctx =>
            {
                var restClient = GetRestClientNoAuth(ctx);
                var oAuthAuthzTokenProvider = ctx.GetService<IOAuthAuthzTokenProvider>();

                return new AuditApiService(restClient, oAuthAuthzTokenProvider);
            }));
        }

        public static RestClient GetRestClientWithAuth(IServiceProvider serviceProvider)
        {
            var configuration = serviceProvider.GetService<IConfiguration>();
            var idbsBaseUrl = configuration["IDBSAPI:BaseUrl"];
            var username = configuration["IDBSAPI:Username"];
            var password = configuration["IDBSAPI:Password"];
            var restClient = new RestClient(idbsBaseUrl);
            restClient.Authenticator = new HttpBasicAuthenticator(username, password);
            return restClient;
        }

        public static RestClient GetRestClientNoAuth(IServiceProvider serviceProvider)
        {
            var configuration = serviceProvider.GetService<IConfiguration>();
            var idbsBaseUrl = configuration["IDBSAPI:BaseUrl"];
            var restClient = new RestClient(idbsBaseUrl);
            return restClient;
        }


    }
}
