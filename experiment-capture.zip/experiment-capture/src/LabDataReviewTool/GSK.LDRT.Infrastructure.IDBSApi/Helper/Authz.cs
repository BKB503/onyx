﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSApi.Helper
{
    public class Authz
    {
        public string EncryptedCode { get; set; }
        public string AuthzCode { get; set; }
    }

    public class Auth
    {
        public string OauthCode { get; set; }
    }
}
