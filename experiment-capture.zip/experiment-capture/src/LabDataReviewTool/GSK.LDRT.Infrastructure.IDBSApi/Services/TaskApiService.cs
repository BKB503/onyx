﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSK.LDRT.Application.Exceptions;

using GSK.LDRT.Domain.IDBSEntities.Task;
using Newtonsoft.Json;
using RestSharp;
using System;
using GSK.LDRT.Domain.IDBSEntities.Entity;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Abstractions.Common;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.Extensions.Logging;

namespace GSK.LDRT.Infrastructure.IDBSApi.Services
{
    public class TaskApiService : ITaskApiService

    {
        private readonly RestClient restClient;
        private readonly IFileReader fileReader;
        private readonly ITemplateConfigurationProvider templateConfigurationProvider;
        private readonly IEntityApiService entityApiService;
        private readonly IHttpClientFactory _clientFactory;
        private readonly ILogger<TaskApiService> logger;
        private const string UsernameParameter = "#{username}#";
        private const string SentDateLessThanOrEqualTo = "#{sentDateLessThanOrEqualTo}#";
        private const string SentDateGreaterThanOrEqualTo = "#{sentDateGreaterThanOrEqualTo}#";

        public TaskApiService(RestClient restClient, IFileReader fileReader, 
                              ITemplateConfigurationProvider templateConfigurationProvider, 
                              IEntityApiService entityApiService,
                              IHttpClientFactory clientFactory,
                              ILogger<TaskApiService> logger)
        {
            this.restClient = restClient;
            this.fileReader = fileReader;
            this.templateConfigurationProvider = templateConfigurationProvider;
            this.entityApiService = entityApiService;
            this._clientFactory = clientFactory;
            this.logger = logger;
        }

        public async Task<IEnumerable<ExperimentTaskEntity>> GetUserAssignedTasks(string username, DateTime startDate, DateTime endDate)
        {
            
            var request = BuildTasksRequestWorkFlowInProgress(username, startDate, endDate);
            var response = await restClient.ExecuteAsync(request);

            if (!response.IsSuccessful)
            {
                var headers = response.Headers;
                var header = headers.FirstOrDefault(x => x.Name == "X-EWB-UserDisabled");
                var message = "";
                if (header == null)
                {
                    message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                    message = $"{message}, Failed when calling IDBS API";
                    throw new ApiException(message, response.StatusCode);
                }
                else
                {
                    message = header.Value.ToString();
                    throw new ApiException(message, System.Net.HttpStatusCode.InternalServerError);
                }

            }
            else
            {
                var taskDetailListEntity = JsonConvert.DeserializeObject<TaskDetailListEntity>(response.Content);

                var experimentTaskEntities = new List<ExperimentTaskEntity>();
                if (taskDetailListEntity.TaskDetails.Any())
                {
                    foreach (var taskDetailEntity in taskDetailListEntity.TaskDetails)
                    {
                        //get the experiment for IDBS API
                        var experimentEntity = await entityApiService.GetEntityByEntitytId(taskDetailEntity.EntityId);

                        var experimentTaskEntity = MapTaskResponse(taskDetailEntity, experimentEntity);

                        experimentTaskEntities.Add(experimentTaskEntity);

                    }
                }
                return experimentTaskEntities;

            }
            
        }

        public async Task<IEnumerable<ExperimentTaskEntity>> GetUserAssignedTasksWithHttpClient(string username, DateTime startDate, DateTime endDate)
        {

            var content = BuildTasksRequestWorkFlowInProgressHttpClient(username, startDate, endDate);
            var client = _clientFactory.CreateClient("idbsclient");
            var taskUrl = $"ewb/services/1.0/tasks";
            var response = await client.PostAsync(taskUrl,content);
            var responseIsSuccess = response.EnsureSuccessStatusCode();
            
            if (!responseIsSuccess.IsSuccessStatusCode)
            {
                var message = await response.Content.ReadAsStringAsync();
                 message = $"{message}, Failed when calling IDBS API";
                logger.LogError($"Task Api Service with http client,{message}");
                throw new ApiException(message, response.StatusCode);

            }
            else
            {
                 var responseStream = await response.Content.ReadAsStringAsync();
                var taskDetailListEntity = JsonConvert.DeserializeObject<TaskDetailListEntity>(responseStream);

                var experimentTaskEntities = new List<ExperimentTaskEntity>();
                if (taskDetailListEntity.TaskDetails.Any())
                {
                    foreach (var taskDetailEntity in taskDetailListEntity.TaskDetails)
                    {
                        //get the experiment for IDBS API
                        var experimentEntity = await entityApiService.GetEntityByEntitytId(taskDetailEntity.EntityId);

                        var experimentTaskEntity = MapTaskResponse(taskDetailEntity, experimentEntity);

                        experimentTaskEntities.Add(experimentTaskEntity);

                    }
                }
                return experimentTaskEntities;

            }

        }

        public async Task<IEnumerable<CommentEntity>> GetTaskComments(string taskId)
        {
            var taskCommentsUrl = $"ewb/services/1.0/tasks/{taskId}/comments";
            var request = new RestRequest(taskCommentsUrl, Method.Get);
            request.AddHeader("Content-Type", "application/json");

            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var headers = response.Headers;
                var header = headers.FirstOrDefault(x => x.Name == "X-EWB-UserDisabled");
                var message = "";
                if (header == null)
                {
                    message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                    message = $"{message}, Failed when calling IDBS API";
                }
                else
                {
                    message = header.Value.ToString();
                }

                throw new ApiException(message, response.StatusCode);

            }
            else
            {
                if (!string.IsNullOrEmpty(response.Content))
                {
                    var commentListEntity = JsonConvert.DeserializeObject<CommentsListEntity>(response.Content);
                    return commentListEntity.Comments;
                }

                return new List<CommentEntity>();
            }
        }

        public async Task<string> CancelTask(string taskId)
        {
            var taskCancelUrl = $"ewb/services/1.0/tasks/{taskId}/cancel";
            var request = new RestRequest(taskCancelUrl, Method.Post);
            request.AddHeader("Content-Type", "application/json");

            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var headers = response.Headers;
                var header = headers.FirstOrDefault(x => x.Name == "X-EWB-UserDisabled");
                var message = "";
                if (header == null)
                {
                    message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                    message = $"{message}, Failed when calling IDBS API";
                }
                else
                {
                    message = header.Value.ToString();
                }

                throw new ApiException(message, response.StatusCode);
            }

            return  "Task has successfully cancelled" ;

        }

        private static ExperimentTaskEntity MapTaskResponse(TaskDetailEntity taskDetailEntity, Entity entity)
        {
            string experimentId = GetValueByAttributeName(entity, "Experiment ID");
            return new ExperimentTaskEntity
            {
                DisplayId = taskDetailEntity.DisplayId,
                EntityId = taskDetailEntity.EntityId,
                EntityPath = taskDetailEntity.EntityPath,
                TaskId = taskDetailEntity.TaskId,
                TaskName = taskDetailEntity.TaskName,
                TaskStatus = taskDetailEntity.TaskStatus,
                TaskType = taskDetailEntity.TaskType,
                WorkflowId = taskDetailEntity.WorkflowId,
                WorkflowName = taskDetailEntity.WorkflowName,
                WorkflowPriority = taskDetailEntity.WorkflowPriority,
                WorkflowRequester = taskDetailEntity.WorkflowRequester,
                WorkflowStatus = taskDetailEntity.WorkflowStatus,
                ExperimentName = entity.EntityCore.EntityName,
                ExperimentDisplayName = entity.EntityCore.NodeDisplayText,
                ExperimentId = experimentId,
                DueDate = ConvertEpochToDate(taskDetailEntity.DueDate),
                SendDate = ConvertEpochToDate(taskDetailEntity.SendDate)
            };
        }

        private static DateTime ConvertEpochToDate(double epoch)
        {   
           return  DateTime.UnixEpoch.AddMilliseconds(epoch);
        }

        private RestRequest BuildTasksRequestWorkFlowInProgress(string username, DateTime startDate, DateTime endDate)
        {
            var dateFormatForIdbs = "yyyy'-'MM'-'dd'T'HH':'mm':'ss";
           
            var taskUrl = $"ewb/services/1.0/tasks";
            var filePath = templateConfigurationProvider.GetTasksByWorkflowStatusInProgressFilePath;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);

            //Replace username
            jsonBodyTemplate =  jsonBodyTemplate.Replace(UsernameParameter, username);
            jsonBodyTemplate =  jsonBodyTemplate.Replace(SentDateGreaterThanOrEqualTo, startDate.ToString(dateFormatForIdbs));
            jsonBodyTemplate =  jsonBodyTemplate.Replace(SentDateLessThanOrEqualTo, endDate.ToString(dateFormatForIdbs));

            var request = new RestRequest(taskUrl, Method.Post).AddBody(jsonBodyTemplate, "application/json");
            //var request = new RestRequest(taskUrl, Method.Post).AddStringBody(jsonBodyTemplate, ContentType.Json);
            request.AddHeader("Content-Type", "application/json");

            return request;
        }

        private StringContent BuildTasksRequestWorkFlowInProgressHttpClient(string username, DateTime startDate, DateTime endDate)
        {
            var dateFormatForIdbs = "yyyy'-'MM'-'dd'T'HH':'mm':'ss";

            var taskUrl = $"ewb/services/1.0/tasks";
            var filePath = templateConfigurationProvider.GetTasksByWorkflowStatusInProgressFilePath;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);

            //Replace username
            jsonBodyTemplate = jsonBodyTemplate.Replace(UsernameParameter, username);
            jsonBodyTemplate = jsonBodyTemplate.Replace(SentDateGreaterThanOrEqualTo, startDate.ToString(dateFormatForIdbs));
            jsonBodyTemplate = jsonBodyTemplate.Replace(SentDateLessThanOrEqualTo, endDate.ToString(dateFormatForIdbs));
           
            var content = new StringContent(jsonBodyTemplate, System.Text.Encoding.UTF8, "application/json");
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            return content;
            //var request = new HttpRequestMessage(HttpMethod.Post, taskUrl);
            //request.Content = content;
            
            //return request;
        }

        private static string GetValueByAttributeName(Entity entity, string attributeName)
        {
            return entity.Attributes.Attribute.FirstOrDefault(x => x.Name == attributeName).Values.Value.FirstOrDefault();
        }
    }
}
