﻿using GSK.LDRT.Application.Exceptions;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Domain.IDBSEntities.Entity;
using GSK.LDRT.Domain.IDBSEntities.Record;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSApi.Services
{
    public class RecordApiService : IRecordApiService
    {
        private readonly RestClient restClient;
        private const string ContentType = "Content-Type";
        private const string ContentTypeValue = "application/json";
        public RecordApiService(RestClient restClient)
        {
            this.restClient = restClient;
        }

        public async Task<RecordEntity> GetRecordByEntityId(string entityId)
        {
            var recordUrl = $"ewb/services/1.0/records/{entityId}";
            var request = new RestRequest(recordUrl, Method.Get);
            request.AddHeader(ContentType, ContentTypeValue);

            var response = await restClient.ExecuteAsync(request);

            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }
            else
            {
                var recordEntity = JsonConvert.DeserializeObject<RecordEntity>(response.Content);
                return recordEntity;
            }
        }

        public async Task<RecordSummaryEntity> GetRecordSummaryByEntityId(string entityId)
        {
            var recordSummaryEntity = new RecordSummaryEntity();
            recordSummaryEntity.RecordEntity = await GetRecordByEntityId(entityId);

            BuilSummaryData(recordSummaryEntity, recordSummaryEntity.RecordEntity);
           
            return recordSummaryEntity;
        }

      
        private static void BuilSummaryData(RecordSummaryEntity recordSummaryEntity, RecordEntity recordEntity)
        {
            recordSummaryEntity.ExperimentId=  GetValueByAttributeName(recordEntity.Entity, "Experiment ID");
            recordSummaryEntity.Title =GetValueByAttributeName(recordEntity.Entity, "title");
            recordSummaryEntity.PrevExpRef = GetValueByAttributeName(recordEntity.Entity, "prevExpRef");
            recordSummaryEntity.ExptRefSucccessor= GetValueByAttributeName(recordEntity.Entity, "succExpRef");
            recordSummaryEntity.AdditionalProjectRef= GetValueByAttributeName(recordEntity.Entity, "Project Ref");
            recordSummaryEntity.AllianceName = GetValueByAttributeName(recordEntity.Entity, "Alliance_Name");

            recordSummaryEntity.CreatedOn = ConvertEpochToDate(recordEntity.CreationInfo.TimeCreated).ToString("MMM dd, yyyy HH:mm:ss tt");
            recordSummaryEntity.ExperimentStatus = GetValueByAttributeName(recordEntity.Entity, "statusName");
            recordSummaryEntity.RequestId = GetValueByAttributeName(recordEntity.Entity, "requestIds");
           
        }

        private static string GetValueByAttributeName(Entity entity, string attributeName)
        {
            var attribute = entity.Attributes.Attribute.FirstOrDefault(x => x.Name == attributeName);
            if (attribute == null)
            {
                return string.Empty;
            }

            if (attribute.Values == null || !attribute.Values.Value.Any())
            {
                return string.Empty;
            }
            else
            {
                return attribute.Values.Value.FirstOrDefault();
            }
        }

        private static DateTime ConvertEpochToDate(long epoch)
        {
            var dt = DateTime.UnixEpoch.AddMilliseconds(epoch);
            return dt;
        }
    }
}
