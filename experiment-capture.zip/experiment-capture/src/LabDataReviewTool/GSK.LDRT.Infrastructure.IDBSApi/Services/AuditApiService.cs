﻿using GSK.LDRT.Application.Exceptions;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Domain.IDBSEntities.Audit;
using GSK.LDRT.Infrastructure.IDBSApi.Abstraction;
using Newtonsoft.Json;
using RestSharp;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSApi.Services
{
    public class AuditApiService : IAuditApiService
    {
        private readonly RestClient restClient;
        private readonly IOAuthAuthzTokenProvider oAuthAuthzTokenProvider;
        public AuditApiService(RestClient restClient, IOAuthAuthzTokenProvider oAuthAuthzTokenProvider)
        {
            this.restClient = restClient;
            this.oAuthAuthzTokenProvider = oAuthAuthzTokenProvider;
        }

        public async Task<IEnumerable<AuditEntity>> GetLogs(string entityId)
        {
            var accessToken = await oAuthAuthzTokenProvider.GetAccessToken();
            var authzUrl = "/audit/api/logs";
            restClient.AddCookie("ewb_token", accessToken.Value,accessToken.Path, accessToken.Domain);
            var request = new RestRequest(authzUrl, Method.Post)
                        .AddJsonBody(new
                        {
                            containerId = entityId,
                            sortColumn = "entityType",
                            sortOrder = "DESC",
                            rowStart = "0"
                        });
            request.AddHeader("Content-Type", "application/json");

            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API AuthZ";
                throw new ApiException(message, response.StatusCode);
            }

            var auditEntities = JsonConvert.DeserializeObject<List<AuditEntity>>(response.Content);

            if (auditEntities.Any())
            {
                return auditEntities.OrderByDescending(x => x.ZoneStamp);
            }
            else
            {
                return new List<AuditEntity>();
            }
         
        }
    }
}
