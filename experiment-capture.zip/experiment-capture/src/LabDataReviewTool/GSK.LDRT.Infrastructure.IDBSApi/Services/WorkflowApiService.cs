﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSK.LDRT.Application.Exceptions;
using Newtonsoft.Json;
using RestSharp;
using GSK.LDRT.Domain.IDBSEntities.Workflow;
using System;
using GSK.LDRT.Domain.IDBSEntities.Entity;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Abstractions.Common;
using RestSharp.Serializers;

namespace GSK.LDRT.Infrastructure.IDBSApi.Services
{
    public class WorkflowApiService : IWorkflowApiService

    {
        private readonly RestClient restClient;
        private readonly IFileReader fileReader;
        private readonly ITemplateConfigurationProvider templateConfigurationProvider;
        private readonly IEntityApiService entityApiService;
        private const string UsernameParameter = "#{username}#";
        private const string SentDateLessThanOrEqualTo = "#{sentDateLessThanOrEqualTo}#";
        private const string SentDateGreaterThanOrEqualTo = "#{sentDateGreaterThanOrEqualTo}#";

        public WorkflowApiService(RestClient restClient, IFileReader fileReader, 
                              ITemplateConfigurationProvider templateConfigurationProvider, IEntityApiService entityApiService)
        {
            this.restClient = restClient;
            this.fileReader = fileReader;
            this.templateConfigurationProvider = templateConfigurationProvider;
            this.entityApiService = entityApiService;
        }

        public async Task<IEnumerable<ExperimentWorkflowEntity>> GetUserAssignedWorkFlowsSentForReview(string username, DateTime startDate, DateTime endDate)
        {
            username = "dls23167";
            var request = BuildWorkflowRequestByWorkflowStatusInProgressAndNew(username, startDate, endDate);

            var response = await restClient.ExecuteAsync(request);

            if (!response.IsSuccessful)
            {
                var headers = response.Headers;
                var header = headers.FirstOrDefault(x => x.Name == "X-EWB-UserDisabled");
                var message = "";
                if (header == null)
                {
                    message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                    message = $"{message}, Failed when calling IDBS API";
                }
                else
                {
                    message = header.Value.ToString();
                }
               
                throw new ApiException(message, response.StatusCode);

            }
            else
            {
                var workflowListEntity = JsonConvert.DeserializeObject<WorkflowListEntity>(response.Content);
                var experimentWorkflows = new List<ExperimentWorkflowEntity>();
                if (workflowListEntity.Workflows.Any())
                {
                    foreach (var workFlowEnitity in workflowListEntity.Workflows)
                    {
                        //get the experiment for IDBS API
                        var experimentEntity = await entityApiService.GetEntityByEntitytId(workFlowEnitity.EntityId);

                        var experimentWorkflowEntity = MapWorkflowResponse(workFlowEnitity, experimentEntity);

                        experimentWorkflows.Add(experimentWorkflowEntity);

                    }
                }
                return experimentWorkflows;

            }
            
        }

        private static ExperimentWorkflowEntity MapWorkflowResponse(WorkFlowEntity workFlowEntity, Entity entity)
        {
            string experimentId = GetValueByAttributeName(entity, "Experiment ID");
            return new ExperimentWorkflowEntity
            {
                DisplayId = workFlowEntity.DisplayId,
                EntityId = workFlowEntity.EntityId,
                EntityPath = workFlowEntity.EntityPath,
                WorkflowId = workFlowEntity.WorkflowId,
                WorkflowStatus = workFlowEntity.WorkflowStatus,
                EntityName = workFlowEntity.EntityName,
                NumberOfCompletedTasks = workFlowEntity.NumberOfCompletedTasks,
                Priority = workFlowEntity.Priority,
                RequestorId = workFlowEntity.RequestorId,
                RequestorName = workFlowEntity.RequestorName,
                TaskProcess = workFlowEntity.TaskProcess,
                TotalNumberOfTasks = workFlowEntity.TotalNumberOfTasks,
                ExperimentName = entity.EntityCore.EntityName,
                ExperimentDisplayName = entity.EntityCore.NodeDisplayText,
                ExperimentId = experimentId,
                DueDate = ConvertEpochToDate(workFlowEntity.DueDate),
                RequestedDate = ConvertEpochToDate(workFlowEntity.RequestedDate)
            };
        }

        private static DateTime ConvertEpochToDate(double epoch)
        {
            return DateTime.UnixEpoch.AddMilliseconds(epoch);
        }


        private RestRequest BuildWorkflowRequestByWorkflowStatusInProgressAndNew(string username, DateTime startDate, DateTime endDate)
        {
            var dateFormatForIdbs = "yyyy'-'MM'-'dd'T'HH':'mm':'ss";
            var workflowurl = $"ewb/services/1.0/workflows";
            var filePath = templateConfigurationProvider.GetWorkflowsByWorkflowStatusInProgressAndNewFilePath;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);

            //replace user name
            jsonBodyTemplate = jsonBodyTemplate.Replace(UsernameParameter, username);
            jsonBodyTemplate = jsonBodyTemplate.Replace(SentDateGreaterThanOrEqualTo, startDate.ToString(dateFormatForIdbs));
            jsonBodyTemplate = jsonBodyTemplate.Replace(SentDateLessThanOrEqualTo, endDate.ToString(dateFormatForIdbs));

            //var request = new RestRequest(workflowurl, Method.Put).AddBody(jsonBodyTemplate, "application/json");
            var request = new RestRequest(workflowurl, Method.Put).AddStringBody(jsonBodyTemplate, ContentType.Json);
            request.AddHeader("Content-Type", "application/json");

            return request;
        }
        private static string GetValueByAttributeName(Entity entity, string attributeName)
        {
            return entity.Attributes.Attribute.FirstOrDefault(x => x.Name == attributeName).Values.Value.FirstOrDefault();
        }
    }
}
