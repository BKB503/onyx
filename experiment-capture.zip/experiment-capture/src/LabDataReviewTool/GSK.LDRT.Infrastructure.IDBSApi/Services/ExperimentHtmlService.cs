﻿using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext;
using GSK.LDRT.Domain.IDBSEntities.Entity;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor;
using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using GSK.LDRT.Domain.IDBSEntities.Record;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSApi.Services
{
    public class ExperimentHtmlService : IExperimentHtmlService
    {
        private readonly IEntityApiService entityApiService;
        private readonly ISpreadSheetService spreadSheetService;
        private readonly IUvVisSampleContext uvVisSampleContext;
        private readonly IBioReactorContext bioReactorContext;
      
        public ExperimentHtmlService(IEntityApiService entityApiService, ISpreadSheetService spreadSheetService, 
            IUvVisSampleContext uvVisSampleContext, IBioReactorContext bioReactorContext)
        {
            this.entityApiService = entityApiService;
            this.spreadSheetService = spreadSheetService;
            this.uvVisSampleContext = uvVisSampleContext;
            this.bioReactorContext = bioReactorContext;
            
        }
        public async Task<List<string>> GenerateHtmlData(RecordSummaryEntity recordSummaryEntity)
        {
            var htmlDataNodes = new List<string>();

            htmlDataNodes.Add(BuildOverviewData(recordSummaryEntity));
            var pageBreak = " <div class='page-break'></div>";
            foreach (var childEntity in recordSummaryEntity.RecordEntity.Entity.Children.Entity)
            {
                if(childEntity.EntityCore.EntityTypeName == "TEXT_DOCUMENT")
                {
                    var textDocumentBodyHtml = await entityApiService.GetTextDocumentData(childEntity.EntityCore.EntityId, childEntity.VersionInfo.VersionId);
                    var signaturesHtml = BuildSignatures(childEntity.Signatures.SignatureDetail);

                    var textDocumentNode = $" <div class='table-wrapper'><p> <h2><b class='header-center'>{childEntity.EntityCore.NodeDisplayText} </b></h2> </p> {textDocumentBodyHtml} <br/> {signaturesHtml}</div> {pageBreak}";
                    htmlDataNodes.Add(textDocumentNode);
                }
                else if(childEntity.EntityCore.EntityTypeName == "IDBS_SPREADSHEET")
                {
                    var headerHTml = $"<div><b class='header-center'><h2>{childEntity.EntityCore.NodeDisplayText} </h2></b> </div>";
                    htmlDataNodes.Add(headerHTml);
                    var spreadsheetModelId = await spreadSheetService.LoadSpreadSheetData(childEntity.VersionInfo.VersionId);
                    if (childEntity.EntityCore.EntityName == "UV-VIS_Sample Testing" || childEntity.EntityCore.EntityName == "UV-VIS Sample Testing" ||
                        childEntity.EntityCore.EntityName.Contains("UV_Vis_Sample_Testing"))
                    {
                        await UVVisSamplingPdfData(htmlDataNodes, pageBreak, childEntity, spreadsheetModelId);
                    }
                    else if (!string.IsNullOrEmpty(childEntity.EntityCore.EntityName) && childEntity.EntityCore.EntityName.ToLower().Contains("bioreactor"))
                    {
                        await BioReactorTemplatePdfData(htmlDataNodes, pageBreak, childEntity, spreadsheetModelId);
                    }
                    else
                    {
                        await AllOtherTemplates(htmlDataNodes, pageBreak, childEntity, spreadsheetModelId);
                    }
                }
                else if(childEntity.EntityCore.EntityTypeName == "DOCUMENT")
                {
                    var headerHTml = $"<div><b class='header-center'>{childEntity.EntityCore.NodeDisplayText} </b> </div> <div> <b>{childEntity.EntityCore.EntityName}</b></div>";
                    var signaturesHtml = BuildSignatures(childEntity.Signatures.SignatureDetail);
                   
                    var wrapAttachment = $"<div class='table-wrapper'> {headerHTml} <br/> {signaturesHtml}</div> <br/>";
                    htmlDataNodes.Add(wrapAttachment);
                }
            }
            return htmlDataNodes;
        }

        private async Task UVVisSamplingPdfData(List<string> htmlDataNodes, string pageBreak, Entity childEntity, string spreadsheetModelId)
        {
            var filterTables = UvVisSampleTestTables();
            var spreadSheetTables = await spreadSheetService.GetSpreadSheetTables(spreadsheetModelId, filterTables);

            var spreadSheetTablesData = new List<SpreadSheetTableData>();

            foreach (var spreadSheetTable in spreadSheetTables)
            {
                var jsonData = await spreadSheetService.GetTableData(spreadsheetModelId, spreadSheetTable);
                var spreadSheetTableData = new SpreadSheetTableData
                {
                    Data = jsonData.ToString(),
                    TableName = spreadSheetTable
                };
                if (spreadSheetTable == "Image Upload Table")
                {
                    var imageUploadTables = (List<ImageUploadTable>)JsonConvert.DeserializeObject<List<ImageUploadTable>>(jsonData.ToString());
                    var imageFilteredTables = imageUploadTables.Where(x => x.Image.Value != null).ToList();
                    foreach (var imageUploaded in imageFilteredTables)
                    {
                        var imageResponseEntity = await spreadSheetService.GetImageData(spreadsheetModelId, imageUploaded.Image.Value);
                        spreadSheetTableData.Images.Add(imageResponseEntity);
                    }
                }
                spreadSheetTablesData.Add(spreadSheetTableData);

            }
            var jsonFilterTableData = spreadSheetTablesData.FirstOrDefault(x => x.TableName == "h JSON").Data;
            var assayMetaData = spreadSheetTablesData.FirstOrDefault(x => x.TableName == "Assay Metadata").Data;
            var jsonFilterTable = JsonConvert.DeserializeObject<List<JsonFilterTable>>(jsonFilterTableData);
            var assayData = JsonConvert.DeserializeObject<List<AssayData>>(assayMetaData);
            var methodName = assayData.FirstOrDefault().MethodName;
            var methodId = assayData.FirstOrDefault().MethodId;
            var spreadSheetFilteredData = spreadSheetTablesData.Where(x => UvVisSampleTestHtmlTables().Any(h => x.TableName == h));
            foreach (var spreadSheetTableData in spreadSheetFilteredData)
            {
                var spreadSheetPdfTableModel = new SpreadSheetPdfTableModel
                {
                    JsonFilterTables = jsonFilterTable,
                    TableName = spreadSheetTableData.TableName,
                    TableData = spreadSheetTableData.Data.ToString(),
                    SpreadSheetTableAndData = spreadSheetTablesData,
                    MethodName = methodName.Value,
                    MethodId = methodId.Value
                };
                var tableHtml = uvVisSampleContext.GetHtmlNode(spreadSheetTableData.TableName, spreadSheetPdfTableModel);
                htmlDataNodes.Add(tableHtml);
            }
            var signaturesHtml = BuildSignatures(childEntity.Signatures.SignatureDetail);
            htmlDataNodes.Add(signaturesHtml);
            htmlDataNodes.Add(pageBreak);
        }

        private async Task BioReactorTemplatePdfData(List<string> htmlDataNodes, string pageBreak, Entity childEntity, string spreadsheetModelId)
        {
            var filterTables = BioReactorTables();
            var spreadSheetTables = await spreadSheetService.GetSpreadSheetTables(spreadsheetModelId, filterTables);

            var spreadSheetTablesData = new List<SpreadSheetTableData>();

            foreach (var spreadSheetTable in spreadSheetTables)
            {
                var jsonData = await spreadSheetService.GetTableData(spreadsheetModelId, spreadSheetTable);
                var spreadSheetTableData = new SpreadSheetTableData
                {
                    Data = jsonData.ToString(),
                    TableName = spreadSheetTable
                };

                if (spreadSheetTable == "Samples")
                {
                    var samples = (List<Samples>)JsonConvert.DeserializeObject<List<Samples>>(jsonData.ToString());
                    var sampleFilteredBarcodes = samples.Where(x => x.Barcode.Value != null).ToList();
                    foreach (var barcode in sampleFilteredBarcodes)
                    {
                        var imageResponseEntity = await spreadSheetService.GetImageData(spreadsheetModelId, barcode.Barcode.Value);
                        spreadSheetTableData.Images.Add(imageResponseEntity);
                    }
                }
                spreadSheetTablesData.Add(spreadSheetTableData);
            }
            var jsonFilterTableData = spreadSheetTablesData.FirstOrDefault(x => x.TableName == "h JSON")?.Data;
            var jsonFilterTable = JsonConvert.DeserializeObject<List<JsonFilterTable>>(jsonFilterTableData);
            var spreadSheetFilteredData = spreadSheetTablesData.Where(x => BioReactorHtmlTables().Any(h => x.TableName == h));
            foreach (var spreadSheetTableData in spreadSheetFilteredData)
            {
                var spreadSheetPdfTableModel = new SpreadSheetPdfTableModel
                {
                    JsonFilterTables = jsonFilterTable,
                    TableName = spreadSheetTableData.TableName,
                    TableData = spreadSheetTableData.Data.ToString(),
                    SpreadSheetTableAndData = spreadSheetTablesData,
                };
                var tableHtml = bioReactorContext.GetHtmlNode(spreadSheetTableData.TableName, spreadSheetPdfTableModel);
                htmlDataNodes.Add(tableHtml);
            }
            var signaturesHtml = BuildSignatures(childEntity.Signatures.SignatureDetail);
            htmlDataNodes.Add(signaturesHtml);
            htmlDataNodes.Add(pageBreak);
        }

        private async Task AllOtherTemplates(List<string> htmlDataNodes, string pageBreak, Entity childEntity, string spreadsheetModelId)
        {
            var filterTables = new List<string> { };
            var spreadSheetTables = await spreadSheetService.GetSpreadSheetTables(spreadsheetModelId, filterTables);
            var spreadSheetTablesData = new List<SpreadSheetTableData>();

            foreach (var spreadSheetTable in spreadSheetTables)
            {
                var dataTable = await spreadSheetService.GetTableDataAsDataTable(spreadsheetModelId, spreadSheetTable);
                var spreadSheetTableData = new SpreadSheetTableData
                {
                    TableName = spreadSheetTable,
                    DataTable = dataTable
                };
                spreadSheetTablesData.Add(spreadSheetTableData);
            }

            var countTableAfter5 = 0;
            var hJsonDataTable = spreadSheetTablesData.FirstOrDefault(x => x.TableName.ToLower() == "h JSON".ToLower());

            var tableNames = new List<string>();
            var hJsonDataList = new List<HJson>();
            if (hJsonDataTable != null && hJsonDataTable.DataTable != null)
            {
                var json = JsonConvert.SerializeObject(hJsonDataTable.DataTable);
                hJsonDataList = JsonConvert.DeserializeObject<List<HJson>>(json);
                if (hJsonDataList.Any())
                {
                    tableNames = hJsonDataList.Where( y => !y.TableName.ToLower().StartsWith("uom")).Select(x => x.TableName).ToList();
                }
                var spreadSheetTablesDataFiltered = spreadSheetTablesData.Where(x => tableNames.Any(t => x.TableName == t));
                foreach (var spreadSheetDataTable in spreadSheetTablesDataFiltered)
                {
                    var hJson = hJsonDataList.FirstOrDefault(x => x.TableName == spreadSheetDataTable.TableName);
                    if (countTableAfter5 == 5)
                    {
                        htmlDataNodes.Add(pageBreak);
                        countTableAfter5 = 0;
                    }
                    var tableHtml = BuildDataTableToHtml(spreadSheetDataTable, spreadSheetTablesData, hJson);
                    htmlDataNodes.Add(tableHtml);
                    countTableAfter5++;
                }
            }
            else
            {
                var exculdeTables = new List<string> { "h ", "iq ", "h iq " };
                var spreadSheetTablesDataFiltered = spreadSheetTablesData.Where(x => !exculdeTables.Any(t => x.TableName.ToLower().StartsWith(t.ToLower())));
                foreach (var spreadSheetDataTable in spreadSheetTablesDataFiltered)
                {
                    var hJson = hJsonDataList.FirstOrDefault(x => x.TableName == spreadSheetDataTable.TableName);
                    if (countTableAfter5 == 5)
                    {
                        htmlDataNodes.Add(pageBreak);
                        countTableAfter5 = 0;
                    }
                    var tableHtml = BuildDataTableToHtml(spreadSheetDataTable, spreadSheetTablesData, hJson);
                    htmlDataNodes.Add(tableHtml);
                    countTableAfter5++;
                }
            }

        }

        private static string BuildOverviewData(RecordSummaryEntity recordSummaryEntity)
        {
            var leftColumnOverviewData = BuildLeftColumnData(recordSummaryEntity);
            var rightColumnOverviewData = BuildRightColumnData(recordSummaryEntity);
            return $"<div class='row'> {BuildColumnOverviewData(leftColumnOverviewData)} " +
                $"{BuildColumnOverviewData(rightColumnOverviewData)}</div>";
        }

        private static Dictionary<string, string> BuildLeftColumnData(RecordSummaryEntity recordSummaryEntity)
        {
            var leftColumnData = new Dictionary<string, string>();
            leftColumnData.Add("Experiment ID", recordSummaryEntity.ExperimentId);
            leftColumnData.Add("Title", recordSummaryEntity.Title);
            leftColumnData.Add("Created By", recordSummaryEntity.RecordEntity.Entity.VersionInfo.UserName);
            leftColumnData.Add("Prev. Exp. Ref", recordSummaryEntity.PrevExpRef);
            leftColumnData.Add("Expt Ref - Succcessor", recordSummaryEntity.ExptRefSucccessor);
            leftColumnData.Add("Additional Project Ref", recordSummaryEntity.AdditionalProjectRef);
            leftColumnData.Add("Alliance_Name", recordSummaryEntity.AllianceName);
            return leftColumnData;
        }

        private static Dictionary<string, string> BuildRightColumnData(RecordSummaryEntity recordSummaryEntity)
        {
            var rightColumnData = new Dictionary<string, string>();
            rightColumnData.Add("Created On", recordSummaryEntity.CreatedOn);
            rightColumnData.Add("Experiment Status", recordSummaryEntity.ExperimentStatus);
            rightColumnData.Add("Request ID",recordSummaryEntity.RequestId);
            rightColumnData.Add("Version Number", recordSummaryEntity.RecordEntity.Entity.VersionInfo.VersionNumber.ToString());
            rightColumnData.Add("Version Type", recordSummaryEntity.RecordEntity.Entity.VersionInfo.VersionState);
            rightColumnData.Add("User", recordSummaryEntity.RecordEntity.Entity.VersionInfo.UserName);
            rightColumnData.Add("User Name", recordSummaryEntity.RecordEntity.Entity.VersionInfo.UserFullName);
            return rightColumnData;
        }


        private static DateTime ConvertEpochToDate(long epoch)
        {
            var dt = DateTime.UnixEpoch.AddMilliseconds(epoch);
            return dt;
        }

        private static string BuildColumnOverviewData(Dictionary<string, string> columnData)
        {
            var htmlData = "";
            foreach (var item in columnData)
            {
                htmlData += $"<p> <b>{item.Key} :</b> {item.Value} </p>";
            }
            return $"<div class='column'>{htmlData} </div>";
        }

        private static string BuildSignatures(List<SignatureDetail> signatureDetails)
        {
            var signaturesHtml = "";
            if (signatureDetails.Any())
            {
                foreach (var signatureDetail in signatureDetails)
                {
                    signaturesHtml += BuildSignatureHtml(signatureDetail);
                }
            }

            return signaturesHtml;
        }
        private static string BuildSignatureHtml(SignatureDetail signatureDetail)
        {
            if (signatureDetail == null)
            {
                return "";
            }
            else
            {
                var date = ConvertEpochToDate(signatureDetail.Timestamp).ToString("MMM dd, yyyy HH:mm:ss tt");
                var html = $"<div class='signature'> <div> <h3> Signature</h3> </div>" +
                    $" <div class='row'> <b>Digitally Signed By </b>: {signatureDetail.UserFullName} </div> " +
                     $"<div class='row'><b>Reason </b>: {signatureDetail.Reason} </div>" +
                     $"<div class='row'><b>Role </b>: {signatureDetail.Role} </div>" +
                     $"<div class='row'><b>Date </b>: {date} </div> </div>";
                return html;
            }
        }
        private static List<string> UvVisSampleTestTables()
        {
            return new List<string> {  "Assay Metadata",
                                       "Experiment Information",
                                       "Compounds and Projects",
                                       "Request Details",
                                       "Equipment Details",
                                       "Material Details",
                                       "Reagent Preparation",
                                       "Material and Reagent Dilution",
                                       "Sample Details",
                                       "Sample Dilution",
                                       "Sample Aliquot Details",
                                       "Sample Metadata",
                                       "Sample Details- Dashboard",
                                       "Aliquot Metadata",
                                       "Aliquot Details- Dashboard",
                                       "Method Parameters",
                                       "Run Setup",
                                       "Standard Setup",
                                       "Standard Curve Details",
                                       "System Suitability",
                                       "Acceptance Criteria",
                                       "Import Filename",
                                       "Control Results",
                                       "Standard Results",
                                       "Sample Results",
                                       "Image Upload Table",
                                       "Sample Summary",
                                       "Conclusion Table",
                                       "File Attachment Reference",
                                       "File Attachment  Reference",
                                       "h JSON",
                                       "UoM_Compounds and Projects",
                                       "UoM_Material Details",
                                       "UoM_Reagent Preparation",
                                       "UoM_Sample Aliquot Details",
                                       "UoM_Control Results",
                                       "UoM_Standard Results",
                                       "UoM_Sample Results",
                                       "UoM_Sample Final Summary"

            };
        }

        private static List<string> UvVisSampleTestHtmlTables()
        {
            return new List<string> {   "Assay Metadata",
               "Experiment Information",
               "Compounds and Projects",
               "Equipment Details",
               "Material Details",
               "Reagent Preparation",
               "Material and Reagent Dilution",
               "Sample Details",
               "Sample Dilution",
               "Sample Aliquot Details",
               "Sample Metadata",
               "Sample Details- Dashboard",
               "Aliquot Metadata",
               "Aliquot Details- Dashboard",
               "Method Parameters",
               "Run Setup",
               "Standard Setup",
               "Standard Curve Details",
               "System Suitability",
               "Acceptance Criteria",
               "Import Filename",
               "Control Results",
               "Standard Results",
               "Sample Results",
               "Image Upload Table",
               "Sample Summary",
               "Conclusion Table",
               "File Attachment Reference",
               "File Attachment  Reference",
            };
        }

        private List<string> BioReactorTables()
        {
            var filterTableNames = new List<string> {
                "Experiment Setup",
                "Experiment Setup Details",
                "Compounds and Projects",
                "Contributors",
                "Bioreactor Details",
                "Other Equipment Details",
                "Reagent Details",
                "Material Details",
                "Culture Details",
                "UoM_Culture Details",
                "Solution Components",
                "Solution Parameters",
                "Centrifugation",
                "UoM_Centrifugation",
                "Inoculum Details",
                "UoM_Inoculum Details",
                "Setpoints",
                "UoM_Setpoints",
                "Experiment Feed Setup",
                "Feed Configuration",
                "Vessel Setup",
                "UoM_Vessel Setup",
                "Sample Setup Configuration",
                "UoM_Sample Setup Configuration",
                "Raman Instrumentation",
                "Raman Data",
                "Raman Instrument Settings",
                "UoM_Raman Instrument Settings",
                "Raman Model",
                "Feed Details",
                "UoM_Feed Details",
                "Parent Sample Details",
                "UoM_Parent Sample Details",
                "Aliquot Sample Details",
                "UoM_Aliquot Sample Details",
                "DCA ID Generation",
                "Barcode Dimension",
                "Samples",
                "Run Summary",
                "UoM_Run Summary",
                "Pooled Culture Details",
                "UoM_Pooled Culture Details",
                "Bioreactor Run Check",
                "Sample Labels",
                "DCA ID Labels",
                "Culture Labels",
                "Analytical Sample Label",
                "Box Label Printing",
                "Incomplete Count",
                "Reactor Daily Data Entry Units",
                "Reactor Daily Data Entry",
                "UoM_Reactor Daily Data Entry",
                "ViCell Data Entry",
                "UoM_ViCell Data Entry",
                "Osmometer Data Entry",
                "UoM_Osmometer Data Entry",
                "BioHT Cedex Data Entry",
                "UoM_BioHT Cedex Data Entry",
                "Flex2 Data Entry",
                "UoM_Flex2 Data Entry",
                "RAPIDPoint 500 Data Entry",
                "UoM_RAPIDPoint 500 Data Entry",
                "YSI Data Entry",
                "UoM_YSI Data Entry",
                "Octet or HPLC Data Entry",
                "UoM_Octet or HPLC Data Entry",
                "Process Results",
                "UoM_Process Results",
                "Result Summary",
                "UoM_Result Summary",
                "h JSON"
                };

            return filterTableNames;
        }

        private List<string> BioReactorHtmlTables()
        {
            return  new List<string>
                            {
                               "Experiment Setup",
                               "Experiment Setup Details",
                               "Compounds and Projects",
                               "Contributors",
                               "Bioreactor Details",
                               "Other Equipment Details",
                               "Reagent Details",
                               "Material Details",
                               "Culture Details",
                               "Solution Components",
                               "Solution Parameters",
                               "Centrifugation",
                               "Inoculum Details",
                               "Setpoints",
                               "Experiment Feed Setup",
                               "Feed Configuration",
                               "Vessel Setup",
                               "Sample Setup Configuration",
                               "Raman Instrumentation",
                               "Raman Data",
                               "Raman Instrument Settings",
                               "Raman Model",
                               "Feed Details",
                               "Parent Sample Details",
                               "Aliquot Sample Details",
                               "DCA ID Generation",
                               "Barcode Dimension",
                               "Samples",
                               "Run Summary",
                               "Pooled Culture Details",
                               "Bioreactor Run Check",
                               "Sample Labels",
                               "DCA ID Labels",
                               "Culture Labels",
                               "Analytical Sample Label",
                               "Box Label Printing",
                               "Incomplete Count",
                               "Reactor Daily Data Entry Units",
                               "Reactor Daily Data Entry",
                               "ViCell Data Entry",
                               "Osmometer Data Entry",
                               "BioHT Cedex Data Entry",
                               "Flex2 Data Entry",
                               "RAPIDPoint 500 Data Entry",
                               "YSI Data Entry",
                               "Octet or HPLC Data Entry",
                               "Process Results"

                }; ;
        }

        private string BuildDataTableToHtml(SpreadSheetTableData spreadSheetData, List<SpreadSheetTableData> spreadSheetTablesData, HJson? hJson)
        {
            var uomTableName = $"uom_{spreadSheetData.TableName}";
            var subHeadersSpreadSheetData = spreadSheetTablesData.FirstOrDefault(x => x.TableName.ToLower() == uomTableName.ToLower());

            var tabledata = CreateTableDataHtml(spreadSheetData.DataTable, subHeadersSpreadSheetData?.DataTable, hJson);
            var tableHtml = $"<div class='table-wrapper'><table class='table'>  <caption class='caption'> <h2>{spreadSheetData.TableName}</h2> </caption>{tabledata}</table></div>";
            return tableHtml;
        }

        private string CreateTableDataHtml(DataTable dataTable, DataTable subHeadersData, HJson? hJson)
        {
            DataRow[] dataRows = dataTable.Select();
            if (hJson != null && !string.IsNullOrEmpty(hJson.hFilterIdentifier) && !string.IsNullOrEmpty(hJson.FilterValues))
            {
                //Check column exists 

                var columnsExists = IsColumnExists(dataTable, hJson.hFilterIdentifier);

                if (columnsExists)
                {
                    var filterQuery = "";
                    if (!string.IsNullOrEmpty(hJson.FilterValues) && hJson.FilterValues.ToLower() == "any value")
                    {
                        filterQuery = $"NOT([{hJson.hFilterIdentifier}] IS NULL OR [{hJson.hFilterIdentifier}]='')";
                        // filterQuery = $"[{hJson.hFilterIdentifier}] IS NOT NULL OR [{hJson.hFilterIdentifier}] <> '')";
                        dataRows = dataTable.Select(filterQuery);

                    }
                    else
                    {
                        filterQuery = $"[{hJson.hFilterIdentifier}] = '{hJson.FilterValues}'";
                        dataRows = dataTable.Select(filterQuery);
                    }

                }
            }
            var tableHeader = "";
            var tableRows = "";
            var tableHeaders = "";
            var tableSubHeaders = "";
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                var columnName = dataTable.Columns[i].ColumnName;
                if (!columnName.ToLower().StartsWith("h "))
                {
                    tableHeaders += $"<th scope='col'>{columnName} </th>";

                    if (subHeadersData != null && subHeadersData.Columns.Count > 0 && subHeadersData.Rows.Count > 0)
                    {
                        var uomRowValue = SubHeader(subHeadersData, columnName);

                        tableSubHeaders += $"<th scope='col' class='th-border'>{uomRowValue} </th>";
                    }
                }
            }

            if (!string.IsNullOrEmpty(tableSubHeaders))
            {
                tableHeader += $"<thead><tr>{tableHeaders}</tr><tr>{tableSubHeaders} </tr> </thead>";
            }
            else
            {
                tableHeader += $"<thead><tr>{tableHeaders}</tr> </thead>";
            }

            // for (int i = 0; i < dataTable.Rows.Count; i++)
            for (int i = 0; i < dataRows.Count(); i++)
            {
                var tableCells = "";
                for (int j = 0; j < dataTable.Columns.Count; j++)
                {
                    var columnName = dataTable.Columns[j].ColumnName;
                    if (!columnName.ToLower().StartsWith("h "))
                    {
                        //var cell = dataTable.Rows[i][j].ToString();
                        var cell = dataRows[i][j].ToString();
                        var isDateTime = DateTime.TryParse(cell, out DateTime dateTime);
                        if (isDateTime)
                        {
                            tableCells += $"<td class='td'>{dateTime.ToString("MMM dd, yyyy HH:mm:ss tt")} </td>";
                        }
                        else
                        {
                            tableCells += $"<td class='td'>{cell} </td>";
                        }
                    }
                }
                tableRows += $"<tr>{tableCells}</tr> ";
            }
            var table = $"{tableHeader}<tbody>{tableRows} </tbody>";

            return table;
        }

        private string SubHeader(DataTable subHeaderTable, string columnName)
        {
            var columnValue = "";
            for (int i = 0; i < subHeaderTable.Rows.Count; i++)
            {
                for (int j = 0; j < subHeaderTable.Columns.Count; j++)
                {
                    var unitColumn = subHeaderTable.Rows[i][j].ToString();
                    if (unitColumn == columnName)
                    {
                        var columnNext = j + 1;
                        columnValue = subHeaderTable.Rows[i][columnNext].ToString();
                        return columnValue;
                    }
                }
            }

            return columnValue;
        }

        private bool IsColumnExists(DataTable dataTable, string columnName)
        {
            return dataTable.Columns.Count > 0 && dataTable.Columns.Contains(columnName);
        }
    }
}
