﻿using GSK.LDRT.Application.Exceptions;
using GSK.LDRT.Contracts.Abstractions.Common;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using RestSharp.Serializers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.IDBSApi.Services
{
    public class SpreadSheetService : ISpreadSheetService
    {
        private readonly RestClient restClient;
        private readonly IFileReader fileReader;
        private readonly ITemplateConfigurationProvider templateConfigurationProvider;
        //private const string ContentType = "Content-Type";
        private const string ContentTypeValue = "application/json";
        private const string TableName = "#{tableName}#";
        private const string ImageName = "#{imageName}#";
        public SpreadSheetService(RestClient restClient, IFileReader fileReader, ITemplateConfigurationProvider templateConfigurationProvider)
        {
            this.restClient = restClient;
            this.fileReader = fileReader;
            this.templateConfigurationProvider = templateConfigurationProvider;
        }
        public async Task<string> LoadSpreadSheetData(string versionId)
        {
            var loadSpreadSheetUrl = $"ewb/services/1.0/spreadsheet?editMode=false&versionId={versionId}";
            var request = new RestRequest(loadSpreadSheetUrl, Method.Put);

            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful && response.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                return $"API-{versionId}";
            }
            else if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }
            var spreadsheetModelId = response.Content;
            return spreadsheetModelId;
        }

        public async Task<IEnumerable<string>> GetSpreadSheetTables(string modelId, IEnumerable<string> filterTables)
        {
            var tableNames = new List<string>();
            var loadSpreadSheetUrl = $"ewb/services/1.0/spreadsheet/data?modelId={modelId}";

            var filePath = templateConfigurationProvider.GetSpreadSheetTableListRequest;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);

            var request = new RestRequest(loadSpreadSheetUrl, Method.Post).AddStringBody(jsonBodyTemplate, ContentType.Json);
           // request.AddHeader(ContentType, ContentTypeValue);
            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }

            var tableDataEntity = JsonConvert.DeserializeObject<TableDataEntity>(response.Content);
            if (tableDataEntity != null && tableDataEntity.BatchResponse.ApiResponses.Any())
            {
                if (filterTables.Any())
                {
                    var tables = tableDataEntity.BatchResponse.ApiResponses.FirstOrDefault()?.Tables?.Where(x => filterTables.Any(e => x.Name == e))?.Select(y => y.Name);
                    return tables;
                }
                else
                {
                    var tables = tableDataEntity.BatchResponse.ApiResponses.FirstOrDefault()?.Tables?.Select(y => y.Name);
                    return tables;
                }
            }

            return tableNames;
        }

        public async Task<dynamic> GetTableData(string modelId, string tableName)
        {
            var loadSpreadSheetUrl = $"ewb/services/1.0/spreadsheet/data?modelId={modelId}";
            var filePath = templateConfigurationProvider.GetSpreadSheetTableDataRequest;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);
            jsonBodyTemplate = jsonBodyTemplate.Replace("#{tableName}#", tableName);

            var request = new RestRequest(loadSpreadSheetUrl, Method.Post).AddStringBody(jsonBodyTemplate, ContentType.Json);
            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }

            var tableDataEntity = JsonConvert.DeserializeObject<TableDataEntity>(response.Content);
            return tableDataEntity.BatchResponse.ApiResponses.FirstOrDefault().Tables.FirstOrDefault().Ranges.FirstOrDefault().Data;
        }

        public async Task<ImageResponseEntity> GetImageData(string modelId, string imageName)
        {
            var loadSpreadSheetUrl = $"ewb/services/1.0/spreadsheet/data?modelId={modelId}";
            var filePath = templateConfigurationProvider.GetSpreadSheetImageDataRequest;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);
            jsonBodyTemplate = jsonBodyTemplate.Replace("#{imageName}#", imageName);

            var request = new RestRequest(loadSpreadSheetUrl, Method.Post).AddStringBody(jsonBodyTemplate, ContentType.Json);
            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }

            var tableDataEntity = JsonConvert.DeserializeObject<ImageDataEntity>(response.Content);
            return tableDataEntity.BatchResponse.ApiResponses.FirstOrDefault();
        }

        public async Task<DataTable> GetTableDataAsDataTable(string modelId, string tableName)
        {
            var loadSpreadSheetUrl = $"ewb/services/1.0/spreadsheet/data?modelId={modelId}";
            var filePath = templateConfigurationProvider.GetSpreadSheetTableDataRequest;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);
            jsonBodyTemplate = jsonBodyTemplate.Replace("#{tableName}#", tableName);

            var request = new RestRequest(loadSpreadSheetUrl, Method.Post).AddStringBody(jsonBodyTemplate, ContentType.Json);
            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }
            var tableDataEntity = JsonConvert.DeserializeObject<TableDataEntity>(response.Content);
            var jsonData = tableDataEntity.BatchResponse.ApiResponses.FirstOrDefault().Tables.FirstOrDefault().Ranges.FirstOrDefault().Data.ToString();

            return JsonToDataTable(jsonData);
        }

        private DataTable JsonToDataTable(string jsonData)
        {
            if (jsonData.Trim().StartsWith("[") && jsonData.Trim().EndsWith("]"))
            {
                var startString = "{\"data\":";
                var endString = "}";
                jsonData = $"{startString}{jsonData}{endString}";
            }
            var dataTable = new DataTable();
            var data = JsonConvert.DeserializeObject<SpreadSheetJsonRoot>(jsonData).Data;
            var firstRow = data.FirstOrDefault();

            foreach (var item in firstRow)
            {
                dataTable.Columns.Add(item.Key, typeof(string));
            }

            foreach (var dict in data)
            {
                var dataRow = dataTable.NewRow();
                foreach (var kvp in dict)
                {
                    if (kvp.Value != null)
                    {
                        var value1 = JsonConvert.DeserializeObject<JObject>(kvp.Value.ToString());
                        var childernValue = JsonConvert.DeserializeObject<string>(
                               value1.Children<JProperty>().FirstOrDefault().Value.ToString(Newtonsoft.Json.Formatting.None));

                        dataRow[kvp.Key] = childernValue;
                    }
                    else
                    {
                        dataRow[kvp.Key] = string.Empty;
                    }
                }
                dataTable.Rows.Add(dataRow);

            }
            return dataTable;
        }
    }
}
