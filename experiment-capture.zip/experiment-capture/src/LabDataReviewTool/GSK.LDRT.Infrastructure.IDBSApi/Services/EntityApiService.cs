﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSK.LDRT.Application.Exceptions;
using GSK.LDRT.Contracts.Abstractions.Common;
using GSK.LDRT.Contracts.Abstractions.IdbsApi;
using GSK.LDRT.Domain.IDBSEntities.Entity;
using HtmlAgilityPack;
using Newtonsoft.Json;
using RestSharp;

namespace GSK.LDRT.Infrastructure.IDBSApi.Services
{
    public class EntityApiService : IEntityApiService

    {
        private readonly RestClient restClient;
        private readonly IFileReader fileReader;
        private readonly ITemplateConfigurationProvider templateConfigurationProvider;
        private const string UsernameParameter = "#{username}#";
        private const string ContentType = "Content-Type";
        private const string ContentTypeValue = "application/json";
        public EntityApiService(RestClient restClient, IFileReader fileReader, ITemplateConfigurationProvider templateConfigurationProvider)
        {
            this.restClient = restClient;
            this.fileReader = fileReader;
            this.templateConfigurationProvider = templateConfigurationProvider;
        }

        public async Task<Entity> GetEntityByEntitytId(string entityId, bool includeAttributes = true, bool includeChildren = false, bool includeVersionInfo=false)
        {
            var entityUrl = $"ewb/services/1.0/entities/{entityId}?includeAttributes={includeAttributes}&includeChildren={includeChildren}&includeVersionInfo={includeVersionInfo}";
            var request = new RestRequest(entityUrl, Method.Get);
            request.AddHeader(ContentType, ContentTypeValue);

            var response = await restClient.ExecuteAsync(request);

            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }

            else
            {
                var entity = JsonConvert.DeserializeObject<Entity>(response.Content);
                return entity;

            }
        }

        public async Task<IEnumerable<ExperimentDocumentEntity>> GetDocumentEntitiesByEntityId(string entityId)
        {
            var entity = await GetEntityByEntitytId(entityId, false, true, true);

            return MapDocumentResponse(entity);

        }

        private static IEnumerable<ExperimentDocumentEntity> MapDocumentResponse(Entity entity)
        {
            var childEntities = new List<ExperimentDocumentEntity>();

            if (entity != null && entity.Children.Entity.Any())
            {
                // get only attached documents, 
                var documentEntities = entity.Children.Entity.Where(x => x.EntityCore.EntityTypeName == "DOCUMENT" 
                                                        && x.EntityCore.EntityName != "Add files here") ;

                if (documentEntities.Any())
                {
                    foreach (var documentEntity in documentEntities)
                    {
                        var childEntity = new ExperimentDocumentEntity
                        {
                            EntityId = documentEntity.EntityCore.EntityId,
                            DisplayText = documentEntity.EntityCore.NodeDisplayText,
                            VersionId = documentEntity.VersionInfo.VersionId,
                            EntityTypeName = documentEntity.EntityCore.EntityTypeName,
                            FileName = documentEntity.EntityCore.EntityName
                        };
                        childEntities.Add(childEntity);
                    }
                    return childEntities;
                }
            }

            return childEntities;
        }

        public async Task<IEnumerable<Entity>> GetEntitiesByUserAndOpenStatus(string username)
        {

            var request = BuildExperimentsWithOpenStatusRequest(username);

            var response = await restClient.ExecuteAsync(request);

            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }

            else
            {
                var entityList = JsonConvert.DeserializeObject<EntityList>(response.Content);
                
                //    string experimentId = GetValueByAttributeName(entity, "Experiment ID");
                //    var experimentStatus = GetValueByAttributeName(entity, "statusName");

                return entityList.Entity;

            }
        }

        public async Task<DocumentEntity> DownloadDocument(string entityId, string entityVersionId)
        {
            var entityUrl = $"ewb/services/1.0/entities/{entityId}/data?entityVersionId={entityVersionId}";
            var request = new RestRequest(entityUrl, Method.Get);
            request.AddHeader(ContentType, ContentTypeValue);
            var response = await restClient.ExecuteAsync(request);
            if (!response.IsSuccessful)
            {
                var message = !string.IsNullOrEmpty(response.Content) ? response.Content : response.ErrorException.Message;
                message = $"{message}, Failed when calling IDBS API";
                throw new ApiException(message, response.StatusCode);
            }

            return new DocumentEntity { Data = response.RawBytes, ContentType = response.ContentType};
        }

        public async Task<string> GetTextDocumentData(string entityId, string entityVersionId)
        {
            var entityUrl = $"ewb/services/1.0/entities/{entityId}/preview?entityVersionId={entityVersionId}";

            var request = new RestRequest(entityUrl, Method.Get);
            var response = await restClient.ExecuteAsync(request);
            HtmlDocument htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(response.Content);

            var images = htmlDoc.DocumentNode.SelectNodes("//img");
            if (images != null && images.Any())
            {
                foreach (var image in images)
                {
                    var src = image.GetAttributeValue("src", "");
                    var imgValues = src.Split(":");
                    var imgDataURI = await GetImageData(imgValues[0], imgValues[1], imgValues[2]);
                    var imgHtml = $"<img src='{imgDataURI}'>";
                    var newNode = HtmlNode.CreateNode(imgHtml);
                    image.ParentNode.ReplaceChild(newNode, image);
                }
            }
            var body = htmlDoc.DocumentNode.SelectSingleNode("//body").InnerHtml;
            return body;
        }

        public async Task<string> GetImageData(string entityId, string entityVersionId, string fileName)
        {
            var entityUrl = $"ewb/services/1.0/entities/{entityId}/preview?entityVersionId={entityVersionId}&fileName={fileName}";

            var request = new RestRequest(entityUrl, Method.Get);
            var response = await restClient.ExecuteAsync(request);
            if (response.IsSuccessful)
            {
                var base64 = @$"data:{response.ContentType};base64," + Convert.ToBase64String(response.RawBytes);
                return base64;
            }

            return string.Empty;

        }


        private RestRequest BuildExperimentsWithOpenStatusRequest(string username)
        {
            var taskUrl = $"ewb/services/1.0/entities/findBy";
            var filePath = templateConfigurationProvider.GetExperimentsByOpenStatusFilePath;
            var jsonBodyTemplate = fileReader.ReadAllText(filePath);

            //Replace username
            jsonBodyTemplate = jsonBodyTemplate.Replace(UsernameParameter, username);

            var request = new RestRequest(taskUrl, Method.Post).AddBody(jsonBodyTemplate, "application/json");
            request.AddHeader(ContentType, ContentTypeValue);

            return request;
        }


    }
}
