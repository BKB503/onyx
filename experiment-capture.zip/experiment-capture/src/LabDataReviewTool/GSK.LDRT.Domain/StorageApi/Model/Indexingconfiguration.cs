﻿namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class Indexingconfiguration
    {
        public string Topic { get; set; }
        public string Type { get; set; }
        public string KafkaServers { get; set; }
        public string SaslUsername { get; set; }
    }


}
