﻿using System.Text.Json.Serialization;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class MetadataModel
    {
        public MetadataModel()
        {

        }

        /// <summary>
        /// set the MetaData dictionary
        /// </summary>
        [JsonPropertyName("metaData")]
        public MetadataDictionary MetaDataDictionary
        {
            get;
            set;
        }

    }
}
