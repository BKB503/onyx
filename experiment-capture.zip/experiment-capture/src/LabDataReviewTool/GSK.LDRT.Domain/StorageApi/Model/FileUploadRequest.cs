﻿using System.IO;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class FileUploadRequest
    {
        public string FileName { get; set; }
        public Stream FileStream { get; set; }
        public string FolderName { get; set; }
        public Stream MetadataFileStream { get; set; }
        public MetadataCollections MetadataCollections { get; set; }
    }
}
