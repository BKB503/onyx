﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public enum UploadFileResultStatus
    {
        Success = 200,
        Error = 500,
        ContainerNotAvailabe = 404,
        VersioningNotEnabled = 400,
        ConnectionNotActive = 400,
        NoContainerClientAvailabe = 400
    };
}
