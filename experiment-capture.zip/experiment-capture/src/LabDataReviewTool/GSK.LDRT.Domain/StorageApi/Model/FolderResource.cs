﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class FolderResource
    {
        public FolderResource(string folderName)
        {
            FolderName = folderName;
            SubFolders = new List<FolderResource>();
            Files = new List<FileResource>();
        }

        private FolderResource(string folderName, bool _)
        {
            FolderName = folderName;
        }

        public string FolderName { get; set; }

        public int? FilesCount
        {
            get { return Files?.Count; }
        }

        public int? SubFoldersCount
        {
            get { return SubFolders?.Count; }
        }

        public List<FileResource> Files { get; set; }

        public List<FolderResource> SubFolders { get; set; }

        public static FolderResource CreateEmptyFolder(string folderName)
        {
            return new FolderResource(folderName, true);
        }
    }
}

