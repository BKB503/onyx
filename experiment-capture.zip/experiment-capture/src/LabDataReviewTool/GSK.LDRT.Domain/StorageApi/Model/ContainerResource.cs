﻿namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class ContainerResource
    {
        public string ContainerName { get; set; }
        public StorageContainerConfiguration Configuration { get; set; }
        public Indexingconfiguration IndexingConfiguration { get; set; }
    }
}
