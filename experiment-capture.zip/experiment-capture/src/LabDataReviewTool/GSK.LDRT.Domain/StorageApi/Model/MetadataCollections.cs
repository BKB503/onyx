﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class MetadataCollections
    {
        [JsonPropertyName("MetaData")]
        public List<MetadataItem> Items { get; set; }
        public MetadataCollections()
        {

        }

        public MetadataCollections(MetadataDictionary inputDict)
        {
            List<MetadataItem> metadata = new List<MetadataItem>();
            MetadataItem metadataItem = null;

            foreach (var item in inputDict)
            {
                metadataItem = new MetadataItem
                {
                    Key = item.Key,
                    Value = item.Value,
                    IsIndexed = true
                };
                metadata.Add(metadataItem);
            }
            Items = metadata;
        }
    }

}

