﻿using System.Collections.Generic;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class MetadataDictionary : Dictionary<string, string>
    {
        public MetadataDictionary()
        {

        }

        public MetadataDictionary(IDictionary<string, string> inputDict)
        {
            foreach (var item in inputDict)
            {
                this[item.Key] = item.Value;
            }
        }
    }
}
