﻿namespace GSK.LDRT.Domain.StorageApi.Model
{
    public enum StorageContainerType
    {
        objectstorage = 0,
        azureblob = 1,
        azureadls = 2,
        googleblob = 3
    }
}
