﻿namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class ContainersResponse
    {
        public bool Succeeded { get; set; }
        public string[] Errors { get; set; }
        public string Message { get; set; }
        public string[] Data { get; set; }
        public string CurrentContinuationToken { get; set; }
        public int Limit { get; set; }
        public int RecordsReturned { get; set; }
        public string NextContinuationToken { get; set; }
        public bool MoreDataAvailable { get; set; }
    }
}