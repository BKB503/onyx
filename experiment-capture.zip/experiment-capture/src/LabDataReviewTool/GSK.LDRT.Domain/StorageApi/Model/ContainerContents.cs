﻿
using GSK.LDRT.Domain.StorageApi.Model.Wrapper;
using System.Collections.Generic;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class ContainerContents : BaseApiResponse, IPagedApiResponse
    {
        public ContainerContents(string containerName)
        {
            ContainerName = containerName;
        }

        public string ContainerName { get; set; }

        public string ParentFolder { get; set; }

        public IList<FolderResource> Folders { get; set; }

        public IList<FileResource> Files { get; set; }

        public int Limit { get; set; }
        public int RecordsReturned { get; set; }
        public string CurrentContinuationToken { get; set; }
        public string NextContinuationToken { get; set; }
        public bool? MoreDataAvailable { get; set; }

    }
}
