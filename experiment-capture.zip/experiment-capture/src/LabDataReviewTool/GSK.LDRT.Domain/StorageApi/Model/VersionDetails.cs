﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Domain.StorageApi.Model
{
    public class VersionDetails
    {
        /// <summary>
        /// File GUID
        /// </summary>
        public string FileGuid { get; set; }

        /// <summary>
        /// file version ID
        /// </summary>
        public string VersionID { get; set; }

        /// <summary>
        /// file size
        /// </summary>
        public long? FileSize { get; set; }

        /// <summary>
        /// file e-tag
        /// </summary>
        public string FileETag { get; set; }

        /// <summary>
        /// file hash value
        /// </summary>
        public string FileMD5 { get; set; }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTimeOffset? CreationTime { get; set; }

        /// <summary>
        /// True for the Latest version of the file and False otherwise
        /// </summary>
        public bool? IsLatestVersion { get; set; }

    }
}
