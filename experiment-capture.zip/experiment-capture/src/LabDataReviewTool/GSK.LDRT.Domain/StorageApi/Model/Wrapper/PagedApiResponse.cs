﻿namespace GSK.LDRT.Domain.StorageApi.Model.Wrapper
{
    public class PagedApiResponse<T> : ApiResponse<T>, IPagedApiResponse
    {
        /// <summary>
        /// current continuation token
        /// </summary>
        public string CurrentContinuationToken { get; set; }

        /// <summary>
        /// current limit
        /// </summary>
        public int Limit { get; set; }

        /// <summary>
        /// records returned
        /// </summary>
        public int RecordsReturned { get; set; }

        /// <summary>
        /// Next page continuation token - if Null then there is no more data available
        /// </summary>
        public string NextContinuationToken { get; set; }

        /// <summary>
        /// more data is available
        /// </summary>
        public bool? MoreDataAvailable { get; set; }


        public PagedApiResponse(T data, int recordsReturned, string continuationToken, string nextContinuationToken, int limit = 1000) : base(data)
        {
            CurrentContinuationToken = continuationToken;
            Limit = limit;
            RecordsReturned = recordsReturned;
            NextContinuationToken = nextContinuationToken;
            MoreDataAvailable = !string.IsNullOrEmpty(nextContinuationToken);
        }

        public PagedApiResponse(string errorMessage, string continuationToken, int limit = 1000)
        {
            Message = errorMessage;
            Data = default;
            MoreDataAvailable = false;
            CurrentContinuationToken = continuationToken;
            Limit = limit;
            RecordsReturned = 0;
        }
    }
}
