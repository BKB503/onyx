﻿

namespace GSK.LDRT.Domain.StorageApi.Model.Wrapper
{
    public class UploadFileResult
    {
        public UploadFileResult(FileResource fileResource, UploadFileResultStatus status, string Message = default)
        {
            FileInformation = fileResource;
            this.Message = Message;
            Status = status;
        }
        /// <summary>
        /// Error scenario : Consider as error message
        /// </summary>
        /// <param name="ErrorMessage"></param>
        public UploadFileResult(string ErrorMessage)
        {
            Message = ErrorMessage;
            FileInformation = null;
            Status = UploadFileResultStatus.Error;
        }
        public UploadFileResult()
        {

        }
        public UploadFileResultStatus Status { get; set; }
        public FileResource FileInformation { get; set; }
        public string Message { get; set; }
        public int StatusCode
        {
            get
            {
                return (int)Status;
            }
        }
    }
}
