﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.SnowflakeEntites
{
    public class RecordVersionEntity
    {
        [JsonProperty("RECORD_ID")]
        public string Id { get; set; }
        [JsonProperty("RECORD_TYPE")]
        public string Type { get; set; }
        [JsonProperty("RECORD_CREATED_BY")]
        public string CreatedBy { get; set; }
        [JsonProperty("RECORD_CREATED_TIMESTAMP")]
        public DateTime CreatedTimeStamp { get; set; }
        [JsonProperty("RECORD_NAME")]
        public string Name { get; set; }
        [JsonProperty("RECORD_STATUS")]
        public string Status { get; set; }
        [JsonProperty("ExperimentID")]
        public string ExperimentId { get; set; }

        [JsonProperty("RECORD_LAST_MODIFIED_BY")]
        public string ModifiedBy { get; set; }
        [JsonProperty("RECORD_LAST_MODIFIED_TIMESTAMP")]
        public DateTime ModifiedTimeStamp { get; set; }

    }
}
