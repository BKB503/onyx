﻿using Newtonsoft.Json;
using System;

namespace GSK.LDRT.Domain.SnowflakeEntites
{
    public class TaskEntity
    {
        [JsonProperty("TASK_ID")]
        public string TaskId { get; set; }
        [JsonProperty("TASK_NAME")]
        public string TaskName { get; set; }
        [JsonProperty("WORKFLOW_ID")]
        public string WorkflowId { get; set; }
        [JsonProperty("WORKFLOW_NAME")]
        public string WorkflowName { get; set; }

        [JsonProperty("DISPLAY_ID")]
        public string DisplayId { get; set; }
        [JsonProperty("TASK_STATUS")]
        public string TaskStatus { get; set; }
        [JsonProperty("TASK_TYPE")]
        public string TaskType { get; set; }
        [JsonProperty("ENTITY_ID")]
        public string EntityId { get; set; }
        [JsonProperty("RECORD_NAME")]
        public string EntityName { get; set; }
        [JsonProperty("ENTITY_PATH")]
        public string EntityPath { get; set; }
        [JsonProperty("REQUESTOR_NAME")]
        public string RequestorName { get; set; }
        [JsonProperty("WORKFLOW_PRIORITY")]
        public string WorkflowPriority { get; set; }
        [JsonProperty("WORKFLOW_STATUS")]
        public string WorkflowStatus { get; set; }
        [JsonProperty("ExperimentID")]
        public string ExperimentId { get; set; }
        [JsonProperty("DUE_DATE")]
        public DateTime DueDate { get; set; }
        [JsonProperty("SEND_DATE")]
        public DateTime SendDate { get; set; }
        [JsonProperty("REQUESTED_DATE")]
        public DateTime RequestedDate { get; set; }
    }
}
