﻿using Newtonsoft.Json;
using System;

namespace GSK.LDRT.Domain.SnowflakeEntites
{
    public class WorkFlowEntity
    {
        [JsonProperty("WORKFLOW_ID")]
        public string WorkflowId { get; set; }
        [JsonProperty("DISPLAY_ID")]
        public string DisplayId { get; set; }
        [JsonProperty("REQUESTOR_ID")]
        public string RequestorId { get; set; }
        [JsonProperty("REQUESTOR_NAME")]
        public string RequestorName { get; set; }
        [JsonProperty("REQUESTED_DATE")]
        public DateTime RequestedDate { get; set; }
        [JsonProperty("WORKFLOW_STATUS")]
        public string WorkflowStatus { get; set; }
        [JsonProperty("ENTITY_ID")]
        public string EntityId { get; set; }
        [JsonProperty("ENTITY_NAME")]
        public string EntityName { get; set; }
        [JsonProperty("ENTITY_PATH")]
        public string EntityPath { get; set; }
        [JsonProperty("TASK_PROCESS")]
        public string TaskProcess { get; set; }
        [JsonProperty("DUE_DATE")]
        public DateTime DueDate { get; set; }
        [JsonProperty("PRIORITY")]
        public string Priority { get; set; }
        [JsonProperty("NUMBER_OF_COMPLETED_TASKS")]
        public int NumberOfCompletedTasks { get; set; }
        [JsonProperty("TOTAL_NUMBER_OF_TASKS")]
        public int TotalNumberOfTasks { get; set; }
        [JsonProperty("ExperimentID")]
        public string ExperimentId { get; set; }
    }
}
