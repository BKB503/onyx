﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables
{
    public class PropValueImage
    {
        [JsonProperty("image")]
        public string Value { get; set; }
    }
}
