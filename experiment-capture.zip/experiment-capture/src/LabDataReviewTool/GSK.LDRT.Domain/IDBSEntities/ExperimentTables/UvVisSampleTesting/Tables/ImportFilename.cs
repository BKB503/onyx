﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class ImportFilename
    {

        [JsonProperty("Exclude Data from File?")]
        public PropValueString ExcludeDataFromFile { get; set; }

        [JsonProperty("Import Filename")]
        public PropValueString ImportFileName { get; set; }
    }
}