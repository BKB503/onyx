﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class AcceptanceCriteria
    {

        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("System Suitabiliity Filter Idx")]
        public PropValueString SystemSuitabiliityFilterIdx { get; set; }

        [JsonProperty("Max/Min")]
        public PropValueString MaxMin { get; set; }

        [JsonProperty("% RSD")]
        public PropValueStringAndNumber PercentageRSD { get; set; }

        [JsonProperty("A560")]
        public PropValueStringAndNumber A560 { get; set; }

        [JsonProperty("R ²")]
        public PropValueStringAndNumber StandardMinR { get; set; }

        [JsonProperty("% Residue")]
        public PropValueStringAndNumber PercentageResidue { get; set; }

    }
}