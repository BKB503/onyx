﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMSampleFinalSummary
    {
        [JsonProperty("sample summary data")]
        public PropValueString Data { get; set; }

        [JsonProperty("uom")]
        public PropValueString Uom { get; set; }

    }
}