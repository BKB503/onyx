﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class SampleMetadata
    {

        [JsonProperty("Dash Sample Idx")]
        public PropValueString DashSampleIdx { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }

        [JsonProperty("Experiment Name")]
        public PropValueString ExperimentName { get; set; }

        [JsonProperty("Experiment Path")]
        public PropValueString ExperimentPath { get; set; }

        [JsonProperty("Parent Material ID")]
        public PropValueString ParentMaterialId { get; set; }
        [JsonProperty("Parent Material Name")]
        public PropValueString ParentMaterialName { get; set; }


    }
}