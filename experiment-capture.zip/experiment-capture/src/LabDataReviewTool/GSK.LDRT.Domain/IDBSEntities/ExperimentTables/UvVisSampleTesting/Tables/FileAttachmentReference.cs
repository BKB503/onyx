﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class FileAttachmentReference
    {

        [JsonProperty("Attachment Index")]
        public PropValueString AttachmentIndex { get; set; }

        [JsonProperty("Attachment Link")]
        public PropValueString AttachmentLink { get; set; }

        [JsonProperty("Attachment Description")]
        public PropValueString AttachmentDescription { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }

    }
}