﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class RunSetup
    {

        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Run Date")]
        public PropValueDate RunDate { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

    }
}