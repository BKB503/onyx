﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class ConclusionTable
    {
        [JsonProperty("Conclusion")]
        public PropValueString Conclusion { get; set; }

    }
}