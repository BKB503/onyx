﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class ControlResults
    {
        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Method Type")]
        public PropValueString MethodType { get; set; }

        [JsonProperty("Control Name")]
        public PropValueString ControlName { get; set; }

        [JsonProperty("Control ID")]
        public PropValueString ControlId { get; set; }

        [JsonProperty("Sub Aliquot ID")]
        public PropValueString SubAliquotId { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Expected Concentration")]
        public PropValueStringAndNumber ExpectedConcentration { get; set; }

        [JsonProperty("Concentration")]
        public PropValueStringAndNumber Concentration { get; set; }

        [JsonProperty("Average Concentration")]
        public PropValueStringAndNumber AverageConcentration { get; set; }


        [JsonProperty("% RSD")]
        public PropValueStringAndNumber PercentageRSD { get; set; }

        [JsonProperty("R²")]
        public PropValueStringAndNumber StandardMinR { get; set; }

        [JsonProperty("% Recovery")]
        public PropValueStringAndNumber PercentageRecovery { get; set; }

        [JsonProperty("Suitability Results")]
        public PropValueString SuitabilityResults { get; set; }

        [JsonProperty("Suitability Results Override")]
        public PropValueString SuitabilityResultsOverride { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("Row Show")]
        public PropValueStringAndNumber RowShow { get; set; }

    }
}