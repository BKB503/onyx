﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class CompoundsAndProjects
    {
        [JsonProperty("Compounds and Projects Id")]
        public PropValueString CompoundsAndProjectsId { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Project")]
        public PropValueString Project { get; set; }

        [JsonProperty("Project ID")]
        public PropValueString ProjectId { get; set; }

        [JsonProperty("Project ID Override")]
        public PropValueString ProjectIdOverride { get; set; }

        [JsonProperty("Extinction Coefficient")]
        public PropValueString ExtinctionCoefficient { get; set; }

        [JsonProperty("Extinction Coefficient Override")]
        public PropValueString ExtinctionCoefficientOverride { get; set; }


    }
}