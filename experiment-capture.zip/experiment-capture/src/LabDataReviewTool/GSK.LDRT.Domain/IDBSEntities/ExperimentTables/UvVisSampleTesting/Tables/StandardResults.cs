﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class StandardResults
    {
        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Method Type")]
        public PropValueString MethodType { get; set; }

        [JsonProperty("Wavelength")]
        public PropValueString WaveLength { get; set; }

        [JsonProperty("Standard Name")]
        public PropValueString ControlName { get; set; }

        [JsonProperty("Standard ID")]
        public PropValueString ControlId { get; set; }

        [JsonProperty("Sub Aliquot ID")]
        public PropValueString SubAliquotId { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Certified Absorbance")]
        public PropValueStringAndNumber CertifiedAbsorbance { get; set; }

        [JsonProperty("Suitability Criteria for Absorbance")]
        public PropValueString SuitabilityCriteriaForAbsorbance { get; set; }

        [JsonProperty("Measured Absorbance")]
        public PropValueStringAndNumber MeasuredAbsorbance { get; set; }


        [JsonProperty("Average Slope")]
        public PropValueStringAndNumber AverageSlope { get; set; }

        [JsonProperty("R²")]
        public PropValueStringAndNumber StandardMinR { get; set; }

        [JsonProperty("% RSD")]
        public PropValueStringAndNumber PercentageRSD { get; set; }

        [JsonProperty("Suitability Results")]
        public PropValueString SuitabilityResults { get; set; }

        [JsonProperty("Suitability Results Override")]
        public PropValueString SuitabilityResultsOverride { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("Row Show")]
        public PropValueStringAndNumber RowShow { get; set; }

    }
}