﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class EquipmentDetails
    {
        [JsonProperty("Entry Mode")]
        public PropValueString EntryMode { get; set; }

        [JsonProperty("Equipment Index")]
        public PropValueString EquipmentIndex { get; set; }

        [JsonProperty("Equipment ID")]
        public PropValueString EquipmentId { get; set; }

        [JsonProperty("Equipment Name")]
        public PropValueString EquipmentName { get; set; }

        [JsonProperty("Equipment Type")]
        public PropValueString EquipmentType { get; set; }

        [JsonProperty("Serial Number")]
        public PropValueString SerialNumber { get; set; }

        [JsonProperty("Vendor/Supplier")]
        public PropValueString VendorSupplier { get; set; }

        [JsonProperty("Calibration Status")]
        public PropValueString CalibrationStatus { get; set; }

        [JsonProperty("Calibration Due Date")]
        public PropValueDate CalibrationDueDate { get; set; }

        [JsonProperty("Location")]
        public PropValueString Location { get; set; }

        [JsonProperty("Inventory Link")]
        public PropValueHyperLink InventoryLink { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }
        [JsonProperty("Row Show")]
        public PropValueString RowShowString { get; set; }
    }
}