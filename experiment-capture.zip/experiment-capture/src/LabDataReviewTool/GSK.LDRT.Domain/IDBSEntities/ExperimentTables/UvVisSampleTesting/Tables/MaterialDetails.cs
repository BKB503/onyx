﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class MaterialDetails
    {
        [JsonProperty("Material Index")]
        public PropValueString MaterialIndex { get; set; }

        [JsonProperty("Entry Mode")]
        public PropValueString EntryMode { get; set; }

        [JsonProperty("Material ID")]
        public PropValueString MaterialId { get; set; }

        [JsonProperty("Material Name")]
        public PropValueString MaterialName { get; set; }

        [JsonProperty("Material Type")]
        public PropValueString MaterialType { get; set; }

        [JsonProperty("Catalog Number")]
        public PropValueString CatalogNumber { get; set; }

        [JsonProperty("Lot Number")]
        public PropValueString LotNumber { get; set; }

        [JsonProperty("Vendor/Supplier")]
        public PropValueString VendorSupplier { get; set; }

        [JsonProperty("Solid/ Liquid")]
        public PropValueString SolidLiquid { get; set; }

        [JsonProperty("Concentration")]
        public PropValueString Concentration { get; set; }

        [JsonProperty("Concentration Unit")]
        public PropValueString ConcentrationUnit { get; set; }

        [JsonProperty("Molecular Weight")]
        public PropValueStringAndNumber MolecularWeight { get; set; }

        [JsonProperty("Safety Information")]
        public PropValueString SafetyInformation { get; set; }

        [JsonProperty("Expiry Date")]
        public PropValueDate ExpiryDate { get; set; }

        [JsonProperty("Category")]
        public PropValueString Category { get; set; }

        [JsonProperty("Inventory Link")]
        public PropValueHyperLink InventoryLink { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("Dilution Required?")]
        public PropValueString DilutionRequired { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }

        [JsonProperty("Row Show")]
        public PropValueString RowShowString { get; set; }
    }
}