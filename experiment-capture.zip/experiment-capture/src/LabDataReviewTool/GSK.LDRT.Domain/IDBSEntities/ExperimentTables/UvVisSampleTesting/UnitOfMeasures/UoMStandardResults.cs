﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMStandardResults
    {
        [JsonProperty("std results data")]
        public PropValueString Data { get; set; }

        [JsonProperty("uom")]
        public PropValueString UoM { get; set; }
    }
}