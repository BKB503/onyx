﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class SampleDetails
    {
        [JsonProperty("Sample Index")]
        public PropValueString SampleIndex { get; set; }

        [JsonProperty("Sample Entry Mode")]
        public PropValueString SampleEntryMode { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleID { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Batch/Lot Number")]
        public PropValueString BatchOrLotNumber { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Concentration")]
        public PropValueStringAndNumber Concentration { get; set; }

        [JsonProperty("Concentration Override")]
        public PropValueStringAndNumber ConcentrationOverride { get; set; }

        [JsonProperty("Concentration Unit")]
        public PropValueString ConcentrationUnit { get; set; }

        [JsonProperty("Concentrion Unit Override")]
        public PropValueString ConcentrionUnitOverride { get; set; }

        [JsonProperty("Dilution Required?")]
        public PropValueString DilutionRequired { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }

        [JsonProperty("Row Show")]
        public PropValueStringAndNumber RowShowNumber { get; set; }

    }
}