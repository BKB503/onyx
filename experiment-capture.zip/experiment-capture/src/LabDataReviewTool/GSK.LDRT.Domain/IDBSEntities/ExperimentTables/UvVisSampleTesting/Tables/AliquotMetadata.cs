﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class AliquotMetadata
    {

        [JsonProperty("Dash Aliquot Idx")]
        public PropValueString DashAliquotIdx { get; set; }

        [JsonProperty("Aliquot ID")]
        public PropValueString AliquotId { get; set; }

        [JsonProperty("Aliquot Name")]
        public PropValueString AliquotName { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Aliquot Concentration")]
        public PropValueNumber AliquotConcentration { get; set; }

        [JsonProperty("Aliquot Concentration Unit")]
        public PropValueString AliquotConcentrationUnit { get; set; }

        [JsonProperty("Aliquot Volume")]
        public PropValueNumber AliquotVolume { get; set; }

        [JsonProperty("Aliquot Volume Unit")]
        public PropValueString AliquotVolumeUnit { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }


    }
}