﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class SampleSummary
    {

        [JsonProperty("Sample Summary Idx")]
        public PropValueString SampleSummaryIdx { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Project")]
        public PropValueString Project { get; set; }

        [JsonProperty("Study Name")]
        public PropValueString StudyName { get; set; }

        [JsonProperty("Project ID")]
        public PropValueString ProjectId { get; set; }

        [JsonProperty("Extinction Coefficient")]
        public PropValueStringAndNumber ExtinctionCoefficient { get; set; }

        [JsonProperty("Concentration")]
        public PropValueStringAndNumber Concentration { get; set; }

        [JsonProperty("Concentration Override")]
        public PropValueString ConcentrationOverride { get; set; }

        [JsonProperty("Concentration  Unit")]
        public PropValueString ConcentrationUnit { get; set; }


        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }



    }
}