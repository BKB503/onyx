﻿using Newtonsoft.Json;


namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class JsonFilterTable
    {
        [JsonProperty("Table Name")]
        public PropValueString TableName { get; set; }

        [JsonProperty("h Filter Identifier")]
        public PropValueString FilterIdentifier { get; set; }

        [JsonProperty("Filter Values")]
        public PropValueStringAndNumber FilterValues { get; set; }
    }
}
