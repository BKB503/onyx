﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class AssayData
    {
        [JsonProperty("Study Name")]
        public PropValueString StudyName { get; set; }

        [JsonProperty("Method Name")]
        public PropValueString MethodName { get; set; }

        [JsonProperty("Method ID")]
        public PropValueString MethodId { get; set; }

        [JsonProperty("Method Version")]
        public PropValueString MethodVersion { get; set; }

        [JsonProperty("Method Description")]
        public PropValueString MethodDescription { get; set; }

        [JsonProperty("Analysis Technique")]
        public PropValueString AnalysisTechnique { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }
    }

}