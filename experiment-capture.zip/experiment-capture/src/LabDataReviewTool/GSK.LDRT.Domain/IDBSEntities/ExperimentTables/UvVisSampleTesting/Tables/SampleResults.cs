﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class SampleResults
    {
        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Sample Result Idx")]
        public PropValueString SampleResultIdx { get; set; }

        [JsonProperty("Rep Index")]
        public PropValueString RepIndex { get; set; }

        [JsonProperty("Method Type")]
        public PropValueString MethodType { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }


        [JsonProperty("Sub Aliquot ID")]
        public PropValueString SubAliquotId { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Expected Concentration")]
        public PropValueStringAndNumber ExpectedConcentration { get; set; }

        [JsonProperty("Concentration")]
        public PropValueStringAndNumber Concentration { get; set; }

        [JsonProperty("Average Concentration")]
        public PropValueStringAndNumber AverageConcentration { get; set; }


        [JsonProperty("% Residue")]
        public PropValueStringAndNumber PercentageResidue { get; set; }

        [JsonProperty("R²")]
        public PropValueStringAndNumber StandardMinR { get; set; }

        [JsonProperty("% RSD")]
        public PropValueStringAndNumber PercentageRSD { get; set; }

        [JsonProperty("A560")]
        public PropValueStringAndNumber A560 { get; set; }

        [JsonProperty("Suitability Results")]
        public PropValueString SuitabilityResults { get; set; }

        [JsonProperty("Suitability Results Override")]
        public PropValueString SuitabilityResultsOverride { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("Row Show")]
        public PropValueStringAndNumber RowShow { get; set; }

    }
}