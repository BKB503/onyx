﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class ExperimentInformation
    {
        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }

        [JsonProperty("Experiment Title")]
        public PropValueString ExperimentTitle { get; set; }

        [JsonProperty("Experiment Title Suffix")]
        public PropValueString ExperimentTitleSuffix { get; set; }

        [JsonProperty("Created By")]
        public PropValueString CreatedBy { get; set; }

        [JsonProperty("Experiment Date")]
        public PropValueDate ExperimentDate { get; set; }

    }
}