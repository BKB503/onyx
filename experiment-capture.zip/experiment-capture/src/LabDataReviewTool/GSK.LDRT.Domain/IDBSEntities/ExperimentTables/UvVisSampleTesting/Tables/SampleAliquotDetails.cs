﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class SampleAliquotDetails
    {
        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Rep Index")]
        public PropValueString RepIndex { get; set; }

        [JsonProperty("Sub Aliquot ID")]
        public PropValueString SubAliquotID { get; set; }

        [JsonProperty("Number of Replicates")]
        public PropValueStringAndNumber NumberOfReplicates { get; set; }

        [JsonProperty("Replicate Name")]
        public PropValueString ReplicateName { get; set; }

        [JsonProperty("Concentration")]
        public PropValueNumber Concentration { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Plate ID")]
        public PropValueString PlateId { get; set; }

        [JsonProperty("Well Position")]
        public PropValueString WellPosition { get; set; }

        [JsonProperty("Well Position Override")]
        public PropValueString WellPositionOverride { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }

    }
}