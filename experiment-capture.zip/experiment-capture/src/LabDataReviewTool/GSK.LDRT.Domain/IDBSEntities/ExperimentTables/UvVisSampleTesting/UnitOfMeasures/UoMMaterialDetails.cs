﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMMaterialDetails
    {
        [JsonProperty("materials data")]
        public PropValueString MaterialsData { get; set; }

        [JsonProperty("uom")]
        public PropValueString UoM { get; set; }
    }
}