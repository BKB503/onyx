﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class StandardSetup
    {

        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Number of Rows")]
        public PropValueStringAndNumber NumberofRows { get; set; }

        [JsonProperty("Concentration Unit")]
        public PropValueString ConcentrationUnit { get; set; }

    }
}