﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class MaterialAndReagentDilution
    {
        [JsonProperty("Dilutions List")]
        public PropValueString DilutionsList { get; set; }

        [JsonProperty("Dilution Index")]
        public PropValueString DilutionIndex { get; set; }

        [JsonProperty("Reagent Component Index")]
        public PropValueString ReagentComponentIndex { get; set; }

        [JsonProperty("Solution Name")]
        public PropValueString SolutionName { get; set; }

        [JsonProperty("Name of Component")]
        public PropValueString NameofComponent { get; set; }

        [JsonProperty("Initial Concentration")]
        public PropValueNumber InitialConcentration { get; set; }

        [JsonProperty("Initial Concentration  Unit")]
        public PropValueString InitialConcentrationUnit { get; set; }

        [JsonProperty("Diluent Name")]
        public PropValueString DiluentName { get; set; }

        [JsonProperty("Total Volume")]
        public PropValueNumber TotalVolume { get; set; }

        [JsonProperty("Total Volume Unit")]
        public PropValueString TotalVolumeUnit { get; set; }

        [JsonProperty("Final Concentration")]
        public PropValueStringAndNumber TargetFinalConcentration { get; set; }

        [JsonProperty("Final Concentration Unit")]
        public PropValueStringAndNumber TargetFinalConcentrationUnit { get; set; }

        [JsonProperty("Concentration Unit Override")]
        public PropValueStringAndNumber TargetConcentrationUnitOverride { get; set; }

        [JsonProperty("Stock Volume")]
        public PropValueStringAndNumber TargetStockVolume { get; set; }

        [JsonProperty("Stock Volume Unit")]
        public PropValueString TargetStockVolumeUnit { get; set; }

        [JsonProperty("Diluent Volume")]
        public PropValueStringAndNumber TargetDiluentVolume { get; set; }

        [JsonProperty("Diluent Volume Unit")]
        public PropValueString TargetDiluentVolumeUnit { get; set; }

        [JsonProperty("Stock  Volume")]
        public PropValueStringAndNumber ActualStockVolume { get; set; }

        [JsonProperty("Stock Volume  Unit")]
        public PropValueString ActualStockVolumeUnit { get; set; }

        [JsonProperty("Diluent  Volume")]
        public PropValueStringAndNumber ActualDiluentVolume { get; set; }

        [JsonProperty("Diluent  Volume Unit")]
        public PropValueString ActualDiluentVolumeUnit { get; set; }

        [JsonProperty("Final  Concentration")]
        public PropValueStringAndNumber ActualFinalConcentration { get; set; }

        [JsonProperty("Final Concentration Override")]
        public PropValueStringAndNumber ActualFinalConcentrationOverride { get; set; }

        [JsonProperty("Concentration  Unit")]
        public PropValueStringAndNumber ActualConcentrationUnit { get; set; }

        [JsonProperty("Further Dilution Required?")]
        public PropValueString FurtherDilutionRequired { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }

        [JsonProperty("Row Show")]
        public PropValueString RowShowString { get; set; }
    }
}