﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMCompoundsAndProjects
    {
        [JsonProperty("Compounds and Projects Data")]
        public PropValueString CompoundsandProjectsData { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}