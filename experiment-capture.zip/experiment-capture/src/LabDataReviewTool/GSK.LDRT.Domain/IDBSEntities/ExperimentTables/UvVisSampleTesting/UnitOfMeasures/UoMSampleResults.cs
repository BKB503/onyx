﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMSampleResults
    {
        [JsonProperty("sample results data")]
        public PropValueString Data { get; set; }

        [JsonProperty("uom")]
        public PropValueString Uom { get; set; }
    }
}