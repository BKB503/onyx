﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class ImageUploadTable
    {

        [JsonProperty("Image Index")]
        public PropValueString ImageIndex { get; set; }

        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Image")]
        public PropValueImage Image { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }

        [JsonProperty("Row Show")]
        public PropValueStringAndNumber RowShowWithSpace { get; set; }

    }
}