﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class StandardCurveDetails
    {

        [JsonProperty("Std#")]
        public PropValueString Std { get; set; }

        [JsonProperty("Standard Concentration")]
        public PropValueStringAndNumber StandardConcentration { get; set; }

        [JsonProperty("Standard Concentration Unit")]
        public PropValueString StandardConcentrationUnit { get; set; }

        [JsonProperty("h Standard row filter")]
        public PropValueStringAndNumber HStandardRowFilter { get; set; }

    }
}