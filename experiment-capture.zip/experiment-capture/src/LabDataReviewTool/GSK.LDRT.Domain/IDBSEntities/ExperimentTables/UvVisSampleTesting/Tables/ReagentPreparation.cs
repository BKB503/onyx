﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class ReagentPreparation
    {
        [JsonProperty("Reagent Index")]
        public PropValueString ReagentIndex { get; set; }

        [JsonProperty("Reagent Component Index")]
        public PropValueString ReagentComponentIndex { get; set; }

        [JsonProperty("IDBS Sample ID")]
        public PropValueString IDBSSampleID { get; set; }

        [JsonProperty("Solution Name")]
        public PropValueString SolutionName { get; set; }

        [JsonProperty("Reagent Type")]
        public PropValueString ReagentType { get; set; }

        [JsonProperty("Concentration Unit")]
        public PropValueString ConcentrationUnit { get; set; }

        [JsonProperty("Number of Components")]
        public PropValueNumber NumberofComponents { get; set; }

        [JsonProperty("Name of Component")]
        public PropValueString NameofComponent { get; set; }

        [JsonProperty("Amount")]
        public PropValueNumber Amount { get; set; }

        [JsonProperty("Amount Unit")]
        public PropValueString AmountUnit { get; set; }

        [JsonProperty("Molecular Weight")]
        public PropValueNumber MolecularWeight { get; set; }

        [JsonProperty("Diluent Name")]
        public PropValueString DiluentName { get; set; }

        [JsonProperty("Diluent Volume")]
        public PropValueNumber DiluentVolume { get; set; }

        [JsonProperty("Total Volume")]
        public PropValueNumber TotalVolume { get; set; }

        [JsonProperty("Concentration")]
        public PropValueNumber Concentration { get; set; }

        [JsonProperty("Initial Concentration  Unit")]
        public PropValueString InitialConcentrationUnit { get; set; }

        [JsonProperty("Dilution Required?")]
        public PropValueString DilutionRequired { get; set; }

        [JsonProperty("Initial pH")]
        public PropValueNumber InitialpH { get; set; }

        [JsonProperty("Final pH")]
        public PropValueNumber FinalpH { get; set; }

        [JsonProperty("pH Adjustment Substance")]
        public PropValueString pHAdjustmentSubstance { get; set; }

        [JsonProperty("Category")]
        public PropValueString Category { get; set; }

        [JsonProperty("Preparation Date")]
        public PropValueDate PreparationDate { get; set; }

        [JsonProperty("Expiry Date")]
        public PropValueDate ExpiryDate { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("RowShow")]
        public PropValueStringAndNumber RowShow { get; set; }

        [JsonProperty("Row Show")]
        public PropValueString RowShowString { get; set; }

    }
}