﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMSampleAliquotDetails
    {
        [JsonProperty("Aliquot Data")]
        public PropValueString AliquotData { get; set; }

        [JsonProperty("Sample Aliquots UoM")]
        public PropValueString SampleAliquotsUoM { get; set; }
    }
}