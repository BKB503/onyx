﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMControlResults
    {
        [JsonProperty("ctrl data")]
        public PropValueString Data { get; set; }

        [JsonProperty("uom")]
        public PropValueString UoM { get; set; }
    }
}
