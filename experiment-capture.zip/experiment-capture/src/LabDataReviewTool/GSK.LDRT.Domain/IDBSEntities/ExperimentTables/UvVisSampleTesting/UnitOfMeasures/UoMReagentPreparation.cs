﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.UnitOfMeasures
{
    public class UoMReagentPreparation
    {
        [JsonProperty("reagent data")]
        public PropValueString ReagentData { get; set; }

        [JsonProperty("reagent preparation uom")]
        public PropValueString UoM { get; set; }
    }
}