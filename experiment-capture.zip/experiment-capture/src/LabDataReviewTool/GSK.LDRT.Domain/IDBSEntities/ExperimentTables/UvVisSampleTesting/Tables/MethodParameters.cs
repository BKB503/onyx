﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class MethodParameters
    {
        [JsonProperty("Parameters Group")]
        public PropValueString ParametersGroup { get; set; }

        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Parameter#")]
        public PropValueString Parameter { get; set; }

        [JsonProperty("Method")]
        public PropValueString Method { get; set; }

        [JsonProperty("Parameter Name")]
        public PropValueString ParameterName { get; set; }

        [JsonProperty("Parameter Value")]
        public PropValueString ParameterValue { get; set; }

        [JsonProperty("Parameter Value Override")]
        public PropValueString ParameterValueOverride { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        //[JsonProperty("RowShow")]
        //public PropValueStringAndNumber RowShow { get; set; }

    }
}