﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables
{
    public class SystemSuitability
    {

        [JsonProperty("Run Number")]
        public PropValueString RunNumber { get; set; }

        [JsonProperty("Max/Min")]
        public PropValueString MaxMin { get; set; }

        [JsonProperty("System type")]
        public PropValueString SystemType { get; set; }

        [JsonProperty("Sutability Filter Helper")]
        public PropValueString SutabilityFilterHelper { get; set; }

        [JsonProperty("% T")]
        public PropValueStringAndNumber PercentageT { get; set; }

        [JsonProperty("System Suitability Result")]
        public PropValueString SystemSuitabilityResult { get; set; }

        [JsonProperty("R²")]
        public PropValueStringAndNumber StandardMinR { get; set; }

        [JsonProperty("Tolerance for Absorbance (+/-)")]
        public PropValueStringAndNumber ToleranceForAbsorbance { get; set; }

        [JsonProperty("% Recovery")]
        public PropValueStringAndNumber PercentageRecovery { get; set; }

    }
}