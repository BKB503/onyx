﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class OctetorHPLCDataEntry
    {
        [JsonProperty("Input Method")]
        public PropValueString InputMethod { get; set; }

        [JsonProperty("HPLC Aliquot Index")]
        public PropValueString HPLCAliquotIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Instrument Sample ID Override")]
        public PropValueString InstrumentSampleIdOverride { get; set; }

        [JsonProperty("Measurement Equipment")]
        public PropValueString MeasurementEquipment { get; set; }

        [JsonProperty("Measurement Date")]
        public PropValueString MeasurementDate { get; set; }

        [JsonProperty("Titre")]
        public PropValueStringAndNumber Titre { get; set; }

        [JsonProperty("Ignore?")]
        public PropValueString Ignore { get; set; }


    }

    public class UoMOctetorHPLCDataEntry
    {
        [JsonProperty("HPLC Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
