﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class Setpoints
    {
        [JsonProperty("Setpoint Idx")]
        public PropValueString SetpointIdx { get; set; }

        [JsonProperty("Setpoint Name")]
        public PropValueString SetpointName { get; set; }

        [JsonProperty("pH Setpoint 1")]
        public PropValueStringAndNumber pHSetpoint1 { get; set; }

        [JsonProperty("Lower pH Deadband Setpoint 1")]
        public PropValueStringAndNumber LowerpHDeadbandSetpoint1 { get; set; }

        [JsonProperty("Upper pH Deadband Setpoint 1")]
        public PropValueStringAndNumber UpperpHDeadbandSetpoint1 { get; set; }

        [JsonProperty("pH Setpoint 2")]
        public PropValueStringAndNumber pHSetpoint2 { get; set; }

        [JsonProperty("Lower pH Deadband Setpoint 2")]
        public PropValueStringAndNumber LowerpHDeadbandSetpoint2 { get; set; }

        [JsonProperty("Upper pH Deadband Setpoint 2")]
        public PropValueStringAndNumber UpperpHDeadbandSetpoint2 { get; set; }

        [JsonProperty("pH Setpoint Change Day")]
        public PropValueStringAndNumber pHSetpointChangeDay { get; set; }

        [JsonProperty("Cell Specific Perfusion Rate")]
        public PropValueStringAndNumber CellSpecificPerfusionRate { get; set; }

        [JsonProperty("Dissolved Oxygen Setpoint")]
        public PropValueStringAndNumber DissolvedOxygenSetpoint { get; set; }

        [JsonProperty("Agitation Setpoint 1")]
        public PropValueStringAndNumber AgitationSetpoint1 { get; set; }

        [JsonProperty("Agitation Setpoint 2")]
        public PropValueStringAndNumber AgitationSetpoint2 { get; set; }

        [JsonProperty("Agitation Setpoint Change Day")]
        public PropValueStringAndNumber AgitationSetpointChangeDay { get; set; }

        [JsonProperty("Temperature Setpoint 1")]
        public PropValueStringAndNumber TemperatureSetpoint1 { get; set; }

        [JsonProperty("Temperature Setpoint 2")]
        public PropValueStringAndNumber TemperatureSetpoint2 { get; set; }

        [JsonProperty("Temperature Setpoint Change Day")]
        public PropValueStringAndNumber TemperatureSetpointChangeDay { get; set; }

        [JsonProperty("CO2 Setpoint")]
        public PropValueStringAndNumber CO2Setpoint { get; set; }

        [JsonProperty("Headspace Gas")]
        public PropValueString HeadspaceGas { get; set; }

        [JsonProperty("Headspace Flowrate")]
        public PropValueStringAndNumber HeadspaceFlowrate { get; set; }

        [JsonProperty("Impeller Config")]
        public PropValueString ImpellerConfig { get; set; }

        [JsonProperty("Max O2 Comp")]
        public PropValueStringAndNumber MaxO2Comp { get; set; }

        [JsonProperty("Sparger 1 Config")]
        public PropValueString Sparger1Config { get; set; }

        [JsonProperty("Sparger 1 Gases")]
        public PropValueString Sparger1Gases { get; set; }

        [JsonProperty("Sparger 2 Config")]
        public PropValueString Sparger2Config { get; set; }

        [JsonProperty("Sparger 2 Gases")]
        public PropValueString Sparger2Gases { get; set; }

        [JsonProperty("Cycle Rate")]
        public PropValueStringAndNumber CycleRate { get; set; }

        [JsonProperty("Perfusion Media 1")]
        public PropValueString PerfusionMedia1 { get; set; }

        [JsonProperty("Perfusion Media 2")]
        public PropValueString PerfusionMedia2 { get; set; }

        [JsonProperty("Perfusion Media 3")]
        public PropValueString PerfusionMedia3 { get; set; }
    }

    public class UoMSetpoints
    {
        [JsonProperty("Setpoints Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
