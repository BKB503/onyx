﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class PooledCultureDetails
    {
        [JsonProperty("Pooled Culture Idx")]
        public PropValueString PooledCultureIdx { get; set; }

        [JsonProperty("Pool Material 1")]
        public PropValueString PoolMaterial1 { get; set; }

        [JsonProperty("Pool Material 1 Volume")]
        public PropValueStringAndNumber PoolMaterial1Volume { get; set; }

        [JsonProperty("Pool Material 2")]
        public PropValueString PoolMaterial2 { get; set; }

        [JsonProperty("Pool Material 2 Volume")]
        public PropValueStringAndNumber PoolMaterial2Volume { get; set; }

        [JsonProperty("Pool Material 3")]
        public PropValueString PoolMaterial3 { get; set; }

        [JsonProperty("Pool Material 3 Volume")]
        public PropValueStringAndNumber PoolMaterial3Volume { get; set; }

        [JsonProperty("Pool Material 4")]
        public PropValueString PoolMaterial4 { get; set; }

        [JsonProperty("Pool Material 4 Volume")]
        public PropValueStringAndNumber PoolMaterial4Volume { get; set; }

        [JsonProperty("Pool Material Volume Unit")]
        public PropValueString PoolMaterialVolumeUnit { get; set; }

        [JsonProperty("Pooled Culture Name")]
        public PropValueString PooledCultureName { get; set; }

        [JsonProperty("Pooled Culture ID")]
        public PropValueString PooledCultureId { get; set; }

        [JsonProperty("Batch ID")]
        public PropValueString BatchId { get; set; }

        [JsonProperty("Pool Volume")]
        public PropValueStringAndNumber PoolVolume { get; set; }

        [JsonProperty("Pool Volume Unit")]
        public PropValueString PoolVolumeUnit { get; set; }


        [JsonProperty("FinalViableCellDensity")]
        public PropValueStringAndNumber FinalViableCellDensity { get; set; }

        [JsonProperty("Final Viability")]
        public PropValueStringAndNumber FinalViability { get; set; }

        [JsonProperty("Titre")]
        public PropValueStringAndNumber Titre { get; set; }

        [JsonProperty("Storage Location ID")]
        public PropValueString StorageLocationId { get; set; }

        [JsonProperty("Culture Print Name")]
        public PropValueString CulturePrintName { get; set; }

        [JsonProperty("Vessel ID")]
        public PropValueString VesselId { get; set; }

        [JsonProperty("Passage Number")]
        public PropValueString PassageNumber { get; set; }

        [JsonProperty("Generation Number")]
        public PropValueString GenerationNumber { get; set; }
    }

    public class UoMPooledCultureDetails
    {
        [JsonProperty("Pooled Culture Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
