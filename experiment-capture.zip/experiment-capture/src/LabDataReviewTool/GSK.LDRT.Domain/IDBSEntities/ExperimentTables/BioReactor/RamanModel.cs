﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class RamanModel
    {
        [JsonProperty("Model Index")]
        public PropValueString ModelIndex { get; set; }

        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Model ID")]
        public PropValueString ModelId { get; set; }

        [JsonProperty("Model Reference")]
        public PropValueString ModelReference { get; set; }

        [JsonProperty("Model Start Date")]
        public PropValueDate ModelStartDate { get; set; }
    }


}
