﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class BioMaterialDetails
    {
        [JsonProperty("Material Idx")]
        public PropValueString MaterialIdx { get; set; }

        [JsonProperty("Material ID")]
        public PropValueString MaterialId { get; set; }

        [JsonProperty("Record Name")]
        public PropValueString RecordName { get; set; }

        [JsonProperty("Item Name")]
        public PropValueString ItemName { get; set; }

        [JsonProperty("Lot Number")]
        public PropValueString LotNumber { get; set; }

        [JsonProperty("Composition")]
        public PropValueString Composition { get; set; }

        [JsonProperty("Expiration Date")]
        public PropValueDate ExpirationDate { get; set; }

        [JsonProperty("Material Type")]
        public PropValueString MaterialType { get; set; }

        [JsonProperty("Material Location")]
        public PropValueString MaterialLocation { get; set; }

        [JsonProperty("Preparation Link")]
        public PropValueHyperLink PreparationLink { get; set; }
    }
}
