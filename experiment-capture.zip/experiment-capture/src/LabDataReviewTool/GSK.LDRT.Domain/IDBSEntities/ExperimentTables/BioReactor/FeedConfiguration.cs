﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class FeedConfigurationDetails
    {
        [JsonProperty("Feed Configuration")]
        public PropValueString FeedConfiguration { get; set; }

        [JsonProperty("Row Index")]
        public PropValueString RowIndex { get; set; }

        [JsonProperty("Day_Index")]
        public PropValueString DayIndex { get; set; }

        [JsonProperty("Feed Number")]
        public PropValueString FeedNumber { get; set; }

        [JsonProperty("Feed Addition Setpoint")]
        public PropValueString FeedAdditionSetpoint { get; set; }

        [JsonProperty("Feed Addition Setpoint Unit")]
        public PropValueString FeedAdditionSetpointUnit { get; set; }

        [JsonProperty("Feed Input Type")]
        public PropValueString FeedInputType { get; set; }

        [JsonProperty("h Feed Filter")]
        public PropValueStringAndNumber hFeedFilter { get; set; }

    }
}
