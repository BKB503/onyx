﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class BarcodeDimensionModel
    {
        [JsonProperty("Barcode Dimension")]
        public PropValueString BarcodeDimension { get; set; }

    }


}
