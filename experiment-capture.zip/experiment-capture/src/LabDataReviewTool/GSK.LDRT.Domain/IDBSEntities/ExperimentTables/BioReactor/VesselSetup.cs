﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class VesselSetup
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Process Recipe Name")]
        public PropValueString ProcessRecipeName { get; set; }

        [JsonProperty("Setpoint Group")]
        public PropValueString SetpointGroup { get; set; }

        [JsonProperty("Inoculation Group")]
        public PropValueString InoculationGroup { get; set; }

        [JsonProperty("Feed Schedule Group 1")]
        public PropValueString FeedScheduleGroup1 { get; set; }

        [JsonProperty("Feed Schedule Group 2")]
        public PropValueString FeedScheduleGroup2 { get; set; }

        [JsonProperty("Feed Schedule Group 3")]
        public PropValueString FeedScheduleGroup3 { get; set; }

        [JsonProperty("Duration")]
        public PropValueString Duration { get; set; }

        [JsonProperty("Culture Name")]
        public PropValueString CultureName { get; set; }

        [JsonProperty("Inoculation Completed Date and Time")]
        public PropValueDate InoculationCompletedDateandTime { get; set; }

        [JsonProperty("Cell Line Name")]
        public PropValueString CellLineName { get; set; }

        [JsonProperty("Reactor")]
        public PropValueString Reactor { get; set; }

        [JsonProperty("Bioreactor Culture Description")]
        public PropValueString BioreactorCultureDescription { get; set; }

        [JsonProperty("Vessel ID")]
        public PropValueString VesselId { get; set; }

        [JsonProperty("Vessel ID Override")]
        public PropValueStringAndNumber VesselIdOverride { get; set; }

        [JsonProperty("Working Volume Setpoint")]
        public PropValueStringAndNumber WorkingVolumeSetpoint { get; set; }

        [JsonProperty("Inoculum Volume Setpoint")]
        public PropValueStringAndNumber InoculumVolumeSetpoint { get; set; }

        [JsonProperty("Inoculum Volume")]
        public PropValueStringAndNumber InoculumVolume { get; set; }

        [JsonProperty("Total Viable Cell Concentration")]
        public PropValueStringAndNumber TotalViableCellConcentration { get; set; }

        [JsonProperty("Media Fill Volume")]
        public PropValueStringAndNumber MediaFillVolume { get; set; }

        [JsonProperty("Working Volume")]
        public PropValueStringAndNumber WorkingVolume { get; set; }

        [JsonProperty("Seed Split Ratio")]
        public PropValueStringAndNumber SeedSplitRatio { get; set; }

        [JsonProperty("Culture Medium Inventory Link")]
        public PropValueHyperLink CultureMediumInventoryLink { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("h Bioreactor Culture User ID")]
        public PropValueString hBioreactorCultureUserId { get; set; }
    }

    public class UoMVesselSetup
    {
        [JsonProperty("Vessel Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
