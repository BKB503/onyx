﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class FeedDetails
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Row Index")]
        public PropValueString RowIndex { get; set; }

        [JsonProperty("Feed Index")]
        public PropValueString FeedIndex { get; set; }

        [JsonProperty("Condition Name")]
        public PropValueString ConditionName { get; set; }

        [JsonProperty("Feed ID")]
        public PropValueString FeedId { get; set; }

        [JsonProperty("Feed Type")]
        public PropValueString FeedType { get; set; }

        [JsonProperty("Feed Input Type")]
        public PropValueString FeedInputType { get; set; }

        [JsonProperty("Day_Index")]
        public PropValueString DayIndex { get; set; }

        [JsonProperty("Feed Date")]
        public PropValueDate FeedDate { get; set; }

        [JsonProperty("Feed Time (24h)")]
        public PropValueDate FeedTime24h { get; set; }

        [JsonProperty("Feed Addition Setpoint")]
        public PropValueString FeedAdditionSetpoint { get; set; }

        [JsonProperty("Feed Addition Setpoint Unit")]
        public PropValueString FeedAdditionSetpointUnit { get; set; }

        [JsonProperty("Feed Addition Setpoint Override")]
        public PropValueString FeedAdditionSetpointOverride { get; set; }

        [JsonProperty("Working Volume")]
        public PropValueString WorkingVolume { get; set; }

        [JsonProperty("h Feed Rowshow")]
        public PropValueStringAndNumber HFeedRowshow { get; set; }
    }

    public class UoMFeedDetails
    {
        [JsonProperty("Feed Details Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
