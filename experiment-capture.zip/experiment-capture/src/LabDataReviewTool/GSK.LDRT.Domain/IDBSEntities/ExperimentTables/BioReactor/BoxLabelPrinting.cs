﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class BoxLabelPrinting
    {
        [JsonProperty("Box Label Index")]
        public PropValueString BoxLabelIndex { get; set; }

        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("User ID")]
        public PropValueString UserId { get; set; }

        [JsonProperty("Analysis")]
        public PropValueString Analysis { get; set; }

        [JsonProperty("Sample Description")]
        public PropValueString SampleDescription { get; set; }

        [JsonProperty("Shipping Temperature")]
        public PropValueString ShippingTemperature { get; set; }

    }


}
