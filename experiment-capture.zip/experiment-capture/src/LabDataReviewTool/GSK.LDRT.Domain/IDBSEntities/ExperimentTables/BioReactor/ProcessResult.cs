﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ProcessResult
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Day Index")]
        public PropValueString DayIndex { get; set; }

        [JsonProperty("Parent Sample Index")]
        public PropValueString ParentSampleIndex { get; set; }

        [JsonProperty("Sample Date")]
        public PropValueDate SampleDate { get; set; }

        [JsonProperty("Elapsed Time")]
        public PropValueStringAndNumber ElapsedTime { get; set; }

        [JsonProperty("Culture Working Volume")]
        public PropValueStringAndNumber CultureWorkingVolume { get; set; }

        [JsonProperty("Total Cell Concentration")]
        public PropValueStringAndNumber TotalCellConcentration { get; set; }

        [JsonProperty("Total Viable Cell Concentration")]
        public PropValueStringAndNumber TotalViableCellConcentration { get; set; }

        [JsonProperty("Cell Culture Viability")]
        public PropValueStringAndNumber CellCultureViability { get; set; }

        [JsonProperty("Average Cell Diameter")]
        public PropValueStringAndNumber AverageCellDiameter { get; set; }

        [JsonProperty("Growth Rate")]
        public PropValueStringAndNumber GrowthRate { get; set; }

        [JsonProperty("Doubling Time")]
        public PropValueStringAndNumber DoublingTime { get; set; }

        [JsonProperty("Incremental IVCD")]
        public PropValueStringAndNumber IncrementalIVCD { get; set; }

        [JsonProperty("Cumulative IVCD")]
        public PropValueStringAndNumber CumulativeIVCD { get; set; }

        [JsonProperty("Titre - Cedex Bio HT")]
        public PropValueStringAndNumber TitreCedexBioHT { get; set; }

        [JsonProperty("Titre - HPLC/Octet")]
        public PropValueStringAndNumber TitreHPLCOctet { get; set; }

        [JsonProperty("Specific Productivity - Cedex Bio HP")]
        public PropValueStringAndNumber SpecificProductivityCedexBioHP { get; set; }

        [JsonProperty("Specific Productivity - HPLC")]
        public PropValueStringAndNumber SpecificProductivityHPLC { get; set; }

        [JsonProperty("h Filter Helper")]
        public PropValueStringAndNumber HFilterHelper { get; set; }
    }

    public class UoMProcessResult
    {
        [JsonProperty("Result Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
