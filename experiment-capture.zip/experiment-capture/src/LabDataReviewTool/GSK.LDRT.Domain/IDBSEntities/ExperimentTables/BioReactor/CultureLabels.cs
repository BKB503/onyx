﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class CultureLabels
    {
        [JsonProperty("Culture Index")]
        public PropValueString CultureIndex { get; set; }

        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Project ID")]
        public PropValueString ProjectId { get; set; }

        [JsonProperty("System ID")]
        public PropValueString SystemId { get; set; }

        [JsonProperty("Cell Line")]
        public PropValueString CellLine { get; set; }

        [JsonProperty("Culture Print Name")]
        public PropValueString CulturePrintName { get; set; }

        [JsonProperty("Seed Date")]
        public PropValueDate SeedDate { get; set; }

        [JsonProperty("User ID")]
        public PropValueString UserId { get; set; }


    }


}
