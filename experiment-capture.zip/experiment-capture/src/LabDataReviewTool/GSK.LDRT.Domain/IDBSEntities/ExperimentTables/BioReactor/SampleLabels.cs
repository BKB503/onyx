﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class SampleLabels
    {
        [JsonProperty("h Aliquot Sample Label Index")]
        public PropValueString HAliquotSampleLabelIndex { get; set; }

        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Sampling Date")]
        public PropValueString SamplingDate { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Culture Print Name")]
        public PropValueString CulturePrintName { get; set; }

        [JsonProperty("Cell Line Name")]
        public PropValueString CellLineName { get; set; }
    }


}
