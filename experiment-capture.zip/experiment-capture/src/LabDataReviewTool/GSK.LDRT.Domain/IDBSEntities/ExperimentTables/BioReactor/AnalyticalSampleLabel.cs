﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class AnalyticalSampleLabel
    {
        [JsonProperty("Analytical Sample Label Index")]
        public PropValueString AnalyticalSampleLabelIndex { get; set; }

        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }

        [JsonProperty("User ID")]
        public PropValueString UserId { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Date")]
        public PropValueDate Date { get; set; }

        [JsonProperty("Concentration")]
        public PropValueStringAndNumber Concentration { get; set; }

        [JsonProperty("Concentration Unit")]
        public PropValueString ConcentrationUnit { get; set; }

        [JsonProperty("Test Analysis")]
        public PropValueString TestAnalysis { get; set; }

        [JsonProperty("Test Variation")]
        public PropValueString TestVariation { get; set; }

        [JsonProperty("Sample Description")]
        public PropValueString SampleDescription { get; set; }


    }


}
