﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class BioreactorDetails
    {
        [JsonProperty("Bioreactor Index")]
        public PropValueString BioreactorIndex { get; set; }

        [JsonProperty("Equipment ID")]
        public PropValueString EquipmentID { get; set; }

        [JsonProperty("Record Name")]
        public PropValueString RecordName { get; set; }

        [JsonProperty("Item Name")]
        public PropValueString ItemName { get; set; }

        [JsonProperty("Serial Number")]
        public PropValueString SerialNumber { get; set; }

        [JsonProperty("Calibration Due Date")]
        public PropValueDate CalibrationDueDate { get; set; }

        [JsonProperty("Equipment Type")]
        public PropValueString EquipmentType { get; set; }

        [JsonProperty("Equipment Status")]
        public PropValueString EquipmentStatus { get; set; }

        [JsonProperty("Equipment Location")]
        public PropValueString EquipmentLocation { get; set; }

        [JsonProperty("Equipment Link")]
        public PropValueHyperLink EquipmentLink { get; set; }
    }
}
