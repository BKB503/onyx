﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ExperimentSetupDetails
    {

        [JsonProperty("c Control")]
        public PropValueString CControl { get; set; }

        [JsonProperty("Study Number")]
        public PropValueString StudyNumber { get; set; }

        [JsonProperty("Organization")]
        public PropValueString Organization { get; set; }

        [JsonProperty("Experiment Title")]
        public PropValueString ExperimentTitle { get; set; }
        [JsonProperty("Experiment Title Suffix")]
        public PropValueString ExperimentTitleSuffix { get; set; }

        [JsonProperty("Experiment ID")]
        public PropValueString ExperimentId { get; set; }

        [JsonProperty("Experiment Purpose")]
        public PropValueString ExperimentPurpose { get; set; }

        [JsonProperty("Location")]
        public PropValueString Location { get; set; }


        [JsonProperty("Bioreactor Type")]
        public PropValueString BioreactorType { get; set; }

        [JsonProperty("Perfusion Experiment ?")]
        public PropValueString PerfusionExperiment { get; set; }

        [JsonProperty("Additional Feeding Required?")]
        public PropValueString AdditionalFeedingRequired { get; set; }

        [JsonProperty("Capacitance Controlled?")]
        public PropValueString CapacitanceControlled { get; set; }

        [JsonProperty("CSFR Controlled?")]
        public PropValueString CSFRControlled { get; set; }

        [JsonProperty("Number of Reactors")]
        public PropValueStringAndNumber NumberofReactors { get; set; }

        [JsonProperty("Number of Culture")]

        public PropValueStringAndNumber NumberofCulture { get; set; }

        [JsonProperty("Number of Inoculation Sets (Auto-populated post Culture Retrieval)")]
        public PropValueStringAndNumber NumberofInoculationSets { get; set; }

        [JsonProperty("Override Number of Inoculation Sets")]
        public PropValueStringAndNumber OverrideNumberofInoculationSets { get; set; }

        [JsonProperty("Import Culture from Batch")]
        public PropValueString ImportCulturefromBatch { get; set; }

        [JsonProperty("Experiment Procedure")]
        public PropValueString ExperimentProcedure { get; set; }

        [JsonProperty("ambr Data Export Path")]
        public PropValueString AmbrDataExportPath { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }
    }
}


