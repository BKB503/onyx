﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ReagentDetails
    {
        [JsonProperty("Reagent Idx")]
        public PropValueString ReagentIdx { get; set; }

        [JsonProperty("Reagent ID")]
        public PropValueString ReagentId { get; set; }

        [JsonProperty("Record Name")]
        public PropValueString RecordName { get; set; }

        [JsonProperty("Item Name")]
        public PropValueString ItemName { get; set; }

        [JsonProperty("Lot Number")]
        public PropValueString LotNumber { get; set; }

        [JsonProperty("Composition")]
        public PropValueString Composition { get; set; }

        [JsonProperty("Expiration Date")]
        public PropValueDate ExpirationDate { get; set; }

        [JsonProperty("Type")]
        public PropValueString Type { get; set; }

        [JsonProperty("Available Quantity")]
        public PropValueStringAndNumber AvailableQuantity { get; set; }

        [JsonProperty("Available Quantity Unit")]
        public PropValueString AvailableQuantityUnit { get; set; }

        [JsonProperty("Reagent Location")]
        public PropValueString ReagentLocation { get; set; }

        [JsonProperty("Reagent Experiment ID")]
        public PropValueString ReagentExperimentId { get; set; }

        [JsonProperty("Preparation Link")]
        public PropValueHyperLink PreparationLink { get; set; }
    }
}
