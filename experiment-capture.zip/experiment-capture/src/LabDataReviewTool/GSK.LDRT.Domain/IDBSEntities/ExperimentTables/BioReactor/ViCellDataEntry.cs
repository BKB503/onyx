﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ViCellDataEntry
    {
        [JsonProperty("Input Method")]
        public PropValueString InputMethod { get; set; }

        [JsonProperty("Vicell Aliquot Index")]
        public PropValueString VicellAliquotIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Instrument Sample ID Override")]
        public PropValueString InstrumentSampleIdOverride { get; set; }

        [JsonProperty("Measurement Equipment")]
        public PropValueString MeasurementEquipment { get; set; }

        [JsonProperty("Measurement Date")]
        public PropValueString MeasurementDate { get; set; }

        [JsonProperty("Total Cell Concentration")]
        public PropValueStringAndNumber TotalCellConcentration { get; set; }

        [JsonProperty("Total Viable Cell Concentration")]
        public PropValueStringAndNumber TotalViableCellConcentration { get; set; }

        [JsonProperty("Cell Culture Viability")]
        public PropValueStringAndNumber CellCultureViability { get; set; }

        [JsonProperty("Average Cell Diameter")]
        public PropValueStringAndNumber AverageCellDiameter { get; set; }

        [JsonProperty("Ignore?")]
        public PropValueString Ignore { get; set; }


    }

    public class UoMViCellDataEntry
    {
        [JsonProperty("Cell Count Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
