﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class SampleSetupConfiguration
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Planned_Days")]
        public PropValueString PlannedDays { get; set; }

        [JsonProperty("Number of Samples per Day")]
        public PropValueStringAndNumber NumberOfSamplesPerDay { get; set; }

        [JsonProperty("Generate Intermediate Cultures?")]
        public PropValueString GenerateIntermediateCultures { get; set; }

        [JsonProperty("Intermediate Cultures #")]
        public PropValueString IntermediateCultures { get; set; }

        [JsonProperty("Volume of Intermediate Cultures")]
        public PropValueStringAndNumber VolumeOfIntermediateCultures { get; set; }

        [JsonProperty("Is Centrifuged?")]
        public PropValueString IsCentrifuged { get; set; }

        [JsonProperty("Centrifuge group")]
        public PropValueString CentrifugeGroup { get; set; }

        [JsonProperty("Is Filtered?")]
        public PropValueString IsFiltered { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("h Intermediate culture Index")]
        public PropValueString HIntermediateCultureIndex { get; set; }

        [JsonProperty("h Sampling Plan filter")]
        public PropValueStringAndNumber HSamplingPlanFilter { get; set; }


    }

    public class UoMSampleSetupConfiguration
    {
        [JsonProperty("Sampling Plan Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
