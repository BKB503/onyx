﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ReactorDailyDataEntry
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Day Index")]
        public PropValueString DayIndex { get; set; }

        [JsonProperty("Timepoint Index")]
        public PropValueString TimepointIndex { get; set; }

        [JsonProperty("User Name")]
        public PropValueString UserName { get; set; }

        [JsonProperty("User ID")]
        public PropValueString UserId { get; set; }

        [JsonProperty("Date")]
        public PropValueDate Date { get; set; }

        [JsonProperty("Time (24h)")]
        public PropValueDate Time24h { get; set; }

        [JsonProperty("Media 1 Pump Total Volume")]
        public PropValueStringAndNumber Media1PumpTotalVolume { get; set; }

        [JsonProperty("Media 2 Pump Total Volume")]
        public PropValueStringAndNumber Media2PumpTotalVolume { get; set; }

        [JsonProperty("Media Flow Rate")]
        public PropValueStringAndNumber MediaFlowRate { get; set; }

        [JsonProperty("Media 3 Pump Total Volume")]
        public PropValueStringAndNumber Media3PumpTotalVolume { get; set; }

        [JsonProperty("Cell Factor")]
        public PropValueStringAndNumber CellFactor { get; set; }

        [JsonProperty("Agitation Rate")]
        public PropValueStringAndNumber AgitationRate { get; set; }

        [JsonProperty("Dissolved Oxygen")]
        public PropValueStringAndNumber DissolvedOxygen { get; set; }

        [JsonProperty("Controller pH")]
        public PropValueStringAndNumber ControllerpH { get; set; }

        [JsonProperty("Vessel Temperature")]
        public PropValueStringAndNumber VesselTemperature { get; set; }

        [JsonProperty("Base Addition Pump Total Volume")]
        public PropValueStringAndNumber BaseAdditionPumpTotalVolume { get; set; }

        [JsonProperty("Acid Addition Pump Total Volume")]
        public PropValueStringAndNumber AcidAdditionPumpTotalVolume { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("Antifoam Added?")]
        public PropValueString AntifoamAdded { get; set; }

        [JsonProperty("Add Timepoints?")]
        public PropValueString AddTimepoints { get; set; }
    }

    public class UoMReactorDailyDataEntry
    {
        [JsonProperty("Parent Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
