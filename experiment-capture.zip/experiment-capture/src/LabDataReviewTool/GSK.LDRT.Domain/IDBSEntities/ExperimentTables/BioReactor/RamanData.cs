﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class RamanData
    {
        [JsonProperty("Raman Spectra location")]
        public PropValueString RamanSpectralocation { get; set; }


    }


}
