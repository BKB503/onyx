﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ParentSampleDetails
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Day Index")]
        public PropValueString DayIndex { get; set; }

        [JsonProperty("Parent Sample Index")]
        public PropValueString ParentSampleIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Sampling Date")]
        public PropValueDate SamplingDate { get; set; }

        [JsonProperty("Sampling Time (24h)")]
        public PropValueDate SamplingTime24h { get; set; }

        [JsonProperty("Sample Volume")]
        public PropValueStringAndNumber SampleVolume { get; set; }

        [JsonProperty("Number of Additional Aliquots (if >1)")]
        public PropValueStringAndNumber NumberofAdditionalAliquots { get; set; }

        [JsonProperty("Elapsed Time")]
        public PropValueStringAndNumber ElapsedTime { get; set; }

        [JsonProperty("Link Sample Results to Intermediate Cultures?")]
        public PropValueString LinkSampleResultstoIntermediateCultures { get; set; }

        [JsonProperty("Culture Working Volume")]
        public PropValueString CultureWorkingVolume { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }
    }

    public class UoMParentSampleDetails
    {
        [JsonProperty("Parent Sample Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
