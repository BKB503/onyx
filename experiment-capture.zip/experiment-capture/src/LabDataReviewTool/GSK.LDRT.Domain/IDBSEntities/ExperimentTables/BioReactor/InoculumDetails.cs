﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class InoculumDetails
    {
        [JsonProperty("Inoculation Idx")]
        public PropValueString InoculationIdx { get; set; }

        [JsonProperty("Inoculation Set Name")]
        public PropValueString InoculationSetName { get; set; }

        [JsonProperty("Culture Name")]
        public PropValueString CultureName { get; set; }

        [JsonProperty("Seed Culture ID")]
        public PropValueString SeedCultureId { get; set; }

        [JsonProperty("Cell Line Name")]
        public PropValueString CellLineName { get; set; }

        [JsonProperty("Total Viable Cell Concentration")]
        public PropValueStringAndNumber TotalViableCellConcentration { get; set; }

        [JsonProperty("Total Viable Cell Concentration Override")]
        public PropValueStringAndNumber TotalViableCellConcentrationOverride { get; set; }

        [JsonProperty("Total Viable Cell Concentration Target")]
        public PropValueStringAndNumber TotalViableCellConcentrationTarget { get; set; }

        [JsonProperty("Inoculation Completed Date and Time")]
        public PropValueDate InoculationCompletedDateandTime { get; set; }

        [JsonProperty("Culture Medium")]
        public PropValueString CultureMedium { get; set; }

        [JsonProperty("Centrifuge group")]
        public PropValueString Centrifugegroup { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

    }

    public class UoMInoculumDetails
    {
        [JsonProperty("Inoculation Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
