﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class RamanInstrumentSetting
    {
        [JsonProperty("Instrument Settings Index")]
        public PropValueString InstrumentSettingsIndex { get; set; }

        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Probe ID")]
        public PropValueString ProbeId { get; set; }

        [JsonProperty("Acquisition Time")]
        public PropValueStringAndNumber AcquisitionTime { get; set; }

        [JsonProperty("Laser Power")]
        public PropValueStringAndNumber LaserPower { get; set; }

        [JsonProperty("Laser Wavelength")]
        public PropValueStringAndNumber LaserWavelength { get; set; }

        [JsonProperty("Number of Scans")]
        public PropValueStringAndNumber NumberofScans { get; set; }

        [JsonProperty("Exposure Time")]
        public PropValueStringAndNumber ExposureTime { get; set; }

        [JsonProperty("Spectral Coverage")]
        public PropValueStringAndNumber SpectralCoverage { get; set; }

        [JsonProperty("Spectral Resolution")]
        public PropValueStringAndNumber SpectralResolution { get; set; }

        [JsonProperty("Date of Instrument Verification")]
        public PropValueDate DateofInstrumentVerification { get; set; }

        [JsonProperty("Test Start Date / Time")]
        public PropValueDate TestStartDateTime { get; set; }

        [JsonProperty("h Rowshow")]
        public PropValueStringAndNumber hRowshow { get; set; }
    }

    public class UoMRamanInstrumentSetting
    {
        [JsonProperty("Instrument Settings Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
