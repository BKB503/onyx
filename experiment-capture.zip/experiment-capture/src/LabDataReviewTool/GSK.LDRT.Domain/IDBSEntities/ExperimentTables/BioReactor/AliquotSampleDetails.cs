﻿using GSK.LDRT.Domain.IDBSEntities.ExperimentTables;
using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class AliquotSampleDetails
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Day Index")]
        public PropValueString DayIndex { get; set; }

        [JsonProperty("Parent Sample Index")]
        public PropValueString ParentSampleIndex { get; set; }

        [JsonProperty("Aliquot Index")]
        public PropValueString AliquotIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Testing Type")]
        public PropValueString TestingType { get; set; }

        [JsonProperty("Self-Analysis")]
        public PropValueString SelfAnalysis { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Sample Volume")]
        public PropValueStringAndNumber SampleVolume { get; set; }

        [JsonProperty("Submit to Analyst")]
        public PropValueString SubmitToAnalyst { get; set; }

        [JsonProperty("Lot Type")]
        public PropValueString LotType { get; set; }

        [JsonProperty("Analytical Assay")]
        public PropValueString AnalyticalAssay { get; set; }

        [JsonProperty("Assay Variation")]
        public PropValueString AssayVariation { get; set; }

        [JsonProperty("Titre")]
        public PropValueStringAndNumber Titre { get; set; }

        [JsonProperty("NLS Exception")]
        public PropValueString NLSException { get; set; }

        [JsonProperty("NLS Sample Number")]
        public PropValueString NLSSampleNumber { get; set; }

        [JsonProperty("NLS Experiment Number")]
        public PropValueString NLSExperimentNumber { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

        [JsonProperty("h Aliquot filter")]
        public PropValueStringAndNumber HAliquotFilter { get; set; }
    }

    public class UoMAliquotSampleDetails
    {
        [JsonProperty("Aliquot Sample Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
