﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class CompoundsAndProjects
    {
        [JsonProperty("Compounds and Projects Index")]
        public PropValueString CompoundsAndProjectsId { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Project")]
        public PropValueString Project { get; set; }

        [JsonProperty("Project ID")]
        public PropValueString ProjectId { get; set; }

        [JsonProperty("Project ID Override")]
        public PropValueString ProjectIdOverride { get; set; }


    }
}
