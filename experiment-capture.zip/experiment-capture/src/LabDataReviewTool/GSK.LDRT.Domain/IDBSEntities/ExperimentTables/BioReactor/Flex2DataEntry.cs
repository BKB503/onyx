﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class Flex2DataEntry
    {
        [JsonProperty("Input Method")]
        public PropValueString InputMethod { get; set; }

        [JsonProperty("Flex Aliquot Index")]
        public PropValueString FlexAliquotIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Instrument Sample ID Override")]
        public PropValueString InstrumentSampleIdOverride { get; set; }

        [JsonProperty("Measurement Equipment")]
        public PropValueString MeasurementEquipment { get; set; }

        [JsonProperty("Measurement Date")]
        public PropValueString MeasurementDate { get; set; }

        [JsonProperty("Osmolality")]
        public PropValueStringAndNumber Osmolality { get; set; }

        [JsonProperty("Ammonium Concentration")]
        public PropValueStringAndNumber AmmoniumConcentration { get; set; }

        [JsonProperty("Calcium Concentration")]
        public PropValueStringAndNumber CalciumConcentration { get; set; }

        [JsonProperty("Glucose Concentration")]
        public PropValueStringAndNumber GlucoseConcentration { get; set; }

        [JsonProperty("Glutamine Concentration")]
        public PropValueStringAndNumber GlutamineConcentration { get; set; }

        [JsonProperty("Glutamate Concentration")]
        public PropValueStringAndNumber GlutamateConcentration { get; set; }


        [JsonProperty("Lactate Concentration")]
        public PropValueStringAndNumber LactateConcentration { get; set; }


        [JsonProperty("pH")]
        public PropValueStringAndNumber PH { get; set; }

        [JsonProperty("pCO2")]
        public PropValueStringAndNumber PCO2 { get; set; }

        [JsonProperty("pO2")]
        public PropValueStringAndNumber PO2 { get; set; }

        [JsonProperty("Potassium Concentration")]
        public PropValueStringAndNumber PotassiumConcentration { get; set; }


        [JsonProperty("Sodium Concentration")]
        public PropValueStringAndNumber SodiumConcentration { get; set; }

        [JsonProperty("pCO2 at temperature")]
        public PropValueStringAndNumber PCO2AtTemperature { get; set; }

        [JsonProperty("pO2 at Temperature")]
        public PropValueStringAndNumber PO2AtTemperature { get; set; }

        [JsonProperty("pH at Temperature")]
        public PropValueStringAndNumber PHAtTemperature { get; set; }

        [JsonProperty("Total Cell Concentration")]
        public PropValueStringAndNumber TotalCellConcentration { get; set; }

        [JsonProperty("Total Viable Cell Concentration")]
        public PropValueStringAndNumber TotalViableCellConcentration { get; set; }

        [JsonProperty("Cell Culture Viability")]
        public PropValueStringAndNumber CellCultureViability { get; set; }

        [JsonProperty("Average Cell Diameter")]
        public PropValueStringAndNumber AverageCellDiameter { get; set; }

        [JsonProperty("Ignore?")]
        public PropValueString Ignore { get; set; }


    }

    public class UoMFlex2CedexDataEntry
    {
        [JsonProperty("Flex Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
