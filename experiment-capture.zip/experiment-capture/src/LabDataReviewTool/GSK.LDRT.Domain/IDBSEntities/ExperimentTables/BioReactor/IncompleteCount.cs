﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class IncompleteCount
    {
        [JsonProperty("Table #")]
        public PropValueString TableIndex { get; set; }

        [JsonProperty("Perspective")]
        public PropValueString Perspective { get; set; }

        [JsonProperty("Table")]
        public PropValueString Table { get; set; }

        [JsonProperty("Mandatory Fields Filled?")]
        public PropValueString MandatoryFieldsFilled { get; set; }

    }


}
