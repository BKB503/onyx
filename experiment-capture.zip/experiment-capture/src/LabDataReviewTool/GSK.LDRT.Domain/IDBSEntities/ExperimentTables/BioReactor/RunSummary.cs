﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class RunSummary
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Run Duration")]
        public PropValueStringAndNumber RunDuration { get; set; }

        [JsonProperty("Final Volume")]
        public PropValueStringAndNumber FinalVolume { get; set; }

        [JsonProperty("Storage Location ID")]
        public PropValueString StorageLocationId { get; set; }

        [JsonProperty("Is Pooling Required ?")]
        public PropValueString IsPoolingRequired { get; set; }

        [JsonProperty("Generated Culture ID")]
        public PropValueString GeneratedCultureId { get; set; }

        [JsonProperty("Batch ID")]
        public PropValueString BatchId { get; set; }

        [JsonProperty("Culture Print Name")]
        public PropValueString CulturePrintName { get; set; }

        [JsonProperty("Is Centrifuged?")]
        public PropValueString IsCentrifuged { get; set; }


        [JsonProperty("Centrifuge group")]
        public PropValueString CentrifugeGroup { get; set; }

        [JsonProperty("h Run Summary reactor")]
        public PropValueStringAndNumber HRunSummaryReactor { get; set; }

    }

    public class UoMRunSummary
    {
        [JsonProperty("Run Summary Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
