﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class DCAIdGeneration
    {
        [JsonProperty("Metabolite Types")]
        public PropValueString MetaboliteTypes { get; set; }

        [JsonProperty("Generate DCA ID for the Test?")]
        public PropValueString GenerateDCAIDfortheTest { get; set; }

        [JsonProperty("h Rowshow")]
        public PropValueStringAndNumber HRowShow { get; set; }


    }


}
