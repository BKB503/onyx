﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class DCAIdLabels
    {
        [JsonProperty("Sample Label Index")]
        public PropValueString SampleLabelIndex { get; set; }

        [JsonProperty("Sample Description")]
        public PropValueString SampleDescription { get; set; }

        [JsonProperty("Self-Analysis")]
        public PropValueString SelfAnalysis { get; set; }

        [JsonProperty("MUD ID")]
        public PropValueString MudId { get; set; }

        [JsonProperty("Sampling Date")]
        public PropValueString SamplingDate { get; set; }

        [JsonProperty("Bioreactor #")]
        public PropValueString Bioreactor { get; set; }

        [JsonProperty("Label Name")]
        public PropValueString LabelName { get; set; }

        [JsonProperty("Cell Line Name")]
        public PropValueString CellLineName { get; set; }
    }


}
