﻿using Newtonsoft.Json;
namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class Contributors
    {
        [JsonProperty("Contributor Idx")]
        public PropValueString ContributorIdx { get; set; }

        [JsonProperty("User ID")]
        public PropValueString UserId { get; set; }

        [JsonProperty("User Name")]
        public PropValueString UserName { get; set; }

        [JsonProperty("Role")]
        public PropValueString Role { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }


    }
}
