﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ResultSummary
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("IVCD")]
        public PropValueStringAndNumber IVCD { get; set; }

        [JsonProperty("Average Growth Rate")]
        public PropValueStringAndNumber AverageGrowthRate { get; set; }

        [JsonProperty("Maximum Viable Cell Density")]
        public PropValueStringAndNumber MaximumViableCellDensity { get; set; }

        [JsonProperty("Final Viable Cell Density")]
        public PropValueStringAndNumber FinalViableCellDensity { get; set; }

        [JsonProperty("Final Viability")]
        public PropValueStringAndNumber FinalViability { get; set; }

        [JsonProperty("Final Titre Cedex Bio HT")]
        public PropValueStringAndNumber FinalTitreCedexBioHT { get; set; }

        [JsonProperty("Final Titre HPLC")]
        public PropValueStringAndNumber FinalTitreHPLC { get; set; }

        [JsonProperty("Average Specific Productivity Cedex Bio HT")]
        public PropValueStringAndNumber AverageSpecificProductivityCedexBioHT { get; set; }

        [JsonProperty("Average Specific Productivity HPLC")]
        public PropValueStringAndNumber AverageSpecificProductivityHPLC { get; set; }

        [JsonProperty("Generation Number")]
        public PropValueStringAndNumber GenerationNumber { get; set; }

        [JsonProperty("h Rowshow")]
        public PropValueStringAndNumber HRowshow { get; set; }
    }

    public class UoMResultSummary
    {
        [JsonProperty("Run Summary Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }


}
