﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class SolutionComponents
    {
        [JsonProperty("Solution Index")]
        public PropValueString SolutionIndex { get; set; }

        [JsonProperty("Component Index")]
        public PropValueString ComponentIndex { get; set; }

        [JsonProperty("Component Name")]
        public PropValueString ComponentName { get; set; }

        [JsonProperty("Component ID")]
        public PropValueString ComponentId { get; set; }

        [JsonProperty("Lot Number")]
        public PropValueString LotNumber { get; set; }

        [JsonProperty("Amount of Component")]
        public PropValueStringAndNumber AmountofComponent { get; set; }

        [JsonProperty("Unit")]
        public PropValueString Unit { get; set; }

        [JsonProperty("Add Another Component?")]
        public PropValueString AddAnotherComponent { get; set; }

        [JsonProperty("h Rowshow")]
        public PropValueStringAndNumber hRowshow { get; set; }

    }


}
