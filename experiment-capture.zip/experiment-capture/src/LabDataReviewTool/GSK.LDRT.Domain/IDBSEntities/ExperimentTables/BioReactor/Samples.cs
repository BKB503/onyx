﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class Samples
    {
        [JsonProperty("B")]
        public PropValueString B { get; set; }

        [JsonProperty("Sample ID")]
        public PropValueString SampleId { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("Barcode")]
        public PropValueImage Barcode { get; set; }

        [JsonProperty("h Rowshow")]
        public PropValueStringAndNumber HRowshow { get; set; }
    }


}
