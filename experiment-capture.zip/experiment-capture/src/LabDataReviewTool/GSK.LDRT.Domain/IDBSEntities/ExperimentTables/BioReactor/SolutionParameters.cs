﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class SolutionParameters
    {
        [JsonProperty("Solution Index")]
        public PropValueString SolutionIndex { get; set; }

        [JsonProperty("Custom Name")]
        public PropValueString CustomName { get; set; }

        [JsonProperty("Filtered?")]
        public PropValueString Filtered { get; set; }

        [JsonProperty("Prepared By")]
        public PropValueString PreparedBy { get; set; }

        [JsonProperty("Prepared On")]
        public PropValueDate PreparedOn { get; set; }

        [JsonProperty("Comments")]
        public PropValueString Comments { get; set; }

    }


}
