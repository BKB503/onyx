﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class CultureDetails
    {
        [JsonProperty("Seed Culture Idx")]
        public PropValueString SeedCultureIdx { get; set; }

        [JsonProperty("Source")]
        public PropValueString Source { get; set; }

        [JsonProperty("Seed Culture ID")]
        public PropValueString SeedCultureID { get; set; }

        [JsonProperty("Culture Name")]
        public PropValueString CultureName { get; set; }

        [JsonProperty("Cell Line Name")]
        public PropValueString CellLineName { get; set; }

        [JsonProperty("Compound ID")]
        public PropValueString CompoundId { get; set; }

        [JsonProperty("Total Viable Cell Concentration")]
        public PropValueStringAndNumber TotalViableCellConcentration { get; set; }

        [JsonProperty("Cell Culture Viability")]
        public PropValueStringAndNumber CellCultureViability { get; set; }

        [JsonProperty("Passage Number")]
        public PropValueStringAndNumber PassageNumber { get; set; }

        [JsonProperty("Generation Number")]
        public PropValueStringAndNumber GenerationNumber { get; set; }

        [JsonProperty("Project")]
        public PropValueString Project { get; set; }

        [JsonProperty("Culture Link")]
        public PropValueHyperLink CultureLink { get; set; }
    }

    public class UoMCultureDetails
    {
        [JsonProperty("Seed Culture Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
