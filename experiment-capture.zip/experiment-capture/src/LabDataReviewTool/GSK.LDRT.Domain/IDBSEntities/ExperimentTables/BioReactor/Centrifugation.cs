﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class Centrifugation
    {
        [JsonProperty("Centrifugation Settings")]
        public PropValueString CentrifugationSettings { get; set; }

        [JsonProperty("Centrifuge")]
        public PropValueString Centrifuge { get; set; }

        [JsonProperty("Centrifuge ID")]
        public PropValueString CentrifugeId { get; set; }

        [JsonProperty("Centrifugation Unit")]
        public PropValueString CentrifugationUnit { get; set; }

        [JsonProperty("Speed")]
        public PropValueStringAndNumber Speed { get; set; }

        [JsonProperty("Temperature Setpoint")]
        public PropValueStringAndNumber TemperatureSetpoint { get; set; }

        [JsonProperty("Duration")]
        public PropValueStringAndNumber Duration { get; set; }

        [JsonProperty("Acceleration")]
        public PropValueStringAndNumber Acceleration { get; set; }

        [JsonProperty("Deceleration")]
        public PropValueStringAndNumber Deceleration { get; set; }

    }

    public class UoMCentrifugation
    {
        [JsonProperty("Centrifugation Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
