﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ExperimentFeedSetup
    {
        [JsonProperty("Feed Configuration")]
        public PropValueString FeedConfiguration { get; set; }

        [JsonProperty("Condition Name")]
        public PropValueString ConditionName { get; set; }

        [JsonProperty("Feed 1 Inventory Item")]
        public PropValueString Feed1InventoryItem { get; set; }

        [JsonProperty("Feed 1 Feed Unit")]
        public PropValueString Feed1FeedUnit { get; set; }

        [JsonProperty("Feed 1 Input Type")]
        public PropValueString Feed1InputType { get; set; }

        [JsonProperty("Feed 1 Feed Type")]
        public PropValueString Feed1FeedType { get; set; }

        [JsonProperty("Feed 2 Inventory Item")]
        public PropValueString Feed2InventoryItem { get; set; }

        [JsonProperty("Feed 2 Feed Unit")]
        public PropValueString Feed2FeedUnit { get; set; }

        [JsonProperty("Feed 2 Input Type")]
        public PropValueString Feed2InputType { get; set; }

        [JsonProperty("Feed 2 Feed Type")]
        public PropValueString Feed2FeedType { get; set; }

        [JsonProperty("Feed 3 Inventory Item")]
        public PropValueString Feed3InventoryItem { get; set; }

        [JsonProperty("Feed 3 Feed Unit")]
        public PropValueString Feed3FeedUnit { get; set; }

        [JsonProperty("Feed 3 Input Type")]
        public PropValueString Feed3InputType { get; set; }

        [JsonProperty("Feed 3 Feed Type")]
        public PropValueString Feed3FeedType { get; set; }

        [JsonProperty("Maximum Number of Feed Events")]
        public PropValueStringAndNumber MaximumNumberofFeedEvents { get; set; }


    }
}
