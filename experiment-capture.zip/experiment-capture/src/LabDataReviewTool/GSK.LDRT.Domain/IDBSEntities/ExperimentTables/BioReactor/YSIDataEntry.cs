﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class YSIDataEntry
    {
        [JsonProperty("Input Method")]
        public PropValueString InputMethod { get; set; }

        [JsonProperty("YSI Aliquot Index")]
        public PropValueString YSIAliquotIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Instrument Sample ID Override")]
        public PropValueString InstrumentSampleIdOverride { get; set; }

        [JsonProperty("Measurement Equipment")]
        public PropValueString MeasurementEquipment { get; set; }

        [JsonProperty("Measurement Date")]
        public PropValueString MeasurementDate { get; set; }

        [JsonProperty("Glucose Concentration")]
        public PropValueStringAndNumber GlucoseConcentration { get; set; }

        [JsonProperty("Lactate Concentration")]
        public PropValueStringAndNumber LactateConcentration { get; set; }

        [JsonProperty("Ignore?")]
        public PropValueString Ignore { get; set; }


    }

    public class UoMYSIDataEntry
    {
        [JsonProperty("YSI Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
