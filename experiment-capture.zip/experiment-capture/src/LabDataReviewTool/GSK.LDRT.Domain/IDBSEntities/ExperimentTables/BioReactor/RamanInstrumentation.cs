﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class RamanInstrumentation
    {
        [JsonProperty("Raman Setup")]
        public PropValueString RamanSetup { get; set; }

        [JsonProperty("Raman Used?")]
        public PropValueString RamanUsed { get; set; }


    }


}
