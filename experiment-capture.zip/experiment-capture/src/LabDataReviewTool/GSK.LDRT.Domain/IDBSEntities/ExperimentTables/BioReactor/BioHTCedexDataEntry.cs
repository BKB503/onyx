﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class BioHTCedexDataEntry
    {
        [JsonProperty("Input Method")]
        public PropValueString InputMethod { get; set; }

        [JsonProperty("Cedex Aliquot Index")]
        public PropValueString CedexAliquotIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Instrument Sample ID Override")]
        public PropValueString InstrumentSampleIdOverride { get; set; }

        [JsonProperty("Measurement Equipment")]
        public PropValueString MeasurementEquipment { get; set; }

        [JsonProperty("Measurement Date")]
        public PropValueString MeasurementDate { get; set; }

        [JsonProperty("Ammonium Concentration")]
        public PropValueStringAndNumber AmmoniumConcentration { get; set; }

        [JsonProperty("Calcium Concentration")]
        public PropValueStringAndNumber CalciumConcentration { get; set; }

        [JsonProperty("Glucose Concentration")]
        public PropValueStringAndNumber GlucoseConcentration { get; set; }

        [JsonProperty("Glutamine Concentration")]
        public PropValueStringAndNumber GlutamineConcentration { get; set; }

        [JsonProperty("Glutamate Concentration")]
        public PropValueStringAndNumber GlutamateConcentration { get; set; }


        [JsonProperty("Lactate Concentration")]
        public PropValueStringAndNumber LactateConcentration { get; set; }


        [JsonProperty("Lactate dehydrogenase concentration")]
        public PropValueStringAndNumber LactateDehydrogenaseConcentration { get; set; }

        [JsonProperty("Potassium Concentration")]
        public PropValueStringAndNumber PotassiumConcentration { get; set; }

        [JsonProperty("Titre")]
        public PropValueStringAndNumber Titre { get; set; }

        [JsonProperty("Sodium Concentration")]
        public PropValueStringAndNumber SodiumConcentration { get; set; }

        [JsonProperty("Iron Concentration")]
        public PropValueStringAndNumber IronConcentration { get; set; }

        [JsonProperty("Magnesium Concentration")]
        public PropValueStringAndNumber MagnesiumConcentration { get; set; }

        [JsonProperty("Phosphate Concentration")]
        public PropValueStringAndNumber PhosphateConcentration { get; set; }

        [JsonProperty("Ignore?")]
        public PropValueString Ignore { get; set; }


    }

    public class UoMBioHTCedexDataEntry
    {
        [JsonProperty("Cedex Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
