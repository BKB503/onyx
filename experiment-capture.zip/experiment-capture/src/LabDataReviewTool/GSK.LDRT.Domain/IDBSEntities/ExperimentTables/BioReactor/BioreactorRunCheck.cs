﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class BioreactorRunCheck
    {
        [JsonProperty("Reactor Index")]
        public PropValueString ReactorIndex { get; set; }

        [JsonProperty("Vessel ID")]
        public PropValueString VesselID { get; set; }

        [JsonProperty("Bioreactor End Date/Time")]
        public PropValueDate BioreactorEndDateTime { get; set; }

        [JsonProperty("Number of Deviations Observed")]
        public PropValueString NumberofDeviationsObserved { get; set; }

        [JsonProperty("Exclude this Batch")]
        public PropValueString ExcludeThisBatch { get; set; }

        [JsonProperty("Exclude this Batch from Calculation")]
        public PropValueString ExcludeThisBatchFromCalculation { get; set; }

        [JsonProperty("Comment")]
        public PropValueString Comment { get; set; }


    }


}
