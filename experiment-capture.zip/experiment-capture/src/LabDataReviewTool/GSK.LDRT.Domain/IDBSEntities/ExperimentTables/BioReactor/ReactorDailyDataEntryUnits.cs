﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class ReactorDailyDataEntryUnits
    {
        [JsonProperty("Perfusion parameters")]
        public PropValueString PerfusionParameters { get; set; }

        [JsonProperty("Units")]
        public PropValueString Units { get; set; }


    }


}
