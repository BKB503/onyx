﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables.BioReactor
{
    public class RAPIDPoint500DataEntry
    {
        [JsonProperty("Input Method")]
        public PropValueString InputMethod { get; set; }

        [JsonProperty("RAPIDPoint Aliquot Index")]
        public PropValueString RAPIDPointAliquotIndex { get; set; }

        [JsonProperty("Sample Name")]
        public PropValueString SampleName { get; set; }

        [JsonProperty("DCA ID")]
        public PropValueString DCAId { get; set; }

        [JsonProperty("Instrument Sample ID Override")]
        public PropValueString InstrumentSampleIdOverride { get; set; }

        [JsonProperty("Measurement Equipment")]
        public PropValueString MeasurementEquipment { get; set; }

        [JsonProperty("Measurement Date")]
        public PropValueString MeasurementDate { get; set; }

        [JsonProperty("Calcium Concentration")]
        public PropValueStringAndNumber CalciumConcentration { get; set; }

        [JsonProperty("Glucose Concentration")]
        public PropValueStringAndNumber GlucoseConcentration { get; set; }

        [JsonProperty("Lactate Concentration")]
        public PropValueStringAndNumber LactateConcentration { get; set; }

        [JsonProperty("pH")]
        public PropValueStringAndNumber PH { get; set; }

        [JsonProperty("pCO2")]
        public PropValueStringAndNumber PCO2 { get; set; }

        [JsonProperty("pO2")]
        public PropValueStringAndNumber PO2 { get; set; }

        [JsonProperty("Potassium Concentration")]
        public PropValueStringAndNumber PotassiumConcentration { get; set; }

        [JsonProperty("Sodium Concentration")]
        public PropValueStringAndNumber SodiumConcentration { get; set; }

        [JsonProperty("Chloride Concentration")]
        public PropValueStringAndNumber ChlorideConcentration { get; set; }

        [JsonProperty("pCO2 at temperature")]
        public PropValueStringAndNumber PCO2AtTemperature { get; set; }

        [JsonProperty("pO2 at Temperature")]
        public PropValueStringAndNumber PO2AtTemperature { get; set; }

        [JsonProperty("pH at Temperature")]
        public PropValueStringAndNumber PHAtTemperature { get; set; }

        [JsonProperty("Temperature Setpoint")]
        public PropValueStringAndNumber TemperatureSetpoint { get; set; }

        [JsonProperty("Ignore?")]
        public PropValueString Ignore { get; set; }


    }

    public class UoMRAPIDPoint500DataEntry
    {
        [JsonProperty("RAPIDPoint Data")]
        public PropValueString Column { get; set; }

        [JsonProperty("UoM")]
        public PropValueString UoM { get; set; }
    }
}
