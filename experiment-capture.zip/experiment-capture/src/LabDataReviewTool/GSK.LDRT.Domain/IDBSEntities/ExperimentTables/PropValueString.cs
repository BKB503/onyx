﻿using Newtonsoft.Json;


namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables
{
    public class PropValueString
    {
        [JsonProperty("string")]
        public string Value { get; set; }
    }
}
