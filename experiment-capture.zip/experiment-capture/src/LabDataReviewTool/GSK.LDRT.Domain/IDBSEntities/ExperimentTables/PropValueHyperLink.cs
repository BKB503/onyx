﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables
{
    public class PropValueHyperLink
    {
        [JsonProperty("hyperlink")]
        public string Value { get; set; }
    }
}
