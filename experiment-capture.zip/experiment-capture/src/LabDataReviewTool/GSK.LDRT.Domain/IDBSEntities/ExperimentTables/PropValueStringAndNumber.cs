﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables
{
    public class PropValueStringAndNumber
    {
        [JsonProperty("string")]
        public string StringValue { get; set; }

        [JsonProperty("number")]
        public string NumberValue { get; set; }
    }
}
