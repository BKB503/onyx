﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables
{
    public class HJson
    {

        [JsonProperty("Table Name")]
        public string TableName { get; set; }

        [JsonProperty("h Filter Identifier")]
        public string hFilterIdentifier { get; set; }

        [JsonProperty("Filter Values")]
        public string FilterValues { get; set; }

        [JsonProperty("c Filter Tables and Field")]
        public string cFilterTablesandField { get; set; }

        [JsonProperty("Dimension Shared")]
        public string DimensionShared { get; set; }
    }
}
