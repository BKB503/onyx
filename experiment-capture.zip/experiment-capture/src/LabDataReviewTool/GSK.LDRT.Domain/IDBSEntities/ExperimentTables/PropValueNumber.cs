﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables
{
    public class PropValueNumber
    {
        [JsonProperty("number")]
        public string Value { get; set; }
    }
}
