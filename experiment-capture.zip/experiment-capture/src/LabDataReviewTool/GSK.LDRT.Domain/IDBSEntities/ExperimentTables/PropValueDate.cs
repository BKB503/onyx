﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.ExperimentTables
{
    public class PropValueDate
    {
        [JsonProperty("datetime")]
        public DateTime? Value { get; set; }
    }
}
