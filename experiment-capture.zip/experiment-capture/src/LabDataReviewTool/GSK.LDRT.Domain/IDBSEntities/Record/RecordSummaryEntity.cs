﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Domain.IDBSEntities.Record
{
    public class RecordSummaryEntity
    {
        public RecordEntity RecordEntity { get; set; }
        public string ExperimentId { get; set; }
        public string Title { get; set; }
        public string PrevExpRef { get; set; }
        public string ExptRefSucccessor { get; set; }
        public string AdditionalProjectRef { get; set; }
        public string AllianceName { get; set; }
        public string CreatedOn { get; set; }
        public string ExperimentStatus { get; set; }
        public string RequestId { get; set; }
    }
}
