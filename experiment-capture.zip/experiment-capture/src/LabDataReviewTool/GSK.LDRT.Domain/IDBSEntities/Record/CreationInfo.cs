﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.Record
{
    public class CreationInfo
    {
        [JsonProperty("createdByUserFullName")]
        public string UserFullName { get; set; }

        [JsonProperty("timeCreated")]
        public long TimeCreated { get; set; }
    }
}
