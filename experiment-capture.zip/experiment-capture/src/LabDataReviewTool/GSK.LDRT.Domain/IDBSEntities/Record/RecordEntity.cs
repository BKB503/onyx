﻿using Newtonsoft.Json;


namespace GSK.LDRT.Domain.IDBSEntities.Record
{
    public class RecordEntity
    {
        [JsonProperty("entityDto")]
        public GSK.LDRT.Domain.IDBSEntities.Entity.Entity Entity { get; set; }

        [JsonProperty("creationInfo")]
        public CreationInfo CreationInfo { get; set; }
    }
}
