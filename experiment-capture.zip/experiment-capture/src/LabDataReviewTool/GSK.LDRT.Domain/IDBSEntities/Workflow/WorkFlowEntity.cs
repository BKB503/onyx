﻿
using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.Workflow
{
    public class WorkFlowEntity
    {
        [JsonProperty("workflowId")]
        public string WorkflowId { get; set; }
        [JsonProperty("displayId")]
        public string DisplayId { get; set; }
        [JsonProperty("requestorId")]
        public string RequestorId { get; set; }
        [JsonProperty("requestorName")]
        public string RequestorName { get; set; }
        [JsonProperty("workflowStatus")]
        public string WorkflowStatus { get; set; }
        [JsonProperty("entityId")]
        public string EntityId { get; set; }
        [JsonProperty("entityName")]
        public string EntityName { get; set; }
        [JsonProperty("entityPath")]
        public string EntityPath { get; set; }
        [JsonProperty("entityTypeId")]
        public string EntityTypeId { get; set; }
        [JsonProperty("taskProcess")]
        public string TaskProcess { get; set; }
        [JsonProperty("priority")]
        public string Priority { get; set; }
        [JsonProperty("onlyOnMostRecentPDF")]
        public bool OnlyOnMostRecentPDF { get; set; }
        [JsonProperty("numberOfCompletedTasks")]
        public int NumberOfCompletedTasks { get; set; }
        [JsonProperty("totalNumberOfTasks")]
        public int TotalNumberOfTasks { get; set; }
        [JsonProperty("dueDate")]
        public double DueDate { get; set; }
        [JsonProperty("requestedDate")]
        public double RequestedDate { get; set; }

    }
}
