﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace GSK.LDRT.Domain.IDBSEntities.Workflow
{
    public  class WorkflowListEntity
    {
        public WorkflowListEntity()
        {
            Workflows = new List<WorkFlowEntity>();
        }
        [JsonProperty("workflow")]
        public IEnumerable<WorkFlowEntity> Workflows { get; set; }
    }
}
