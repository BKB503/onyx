﻿

using System;

namespace GSK.LDRT.Domain.IDBSEntities.Workflow
{
    public class ExperimentWorkflowEntity
    {
        public string ExperimentName { get; set; }
        public string ExperimentDisplayName { get; set; }
        public string ExperimentId { get; set; }
        public string WorkflowId { get; set; }
        public string DisplayId { get; set; }
        public string RequestorId { get; set; }
        public string RequestorName { get; set; }
        public string WorkflowStatus { get; set; }
        public string EntityId { get; set; }
        public string EntityName { get; set; }
        public string EntityPath { get; set; }
        public string EntityTypeId { get; set; }
        public string TaskProcess { get; set; }
        public string Priority { get; set; }
        public bool OnlyOnMostRecentPDF { get; set; }
        public int NumberOfCompletedTasks { get; set; }
        public int TotalNumberOfTasks { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime RequestedDate { get; set; }
    }
}
