﻿using System.Collections.Generic;

namespace GSK.LDRT.Domain.IDBSEntities.Entity
{
    public partial class Children
    {
        public Children()
        {
            Entity = new List<Entity>();
        }

        public IEnumerable<Entity> Entity { get; set; }
    }
}
