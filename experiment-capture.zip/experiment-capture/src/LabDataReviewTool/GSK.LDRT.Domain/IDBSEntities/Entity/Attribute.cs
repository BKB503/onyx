﻿public class Attribute
{
    public Values Values { get; set; }
    public Displayvalues DisplayValues { get; set; }
    public string Name { get; set; }
    public string Caption { get; set; }
}
