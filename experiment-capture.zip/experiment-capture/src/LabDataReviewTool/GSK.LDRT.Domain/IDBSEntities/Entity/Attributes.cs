﻿using System.Collections.Generic;

public class Attributes
{
    public Attributes()
    {
        Attribute = new List<Attribute>();
    }
    public IEnumerable<Attribute> Attribute { get; set; }
}
