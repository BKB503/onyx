﻿using System.Collections.Generic;

public class Values
{
    public Values()
    {
        Value = new List<string>();
    }
    public List<string> Value { get; set; }
}
