﻿using System.Collections.Generic;

public class Displayvalues
{
    public Displayvalues()
    {
        Value = new List<string>();
    }
    public List<string> Value { get; set; }
}
