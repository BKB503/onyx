﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.Entity
{
    public class Signature
    {
        public Signature()
        {
            SignatureDetail = new List<SignatureDetail>();
        }

        [JsonProperty("signature")]
        public List<SignatureDetail> SignatureDetail { get; set; }
    }

    public class SignatureDetail
    {
        public string UserName { get; set; }
        public string UserFullName { get; set; }
        public string Reason { get; set; }
        public string Role { get; set; }
        public long Timestamp { get; set; }
    }
}
