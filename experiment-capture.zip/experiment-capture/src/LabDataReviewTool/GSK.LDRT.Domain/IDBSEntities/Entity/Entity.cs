﻿
namespace GSK.LDRT.Domain.IDBSEntities.Entity
{
    public class Entity
    {
        public Entitycore EntityCore { get; set; }
        public Attributes Attributes { get; set; }
        public VersionInfo VersionInfo { get; set; }
        public Children Children { get; set; }
        public Signature Signatures { get; set; }
    }
}
