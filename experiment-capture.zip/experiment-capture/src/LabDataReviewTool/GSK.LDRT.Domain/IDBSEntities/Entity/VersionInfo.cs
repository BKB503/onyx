﻿namespace GSK.LDRT.Domain.IDBSEntities.Entity
{
    public class VersionInfo
    {
        public string VersionState { get; set; }
        public int VersionNumber { get; set; }
        public string VersionId { get; set; }
        public string UserName { get; set; }
        public string UserFullName { get; set; }
        public string AuthorComment { get; set; }
        public object AuthorAdditionalComment { get; set; }
    }

}
