﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.Entity
{
    public class EntityList
    {
        public EntityList()
        {
            Entity = new List<Entity>();
        }
        public int TotalEntities { get; set; }
        public IEnumerable<Entity> Entity { get; set; }
    }
}
