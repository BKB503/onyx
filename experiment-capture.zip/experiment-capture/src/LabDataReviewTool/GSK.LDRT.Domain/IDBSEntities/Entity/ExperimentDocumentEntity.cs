﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.Entity
{
    public class ExperimentDocumentEntity
    {
        public string EntityId { get; set; }
        public string VersionId { get; set; }
        public string FileName { get; set; }
        public string DisplayText { get; set; }
        public string EntityTypeName { get; set; }
    }
}
