﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.Task
{
    public class TaskDetailListEntity
    {
        public TaskDetailListEntity()
        {
            TaskDetails = new List<TaskDetailEntity>();
        }

        [JsonProperty("taskDetail")]
        public IEnumerable<TaskDetailEntity> TaskDetails { get; set; }
    }
}
