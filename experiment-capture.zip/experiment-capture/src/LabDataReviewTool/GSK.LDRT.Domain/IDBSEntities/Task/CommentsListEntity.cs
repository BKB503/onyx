﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.Task
{
    public class CommentsListEntity
    {
        public CommentsListEntity()
        {
            Comments = new List<CommentEntity>();
        }

        [JsonProperty("comment")]
        public IEnumerable<CommentEntity> Comments { get; set; }
    }
}
