﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.Task
{
    public class TaskDetailEntity
    {
        [JsonProperty("taskId")]
        public string TaskId { get; set; }
        [JsonProperty("taskName")]
        public string TaskName { get; set; }
        [JsonProperty("workflowId")]
        public string WorkflowId { get; set; }
        [JsonProperty("workflowName")]
        public string WorkflowName { get; set; }
        [JsonProperty("displayId")]
        public string DisplayId { get; set; }
        [JsonProperty("taskStatus")]
        public string TaskStatus { get; set; }
        [JsonProperty("taskType")]
        public string TaskType { get; set; }
        [JsonProperty("entityId")]
        public string EntityId { get; set; }
        [JsonProperty("entityType")]
        public string EntityType { get; set; }
        [JsonProperty("entityPath")]
        public string EntityPath { get; set; }
        [JsonProperty("workflowRequester")]
        public string WorkflowRequester { get; set; }
        [JsonProperty("workflowPriority")]
        public string WorkflowPriority { get; set; }
        [JsonProperty("workflowStatus")]
        public string WorkflowStatus { get; set; }
        [JsonProperty("dueDate")]
        public double DueDate { get; set; }
        [JsonProperty("sendDate")]
        public double SendDate { get; set; }
    }
}
