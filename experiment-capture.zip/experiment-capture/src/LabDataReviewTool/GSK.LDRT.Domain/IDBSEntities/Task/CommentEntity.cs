﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.Task
{
    public class CommentEntity
    {
        [JsonProperty("text")]
        public string Text { get; set; }
        [JsonProperty("header")]
        public string Header { get; set; }
    }
}
