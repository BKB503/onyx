﻿using System;

namespace GSK.LDRT.Domain.IDBSEntities.Task
{
    public class ExperimentTaskEntity 
    {
        public string ExperimentName { get; set; }
        public string ExperimentDisplayName { get; set; }
        public string ExperimentId { get; set; }
        public string TaskId { get; set; }
        public string TaskName { get; set; }
        public string WorkflowId { get; set; }
        public string WorkflowName { get; set; }
        public string DisplayId { get; set; }
        public string TaskStatus { get; set; }
        public string TaskType { get; set; }
        public string EntityId { get; set; }
        public string EntityType { get; set; }
        public string EntityPath { get; set; }
        public string WorkflowRequester { get; set; }
        public string WorkflowPriority { get; set; }
        public string WorkflowStatus { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime SendDate { get; set; }
    }
}
