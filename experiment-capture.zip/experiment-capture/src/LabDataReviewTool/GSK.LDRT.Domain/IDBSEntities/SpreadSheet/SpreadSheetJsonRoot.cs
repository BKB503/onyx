﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class SpreadSheetJsonRoot
    {
        public SpreadSheetJsonRoot()
        {
            Data = new List<Dictionary<string, object>>();
        }
        public List<Dictionary<string, object>> Data { get; set; }
    }
}
