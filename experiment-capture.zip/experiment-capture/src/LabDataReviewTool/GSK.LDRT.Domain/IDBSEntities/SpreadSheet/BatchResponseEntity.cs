﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class BatchResponseEntity
    {
        public BatchResponseEntity()
        {
            ApiResponses = new List<ApiResponseEntity>();
        }
        [JsonProperty("api-responses")]
        public IEnumerable<ApiResponseEntity> ApiResponses { get; set; }
    }

    public class BatchImageResponseEntity
    {
        public BatchImageResponseEntity()
        {
            ApiResponses = new List<ImageResponseEntity>();
        }
        [JsonProperty("api-responses")]
        public IEnumerable<ImageResponseEntity> ApiResponses { get; set; }
    }
}

