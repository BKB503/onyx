﻿using GSK.LDRT.Domain.IDBSEntities.ExperimentTables.UvVisSampleTesting.Tables;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class SpreadSheetPdfTableModel
    {
        public SpreadSheetPdfTableModel()
        {
            SpreadSheetTableAndData = new List<SpreadSheetTableData>();
            JsonFilterTables = new List<JsonFilterTable>();
        }
        public string TableName { get; set; }
        public string TableData { get; set; }
        public string MethodName { get; set; }
        public string MethodId { get; set; }
        public List<SpreadSheetTableData> SpreadSheetTableAndData { get; set; }
        public List<JsonFilterTable> JsonFilterTables { get; set; }
    }
}
