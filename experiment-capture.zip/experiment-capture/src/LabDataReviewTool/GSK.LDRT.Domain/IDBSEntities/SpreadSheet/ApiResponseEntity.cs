﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class ApiResponseEntity
    {
        public ApiResponseEntity()
        {
            Tables = new List<TableEntity>();
        }
        [JsonProperty("tables")]
        public IEnumerable<TableEntity> Tables { get; set; }
    }
}
