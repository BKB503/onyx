﻿using Newtonsoft.Json;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class TableDataEntity
    {
        [JsonProperty("batch-response")]
        public BatchResponseEntity BatchResponse { get; set; }
    }

    public class ImageDataEntity
    {
        [JsonProperty("batch-response")]
        public BatchImageResponseEntity BatchResponse { get; set; }
    }
}
