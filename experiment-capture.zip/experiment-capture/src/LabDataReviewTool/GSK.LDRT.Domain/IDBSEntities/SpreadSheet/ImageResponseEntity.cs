﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class ImageResponseEntity
    {
        public ImageResponseEntity()
        {
        }
  
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("base64")]
        public string Base64 { get; set; }

        [JsonProperty("mimeType")]
        public string MimeType { get; set; }
    }

    
}
