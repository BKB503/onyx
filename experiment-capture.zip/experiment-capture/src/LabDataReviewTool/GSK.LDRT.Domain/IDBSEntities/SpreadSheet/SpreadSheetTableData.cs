﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class SpreadSheetTableData
    {
        public SpreadSheetTableData()
        {
            Images = new List<ImageResponseEntity>();
            DataTable = new DataTable();
        }
        public string TableName { get; set; }
        public string Data { get; set; }
        public DataTable DataTable { get; set; }

        public List<ImageResponseEntity> Images { get; set; }
    }
}
