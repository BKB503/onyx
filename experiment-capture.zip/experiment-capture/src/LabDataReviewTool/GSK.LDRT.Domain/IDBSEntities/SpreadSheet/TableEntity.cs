﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class TableEntity
    {
        public TableEntity()
        {
            Ranges = new List<RangeEntity>();
        }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("ranges")]
        public IEnumerable<RangeEntity> Ranges { get; set; }
    }
}
