﻿using Newtonsoft.Json;


namespace GSK.LDRT.Domain.IDBSEntities.SpreadSheet
{
    public class RangeEntity
    {
        [JsonProperty("data")]
        public dynamic Data { get; set; }


    }
}
