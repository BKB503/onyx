﻿using System.ComponentModel;


namespace GSK.LDRT.Domain.IDBSEntities.Enums
{
    public enum EntityType
    {
        [Description("EXPERIMENT")]
        Experiment = 0,

        [Description("TEXT_DOCUMENT")]
        TextDocument = 1,

        [Description("IDBS_SPREADSHEET")]
        IDBSSpreadSheet =2
    }
}
