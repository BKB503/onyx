using Azure.Identity;
using GSK.LDRT.API;
using GSK.LDRT.API.Extensions;
using GSK.LDRT.Application;
using GSK.LDRT.Infrastructure.IDBSApi;
using GSK.LDRT.Infrastructure.IDBSSnowflake;
using GSK.LDRT.Infrastructure.StorageApi; 
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Identity.Web;
using Swashbuckle.AspNetCore.SwaggerUI;
using System.Net;


var builder = WebApplication.CreateBuilder(args);
//var keyVaultName = Environment.GetEnvironmentVariable("KeyVaultName");
var keyVaultName = builder.Configuration["KeyVaultName"];
var keyVaultEndpoint = new Uri($"https://{keyVaultName}.vault.azure.net/");
builder.Configuration.AddAzureKeyVault(keyVaultEndpoint, new DefaultAzureCredential());

//builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//                  .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));

// Add services to the container.
builder.Services.ConfigureAuthentication();
builder.Services.AddHttpContextAccessor();
builder.Services.AddInfrastructureIdbsApi();
builder.Services.AddInfrastructureSnowflake();
builder.Services.AddInfrastructureStorageApi();
builder.Services.AddApplicationServices();
builder.Services.AddControllers();
builder.Services.AddApplicationInsightsTelemetry();
//builder.Services.AddApplicationInsightsKubernetesEnricher();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHealthChecks();
//HttpClient.DefaultProxy.Credentials = CredentialCache.DefaultCredentials;

//services cors 
builder.Services.AddCors(p => p.AddPolicy("corsapp", builder => { builder.WithOrigins("*").AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader(); }));

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI(
        c =>
        {
            c.OAuthConfigObject = new OAuthConfigObject
            {
                AppName = "GSK.LDRT.API",
                ClientId = "",
                ClientSecret = "",
            };
            c.OAuthUsePkce();
        }
    );
//}
app.UseErrorHandlingMiddleware();
app.UseHealthChecks("/api/health");
app.UseCors("corsapp");
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();


