﻿using GSK.LDRT.Contracts.Abstractions.Application;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GSK.LDRT.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuditController : ControllerBase
    {
        private readonly IAuditService auditService;
        private readonly ILogger<AuditController> logger;
        public AuditController(IAuditService auditService, ILogger<AuditController> logger)
        {
            this.auditService = auditService;
            this.logger = logger;
        }

        [HttpGet("GetLogs")]
        public async Task<IActionResult> GetLogs(string entityId)
        {
            logger.LogInformation("GetLogs request triggered");
            var auditResponses = await auditService.GetLogs(entityId);
            logger.LogInformation("GetLogs request completed");
            return Ok(auditResponses);
        }

       
    }
}
