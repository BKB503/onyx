﻿using GSK.LDRT.Application.Features.Tasks.Models;
using GSK.LDRT.Contracts.Abstractions.Application;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GSK.LDRT.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITaskService taskService;
        private readonly ILogger<TaskController> logger;
        public TaskController(ITaskService taskService, ILogger<TaskController> logger)
        {
            this.taskService = taskService;
            this.logger = logger;
        }

        [HttpGet("GetComments")]
        public async Task<IActionResult> GetComments(string taskId)
        {
            logger.LogInformation("GetComments request triggered");
            var taskCommentResponses = await taskService.GetTaskComments(taskId);
            logger.LogInformation("GetComments request completed");
            return Ok(taskCommentResponses);
        }

        [HttpPost("Cancel")]
        public async Task<IActionResult> Cancel([FromBody]TaskRequestModel taskRequestModel)
        {
            logger.LogInformation("Task cancel request triggered");

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var response = await taskService.CancelTask(taskRequestModel.TaskId);
            logger.LogInformation("Task cancel request completed");
            return Ok(response);
        }

        [HttpPost("Complete")]
        public async Task<IActionResult> Complete([FromBody] TaskCompleteRequestModel taskCompleteRequestModel)
        {
            logger.LogInformation("Task complete request triggered");

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var response = await taskService.Complete(taskCompleteRequestModel.TaskId, taskCompleteRequestModel.EntityId);
            logger.LogInformation("Task complete request completed");
            return Ok(response);
        }

    }
}
