﻿using GSK.LDRT.Contracts.Abstractions.Application;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GSK.LDRT.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ExperimentController : ControllerBase
    {
        private readonly IExperimentService experimentService;
        private readonly IRecordService recordService;
        private readonly ILogger<ExperimentController> logger;
        public ExperimentController(IExperimentService experimentService, IRecordService recordService, ILogger<ExperimentController> logger)
        {
            this.experimentService = experimentService;
            this.recordService = recordService;
            this.logger = logger;
        }

        [HttpGet("GetExperimentsForUserReview")]
        public async Task<IActionResult> GetExperimentsForUserReview(string startDate, string endDate)
        {
            logger.LogInformation("GetExperimentsForUserReview request triggered");
            var startDateTime = Convert.ToDateTime(startDate);
            var endDateTime = Convert.ToDateTime(endDate);
            var experimentTaskListResponse = await experimentService.GetExperimentsForUserReview(startDateTime, endDateTime);
            logger.LogInformation("GetExperimentsForUserReview request completed");
            return Ok(experimentTaskListResponse);
        }

        [HttpGet("GetTest")]
        public async Task<IActionResult> GetUserAssignedTasksWithHttpClient(string startDate, string endDate)
        {
            logger.LogInformation("GetExperimentsForUserReview request triggered");
            var startDateTime = Convert.ToDateTime(startDate);
            var endDateTime = Convert.ToDateTime(endDate);
            var experimentTaskListResponse = await experimentService.GetExperimentsForUserReviewWithHttpClient(startDateTime, endDateTime);
            logger.LogInformation("GetExperimentsForUserReview request completed");
            return Ok(experimentTaskListResponse);
        }

        [HttpGet("GetExperimentsSentForReview")]
        public async Task<IActionResult> GetExperimentsSentForReview(string startDate, string endDate)
        {
            logger.LogInformation("GetExperimentsSentForReview request triggered");
            var startDateTime = Convert.ToDateTime(startDate);
            var endDateTime = Convert.ToDateTime(endDate);
            var experimentWorkflowListResponse =  await experimentService.GetExperimentsSentForReview(startDateTime, endDateTime);
            logger.LogInformation("GetExperimentsSentForReview request completed");
            return Ok(experimentWorkflowListResponse);
        }

        [HttpGet("GetExperimentsByOpenStatus")]
        public async Task<IActionResult> GetExperimentsByOpenStatus(string startDate, string endDate)
        {
            logger.LogInformation("GetExperimentsByOpenStatus request triggered");
            var startDateTime = Convert.ToDateTime(startDate);
            var endDateTime = Convert.ToDateTime(endDate);
            var experimentResponses = await experimentService.GetExperimentsByOpenStatus(startDateTime, endDateTime);
            logger.LogInformation("GetExperimentsByOpenStatus request completed");
            return Ok(experimentResponses);
        }

        [HttpGet("GetDocumentsByEntityId")]
        public async Task<IActionResult> GetDocumentsByEntityId(string entityId)
        {
            logger.LogInformation("GetDocumentsByEntityId request triggered");
            var experimentDocumentResponses = await experimentService.GetDocumentsByEntityId(entityId);
            logger.LogInformation("GetDocumentsByEntityId request completed");
            return Ok(experimentDocumentResponses);
        }

        [HttpGet("DownloadDocument")]
        public async Task<IActionResult> DownloadDocument(string entityId, string entityVersionId)
        {
            logger.LogInformation("DownloadDocument request triggered");
            var documentResponse = await experimentService.DownloadDocument(entityId, entityVersionId);
            logger.LogInformation("DownloadDocument request completed");
            return File(documentResponse.Data, documentResponse.ContentType);
        }

        [HttpGet("DownloadPdf")]
        public async Task<IActionResult> DownloadPdf(string entityId)
        {
            logger.LogInformation("DownloadPdf request triggered");
            var memoryStream = await recordService.DownloadPdf(entityId);
            logger.LogInformation("DownloadPdf request completed");
            return File(memoryStream, "application/pdf");
        }
    }
}
