﻿using GSK.LDRT.Application.Features.Experiments;
using GSK.LDRT.Contracts.Abstractions.Application;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GSK.LDRT.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class KeyTestController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private readonly ILogger<KeyTestController> logger;
        public KeyTestController(IConfiguration configuration, IExperimentService experimentService, ILogger<KeyTestController> logger)
        {
            this.configuration = configuration;
            this.logger = logger;
        }
        [HttpGet("GetKey")]
        public async Task<IActionResult> GetKey()
        {
            var username = configuration["IDBSAPI:Username"];
            return Ok(username);
        }
    }
}
