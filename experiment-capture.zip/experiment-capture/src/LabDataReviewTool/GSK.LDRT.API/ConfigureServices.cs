﻿using GSK.LDRT.Contracts.Configuration;
using GSK.LDRT.Contracts.Helpers;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Security.Claims;

namespace GSK.LDRT.API
{
    public static class ConfigureServices
    {
        public static void ConfigureAuthentication(this IServiceCollection services)
        {
            var configuration = services.BuildServiceProvider().GetService<IConfiguration>();
            var identityProvider = new PingIdConfiguration();
            identityProvider = configuration.GetSection("PingId").Get<PingIdConfiguration>();

            IEnumerable<SecurityKey> issuerSigningKeys = new List<SecurityKey>();
            var getKeysTaks = Task.Run(async () => { issuerSigningKeys = await JWKSSecurityKeysProvider.GetPingFederateJwtSigningKeyAsync(identityProvider.PingFederationHost, identityProvider.Endpoints.JwksExtEndpoint); });
            getKeysTaks.Wait();

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                //This enables the JwtBearer code to validate the JWT tokens issued by the the GSK ping federate IdP. It does this 
                //by fetching the JWKS file which holds the public certs of the IdP. This saves us a whole bunch of work!.
                options.MetadataAddress = $"{identityProvider.PingFederationHost}/{identityProvider.Endpoints.OpenIDConnectMetadataEndpoint}";

                //The list of valid audiences is an array of client_id's that are allowed to call this API. This is in fact not the
                //correct usage of validateAudience and only works because the PingFederate configuration always sets the aud claim
                //in the payload of the JWT to be the client_id.
                var tokenValidationParameterSettings = identityProvider.TokenValidation;

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    NameClaimType = ClaimTypes.NameIdentifier,
                    RequireSignedTokens = tokenValidationParameterSettings.RequireSignedTokens,
                    ValidateIssuerSigningKey = tokenValidationParameterSettings.ValidateIssuerSigningKey,
                    ValidateIssuer = tokenValidationParameterSettings.ValidateIssuer,
                    ValidIssuer = identityProvider.PingFederationHost,
                    ValidateAudience = tokenValidationParameterSettings.ValidateAudience,
                    ValidAudiences = tokenValidationParameterSettings.ValidAudiences,
                    ValidateLifetime = tokenValidationParameterSettings.ValidateLifetime,
                    ValidateActor = tokenValidationParameterSettings.ValidateActor,
                    ValidateTokenReplay = tokenValidationParameterSettings.ValidateTokenReplay,
                    IssuerSigningKeys = issuerSigningKeys,
                    ClockSkew = TimeSpan.FromSeconds(tokenValidationParameterSettings.ClockSkewSeconds),
                };

                options.Events = new JwtBearerEvents
                {
                    OnTokenValidated = async tokenValidatedContext =>
                    {


                        //    await Task.Run(() =>
                        //    {
                        //        //Add claim if yes
                        //        var claims = new List<Claim>
                        //    {
                        //    new Claim("ConfidentialAccess", "true")
                        //    };
                        //        var appIdentity = new ClaimsIdentity(claims);
                        //        tokenValidatedContext.Principal.AddIdentity(appIdentity);
                        //    });
                    }
                };
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "GSK.LDRT.API",
                    Description = $"GSK.LDRT.API"
                });
                // Set the comments path for the Swagger JSON and UI.
                //var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                //var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                //options.IncludeXmlComments(xmlPath);
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = @"JWT Authorization header using the Bearer scheme. Example: ""Authorization: Bearer {token}""",
                    Type = SecuritySchemeType.OAuth2,
                    Flows = new OpenApiOAuthFlows
                    {
                        AuthorizationCode = new OpenApiOAuthFlow
                        {
                            AuthorizationUrl = new Uri($"{identityProvider.PingFederationHost}/{identityProvider.Endpoints.OauthAuthorizationEndpoint}"),
                            TokenUrl = new Uri($"{identityProvider.PingFederationHost}/{identityProvider.Endpoints.OauthTokenEndpoint}"),
                            Scopes = new Dictionary<string, string>
                                            {
                                               { "openid", "Access to open id connect." }
                                            }
                        }
                    }

                });

                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                      new OpenApiSecurityScheme
                      {
                        Reference = new OpenApiReference
                          {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                          },
                          Scheme = "oauth2",
                          Name = "Bearer",
                          In = ParameterLocation.Header,
                        },
                        new List<string>()
                      }
                    });
            });
        }
    }
}
