﻿using GSK.LDRT.Application.Exceptions;
using GSK.LDRT.Contracts.Abstractions.StorageApi;
using GSK.LDRT.Domain.StorageApi.Model;
using GSK.LDRT.Domain.StorageApi.Model.Wrapper;
using GSK.LDRT.Infrastructure.StorageApi.Abstraction;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.StorageApi
{
    public class StorageApiHttpClient : IStorageApiClient
    {
        private JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };
        public int ClientTimeout { get; set; } = 180;
        private readonly ILogger<StorageApiHttpClient> logger;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly Uri BaseApiUrl;
        private readonly string ApiKey;
        private readonly string ContainerName;

        public StorageApiHttpClient(string baseApiUrl, string apiKey, string containerName, IHttpContextAccessor httpContextAccessor, ILogger<StorageApiHttpClient> logger)
        {
            if (baseApiUrl is null)
            {
                throw new ArgumentNullException(nameof(baseApiUrl));
            }

            if (apiKey is null)
            {
                throw new ArgumentNullException(nameof(apiKey));
            }

            if (containerName is null)
            {
                throw new ArgumentNullException(nameof(containerName));
            }

            if (!CheckURLValid(baseApiUrl))
            {
                throw new ArgumentException($"'{nameof(baseApiUrl)}' is not in the correct format. Please provide a valid URL", nameof(baseApiUrl));
            }
            if (!baseApiUrl.EndsWith('/'))
            {
                baseApiUrl += "/";
            }

            BaseApiUrl = new Uri(baseApiUrl);
            ApiKey = apiKey;
            ContainerName = containerName;
            this.httpContextAccessor = httpContextAccessor;
            this.logger = logger;
            jsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        }

        public async Task<ContainersResponse> GetContainersAsync(int Limit = 1000, CancellationToken cancellationToken = default)
        {
            using var client = new HttpClient();
            ContainersResponse responses = null;
            string apiURL = "api/v1/containers";
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientTimeout);
            //var token = await tokenProvider.GetTokenAsync(cancellationToken);
            var token = GetAccessToken();
            //get containers
            using (var request = new HttpRequestMessage(HttpMethod.Get, apiURL))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);

                response.EnsureSuccessStatusCode();

                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<ContainersResponse>(result, jsonSerializerOptions);

                logger.LogInformation($"Get containers completed");
            }
            return responses;
        }

        public async Task<ContainerContents> GetContainerContentsAsync(string folder, string continuationToken, int Limit = 1000, CancellationToken cancellationToken = default)
        {
          
            var client = new HttpClient();
            ContainerContents responses = null;
            //var token = await tokenProvider.GetTokenAsync(cancellationToken);
            var token = GetAccessToken();
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientTimeout);
            //get container contents
            string queryString = null;
            if (!string.IsNullOrEmpty(folder))
            {
                queryString = $"?folder={folder}";
            }
            if (!string.IsNullOrEmpty(continuationToken))
            {
                queryString = $"{queryString}{(queryString == null ? "?" : "&")}continuationToken={continuationToken}";
            }
            if (Limit > 0 && Limit < 1000)
            {
                queryString = $"{queryString}{(queryString == null ? "?" : "&")}Limit={Limit}";
            }
            string getContainerContents = $"api/v1/container/{ContainerName}/contents{queryString}";
            using (var request = new HttpRequestMessage(HttpMethod.Get, getContainerContents))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    request.Headers.Add("apikey", ApiKey);
                }
                var response = await client.SendAsync(request, cancellationToken);
                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                responses = JsonSerializer.Deserialize<ContainerContents>(result, jsonSerializerOptions);
                logger.LogInformation($"ContainerName : {responses.ContainerName}. Files of container count: {responses.Files.Count} Folder of container: {responses.Folders.Count} Get container contents completed.");
                if (!response.IsSuccessStatusCode)
                {
                    //response.EnsureSuccessStatusCode();
                    var message = $"{responses.Message}, Failed when calling Storage API";
                    throw new ApiException(message, response.StatusCode);
                }
             
            }
            return responses;
        }

        public async Task<UploadFileResult> UploadFileObjectAsync(FileUploadRequest fileDetails, CancellationToken cancellationToken = default)
        {

            using var client = new HttpClient();
            client.BaseAddress = BaseApiUrl;
            client.Timeout = TimeSpan.FromSeconds(ClientTimeout);
            // var token = await tokenProvider.GetTokenAsync(cancellationToken);
            var token = GetAccessToken();
            UploadFileResult responses = null;

            //send a file to service 
            string uploadFile = $"api/v1/upload/{ContainerName}/fileObj";
            if (!string.IsNullOrEmpty(fileDetails.FolderName))
            {
                uploadFile += $"?folder={fileDetails.FolderName}";
            }
            using (var content = new MultipartFormDataContent())
            {
                var fileContent = new StreamContent(fileDetails.FileStream);
                var collection = fileDetails.MetadataCollections;

                content.Add(fileContent, "File", fileDetails.FileName);
                foreach (var item in collection.Items)
                {
                    // JSON Format eg: "{\"key\": \"string\",\"value\": \"string\", \"isIndexed\": true}";
                    content.Add(new StringContent(JsonSerializer.Serialize(item)), $"Metadata.Items");
                }
                var requestUpload = new HttpRequestMessage(HttpMethod.Post, uploadFile)
                {
                    Content = content
                };

                requestUpload.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                if (!string.IsNullOrEmpty(ApiKey))
                {
                    requestUpload.Headers.Add("apikey", ApiKey);
                }

                requestUpload.Headers.Add("accept", "application/json");
                var response = await client.SendAsync(requestUpload, cancellationToken);
                var result = await response.Content.ReadAsStringAsync(cancellationToken);
                logger.LogInformation(result);
                responses = JsonSerializer.Deserialize<UploadFileResult>(result, jsonSerializerOptions);
                if (!response.IsSuccessStatusCode)
                {
                    //response.EnsureSuccessStatusCode();
                    var message = $"{responses.Message}, Failed when calling Storage API";
                    throw new ApiException(message, response.StatusCode);
                }

            }
            return responses;

        }

        public async Task<Stream> DownloadFileAsync(string fileName, string folder, string fileGuid, CancellationToken cancellationToken = default)
        {
            try
            {
                using var client = new HttpClient();
                client.BaseAddress = BaseApiUrl;
                client.Timeout = TimeSpan.FromSeconds(ClientTimeout);
                // var token = await tokenProvider.GetTokenAsync(cancellationToken);
                var token = GetAccessToken();
                //send a file to service 
                var downloadFile = new StringBuilder();

                downloadFile.Append($"api/v1/download/{ContainerName}/file");

                downloadFile.Append($"?fileName={fileName}&folder={folder}&fileGuid={fileGuid}");
                Stream fileContentMetadata = null;
                using (var request = new HttpRequestMessage(HttpMethod.Get, downloadFile.ToString()))
                {
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                    if (!string.IsNullOrEmpty(ApiKey))
                    {
                        request.Headers.Add("apikey", ApiKey);
                    }
                    var responses = await client.SendAsync(request, cancellationToken);
                    fileContentMetadata = await responses.Content.ReadAsStreamAsync(cancellationToken);

                    if (!responses.IsSuccessStatusCode)
                    {
                        //response.EnsureSuccessStatusCode();
                        var message = $"Failed when calling Storage API";
                        throw new ApiException(message, responses.StatusCode);
                    }

                    var result = await responses.Content.ReadAsStringAsync(cancellationToken);
                    logger.LogInformation($"Downloaded File Details " +
                                          $"File Content Disposition: {responses.Content.Headers.ContentDisposition} " +
                                          $"File Content Type: {responses.Content.Headers.ContentType} " +
                                          $"File Content Length: {responses.Content.Headers.ContentLength} ");
                }
                return fileContentMetadata;
            }
            catch (Exception ex)
            {
                logger.LogError(ex.Message);
                return null;
            }
        }

        private static bool CheckURLValid(string source) => Uri.TryCreate(source, UriKind.Absolute, out Uri uriResult) && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);
   
        private string GetAccessToken()
        {
            var authHeader =  (string)httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            if(authHeader == null)
            {
                throw new ApiException("No Authorization Header When Calling Storage API");
            }
            var token = authHeader.Substring("Bearer ".Length).Trim();
            return token;

        }
    }
}
