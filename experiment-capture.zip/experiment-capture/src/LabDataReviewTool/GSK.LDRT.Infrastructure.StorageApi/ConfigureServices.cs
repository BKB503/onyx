﻿
using GSK.LDRT.Contracts.Abstractions.StorageApi;
using GSK.LDRT.Infrastructure.StorageApi.Abstraction;
using GSK.LDRT.Infrastructure.StorageApi.Helper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;

namespace GSK.LDRT.Infrastructure.StorageApi
{
    public static class ConfigureServices
    {
        public static void AddInfrastructureStorageApi(this IServiceCollection services)
        {
            services.AddTransient<IOAuth2TokenProvider>(ctx => {
                var configuration = ctx.GetService<IConfiguration>();
                var logger = ctx.GetService<ILogger<OAuth2ClientCredentialsTokenProvider>>();
                var oAuth2Configuration = new OAuth2Configuration
                {
                    AccessTokenUrl = new Uri(configuration["StorageApi:AccessTokenUrl"]),
                    ClientId = configuration["StorageApi:ClientId"],
                    ClientSecret = configuration["StorageApi:ClientSecret"],
                    Scope = configuration["StorageApi:Scope"]
                };
                return new OAuth2ClientCredentialsTokenProvider(oAuth2Configuration, logger);
            });
            services.AddTransient<IStorageApiClient>(ctx =>
            {
                var configuration = ctx.GetService<IConfiguration>();
                var httpContextAccessor = ctx.GetService<IHttpContextAccessor>();
                var logger = ctx.GetService<ILogger<StorageApiHttpClient>>();
                var baseApirUrl = configuration["StorageApi:BaseApiUrl"];
                var apiKey = configuration["StorageApi:ApiKey"];
                var containerName = configuration["StorageApi:ContainerName"];
                return new StorageApiHttpClient(baseApirUrl,apiKey, containerName, httpContextAccessor, logger);
            });
        }
    }
}
