﻿using GSK.LDRT.Infrastructure.StorageApi.Helper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.StorageApi.Abstraction
{
    public interface IOAuth2TokenProvider
    {
        Task<OAuth2Token> GetTokenAsync(CancellationToken cancellationToken);
    }
}
