﻿using GSK.LDRT.Infrastructure.StorageApi.Abstraction;
using GSK.LDRT.Infrastructure.StorageApi.Helper;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace GSK.LDRT.Infrastructure.StorageApi
{
    public class OAuth2ClientCredentialsTokenProvider : IOAuth2TokenProvider
    {
        private readonly JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        private readonly ILogger<OAuth2ClientCredentialsTokenProvider> logger;
        private readonly OAuth2Configuration oAuth2Configuration;
        private static ConcurrentDictionary<string, OAuth2Token> CachedTokenDict = new ConcurrentDictionary<string, OAuth2Token>();
        private static ConcurrentDictionary<string, DateTime?> CachedTokenExpirationDict = new ConcurrentDictionary<string, DateTime?>();
        private readonly string configKey;
        public OAuth2ClientCredentialsTokenProvider(OAuth2Configuration oAuth2Configuration, ILogger<OAuth2ClientCredentialsTokenProvider> logger)
        {
            this.logger = logger;
            this.oAuth2Configuration = oAuth2Configuration;
            configKey = $"{oAuth2Configuration.AccessTokenUrl}|{oAuth2Configuration.ClientId}|{oAuth2Configuration.ClientSecret}|{oAuth2Configuration.Scope}";
        }
        public async Task<OAuth2Token> GetTokenAsync(CancellationToken cancellationToken)
        {
            CachedTokenDict.TryGetValue(configKey, out OAuth2Token CachedToken);
            CachedTokenExpirationDict.TryGetValue(configKey, out DateTime? CachedTokenExpiration);
            if (CachedToken != null &&
               CachedTokenExpiration != null &&
               DateTime.UtcNow < CachedTokenExpiration.Value)
            {
                return CachedToken;
            }
            else
            {
                CachedTokenDict.TryRemove(configKey, out OAuth2Token r1);
                CachedTokenExpirationDict.TryRemove(configKey, out DateTime? r2);
            }

            try
            {
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Post, oAuth2Configuration.AccessTokenUrl);
                request.Headers.Add("cache-control", "no-cache");
                //request.Headers.Add("content-type", "application/x-www-form-urlencoded");
                var callParameters = new List<KeyValuePair<string, string>>()
                {
                   new KeyValuePair<string, string> ("grant_type","client_credentials"),
                   new KeyValuePair<string, string> ("client_id",oAuth2Configuration.ClientId),
                   new KeyValuePair<string, string> ("client_secret",oAuth2Configuration.ClientSecret)
                };
                if (oAuth2Configuration.Scope != null)
                {
                    callParameters.Add(new KeyValuePair<string, string>("scope", oAuth2Configuration.Scope));
                }
                request.Content = new FormUrlEncodedContent(callParameters);
                var responseToken = await client.SendAsync(request, cancellationToken);
                if (responseToken.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var contentData = await responseToken.Content.ReadAsStringAsync();
                    CachedToken = JsonSerializer.Deserialize<OAuth2Token>(contentData, jsonSerializerOptions);
                    CachedTokenExpiration = DateTime.UtcNow.AddSeconds(CachedToken.ExpiresIn);
                    CachedTokenDict.TryAdd(configKey, CachedToken);
                    CachedTokenExpirationDict.TryAdd(configKey, CachedTokenExpiration);
                    return CachedToken;
                }
                else
                {
                    logger.LogWarning($"No token was generated. Reason = {responseToken.Content}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"OAuth2ClientCredentialsTokenProvider.GetTokenAsync() {ex.Message}");
                throw;
            }
        }
    }
}
