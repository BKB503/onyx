﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Infrastructure.StorageApi.Helper
{
    public class OAuth2Configuration
    {
        public Uri AccessTokenUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string Scope { get; set; }
    }
}
