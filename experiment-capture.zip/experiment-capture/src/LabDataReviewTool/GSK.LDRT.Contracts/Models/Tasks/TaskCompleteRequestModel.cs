﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace GSK.LDRT.Application.Features.Tasks.Models
{
    public class TaskCompleteRequestModel
    {
        [Required]
        public string TaskId { get; set; }


        [Required]
        public string EntityId { get; set; }
    }
}
