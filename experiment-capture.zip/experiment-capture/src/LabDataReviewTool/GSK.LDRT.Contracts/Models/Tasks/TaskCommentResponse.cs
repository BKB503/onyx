﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Application.Features.Tasks.Models
{
    public class TaskCommentResponse
    {
        public string Text { get; set; }
        public string Header { get; set; }
    }
}
