﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Contracts.Models
{
    public class Response
    {
        public string Message { get; set; }
    }
}
