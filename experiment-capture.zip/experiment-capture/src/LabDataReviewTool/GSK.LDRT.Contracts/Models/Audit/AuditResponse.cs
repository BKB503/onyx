﻿namespace GSK.LDRT.Contracts.Models.Audit
{
    public class AuditResponse
    {
        public DateTime ZoneStamp { get; set; }
        public string Username { get; set; }
        public string UserFullName { get; set; }
        public string HostName { get; set; }
        public string IpAddress { get; set; }
        public string ContainerId { get; set; }
        public string Reason { get; set; }
        public string Message { get; set; }
        public string Type { get; set; }
        public string Location { get; set; }
        public string EntityType { get; set; }
        public string EntityName { get; set; }
        public string EntityPath { get; set; }
    }
}
