﻿using System.Collections.Generic;

namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class ValuesResponse
    {
        public ValuesResponse()
        {
            Value = new List<string>();
        }
        public List<string> Value { get; set; }
    }
}