﻿using System;
using System.Net;
using System.Text;

namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class ExperimentResponse
    {
        public string ExperimentId { get; set; }
        public string ExperimentStatus { get; set; }
        public string EntityId { get; set; }
        public string ExperimentName { get; set; }
        public string ExperimentDisplayName { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedTimeStamp { get; set; }
        // public EntityResponse Entity { get; set; }
    }

    public class EntityResponse
    {
        public EntitycoreResponse EntityCore { get; set; }
        //public AttributesResponse Attributes { get; set; }
    }
}
