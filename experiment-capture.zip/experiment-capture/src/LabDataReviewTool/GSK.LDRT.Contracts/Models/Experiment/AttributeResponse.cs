﻿namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class AttributeResponse
    {
        public ValuesResponse Values { get; set; }
        public DisplayvaluesResponse DisplayValues { get; set; }
        public string Name { get; set; }
        public string Caption { get; set; }
    }
}