﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class DocumentResponse
    {
        public byte[] Data { get; set; }
        public string ContentType { get; set; }
        public string FileName { get; set; }
    }
}
