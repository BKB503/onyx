﻿namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class EntitycoreResponse
    {
        public string EntityId { get; set; }
        public string VisibleUniqueId { get; set; }
        public string ViewableInEntityId { get; set; }
        public string EntityTypeName { get; set; }
        public string EntityNature { get; set; }
        public string NodeDisplayText { get; set; }
        public string EntityName { get; set; }
        public bool PublishedFlag { get; set; }
    }
}