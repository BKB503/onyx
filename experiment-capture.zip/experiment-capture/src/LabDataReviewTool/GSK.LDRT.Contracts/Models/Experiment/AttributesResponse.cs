﻿using System.Collections.Generic;

namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class AttributesResponse
    {
        public AttributesResponse()
        {
            Attribute = new List<AttributeResponse>();
        }
        public IEnumerable<AttributeResponse> Attribute { get; set; }
    }
}