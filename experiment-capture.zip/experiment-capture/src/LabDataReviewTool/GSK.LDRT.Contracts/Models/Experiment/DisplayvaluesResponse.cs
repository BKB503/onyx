﻿using System.Collections.Generic;

namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class DisplayvaluesResponse
    {
        public DisplayvaluesResponse()
        {
            Value = new List<string>();
        }
        public List<string> Value { get; set; }
    }
}