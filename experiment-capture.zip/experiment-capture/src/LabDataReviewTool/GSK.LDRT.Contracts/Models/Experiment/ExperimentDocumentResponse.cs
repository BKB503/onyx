﻿namespace GSK.LDRT.Contracts.Models.Experiment
{
    public class ExperimentDocumentResponse
    {
        public string EntityId { get; set; }
        public string VersionId { get; set; }
        public string FileName { get; set; }
        public string DisplayText { get; set; }
        public string EntityTypeName { get; set; }
    }
}
