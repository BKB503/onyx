﻿namespace GSK.LDRT.Contracts.Abstractions.Common
{
    public interface IFileReader
    {
        string ReadAllText(string filePath);
    }
}
