﻿using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface ISpreadSheetService
    {
        Task<string> LoadSpreadSheetData(string versionId);

        Task<IEnumerable<string>> GetSpreadSheetTables(string modelId, IEnumerable<string> filterTables);
        Task<dynamic> GetTableData(string modelId, string tableName);
        Task<ImageResponseEntity> GetImageData(string modelId, string imageName);
        Task<DataTable> GetTableDataAsDataTable(string modelId, string tableName);
    }
}
