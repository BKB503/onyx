﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface IPdfGenerator
    {
        Stream Generate(List<string> htmlNodes);
    }
}
