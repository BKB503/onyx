﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface ITemplateConfigurationProvider
    {
        string GetTasksByWorkflowStatusInProgressFilePath { get; }
        string GetWorkflowsByWorkflowStatusInProgressAndNewFilePath { get; }
        string GetExperimentsByOpenStatusFilePath { get; }
        string GetSpreadSheetTableDataRequest { get; }
        string GetSpreadSheetImageDataRequest { get; }
        string GetSpreadSheetTableListRequest { get; }
        string GskLogo { get; }
    }
}
