﻿using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext
{
    public interface IUvVisSampleContext
    {
        string GetHtmlNode(string tableType, SpreadSheetPdfTableModel uvVisSampleTestingModel);
    }
}
