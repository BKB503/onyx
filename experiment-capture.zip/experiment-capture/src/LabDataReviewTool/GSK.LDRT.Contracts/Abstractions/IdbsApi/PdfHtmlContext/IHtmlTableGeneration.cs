﻿using GSK.LDRT.Domain.IDBSEntities.SpreadSheet;
using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi.PdfHtmlContext
{
    public interface IHtmlTableGeneration
    {
        string BuildTableHtml(SpreadSheetPdfTableModel uvVisSampleTestingModel);
    }
}
