﻿using GSK.LDRT.Domain.IDBSEntities.Audit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface IAuditApiService
    {
        Task<IEnumerable<AuditEntity>> GetLogs(string entityId);
    }
}
