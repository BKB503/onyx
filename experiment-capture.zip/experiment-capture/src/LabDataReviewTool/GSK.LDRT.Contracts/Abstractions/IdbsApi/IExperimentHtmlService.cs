﻿using GSK.LDRT.Domain.IDBSEntities.Record;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface IExperimentHtmlService
    {
        Task<List<string>> GenerateHtmlData(RecordSummaryEntity recordSummaryEntity);
    }
}
