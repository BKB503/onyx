﻿
using GSK.LDRT.Domain.IDBSEntities.Workflow;

using System.Collections.Generic;


namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface IWorkflowApiService
    {
        Task<IEnumerable<ExperimentWorkflowEntity>> GetUserAssignedWorkFlowsSentForReview(string username, DateTime startDate, DateTime endDate);
    }
}
