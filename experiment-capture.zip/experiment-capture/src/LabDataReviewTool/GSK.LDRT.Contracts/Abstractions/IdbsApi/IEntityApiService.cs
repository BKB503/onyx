﻿using GSK.LDRT.Domain.IDBSEntities.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface IEntityApiService
    {
        Task<Entity> GetEntityByEntitytId(string entityId, bool includeAttributes = true, bool includeChildren = false, bool includeVersionInfo = false);
        Task<IEnumerable<Entity>> GetEntitiesByUserAndOpenStatus(string username);
        Task<IEnumerable<ExperimentDocumentEntity>> GetDocumentEntitiesByEntityId(string entityId);
        Task<DocumentEntity> DownloadDocument(string entityId, string entityVersionId);
        Task<string> GetTextDocumentData(string entityId, string entityVersionId);
    }
}
