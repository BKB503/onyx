﻿using GSK.LDRT.Domain.IDBSEntities.Task;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.IdbsApi
{
    public interface ITaskApiService
    {
        Task<IEnumerable<ExperimentTaskEntity>> GetUserAssignedTasks(string username, DateTime startDate, DateTime endDate);
        Task<IEnumerable<ExperimentTaskEntity>> GetUserAssignedTasksWithHttpClient(string username, DateTime startDate, DateTime endDate);
        Task<IEnumerable<CommentEntity>> GetTaskComments(string taskId);
        Task<string> CancelTask(string taskId);
    }
}
