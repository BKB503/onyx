﻿using GSK.LDRT.Application.Features.Tasks.Models;
using GSK.LDRT.Contracts.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.Application
{
    public interface ITaskService
    {
        Task<IEnumerable<TaskCommentResponse>> GetTaskComments(string taskId);
        Task<Response> CancelTask(string taskId);
        Task<Response> Complete(string taskId, string entityId);
    }
}
