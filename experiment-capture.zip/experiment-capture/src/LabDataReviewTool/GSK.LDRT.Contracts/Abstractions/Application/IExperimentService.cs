﻿using GSK.LDRT.Contracts.Models.Experiment;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.Application
{
    public interface IExperimentService
    {
        Task<IEnumerable<ExperimentTaskResponse>> GetExperimentsForUserReview(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ExperimentTaskResponse>> GetExperimentsForUserReviewWithHttpClient(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ExperimentWorkflowResponse>> GetExperimentsSentForReview(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ExperimentResponse>> GetExperimentsByOpenStatus(DateTime startDate, DateTime endDate);
        Task<IEnumerable<ExperimentDocumentResponse>> GetDocumentsByEntityId(string entityId);
        Task<DocumentResponse> DownloadDocument(string entityId, string entityVersionId);
    }
}
