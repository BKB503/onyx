﻿using GSK.LDRT.Contracts.Models.Audit;
using GSK.LDRT.Domain.IDBSEntities.Audit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.Application
{
    public interface IAuditService
    {
        Task<List<AuditResponse>> GetLogs(string entityId);
    }
}
