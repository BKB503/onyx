﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GSK.LDRT.Contracts.Abstractions.Application
{
    public interface IUserService
    {
        string GetMudId();
    }
}
