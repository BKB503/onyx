﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.Application
{
    public interface IRecordService
    {
        Task<Stream> DownloadPdf(string entityId);
    }
}
