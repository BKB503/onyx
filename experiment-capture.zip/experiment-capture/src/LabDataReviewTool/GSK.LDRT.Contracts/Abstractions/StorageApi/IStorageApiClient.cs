﻿using GSK.LDRT.Domain.StorageApi.Model;
using GSK.LDRT.Domain.StorageApi.Model.Wrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.StorageApi
{
    public interface IStorageApiClient
    {
        Task<ContainersResponse> GetContainersAsync(int Limit = 1000, CancellationToken cancellationToken = default);
        Task<ContainerContents> GetContainerContentsAsync(string folder, string continuationToken, int Limit = 1000, CancellationToken cancellationToken = default);
        Task<UploadFileResult> UploadFileObjectAsync(FileUploadRequest fileDetails, CancellationToken cancellationToken = default);
        Task<Stream> DownloadFileAsync(string fileName, string folder, string fileGuid, CancellationToken cancellationToken = default);
    }
}
