﻿using GSK.LDRT.Domain.SnowflakeEntites;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace GSK.LDRT.Contracts.Abstractions.IdbsSnowflake
{
    public interface ISnowflakeContext
    {
        Task<IEnumerable<RecordVersionEntity>> GetRecordsByOpenStatus(string username, DateTime startDate, DateTime endDate);
        Task<IEnumerable<WorkFlowEntity>> GetWorkFlowsByStatusInProgressAndNew(string username, DateTime startDate, DateTime endDate);
        Task<IEnumerable<TaskEntity>> GetAssignedTasksByWorkFlowStatusInProgress(string username, DateTime startDate, DateTime endDate);
    }
}
