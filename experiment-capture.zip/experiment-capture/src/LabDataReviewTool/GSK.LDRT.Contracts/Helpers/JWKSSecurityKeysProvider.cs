﻿using Microsoft.IdentityModel.Tokens;
using System.Security.Cryptography.X509Certificates;


namespace GSK.LDRT.Contracts.Helpers
{
    public class JWKSSecurityKeysProvider
    {
        #region Notes on the format of JWKS – JSON Web Keys document

        //https://federation-qa.gsk.com/.well-known/openid-configuration
        //
        //  "jwks_uri": "https://federation-qa.gsk.com/pf/JWKS"
        //              "https://federation-qa.gsk.com/ext/oauth/jwks"
        //
        //----------------------------------------------------------------------------------------------------
        // Ref: https://redthunder.blog/2017/06/08/jwts-jwks-kids-x5ts-oh-my/
        //
        //  kty: Key Type – Identifies the family of algorithms used with this key.
        //
        //  alg: Algorithm – Identifies the specific algorithm.
        //
        //  use: Usage – ‘sig’ for signing keys, ‘enc’ for encryption keys.
        //
        //  x5t: X.509 Certificate Thumbprint – Used to identify specific certificates. This is the Base64Url
        //       encoded string of the certificate thumbprint (aka hash).
        //
        //  kid: Key Identifier – Acts as an ‘alias’ for the key.
        //
        //  x5c: X.509 Certificate Chain – Chain of certificates used for verification.The first entry in the
        //       array is always the cert to use for token verification. The other certificates can be used to
        //       verify this first certificate.
        //----------------------------------------------------------------------------------------------------

        #endregion

        public static async Task<IEnumerable<SecurityKey>> GetPingFederateJwtSigningKeyAsync(string pingFederateHost, string jwksEndpoint)
        {
            JsonWebKeySet jsonWebKeySetExt = await GetJsonWebKeySetAsync(pingFederateHost, jwksEndpoint);

            if (jsonWebKeySetExt != null)
            {
                return from k in jsonWebKeySetExt.Keys
                       where k.Kty == "RSA" && k.Use == "sig"
                       let x5c = (string)k.X5c[0]
                       let x5cByteArray = Convert.FromBase64String(x5c)
                       let jwtSigningCertificate = new X509Certificate2(x5cByteArray)
                       select new RsaSecurityKey(jwtSigningCertificate.GetRSAPublicKey());
            }
            return null;
        }

        private static async Task<JsonWebKeySet> GetJsonWebKeySetAsync(string pingFederateHost, string jwksEndpoint)
        {
            var httpClientHandler = new HttpClientHandler
            {
                //UseDefaultCredentials = true,               
            };
            var httpClient = new HttpClient(httpClientHandler)
            {
                BaseAddress = new Uri(pingFederateHost),
            };

            var json = await httpClient.GetStringAsync(jwksEndpoint);

            var jsonWebKeySet = JsonWebKeySet.Create(json);

            return jsonWebKeySet;
        }
    }
}
