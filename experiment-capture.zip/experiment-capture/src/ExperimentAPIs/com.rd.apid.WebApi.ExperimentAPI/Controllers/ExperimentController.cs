﻿using com.rd.apid.Repository.Idbs;
using com.rd.apid.Repository.Idbs.Extensions;
using com.rd.apid.WebApi.ExperimentAPI.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace com.rd.apid.WebApi.ExperimentAPI.Controllers
{
   [ApiController]
   [Route("[controller]")]
   public class ExperimentController : ControllerBase
   {
      private readonly ILogger<ExperimentController> _logger;
      private readonly IIdbsRepository _idbsRepository;

      public ExperimentController(ILogger<ExperimentController> logger, IIdbsRepository idbsRepository)
      {
         _logger = logger;
         _idbsRepository = idbsRepository;
      }

      [HttpGet("GetExperiment")]
      public async Task<IActionResult> GetExperiment(string experimentId = "E25312")
      {
         var experimentEntities = await _idbsRepository.FindExperimentEntitiesByExperimentIdAsync(experimentId);

         //Experiments
         var experimentEntity = experimentEntities.Entity.FirstOrDefault(); //Expecting only one experiment

         var experimentEntityId = experimentEntity.EntityCore.EntityId;

         var experimentEntityWithChildren = await _idbsRepository.GetEntityByEntityIdAsync(experimentEntityId, includeVersionInfo: true, includeChildren: true);

         var spreadsheetVersionIds = (from e in experimentEntityWithChildren.Children.Entity
                                      where e.EntityCore.EntityTypeName == "IDBS_SPREADSHEET"
                                      select e.VersionInfo.VersionId).ToArray();


         var tableData = new List<object>();
         //Spreadsheets
         foreach (var spreadsheetVersionId in spreadsheetVersionIds)
         {
            var spreadsheetModelId = await _idbsRepository.LoadSpreadsheet(spreadsheetVersionId);

            var tables = await _idbsRepository.GetSpreadsheetTables(spreadsheetModelId);

            //Table data
            foreach (var tableName in tables.Select(t => t.Name))
            {
               var tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, tableName);
               tableData.Add(tableDataResult);
            }

            await _idbsRepository.UnLoadSpreadsheet(spreadsheetModelId);
         }

         var tableData2 = tableData.ToArray();
         //return Ok(experimentEntityWithChildren);
         return Ok(tableData2);
      }

      [HttpGet("GetMetadata")]
      public async Task<IActionResult> GetMetadata(string experimentId = "E25312")
      {
         var experimentEntities = await _idbsRepository.FindExperimentEntitiesByExperimentIdAsync(experimentId, includeVersionInfo: true, includePath: true);
         var experimentEntity = experimentEntities.Entity.FirstOrDefault(); //Expecting only one experiment

         var experimentEntityId = experimentEntity.EntityCore.EntityId;
         var experimentVersionId = experimentEntity.VersionInfo.VersionId;
         var experimentBusinessArea = experimentEntity.Path.PathElement.Where(x => x.EntityType == "BUSINESS_AREA").Select(x => x.EntityName).FirstOrDefault();

         var experimentEntityVersions = await _idbsRepository.GetEntityVersionsAsync(experimentEntityId);

         var firstVersion = experimentEntityVersions.Version.First();
         DateTime experimentCreatedOn = DateTimeOffset.FromUnixTimeMilliseconds(firstVersion.TimeSaved).DateTime;
         var experimentCreatedBy = firstVersion.UserFullName;

         var currentVersion = experimentEntityVersions.Version.Last();
         DateTime timestamp = DateTimeOffset.FromUnixTimeMilliseconds(currentVersion.TimeSaved).DateTime;

         var experimentEntityAttributes = await _idbsRepository.GetEntityAttributesAsync(experimentEntityId, experimentVersionId);

         string templateEntityId = null;
         string templateName = null;
         string templateVersionNumber = null;

         var templateAttribute = experimentEntityAttributes.Attribute.Where(a => a.Name == "templates").FirstOrDefault();
         var templateAttributeFirstLink = templateAttribute.Links?.Link.First();
         if (templateAttributeFirstLink != null)
         {
            var templateVersionId = templateAttributeFirstLink?.VersionId;
            templateEntityId = templateAttributeFirstLink?.Id;
            if (templateEntityId != null && templateVersionId != null)
            {
               var templateEntity = await _idbsRepository.GetEntityByEntityIdAsync(templateEntityId, templateVersionId, includeVersionInfo: true);
               templateName = templateEntity.EntityCore.EntityName;
               templateVersionNumber = templateEntity.VersionInfo.VersionNumber.ToString();
            }
         }

         var result = new Metadata
         {
            experimentId = experimentEntityAttributes.GetAttributeValue("Experiment ID"),
            createdOn = $"{experimentCreatedOn:dd-MMM-yyyy HH:mm:ss}",
            title = experimentEntityAttributes.GetAttributeValue("title"),
            exprimentStatus = experimentEntityAttributes.GetAttributeValue("statusName"),
            createdBy = experimentCreatedBy,
            requestID = experimentEntityAttributes.GetAttributeValue("Request ID"),
            exptRefPrevious = experimentEntityAttributes.GetAttributeValue("prevExpRef"),
            versionNumber = currentVersion.VersionNumber.ToString(),
            exptRefSucccessor = experimentEntityAttributes.GetAttributeValue("succExpRef"),
            versionType = currentVersion.VersionState,
            additionalProjectRef = experimentEntityAttributes.GetAttributeValue("Project Ref"),
            templateID = templateEntityId,
            templateName = templateName,
            templateVersionNumber = templateVersionNumber,
            user = currentVersion.UserName,
            timeStamp = $"{timestamp:dd-MMM-yyyy HH:mm:ss}",
            allianceName = experimentBusinessArea,
            plates = "TODO",
            samples = "TODO",
         };

         return Ok(result);
      }

      [HttpGet("TestFeatures")]
      public async Task<IActionResult> TestFeatures(string experimentId = "E22187")
      {
         var experimentEntities = await _idbsRepository.FindExperimentEntitiesByExperimentIdAsync(experimentId);

         //Experiments
         var experimentEntity = experimentEntities.Entity.FirstOrDefault(); //Expecting only one experiment

         var experimentEntityId = experimentEntity.EntityCore.EntityId;

         var experimentEntityWithChildren = await _idbsRepository.GetEntityByEntityIdAsync(experimentEntityId, includeVersionInfo: true, includeChildren: true);

         var spreadsheetVersionIds = (from e in experimentEntityWithChildren.Children.Entity
                                      where e.EntityCore.EntityTypeName == "IDBS_SPREADSHEET"
                                      select e.VersionInfo.VersionId).ToArray();

         object tableDataResult = null;

         //Spreadsheets
         foreach (var spreadsheetVersionId in spreadsheetVersionIds)
         {
            var spreadsheetModelId = await _idbsRepository.LoadSpreadsheet(spreadsheetVersionId);

            var tables = await _idbsRepository.GetSpreadsheetTables(spreadsheetModelId);

            //var tableDimensionsResults1 = await _idbsRepository.GetSpreadsheetAllTableDimensions(spreadsheetModelId, "Experiment Setup");
            //var tableDimensionsResults2 = await _idbsRepository.GetSpreadsheetAllTableDimensions(spreadsheetModelId, "Compounds and Projects");
            //var tableDimensionsResults3 = await _idbsRepository.GetSpreadsheetAllTableDimensions(spreadsheetModelId, "Bioreactor Details");
            //var tableDimensionsResults4 = await _idbsRepository.GetSpreadsheetAllTableDimensions(spreadsheetModelId, "Setpoints");
            //var tableDimensionsResults5 = await _idbsRepository.GetSpreadsheetAllTableDimensions(spreadsheetModelId, "Material");
            var tableDimensionsResults6 = await _idbsRepository.GetSpreadsheetAllTableDimensions(spreadsheetModelId, "Analytical Sample Submissions");

            //All tables with all table structure 
            var tableDimensionsResults = await _idbsRepository.GetSpreadsheetAllTableDimensions(spreadsheetModelId, tables.Select(t => t.Name));

            //tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, "Experiment Setup");
            //tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, "Compounds and Projects");
            //tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, "Bioreactor Details");
            //tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, "Setpoints");
            //tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, "Material");
            //tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, "Material", "Material_Index");
            tableDataResult = await _idbsRepository.GetSpreadsheetTableData(spreadsheetModelId, "Analytical Sample Submissions");

            await _idbsRepository.UnLoadSpreadsheet(spreadsheetModelId);
         }

         return Ok(tableDataResult);
      }
   }
}
