﻿namespace com.rd.apid.WebApi.ExperimentAPI.Model
{
   public class Metadata
   {
      public string experimentId { get; set; }
      public string createdOn { get; set; }
      public string title { get; set; }
      public string exprimentStatus { get; set; }
      public string createdBy { get; set; }
      public object requestID { get; set; }
      public object exptRefPrevious { get; set; }
      public string versionNumber { get; set; }
      public object exptRefSucccessor { get; set; }
      public string versionType { get; set; }
      public object additionalProjectRef { get; set; }
      public string templateID { get; set; }
      public string templateName { get; set; }
      public string templateVersionNumber { get; set; }
      public string user { get; set; }
      public string timeStamp { get; set; }
      public string allianceName { get; set; }
      public string plates { get; set; }
      public string samples { get; set; }
   }
}
