﻿namespace com.rd.apid.Repository.Idbs
{
   public class IdbsRepositoryOptions
   {
      public string BaseAddress { get; set; } = "https://gskdev.idbs-eworkbook.com:8443/";
      public string Username { get; set; }
      public string Password { get; set; }
   }
}
