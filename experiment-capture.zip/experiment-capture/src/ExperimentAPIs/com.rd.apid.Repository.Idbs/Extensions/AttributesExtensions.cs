﻿using System.Linq;
using com.rd.apid.Repository.Idbs.Model;

namespace com.rd.apid.Repository.Idbs.Extensions
{
   public static class AttributesExtensions
   {
      public static string GetAttributeValue(this Attributes attributes, string name)
      {
         var attribute = attributes.Attribute.Where(a => a.Name == name).FirstOrDefault();
         return attribute.Values?.Value.FirstOrDefault();
      }
   }
}
