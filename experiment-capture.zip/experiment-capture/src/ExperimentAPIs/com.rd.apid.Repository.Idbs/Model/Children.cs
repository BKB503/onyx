﻿using System.Collections.Generic;

namespace com.rd.apid.Repository.Idbs.Model
{
   public class Children
   {
      public Entity[] Entity { get; set; }
   }
}
