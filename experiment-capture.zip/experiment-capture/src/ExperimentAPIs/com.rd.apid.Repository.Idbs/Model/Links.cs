﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.rd.apid.Repository.Idbs.Model
{
   public class Links
   {
      public Link[] Link { get; set; }
   }
}
