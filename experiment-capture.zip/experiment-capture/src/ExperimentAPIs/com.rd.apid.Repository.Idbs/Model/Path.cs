﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class Path
   {
      public PathElement[] PathElement { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(Path)}: {(PathElement != null ? String.Join("/", PathElement.Select(p => p.EntityName).ToArray()) : null)}"; }
      }
   }
}
