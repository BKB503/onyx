﻿using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class VersionInfo
   {
      public string VersionState { get; set; }
      public int VersionNumber { get; set; }
      public string VersionId { get; set; }
      public long TimeSaved { get; set; }
      public string UserName { get; set; }
      public string UserFullName { get; set; }
      public string AuthorComment { get; set; }
      public string AuthorAdditionalComment { get; set; }
      public string Witness { get; set; }
      public string WitnessComment { get; set; }
      public string WitnessAdditionalComment { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(VersionInfo)}: {VersionNumber} ({VersionState})"; }
      }
   }
}
