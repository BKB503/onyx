﻿using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class Link
   {
      public string Name { get; set; }
      public string Id { get; set; }
      public string VersionId { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(Link)}: {Name}"; }
      }
   }
}
