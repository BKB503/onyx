﻿using System.Collections.Generic;

namespace com.rd.apid.Repository.Idbs.Model
{
   public class FindByResult
   {
      public int TotalEntities { get; set; }
      public Entity[] Entity { get; set; }
   }
}
