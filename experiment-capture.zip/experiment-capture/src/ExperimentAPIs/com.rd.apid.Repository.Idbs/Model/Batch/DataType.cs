﻿namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   public enum DataType
   {
      Undefined = -1,

      String,
      Number,
   }
}
