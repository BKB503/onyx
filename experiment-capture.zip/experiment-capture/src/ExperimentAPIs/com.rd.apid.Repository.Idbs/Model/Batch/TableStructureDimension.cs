﻿using System.Diagnostics;
using System.Linq;

namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class TableStructureDimension
   {
      public string Name { get; set; }
      public string[] ItemNames { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(TableStructureDimension)}: {Name} (Count={ItemNames.Count()})"; }
      }
   }
}
