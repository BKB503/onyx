﻿namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   public class DataRowO
   {
      public object[] Datum { get; set; }
   }
}
