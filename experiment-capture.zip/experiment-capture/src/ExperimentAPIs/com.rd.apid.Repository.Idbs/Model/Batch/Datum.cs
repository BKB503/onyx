﻿using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class Datum
   {
      public string Name { get; set; }
      public DataType DataType { get; set; }
      public string StringValue { get; set; }
      public float NumberValue { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(Datum)}: {Name} ({DataType.ToString()}) = {(DataType == DataType.String ? StringValue : NumberValue.ToString())}"; }
      }
   }
}
