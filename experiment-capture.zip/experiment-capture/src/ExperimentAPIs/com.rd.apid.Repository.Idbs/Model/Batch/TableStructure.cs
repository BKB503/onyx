﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class TableStructure
   {
      public string TableName { get; set; }
      public string DataDimensionName { get; set; }
      public TableStructureDimension[] Dimensions { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(TableStructure)}: {TableName} ({DataDimensionName}, Dimensions Count={Dimensions.Count()})"; }
      }
   }
}
