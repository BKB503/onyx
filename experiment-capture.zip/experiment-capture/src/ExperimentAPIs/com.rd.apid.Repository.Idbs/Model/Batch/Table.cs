﻿namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   public class Table
   {
      public string Name { get; set; }
      public Range[] Ranges { get; set; }
   }
}
