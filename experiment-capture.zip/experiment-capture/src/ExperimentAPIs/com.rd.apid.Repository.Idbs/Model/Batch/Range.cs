﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   public class Range
   {
      public string RangeName { get; set; }
      public object[] Data { get; set; }
   }
}
