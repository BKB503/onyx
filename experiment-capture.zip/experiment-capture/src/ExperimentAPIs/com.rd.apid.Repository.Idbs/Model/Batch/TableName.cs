﻿using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class TableName
   {
      public string Name { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(TableName)}: {Name}"; }
      }
   }
}
