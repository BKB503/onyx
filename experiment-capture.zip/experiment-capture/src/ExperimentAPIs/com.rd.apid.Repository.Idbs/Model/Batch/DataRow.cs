﻿namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   public class DataRow
   {
      public Datum[] Datum { get; set; }
   }
}
