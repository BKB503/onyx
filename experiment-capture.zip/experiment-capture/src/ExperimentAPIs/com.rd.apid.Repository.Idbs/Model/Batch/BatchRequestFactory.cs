﻿using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace com.rd.apid.Repository.Idbs.Model.Batch
{
   internal static class BatchRequestFactory
   {
      private static JsonWriterOptions _jsonWriterOptions = new JsonWriterOptions { Indented = true };

      public static string TableList()
      {
         using (var memoryStream = new MemoryStream())
         {
            using (var jsonWriter = new Utf8JsonWriter(memoryStream, _jsonWriterOptions))
            {
               jsonWriter.WriteStartObject();
               jsonWriter.WriteStartArray("batch-request");

               jsonWriter.WriteStartObject();
               jsonWriter.WriteString("version", "1.0");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteStartArray();

               jsonWriter.WriteStartObject();
               jsonWriter.WriteString("api-id", "table.list");
               jsonWriter.WriteString("api-version", "1.0");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteStartObject();

               jsonWriter.WriteStartObject("data");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteEndObject();

               jsonWriter.WriteEndArray();

               jsonWriter.WriteEndArray();


               jsonWriter.WriteEndObject();
            }

            string jsonString = Encoding.UTF8.GetString(memoryStream.ToArray());
            return jsonString;
         }
      }

      public static string TableData(string tableName, string rangeName = "", bool includeKnockoutState = false)
      {
         using (var memoryStream = new MemoryStream())
         {
            using (var jsonWriter = new Utf8JsonWriter(memoryStream, _jsonWriterOptions))
            {
               jsonWriter.WriteStartObject();
               jsonWriter.WriteStartArray("batch-request");

               jsonWriter.WriteStartObject();
               jsonWriter.WriteString("version", "1.0");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteStartArray();

               jsonWriter.WriteStartObject();
               jsonWriter.WriteString("api-id", "table.data");
               jsonWriter.WriteString("api-version", "1.0");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteStartObject();

               jsonWriter.WriteStartObject("data");
               jsonWriter.WriteStartArray("queries");
               jsonWriter.WriteStartObject();
               jsonWriter.WriteString("table", tableName);
               jsonWriter.WriteString("range", rangeName);
               jsonWriter.WriteBoolean("includeKnockoutState", includeKnockoutState);
               jsonWriter.WriteEndObject();
               jsonWriter.WriteEndArray();
               jsonWriter.WriteEndObject();

               jsonWriter.WriteEndObject();

               jsonWriter.WriteEndArray();

               jsonWriter.WriteEndArray();
               jsonWriter.WriteEndObject();
            }

            string jsonString = Encoding.UTF8.GetString(memoryStream.ToArray());
            return jsonString;
         }
      }

      public static string TableStructure(IEnumerable<string> tableNames)
      {
         using (var memoryStream = new MemoryStream())
         {
            using (var jsonWriter = new Utf8JsonWriter(memoryStream, _jsonWriterOptions))
            {
               jsonWriter.WriteStartObject();
               jsonWriter.WriteStartArray("batch-request");

               jsonWriter.WriteStartObject();
               jsonWriter.WriteString("version", "1.0");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteStartArray();

               jsonWriter.WriteStartObject();
               jsonWriter.WriteString("api-id", "table.structure");
               jsonWriter.WriteString("api-version", "1.0");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteStartObject();

               jsonWriter.WriteStartObject("data");
               jsonWriter.WriteStartArray("tables");
               foreach (var tableName in tableNames)
               {
                  jsonWriter.WriteStringValue(tableName);
               }
               jsonWriter.WriteEndArray();

               jsonWriter.WriteStartObject("options");
               jsonWriter.WriteString("itemNames", "all");
               jsonWriter.WriteEndObject();

               jsonWriter.WriteEndObject();

               jsonWriter.WriteEndObject();

               jsonWriter.WriteEndArray();

               jsonWriter.WriteEndArray();
               jsonWriter.WriteEndObject();
            }

            string jsonString = Encoding.UTF8.GetString(memoryStream.ToArray());
            return jsonString;
         }
      }


   }
}
