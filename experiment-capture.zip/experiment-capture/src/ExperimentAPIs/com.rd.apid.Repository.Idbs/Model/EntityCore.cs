﻿using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class EntityCore
   {
      public string EntityId { get; set; }
      public string VisibleUniqueId { get; set; }
      public string ViewableInEntityId { get; set; }
      public string EntityTypeName { get; set; }
      public string EntityNature { get; set; }
      public string NodeDisplayText { get; set; }
      public string EntityName { get; set; }
      public bool PublishedFlag { get; set; }
      public bool LockedAgainstEdit { get; set; }
      public string IconUrl { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(EntityCore)}: {EntityName} ({EntityTypeName})"; }
      }
   }
}
