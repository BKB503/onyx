﻿namespace com.rd.apid.Repository.Idbs.Model
{
   public class EntityExtended : Entity
   {
      public Children Children { get; set; }
   }
}
