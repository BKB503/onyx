﻿using System;
using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class Attribute
   {
      public Values Values { get; set; }
      public Links Links { get; set; }
      public DisplayValues DisplayValues { get; set; }
      public string Name { get; set; }
      public string Caption { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(Attribute)}: {Name} = {(Values != null ? String.Join(", ", Values.Value) : null)}"; }
      }
   }
}
