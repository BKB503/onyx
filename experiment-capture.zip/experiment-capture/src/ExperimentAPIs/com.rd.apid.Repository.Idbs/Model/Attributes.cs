﻿using System.Diagnostics;
using System.Linq;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class Attributes
   {
      public Attribute[] Attribute { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(Attributes)}: Count={Attribute?.Count()}"; }
      }
   }
}
