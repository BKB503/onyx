﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class DisplayValues
   {
      public string[] Value { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(DisplayValues)}: {(Value != null ? String.Join(", ", Value) : null)}"; }
      }
   }
}
