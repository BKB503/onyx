﻿using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class Entity
   {
      public EntityCore EntityCore { get; set; }
      public Attributes Attributes { get; set; }
      public VersionInfo VersionInfo { get; set; }
      public Path Path { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(Entity)}: {EntityCore.EntityName} ({EntityCore.EntityTypeName})"; }
      }
   }
}
