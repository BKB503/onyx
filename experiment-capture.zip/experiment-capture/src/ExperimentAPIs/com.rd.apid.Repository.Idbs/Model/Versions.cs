﻿namespace com.rd.apid.Repository.Idbs.Model
{
   public class Versions
   {
      public VersionInfo[] Version { get; set; }
   }
}
