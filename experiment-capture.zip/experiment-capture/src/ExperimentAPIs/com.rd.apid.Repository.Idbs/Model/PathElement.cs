﻿using System.Diagnostics;

namespace com.rd.apid.Repository.Idbs.Model
{
   [DebuggerDisplay("{DebuggerDisplay,nq}")]
   public class PathElement
   {
      public string EntityName { get; set; }
      public string EntityId { get; set; }
      public string EntityType { get; set; }

      [DebuggerBrowsable(DebuggerBrowsableState.Never)]
      private string DebuggerDisplay
      {
         get { return $"{nameof(PathElement)}: {EntityName} ({EntityType})"; }
      }
   }
}
