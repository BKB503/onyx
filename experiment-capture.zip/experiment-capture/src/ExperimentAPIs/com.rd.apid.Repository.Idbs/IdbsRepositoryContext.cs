﻿namespace com.rd.apid.Repository.Idbs
{
   public class IdbsRepositoryContext
   {
      //Not currently used
   }
}
