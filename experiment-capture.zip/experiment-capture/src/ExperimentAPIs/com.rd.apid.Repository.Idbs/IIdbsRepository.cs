﻿using System.Collections.Generic;
using System.Threading.Tasks;
using com.rd.apid.Repository.Idbs.Model;
using com.rd.apid.Repository.Idbs.Model.Batch;

namespace com.rd.apid.Repository.Idbs
{
   public interface IIdbsRepository
   {
      Task<FindByResult> FindExperimentEntitiesByExperimentIdAsync(
         string experimentId,
         string userName = "",
         bool includeAttributes = false,
         bool includeVersionInfo = false,
         bool includePath = false);

      Task<EntityExtended> GetEntityByEntityIdAsync(
         string entityId,
         string entityVersionId = null,
         bool? includeAttributes = null,
         bool? includeVersionInfo = null,
         bool? includePath = null,
         bool? includeChildren = null);


      Task<Attributes> GetEntityAttributesAsync(string entityId, string entityVersionId = null);

      Task<Versions> GetEntityVersionsAsync(string entityId);

      Task<string> LoadSpreadsheet(string spreadsheetVersionId);

      Task UnLoadSpreadsheet(string spreadsheetModelId);

      Task<IEnumerable<TableName>> GetSpreadsheetTables(string spreadsheetModelId);

      Task<IEnumerable<TableStructure>> GetSpreadsheetAllTableDimensions(string spreadsheetModelId, string tableName);
      Task<IEnumerable<TableStructure>> GetSpreadsheetAllTableDimensions(string spreadsheetModelId, IEnumerable<string> tableNames);

      Task<object> GetSpreadsheetTableData(string spreadsheetModelId, string tableName, string rangeName = "", bool includeKnockoutState = false);
   }
}
