﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using com.rd.apid.Repository.Idbs.Model;
using com.rd.apid.Repository.Idbs.Model.Batch;
using com.rd.apid.Repository.Idbs.Serialization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Options;

namespace com.rd.apid.Repository.Idbs
{
   public class IdbsRepository : IIdbsRepository
   {
      private readonly HttpClient _client;
      private readonly IdbsRepositoryOptions _options;
      private readonly IdbsRepositoryContext _context;

      public IdbsRepository(HttpClient client, IOptions<IdbsRepositoryOptions> options, IdbsRepositoryContext context)
      {
         _client = client ?? throw new ArgumentNullException(nameof(client));
         _options = options?.Value ?? throw new ArgumentNullException(nameof(options));
         _context = context ?? throw new ArgumentNullException(nameof(context));
      }

      public async Task<FindByResult> FindExperimentEntitiesByExperimentIdAsync(
         string experimentId,
         string userName = "",
         bool includeAttributes = false,
         bool includeVersionInfo = false,
         bool includePath = false)
      {
         var content = new StringContent(
             JsonSerializer.Serialize(new
             {
                matches = new
                {
                   attribute = new
                   {
                      name = "Experiment ID",
                      value = experimentId
                   }
                },
                options = new
                {
                   entityType = "EXPERIMENT",
                   userName = userName.ToLower(),
                   includeAttributes = includeAttributes.ToString().ToLower(),
                   includeVersionInfo = includeVersionInfo.ToString().ToLower(),
                   includePath = includePath.ToString().ToLower()
                }
             }),
             Encoding.UTF8,
             "application/json");

         var httpResponseMessage = await _client.PostAsync("ewb/services/1.0/entities/findBy", content);
         httpResponseMessage.EnsureSuccessStatusCode();

         var jsonString = await httpResponseMessage.Content.ReadAsStringAsync();

         var findByResult = JsonSerializer.Deserialize<FindByResult>(jsonString, JsonSerializerOptionsProvider.Options);

         return findByResult;
      }

      public async Task<EntityExtended> GetEntityByEntityIdAsync(
         string entityId,
         string entityVersionId = null,
         bool? includeAttributes = null,
         bool? includeVersionInfo = null,
         bool? includePath = null,
         bool? includeChildren = null)
      {
         var queryParameters = new Dictionary<string, string>();
         if (entityVersionId != null) queryParameters.Add("entityVersionId", entityVersionId.ToLower());
         if (includeAttributes.HasValue) queryParameters.Add("includeAttributes", includeAttributes.Value.ToString().ToLower());
         if (includeVersionInfo.HasValue) queryParameters.Add("includeVersionInfo", includeVersionInfo.Value.ToString().ToLower());
         if (includePath.HasValue) queryParameters.Add("includePath", includePath.Value.ToString().ToLower());
         if (includeChildren.HasValue) queryParameters.Add("includeChildren", includeChildren.Value.ToString().ToLower());

         var queryString = new QueryBuilder(queryParameters).ToQueryString();

         var httpResponseMessage = await _client.GetAsync($"ewb/services/1.0/entities/{entityId}{queryString}");
         httpResponseMessage.EnsureSuccessStatusCode();

         var jsonString = await httpResponseMessage.Content.ReadAsStringAsync();

         var result = JsonSerializer.Deserialize<EntityExtended>(jsonString, JsonSerializerOptionsProvider.Options);
         return result;
      }

      public async Task<Attributes> GetEntityAttributesAsync(string entityId, string entityVersionId = null)
      {
         var queryParameters = new Dictionary<string, string>();
         if (entityVersionId != null) queryParameters.Add("entityVersionId", entityVersionId.ToLower());

         var queryString = new QueryBuilder(queryParameters).ToQueryString();

         var httpResponseMessage = await _client.GetAsync($"ewb/services/1.0/entities/{entityId}/attributes{queryString}");
         httpResponseMessage.EnsureSuccessStatusCode();

         var jsonString = await httpResponseMessage.Content.ReadAsStringAsync();

         var result = JsonSerializer.Deserialize<Attributes>(jsonString, JsonSerializerOptionsProvider.Options);
         return result;
      }

      public async Task<Versions> GetEntityVersionsAsync(string entityId)
      {
         var httpResponseMessage = await _client.GetAsync($"ewb/services/1.0/entities/{entityId}/versions");
         httpResponseMessage.EnsureSuccessStatusCode();

         var jsonString = await httpResponseMessage.Content.ReadAsStringAsync();

         var result = JsonSerializer.Deserialize<Versions>(jsonString, JsonSerializerOptionsProvider.Options);
         return result;
      }


      public async Task<string> LoadSpreadsheet(string spreadsheetVersionId)
      {
         bool editMode = false;

         var queryParameters = new Dictionary<string, string>
         {
            { "editMode", editMode.ToString().ToLower() },
            { "versionId", spreadsheetVersionId }
         };

         var queryString = new QueryBuilder(queryParameters).ToQueryString();

         string spreadsheetModelId = null;

         var httpResponseMessage = await _client.PutAsync($"ewb/services/1.0/spreadsheet{queryString}", new StringContent("", Encoding.UTF8, "application/json"));
         switch (httpResponseMessage.StatusCode)
         {
            case HttpStatusCode.Forbidden:
               var responseText = await httpResponseMessage.Content.ReadAsStringAsync();
               if (responseText == "Authorization failure: The spreadsheet model is already loaded.")
               {
                  spreadsheetModelId = $"API-{spreadsheetVersionId}";
               }
               break;
            default:
               httpResponseMessage.EnsureSuccessStatusCode();
               spreadsheetModelId = await httpResponseMessage.Content.ReadAsStringAsync();
               break;
         }

         return spreadsheetModelId;
      }

      public async Task UnLoadSpreadsheet(string spreadsheetModelId)
      {
         var queryParameters = new Dictionary<string, string>
         {
            { "modelId", spreadsheetModelId }
         };

         var queryString = new QueryBuilder(queryParameters).ToQueryString();

         var httpResponseMessage = await _client.DeleteAsync($"ewb/services/1.0/spreadsheet{queryString}");

         switch (httpResponseMessage.StatusCode)
         {
            case HttpStatusCode.NotFound:
               var responseText = await httpResponseMessage.Content.ReadAsStringAsync();
               if (responseText != "Resource not found for given ID: Spreadsheet is not loaded")
               {
                  httpResponseMessage.EnsureSuccessStatusCode();
               }
               break;

            default:
               httpResponseMessage.EnsureSuccessStatusCode();
               break;
         }
      }

      public async Task<IEnumerable<TableName>> GetSpreadsheetTables(string spreadsheetModelId)
      {
         var contentText = BatchRequestFactory.TableList();

         var content = new StringContent(contentText, Encoding.UTF8, "application/json");

         var queryParameters = new Dictionary<string, string>
         {
            { "modelId", spreadsheetModelId }
         };

         var queryString = new QueryBuilder(queryParameters).ToQueryString();

         var httpResponseMessage = await _client.PostAsync($"ewb/services/1.0/spreadsheet/data{queryString}", content);
         httpResponseMessage.EnsureSuccessStatusCode();

         var jsonString = await httpResponseMessage.Content.ReadAsStringAsync();

         var jsonDocument = JsonDocument.Parse(jsonString);

         var result = jsonDocument.RootElement.GetProperty("batch-response")
            .GetProperty("api-responses").EnumerateArray().ElementAt(0).GetProperty("tables").EnumerateArray().Select(x => new TableName
            {
               Name = x.GetProperty("name").GetString(),
            });

         //var result = JsonSerializer.Deserialize<MyRoot<TableName>>(jsonString, JsonSerializerOptionsProvider.Options);

         return result;
      }

      public async Task<IEnumerable<TableStructure>> GetSpreadsheetAllTableDimensions(string spreadsheetModelId, string tableName)
      {
         return await GetSpreadsheetAllTableDimensions(spreadsheetModelId, new string[] { tableName });
      }

      public async Task<IEnumerable<TableStructure>> GetSpreadsheetAllTableDimensions(string spreadsheetModelId, IEnumerable<string> tableNames)
      {
         var contentText = BatchRequestFactory.TableStructure(tableNames);

         var content = new StringContent(contentText, Encoding.UTF8, "application/json");

         var queryParameters = new Dictionary<string, string>
         {
            { "modelId", spreadsheetModelId }
         };

         var queryString = new QueryBuilder(queryParameters).ToQueryString();

         var httpResponseMessage = await _client.PostAsync($"ewb/services/1.0/spreadsheet/data{queryString}", content);
         httpResponseMessage.EnsureSuccessStatusCode();

         var jsonString = await httpResponseMessage.Content.ReadAsStringAsync();

         var jsonDocument = JsonDocument.Parse(jsonString);
         var result = jsonDocument.RootElement.GetProperty("batch-response").GetProperty("api-responses").EnumerateArray().ElementAt(0).GetProperty("tables").EnumerateObject()
            .Select(p => new TableStructure
            {
               TableName = p.Name,
               DataDimensionName = p.Value.GetProperty("dataDimensionName").GetString(),
               Dimensions = p.Value.GetProperty("dimensions").EnumerateArray().Select(o => new TableStructureDimension
               {
                  Name = o.GetProperty("name").GetString(),
                  ItemNames = o.GetProperty("itemNames").EnumerateArray().Select(i => i.GetString()).ToArray(),
               }).ToArray(),
            });

         return result;
      }

      public async Task<object> GetSpreadsheetTableData(string spreadsheetModelId, string tableName, string rangeName = "", bool includeKnockoutState = false)
      {
         var contentText = BatchRequestFactory.TableData(tableName, rangeName, includeKnockoutState);

         var content = new StringContent(contentText, Encoding.UTF8, "application/json");

         var queryParameters = new Dictionary<string, string>
         {
            { "modelId", spreadsheetModelId }
         };

         var queryString = new QueryBuilder(queryParameters).ToQueryString();

         var httpResponseMessage = await _client.PostAsync($"ewb/services/1.0/spreadsheet/data{queryString}", content);
         httpResponseMessage.EnsureSuccessStatusCode();

         var jsonString = await httpResponseMessage.Content.ReadAsStringAsync();

         var jsonDocument = JsonDocument.Parse(jsonString);

         var result2 = jsonDocument.RootElement.GetProperty("batch-response").GetProperty("api-responses").EnumerateArray().ElementAt(0).GetProperty("tables").EnumerateArray()
            .Select(t => new Table
            {
               Name = t.GetProperty("name").GetString(),
               Ranges = t.GetProperty("ranges").EnumerateArray().Select(r => new Range
               {
                  RangeName = r.GetProperty("range").GetString(),
                  Data = r.GetProperty("data").EnumerateArray().Select(x => x.EnumerateObject().Select(o =>
                     {
                        var property0 = o.Value.EnumerateObject().ElementAt(0);
                        object value = null;
                        if (property0.Value.ValueKind != JsonValueKind.Null)
                        {
                           switch (property0.Name)
                           {
                              case "string":
                              case "hyperlink":
                              case "error":
                                 value = property0.Value.GetString();
                                 break;
                              case "number":
                                 value = property0.Value.GetSingle();
                                 break;
                              case "datetime":
                                 value = property0.Value.GetDateTime();
                                 break;
                              default:
                                 throw new Exception($"Unhandled property name '{property0.Name}'");
                           }
                        }
                        return value;
                     }).ToArray()
                  ).ToArray(),
               }).ToArray(),
            }).ToArray();

         //var result = jsonDocument.RootElement.GetProperty("batch-response").GetProperty("api-responses").EnumerateArray().ElementAt(0).GetProperty("tables").EnumerateArray()
         //   .Select(t => new Table
         //   {
         //      Name = t.GetProperty("name").GetString(),
         //      Ranges = t.GetProperty("ranges").EnumerateArray().Select(r => new Range
         //      {
         //         RangeName = r.GetProperty("range").GetString(),
         //         Data = r.GetProperty("data").EnumerateArray().Select(x => new DataRow
         //         {
         //            Datum = x.EnumerateObject().Select(o =>
         //            {
         //               JsonProperty property0 = o.Value.EnumerateObject().ElementAt(0);

         //               DataType dataType = default(DataType);
         //               switch (property0.Name)
         //               {
         //                  case "number": dataType = DataType.Number; break;
         //                  case "string": dataType = DataType.String; break;
         //               };

         //               return new Datum
         //               {
         //                  Name = o.Name,
         //                  DataType = dataType,
         //                  StringValue = dataType == DataType.String ? property0.Value.GetString() : default(string),
         //                  NumberValue = dataType == DataType.Number ? property0.Value.GetSingle() : default(float),
         //               };

         //            }).ToArray()
         //         }).ToArray()
         //      }).ToArray(),
         //   });

         //return result;
         return result2;
      }
   }
}
