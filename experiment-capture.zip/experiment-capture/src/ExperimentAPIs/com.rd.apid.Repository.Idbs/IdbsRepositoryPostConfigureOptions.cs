﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace com.rd.apid.Repository.Idbs
{
   internal class IdbsRepositoryPostConfigureOptions : IPostConfigureOptions<IdbsRepositoryOptions>
   {
      private readonly IConfiguration _configuration;

      public IdbsRepositoryPostConfigureOptions(IConfiguration configuration)
      {
         _configuration = configuration;
      }

      public void PostConfigure(string name, IdbsRepositoryOptions options)
      {
         Initialize(options);

         if (string.IsNullOrEmpty(options.Username))
         {
            throw new InvalidOperationException("Username must be configured.");
         }

         if (string.IsNullOrEmpty(options.Password))
         {
            throw new InvalidOperationException("Password must be configured.");
         }

         if (!Uri.TryCreate(options.BaseAddress, UriKind.Absolute, out var _))
         {
            options.BaseAddress = "https://gskdev.idbs-eworkbook.com:8443/";
         }
      }

      private void Initialize(IdbsRepositoryOptions options)
      {
         //If there is no Username try to read values from Configuration
         if (string.IsNullOrEmpty(options.Username))
         {
            var newOptions = _configuration.GetSection(nameof(IdbsRepositoryOptions)).Get<IdbsRepositoryOptions>();
            options.Username = newOptions.Username;
            options.Password = newOptions.Password;
         }
      }
   }
}
