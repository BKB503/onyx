﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Contrib.WaitAndRetry;
using Polly.Extensions.Http;

namespace com.rd.apid.Repository.Idbs.DependencyInjection
{
   public static class IServiceCollectionExtensions
   {
      public static IServiceCollection AddIdbsRepository(this IServiceCollection services, Action<IdbsRepositoryOptions> configurationOptions = null)
      {
         services.AddOptions();

         if (configurationOptions != null)
         {
            services.Configure(configurationOptions);
         }

         services.TryAddSingleton<IdbsRepositoryContext>();

         services.AddHttpClient<IIdbsRepository, IdbsRepository>("IdbsRepository", (provider, client) =>
         {
            var options = provider.GetService<IOptions<IdbsRepositoryOptions>>().Value;

            client.BaseAddress = new Uri(options.BaseAddress);

            client.DefaultRequestHeaders.Accept.Clear();
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypeNames.Application.Json));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            string auth = $"{options.Username}:{options.Password}";
            var encodedAuth = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(auth));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", encodedAuth);
         })
         .AddPolicyHandler(GetRetryPolicy());

         services.TryAddEnumerable(ServiceDescriptor.Singleton<IPostConfigureOptions<IdbsRepositoryOptions>, IdbsRepositoryPostConfigureOptions>());

         return services;
      }

      private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
      {
         var delay = Backoff.DecorrelatedJitterBackoffV2(medianFirstRetryDelay: TimeSpan.FromSeconds(1), retryCount: 5);

         return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(delay);
      }

   }
}
